﻿define(function validationHelperModule(require) {

    var global = require('common/global');
    var ko = require('knockout');
    var resourcesManager = require('common/resourcesManager');
    var helper = require('common/helper');
    var form101Helper = require('views/forms/form101/form101Helper');

    //Add property hasValidationErrors to entity , that  will updated when validationErrorsChanged
    function addhasValidationErrorsProperty(entity) {

        var prop = ko.observable(false);

        var onChange = function () {
            var hasError = entity.entityAspect.getValidationErrors().length > 0;

            if (prop() == true && hasError == true) {
                prop(!hasError); // need to force the update message, because that the current error can be different from the previous error
            }
            prop(hasError); // change the value and notify
        };

        onChange();             // check now ...
        entity.entityAspect // ... and when errors collection changes
            .validationErrorsChanged.subscribe(onChange);

        // observable property is wired up; now add it to the entity
        entity.hasValidationErrors = prop;

        entity.hasValidationErrorsOnSave = ko.observable(false);

        entity.validateBeforeSubmit = function () {

            this.entityAspect.validateEntity();
            this.hasValidationErrorsOnSave(!this.hasValidationErrorsOnSave());
            this.hasValidationErrorsOnSave(this.entityAspect.hasValidationErrors);
        }

        entity.validateBeforeSubmitOnProperty = function (propNmae) {

            var isValid = this.entityAspect.validateProperty(propNmae);
            this.hasValidationErrorsOnSave(!this.hasValidationErrorsOnSave());
            this.hasValidationErrorsOnSave(this.entityAspect.hasValidationErrors);

            return isValid;
        }
    }

    function addhasValidationErrorsPropertySon(entity) {
        entity.hasValidationErrorsOnSave = ko.computed(function () {
            return entity.complexAspect.parent.hasValidationErrorsOnSave();
        });
    }

    var initializer = function entityInitializer(entity) {
        if (global.isNull(entity.complexAspect))
            addhasValidationErrorsProperty(entity);
        else
            addhasValidationErrorsPropertySon(entity);

        entity.getFirstValErrMsg = function (pname) {
            var errs = this.entityAspect.getValidationErrors(pname);
            return (errs.length) ? errs[0].errorMessage : "";
        };
        entity.getFirstValErrMsgToShow = function (pname) {
            return this.hasValidationErrorsOnSave() ?
                this.getFirstValErrMsg(pname) :
                '';
        };
        // extend its prototype with the helper method
        entity.getAllErrors = function () {
            var errs = this.entityAspect.getValidationErrors();
            return (errs.length) ? errs : null;
        };

        // extend its prototype with the helper method
        entity.getAllValErrMsg = function () {
            var errs = this.entityAspect.getValidationErrors();
            var msg = "";
            if (errs.length) {
                errs.each(function (item) {
                    msg += item.errorMessage;
                }
                    );
            }
            return msg;
        };
    }

    function createMessage(context) {
        var msg = '';
        var ids = context.resourceId.toString().split('/');
        if (context.messageByDictMsg == true)
            for (var i = 0; i < ids.length; i++) {
                msg = msg + ' ' + global.dictMsg()[ids[i]];
            }
        else
            for (var i = 0; i < ids.length; i++) {
                msg = msg + ' ' + global.dict()[ids[i]];
            }

        if (!global.isNull(context.supplementMessage))
            msg = msg + context.supplementMessage;
        if (!global.isNullOrEmpty(msg)) return msg;

        return "default field is not valid";
    }

    //createMessageFromDictByParams method
    //create validator's message by context params(resourceID + seconfFieldId + firstFieldId
    function createMessageFromDictByParams(context) {
        return helper.replaceDelimFromDict("{1}", helper.replaceDelimFromDict("{0}", resourcesManager.getMessageByKey(context.resourceId), resourcesManager.getValueByKey(context.firstResourceID)), resourcesManager.getValueByKey(context.secondResourceID))
    }

    //#region custom validators

    //Note: all line of breeze.Validator.registerFactory(xxx, "XXX"); have been removed cause in our app case there are not necessary
    //such as written in link http://stackoverflow.com/questions/23573139/why-is-my-required-validator-not-replacing-the-standard-breeze-required-valida
    //**************As far as I understand the breeze docs (see here) "registerFactory" is only necessary when you load previously exported data. It says:
    //**************We think it's a good practice to register your custom validators although you don't have to unless you'll be getting metadata from a serialized source other than the server.

    //requiredIf validator
    function requiredIfValidator(context) {
        return new breeze.Validator(
            "requiredIfValidator",  // validator name
            requiredIfFn, // validation function
            {                    // validator context
                messageTemplate: "'%requierdfieldName%' is requierd",
                //שם השדה עליו נבדוק אם הוא חובה לצורך תצוגה
                requierdfieldName: context.requierdfieldName,
                valueToCompare: context.valueToCompare,
                fieldName: context.fieldName,
                message: createMessage,
                resourceId: context.resourceId
            });

        function requiredIfFn(value, context) {
            var isValid = true;
            if (Array.isArray(context.valueToCompare)) {
                var isExists = false;
                for (var i = 0; i < context.valueToCompare.length; i++) {
                    if (context.entity.getProperty(context.fieldName) == context.valueToCompare[i]) {
                        isExists = true;
                        break;
                    }
                }
                if (isExists) {
                    isValid = !(value == null || value == "" || !value);
                }

            }
            else {
                var isValid = (!((context.entity.getProperty(context.fieldName) == context.valueToCompare)
                         &&
                         (value == null || value == "" || !value)));// add undefined
            }
            return isValid;
        };
    }

    function mustBeEmptyIfOtherFieldEmpty(context) {
        return new breeze.Validator(
             "mustBeEmptyIfOtherFieldEmpty",  // validator name
             mustBeEmptyIfOtherFieldEmptyFn, // validation function
             {                  // validator context               

                 otherFieldName: context.otherFieldName,
                 message: context.mustBeEmptyFieldTitle + " must not have value when " + context.otherFieldTitle + " doesn't have value"

             });

        function mustBeEmptyIfOtherFieldEmptyFn(value, context) {
            var isValid = true;
            if (global.isNullOrEmpty(context.entity.getProperty(context.otherFieldName))) {
                if (!global.isNullOrEmpty(value)) {
                    isValid = false;
                }
            }
            return isValid;
        };
    }

    //end Date greater than start date validator
    function endDatetimeGreaterThanStartDatetimeValidator(context) {
        return new breeze.Validator(
            "endDatetimeGreaterThanStartDatetimeValidator",  // validator name
            endDatetimeGreaterThanStartDatetimeValidatorFn, // validation function
            {                    // validator context
                startDateFieldName: context.startDateFieldName,
                startTimeFieldName: context.startTimeFieldName,
                endTimeFieldName: context.endTimeFieldName,
                message: createMessage,
                resourceId: context.resourceId
            });
    }

    function endDateLessThanToday(context) {

        return new breeze.Validator(
            "endDateLessThanToday",  // validator name
            endDateLessThanTodayFn, // validation function
            {                    // validator context
                message: createMessage,
                resourceId: context.resourceId,
                messageByDictMsg: context.messageByDictMsg
            });
    }

    function endDateLessThanTodayFn(value, context) {
        var _value;
        if (!(value instanceof Date))
            _value = Date.parse(value);
        else
            _value = value;
        if (_value >= new Date())
            return false;

        return true;
    };

    function endDatetimeGreaterThanStartDatetimeValidatorFn(value, context) {
        var isValid = true;

        var startDateString = context.entity.getProperty(context.startDateFieldName);
        var startTime = context.entity.getProperty(context.startTimeFieldName);
        if (global.isNullOrEmpty(startTime)) {
            startTime = "00:00";
        }
        var startTimeData = startTime.split(":");
        startTimeData[0] = startTimeData[0].length == 1 ? "0" + startTimeData[0] : startTimeData[0];
        startTimeData[1] = startTimeData[1].length == 1 ? "0" + startTimeData[1] : startTimeData[1];

        if (global.isNullOrEmpty(startDateString))
            return isValid;

        var startDate = Date.parse(startDateString.substring(0, 19));
        var startDateAndTime = new Date(startDate.getFullYear(), startDate.getMonth(), startDate.getDate(), startTimeData[0], startTimeData[1]);

        var endDateString = value;
        var endTime = context.entity.getProperty(context.endTimeFieldName);
        if (global.isNullOrEmpty(endTime)) {
            endTime = "23:59";
        }
        var endTimeData = endTime.split(":");
        endTimeData[0] = endTimeData[0].length == 1 ? "0" + endTimeData[0] : endTimeData[0];
        endTimeData[1] = endTimeData[1].length == 1 ? "0" + endTimeData[1] : endTimeData[1];

        if (global.isNullOrEmpty(endDateString))
            return isValid;

        var endDate = Date.parse(endDateString.substring(0, 19));
        var endDateAndTime = new Date(endDate.getFullYear(), endDate.getMonth(), endDate.getDate(), endTimeData[0], endTimeData[1])
        if (endDateAndTime > startDateAndTime) {
            isValid = true;
        }
        else {
            isValid = false;
        }
        return isValid;
    };

    function endDateGreaterThanStartDateValidator(context) {

        return new breeze.Validator(
            "endDateGreaterThanStartDateValidator",  // validator name
            endDateGreaterThanStartDateValidatorFn, // validation function
            {                    // validator context
                startDateFieldName: context.startDateFieldName,
                message: global.isNull(context.message) ? createMessage : context.message,
                resourceId: global.isNull(context.resourceId) ? '1732' : context.resourceId,
                complexTypeName: context.complexTypeName
            });
    }

    function endDateGreaterThanStartDateValidatorFn(value, context) {
        var isValid = true;
        if (!global.isNull(context.complexTypeName)) {
            context.entity = context.entity.getProperty(context.complexTypeName);
        }
        var startDate = context.entity.getProperty(context.startDateFieldName);
        if (!(startDate instanceof Date))
            startDate = Date.parse(startDate);
        var endDate = value;
        if (!(endDate instanceof Date))
            endDate = Date.parse(endDate);
        if (endDate > startDate || endDate == null || startDate == null) {
            isValid = true;
        }
        else {
            isValid = false;
        }
        return isValid;
    };

    function startDateSmallerThanEndDateValidator(context) {

        return new breeze.Validator(
            "startDateSmallerThanEndDateValidator",  // validator name
            startDateSmallerThanEndDateValidatorFn, // validation function
            {                    // validator context
                endDateFieldName: context.endDateFieldName,
                message: global.isNull(context.message) ? createMessage : context.message, 
                resourceId: global.isNull(context.resourceId) ? '1085' : context.resourceId
            });
    }

    function startDateSmallerThanEndDateValidatorFn(value, context) {
        var isValid = true;
        var endDate = context.entity.getProperty(context.endDateFieldName);//saved in string
        if (!global.isNullOrEmpty(endDate)) {
            if (endDate instanceof Date)
                endDate = endDate.clearTime();
            else
                endDate = (Date.parse(endDate.substring(0, 19))).clearTime();
        }

        var startDate;
        if (global.isNullOrEmpty(value))
            startDate = null;
        else {
            if (value instanceof Date)
                startDate = value.clearTime();
            else
                startDate = (Date.parse(value.substring(0, 19))).clearTime();
        }

        if (endDate >= startDate || endDate == null || startDate == null) {
            isValid = true;
        }
        else {
            isValid = false;
        }
        return isValid;
    };

    function complexTypeEndDateGreaterThanStartDateValidator(context) {
        return new breeze.Validator(
           "complexTypeEndDateGreaterThanStartDateValidator",  // validator name
           complexTypeEndDateGreaterThanStartDateValidatorFn, // validation function
           {                    // validator context
               entityName: context.entityName,
               entityNameSub: context.entityNameSub,
               startDateFieldName: context.startDateFieldName,
               startTimeFieldName: context.startTimeFieldName,
               endTimeFieldName: context.endTimeFieldName,
               message: createMessage,
               resourceId: context.resourceId
           });
        function complexTypeEndDateGreaterThanStartDateValidatorFn(value, context) {
            if (!global.isNull(context.entityNameSub))
                context.entity = context.entity.getProperty(context.entityName).getProperty(context.entityNameSub);
            else
                context.entity = context.entity.getProperty(context.entityName);
            return endDateGreaterThanStartDateValidatorFn(value, context);
        }
    }

    function complexTypeStartDateSmallerThanEndDateValidator(context) {
        return new breeze.Validator(
           "complexTypeStartDateSmallerThanEndDateValidator",  // validator name
           complexTypeStartDateSmallerThanEndDateValidator, // validation function
           {                    // validator context
               entityName: context.entityName,
               entityNameSub: context.entityNameSub,
               startTimeFieldName: context.startTimeFieldName,
               endDateFieldName: context.endDateFieldName,
               endTimeFieldName: context.endTimeFieldName,
               message: createMessage,
               resourceId: context.resourceId,
               messageByDictMsg: context.messageByDictMsg
           });
        function complexTypeStartDateSmallerThanEndDateValidator(value, context) {
            if (!global.isNull(context.entityNameSub))
                context.entity = context.entity.getProperty(context.entityName).getProperty(context.entityNameSub);
            else
                context.entity = context.entity.getProperty(context.entityName);
            return startDateSmallerThanEndDateValidatorFn(value, context);
        }
    }

    //equal fields validator
    function equalFieldsValidator(context) {

        return new breeze.Validator(
            "equalFieldsValidator",  // validator name
            equalFieldsFn, // validation function
            {                    // validator context
                fieldNameToCompare: context.fieldNameToCompare,
                message: createMessage,
                resourceId: context.resourceId
            });

        function equalFieldsFn(value, context) {

            if (value == null || value == "" || value == undefined)
                return true;
            return (context.entity.getProperty(context.fieldNameToCompare) == value);
        }
    }

    //email validator
    function emailValidator(context) {

        return new breeze.Validator(
            "emailValidator",  // validator name
            emailValidatorFn, // validation function
            {                    // validator context
                message: createMessage,
                resourceId: context.resourceId
            });

        function emailValidatorFn(value, context) {
            return helper.isValidEmail(value);
        }
    }

    // phoneValidator
    function phoneValidator(context) {
        context.message = global.dictMsg()[463];
        return new breeze.Validator(
            "phoneValidator",  // validator name
            phoneValidatorFn, // validation function
            context
           );
    }

    function phoneValidatorFn(value, context) {
        if (global.isNullOrEmpty(value)) {
            return true;
        }
        var re = /[0-9\-\(\)\s]+/; // e.g.+972-5444444
        return re.test(value);
    }


    //searchBy: context.searchBy,
    /*
    function empIdValidator(context) {

        return new breeze.Validator(
            "empIdValidator",  // validator name
            empIdValidatorFn, // validation function
            {                   // validator context                    
                searchBy: context.searchBy,
                message: createMessage,
                resourceId: context.resourceId
            });

        function empIdValidatorFn(value, context) {
            if (value == null || value == "" || value == undefined)
                return true;
            if (context.entity.searchBy() == "byNo") {
                if (value == -99999) {//external login by backOffice
                    return true;
                }
                context.allowStartByZero = false;
                return numericValidatorFn(value, context);
            }
            return true;
        };
    }



    */
    function contactNumberValidator(context) {
        return new breeze.Validator(
            "contactNumberValidator",  // validator name
            contactNumberValidatorFn, // validation function
            {                   // validator context                    
                sendByMailOrSMS: context.sendByMailOrSMS,
                resourceId: context.resourceId
            });

        function contactNumberValidatorFn(value, context) {
            if (global.isNullOrEmpty(value)) {
                return true;
            }
            if (context.entity.sendByMailOrSMS() == "0") { //-- sms
                var re = /[0-9\-\(\)\s]+/;
                context.message = global.dict()[5053];
                return re.test(value);
            }
            else { //--email, sendByMailOrSMS=1 
                context.message = global.dictMsg()[463];
                return helper.isValidEmail(value)
            }
        }
    }
    function numericRangeValidator(context) {

        return new breeze.Validator(
            "numericRangeValidator",  // validator name
            numericRangeValidatorFn, // validation function
            {                    // validator context
                message: createMessage,
                resourceId: context.resourceIdForOverMax,//by default => max
                supplementMessage: ': ' + context.maxVal,//by default => max
                resourceIdForOverMax: context.resourceIdForOverMax,
                resourceIdForLessThanMin: context.resourceIdForLessThanMin,
                maxVal: context.maxVal,
                minVal: context.minVal

            });
    }

    function numericRangeValidatorFn(value, context) {
        if (!global.isNullOrEmpty(context.maxVal) && value > context.maxVal) {
            context.resourceId = context.resourceIdForOverMax;
            context.supplementMessage = ': ' + context.maxVal
            return false;
        }
        if (!global.isNullOrEmpty(context.minVal) && value < context.minVal) {
            context.resourceId = context.resourceIdForLessThanMin;
            context.supplementMessage = ': ' + context.minVal
            return false;
        }
        return true;

    }

    //integer validator
    function integerValidator(context) {

        return new breeze.Validator(
            "integerValidator",  // validator name
            integerValidatorFn, // validation function
            {                    // validator context
                message: createMessage,
                resourceId: context.resourceId
            });

        function integerValidatorFn(value, context) {
            return (breeze.Validator.integer().validate(value, context) == null);
        }
    }

    //empId validator
    function empIdValidator(context) {

        return new breeze.Validator(
            "empIdValidator",  // validator name
            empIdValidatorFn, // validation function
            {                   // validator context                    
                searchBy: context.searchBy,
                message: createMessage,
                resourceId: context.resourceId
            });

        function empIdValidatorFn(value, context) {
            if (value == null || value == "" || value == undefined)
                return true;
            if (context.entity.searchBy() == "byNo") {
                if (value == -99999) {//external login by backOffice
                    return true;
                }
                context.allowStartByZero = false;
                return numericValidatorFn(value, context);
            }
            return true;
        };
    }

    function numeric(context) {

        return new breeze.Validator(
            "numeric",  // validator name
            numericValidatorFn, // validation function
            {
                message: "numeric field",
                allowStartByZero: !global.isNull(context) && !global.isNull(context.allowStartByZero) ? context.allowStartByZero : false
            });  // validator context  
    }

    function numericValidatorFn(value, context) {
        if (value == null || value == "" || value == undefined)
            return true;
        valueString = value.toString();
        if (context.allowStartByZero != true) {
            if (valueString.substring(0, 1) == '0' && valueString.length > 1) {
                return false;
            }
        }
        for (var i = 0; i < valueString.length; i++) {
            if (valueString.substring(i, i + 1) > '9' || valueString.substring(i, i + 1) < '0')
                return false;
        }
        return true;
    };

    function numericOrSpaces(context) {

        return new breeze.Validator(
            "numeric",  // validator name
            numericOrSpacesFn, // validation function
            {
                message: "numeric field",
                allowStartByZero: !global.isNull(context) && !global.isNull(context.allowStartByZero) ? context.allowStartByZero : false
            });  // validator context  
    }

    function numericOrSpacesFn(value, context) {
        if (value == null || value == "" || value == undefined)
            return true;
        valueString = value.toString();
        if (context.allowStartByZero != true) {
            if (valueString.substring(0, 1) == '0') {
                return false;
            }
        }
        for (var i = 0; i < valueString.length; i++) {
            if ((valueString.substring(i, i + 1) > '9' || valueString.substring(i, i + 1) < '0') && valueString.substring(i, i + 1) != ' ')
                return false;
        }
        return true;
    };

    function decimalNumeric(context) {

        return new breeze.Validator(
            "numeric",  // validator name
            decimalNumericFn, // validation function
            {
                message: "numeric field"
            });  // validator context              

        function decimalNumericFn(value, context) {
            if (value == null || value == "" || value == undefined)
                return true;
            valueString = value.toString();
            for (var i = 0; i < valueString.length; i++) {
                var valueChar = valueString.substring(i, i + 1);
                if ((valueChar > '9' || valueChar < '0') && valueChar != '.')
                    return false;
            }
            return true;
        };
    }

    function requiredAndNotZeroTime(context) {
        return new breeze.Validator(
          "requiredAndNotZeroTime",  // validator name
          requiredAndNotZeroTimeFn, // validation function
          {
              message: createMessage,
              resourceId: context.resourceId,
              conditionFieldName: context.conditionFieldName,
              conditionType: context.conditionType
          });
    }

    function requiredAndNotZeroTimeFn(value, context) {
        if (global.isNull(context.conditionType) ||
           checkNeedValidate(context.entity, context.conditionFieldName, context.conditionType)) {
            if (global.isNullOrEmpty(value) || value == '00:00')
                return false;
        }

        return true;
    }

    function startTimeLessThenEndTimeWhenStartDateEqualToEndDate(context) {
        return new breeze.Validator(
         "startTimeLessThenEndTimeWhenStartDateEqualToEndDate",  // validator name
         startTimeLessThenEndTimeWhenStartDateEqualToEndDateFn, // validation function
         {
             endTimeName: context.endTimeName,
             startDateName: context.startDateName,
             endDateName: context.endDateName,
             message: createMessage,
             resourceId: 1085
         });
        function startTimeLessThenEndTimeWhenStartDateEqualToEndDateFn(value, context) {
            var startDateProp = context.entity.getProperty(context.startDateName);
            var endDateProp = context.entity.getProperty(context.endDateName);

            if (global.isNullOrEmpty(startDateProp) || global.isNullOrEmpty(endDateProp) || startDateProp != endDateProp) {
                return true;
            }

            var endTimeProp = context.entity.getProperty(context.endTimeName);
            if (global.isNullOrEmpty(endTimeProp) || global.isNullOrEmpty(value)) {
                return true;
            }

            var startTimeAsArray = value.split(':');
            var endTimeAsArray = endTimeProp.split(':');
            startTimeAsArray[0] = parseInt(startTimeAsArray[0]);
            startTimeAsArray[1] = parseInt(startTimeAsArray[1]);
            endTimeAsArray[0] = parseInt(endTimeAsArray[0]);
            endTimeAsArray[1] = parseInt(endTimeAsArray[1]);
            var mm;
            var hh;
            //condition summery: if (endTime < startTime)
            if (endTimeAsArray[0] < startTimeAsArray[0] || endTimeAsArray[0] == startTimeAsArray[0] && endTimeAsArray[1] < startTimeAsArray[1]) {
                return false;
            }
            return true;
        }
    }

    function requiredIfCompanyPreferance(context) {
        return new breeze.Validator(
         "requiredIfCompanyPreferance",  // validator name
         requiredIfCompanyPreferanceFn, // validation function
         {
             message: createMessage,
             resourceId: '517',
             preferance: context.preferance,
             permission: context.permission
         });
        function requiredIfCompanyPreferanceFn(value, context) {

            if (global.isNull(context.permission) || global.permissions.isVisible(context.permission)) {

                if (checkCompanyPreferenceIsTrue(context.preferance)) {
                    if (global.isNullOrEmpty(value)) {
                        return false;
                    }
                    return true;
                }
            }
            return true;
        }
    }

    function checkCompanyPreferenceIsTrue(preference) {
        return global.cache.getCompanyPreferenceByName(preference) == "1"
    }

    function requiredIfCompanyParam(context) {
    	return new breeze.Validator(
         "requiredIfCompanyParam",  // validator name
         requiredIfCompanyParamFn, // validation function
         {
         	message: createMessage,
         	resourceId: '517',
         	param: context.param,
         	permission: context.permission
         });
    	function requiredIfCompanyParamFn(value, context) {

    		if (global.isNull(context.permission) || global.permissions.isVisible(context.permission)) {

    			if (checkCompanyParamIsTrue(context.param)) {
    				if (global.isNullOrEmpty(value)) {
    					return false;
    				}
    				return true;
    			}
    		}
    		return true;
    	}
    }

    function checkCompanyParamIsTrue(param) {
    	return global.cache.getCompanyParamByFieldName(param.name) == "1";
    }

    function validateSingleField(object, fieldName) {
        var aspect = object.entityAspect || object.complexAspect;
        var entityAspect = object.entityAspect || object.complexAspect.getEntityAspect();
        var objectType = object.entityType || object.complexType;
        var prop = objectType.getProperty(fieldName);

        var value = object.getProperty(fieldName);
        if (prop.validators.length > 0) {
            var context = { entity: entityAspect.entity, property: prop, propertyName: fieldName };
            if (entityAspect._validateProperty(value, context)) {
                return true;
            }
            return false;
        }
        return true;
    }

    function validateComplexType(object, fieldName) {
        var complexObject = object[fieldName]();
        var complexType = complexObject.complexType;
        var isOk = true;
        complexType.getProperties().forEach(function (p) {
            isOk = validateSingleField(complexObject, p.name) && isOk;
            if (!isOk) return isOk;
        });
        return isOk;
    }

    function requiredValidator(context) {
        return new breeze.Validator(
        "requiredValidator",  // validator name
        requiredValidatorFn, // validation function
        {
            message: global.isNull(context.message) ? createMessage : context.message,
            fieldName: context.fieldName,
            resourceId: global.isNull(context.resourceId) ? '517' : context.resourceId,
            conditionFieldName: context.conditionFieldName,
            conditionFieldComplexType: context.conditionFieldComplexType,
            conditionType: context.conditionType,
            conditionVal: context.conditionVal,
            conditions: context.conditions,
            multipleType: context.multipleType
        });
    }

    function requiredValidatorFn(value, context) {
        var needValidate;
        if (!global.isNull(context.conditions)) {//multiple conditions
            if (context.multipleType == 'and') {
                needValidate = true;
            }
            $.each(context.conditions, function (index, condition) {
                var currentEntity = global.isNull(condition.conditionFieldComplexType) ? context.entity : context.entity.getProperty(condition.conditionFieldComplexType);
                if (context.multipleType == 'and') {
                    needValidate = needValidate && checkNeedValidate(currentEntity, condition.conditionFieldName, condition.conditionType, condition.conditionVal);
                    if (!needValidate) {
                        return false;//break loop, becouse multipleType = and
                    }
                }
                else {
                    needValidate = needValidate || checkNeedValidate(currentEntity, condition.conditionFieldName, condition.conditionType, condition.conditionVal);
                }
            });
        }
        else {//only one condition
            context.entity = global.isNull(context.conditionFieldComplexType) ? context.entity : context.entity.getProperty(context.conditionFieldComplexType);
            if (global.isNull(context.conditionType) ||
                checkNeedValidate(context.entity, context.conditionFieldName, context.conditionType, context.conditionVal)) {
                needValidate = true;
            }
        }

        if (needValidate) {
            var tabPermission = getFieldAtSameComplexType(context, 'TabPermission');
            if (tabPermission) {
                if (!global.permissions.isVisible(tabPermission())) {
                    return true;//parent is not visible - not check validation of required field!
                }
            }
            if (!global.isNull(context.fieldName)) {
                value = value[context.fieldName]();
            }          
            if (global.isNullOrEmptyOrSpacesOnly(value)) {
                return false;
            }
        }
        return true;

    }

    function greaterThenEqualTo(context) {
        return new breeze.Validator(
       "greaterThenEqualTo",  // validator name
       greaterThenEqualToFn, // validation function
       {
           message: createMessageFromDictByParams,
           resourceId: '351',
           secondFieldName: context.secondFieldName,
           firstResourceID: context.firstResourceID,
           secondResourceID: context.secondResourceID
       });
    }

    function greaterThenEqualToFn(value, context) {
        var firstValue = context.entity.getProperty(context.secondFieldName);
        if (global.isNullOrEmpty(firstValue) || global.isNullOrEmpty(value)){// || parseInt(firstValue) <= parseInt(value)) {
            return true;
        }
        if (!(/^[0-9]+$/.test(firstValue)) || !(/^[0-9]+$/.test(value)))//strings contains chars&digits
            return firstValue <= value;
        else //strings contains only digits
            return parseInt(firstValue) <= parseInt(value);        
        return false;
    }

    function isIn(context) {
        return new breeze.Validator(
     "isIn",  // validator name
     isInFn, // validation function
     context
          );
    }

    function isInFn(value, context) {
        return context.array.indexOf(value) > -1 ? true : false;
    }

    function checkFileValidInComplexType(context) {
        return new breeze.Validator(
     "checkFileValidInComplexType",  // validator name
     checkFileValidInComplexTypeFn, // validation function
     context
          );
    }

    function checkFileValidInComplexTypeFn(complexType, context) {
        var fileValidMessageEnum = global.enums.fileValidMessage;
        var value = complexType[context.fieldName]();
        var intValue = parseInt(value);
        switch (intValue) {
            case fileValidMessageEnum.invalidType:
                context.message = global.resMsg[363];
                return false;
            case fileValidMessageEnum.invalidSize:
                context.message = global.resMsg[494];
                return false;
            default: return true;
        }
    }

    function mustBeIfOtherField(context) {
        return new breeze.Validator(
       "mustBeIfOtherField",  // validator name
       mustBeIfOtherFieldFn, // validation function
       context
            );
    }

    function mustBeIfOtherFieldFn(value, context) {
        var needValidate;
        if (!global.isNull(context.conditions)) {//multiple conditions
            if (context.multipleType == 'and') {
                needValidate = true;
            }
            $.each(context.conditions, function (index, condition) {
                var currentEntity = global.isNull(condition.conditionFieldComplexType) ? context.entity : context.entity.getProperty(condition.conditionFieldComplexType);
                if (context.multipleType == 'and') {
                    needValidate = needValidate && checkNeedValidate(currentEntity, condition.conditionFieldName, condition.conditionType, condition.conditionVal);
                    if (!needValidate) {
                        return false;//break loop, becouse multipleType = and
                    }
                }
                else {
                    needValidate = needValidate || checkNeedValidate(currentEntity, condition.conditionFieldName, condition.conditionType, condition.conditionVal);
                }
            });
        }
        else {
            var currentEntity = global.isNull(context.conditionFieldComplexType) ? context.entity : context.entity.getProperty(context.conditionFieldComplexType);

            if (checkNeedValidate(currentEntity, context.conditionFieldName, context.conditionType)) {
                needValidate = true;
            }
        }

        if (needValidate) {
            return checkValidate(value, context.validateType);
        }
        return true;
    }

    function checkNeedValidate(entity, fieldName, conditionType, conditionVal) {
        var value;
        if (fieldName) {//some time field name is not relevant and not accepted as param, like: companyPreferance condition
            value = entity.getProperty(fieldName);
        }
        return checkValidate(value, conditionType, conditionVal);
    }

    function checkValidate(value, conditionType, conditionVal) {
        switch (conditionType) {
            case global.enums.conditionsTypes.full:
                return !global.isNullOrEmpty(value);
            case global.enums.conditionsTypes.empty:
                return global.isNullOrEmpty(value);
            case global.enums.conditionsTypes.trueVal:
                return value == true;
            case global.enums.conditionsTypes.falseVal:
                return value == false;
            case global.enums.conditionsTypes.fullAndNotZeroTime:
                return !global.isNullOrEmpty(value) && value != global.consts.zeroTime;
            case global.enums.conditionsTypes.equalToVal:
                return value == conditionVal;
            case global.enums.conditionsTypes.notEqualToVal:
                return value != conditionVal;
            case global.enums.conditionsTypes.companyPreference:
            	return checkCompanyPreferenceIsTrue(conditionVal);
        	case global.enums.conditionsTypes.companyParam:
        		return checkCompanyParamIsTrue(conditionVal);
            default:
                throw Error('conditionType is not valid condition type');;
        }
    }

    function idValidation(context) {
        return new breeze.Validator(
      "idValidation",  // validator name
      idValidationFn, // validation function
      {
          message: global.isNull(context.resourceId) ? context.message : createMessageFromDictByParams,
          resourceId: context.resourceId,
          conditionFieldName: context.conditionFieldName,
          conditionFieldComplexType: context.conditionFieldComplexType,
          conditionType: context.conditionType,
          conditionVal: context.conditionVal,
          conditions: context.conditions
      }
           );
    }

    function idValidationFn(IDnum, context) {
        if (global.isNullOrEmpty(IDnum)) {
            return true;
        }
        // TZ || Passport_ID (Darkon) validation
        if (context.entity.entityAspect.entity.Unit_B()) {
            var thisEntityB = context.entity.entityAspect.entity.Unit_B();
        
            if (!global.isNullOrEmpty(context.conditionFieldName) && !global.isNullOrEmpty(context.conditionType))
                if (context.conditionFieldName == "rdbPassportType" && context.conditionVal != thisEntityB.rdbPassportType())
                {
                  //  needValidate = checkNeedValidate(context.entity.entityAspect.entity.Unit_B(), context.conditionFieldName, context.conditionType, context.conditionVal)
                    return true; //don't continue validate if not TeudatZehut (e.g. Darkon)
                }
        }

        var mone = 0, incNum;
        for (var i = 0; i < 9; i++) {
            incNum = Number(IDnum.charAt(i));
            incNum *= (i % 2) + 1;
            if (incNum > 9)
                incNum -= 9;
            mone += incNum;
        }
        if (mone % 10 == 0)
            return true;
        else
            return false;
    }

    function validMail(context) {
        context.message = global.dictMsg()[463];
        return new breeze.Validator(
      "validMail",  // validator name
      validMailFn, // validation function
     context
           );
    }

    function validMailFn(value, context) {
        if (global.isNullOrEmpty(value)) {
            return true;
        }
        var re = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;

        return re.test(value);
    }

    function validURL(context) {
        return new breeze.Validator(
      "validURL",  // validator name
      validURLFn, // validation function
     {
         message: global.resMsg[354],
     });
    }

    function validURLFn(value, context) {
        if (global.isNullOrEmpty(value)) {
            return true;
        }
        // var re = /^(http(s)?:\/\/)?(www\.)?[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$/;--url can be onlt www.blabla
        var re = /^(http|https|ftp)?:\/\/[a-zA-Z0-9-\.]+\.[a-z]{2,4}/;//must enter http/https/ftp
        context.message = helper.replaceDelimFromDict("{0}", context.message, context.entity[context.property.name]());
        return re.test(value);
    }

    function minLength(context) {
        return new breeze.Validator(
      "minLength",  // validator name
      minLengthFn, // validation function
      {
          message: global.isNull(context.resourceId) ? context.message : createMessageFromDictByParams,
          resourceId: context.resourceId,
          minLength: context.minLength
      }
           );
    }

    function minLengthFn(value, context) {
        if (global.isNullOrEmpty(value)) {
            return true;
        }
        if (value.toString().length < context.minLength) {
            return false;
        }
        return true;
    }

    function requireFieldInComplexType(context) {
        return new breeze.Validator(
      "requireFieldInComplexType",  // validator name
      requireFieldInComplexTypeFn, // validation function
      {
          fieldName: context.fieldName,
          message: global.isNull(context.message) ? createMessage : context.message,
          resourceId: global.isNull(context.resourceId) ? '517' : context.resourceId,
          conditionFieldName: context.conditionFieldName,
          conditionFieldComplexType: context.conditionFieldComplexType,
          conditionType: context.conditionType,
          conditionVal: context.conditionVal,
          conditions: context.conditions,
          multipleType: context.multipleType
      }
           );
    }

    function requireFieldInComplexTypeFn(value, context) {
        return requiredValidatorFn(value[context.fieldName](), context);
    }

    function isDate() {
        return new breeze.Validator(
      "isDate",  // validator name
      isDateFn, // validation function
      {
          message: global.resMsg[350],
      }
    );
    }

    function isDateFn(value, context) {
        context.message = helper.replaceDelimFromDict("{0}", context.message, context.property.name);
        if ((!global.isNullOrEmpty(value) && !global.isNullOrEmpty(Date.parse(value))) || global.isNullOrEmpty(value))
            return true;

        return false;
    };

    function isExistKey(context) {
        return new breeze.Validator(
            "isExistKey",  // validator name
            isExistKeyFn, // validation function
            {
                xmlRoot: context.xmlRoot,
                table: context.table
            }
          );
    }

    function isExistKeyFn(value, context) {
        if (global.isNullOrEmpty(value)) return true; // prevent check exist ProfileNo for empty Val
        if (context.entity.entityAspect.originalValues.hasOwnProperty(context.propertyName) || context.entity.entityAspect.entityState.isAdded()) {//if key has been change. prevent check exist for old key - becouse it always exist...

            var xmlObject = {};
            xmlObject[context.xmlRoot] = value;
            var query = {
                TableName: context.table,
                KeysXML: json2xml.convert(xmlObject, 'Root')
            }
            var result = $.ajax({
                url: global.webApiConfig.getApiPath(global.enums.httpPath.CheckKeyValInTable.path),
                data: query,
                type: 'POST',
                cache: false,
                async: false
            });
            var message = JSON.parse(result.responseText).Message;
            if (!global.isNullOrEmpty(message)) {
                context.message = message;
                return false;
            }
        }
        return true;
    }

    function getFieldAtSameComplexType(context, fieldName) {
        var pathAsList = context.propertyName.split('.');
        pathAsList.pop();//remove last part- it is the senderField.
        var entity = context.entity;
        while (entity.complexAspect) {
            entity = entity.complexAspect.parent;
        }
        while (pathAsList.length > 0) {
            entity = entity[pathAsList[0]]();
            pathAsList.shift();
        }
        return entity[fieldName];
    }

    function bankAccountValidation(context) {
        return new breeze.Validator(
      "bankAccountValidation",  // validator name
      bankAccountValidationFn, // validation function
      {
          message: global.resMsg[520],
          bankFieldName: context.bankFieldName,
          branchFieldName: context.branchFieldName,
          conditionFieldComplexType: context.conditionFieldComplexType
      });
    }

    function bankAccountValidationFn(account, context) {
        var currentEntity = global.isNull(context.conditionFieldComplexType) ? context.entity : context.entity.getProperty(context.conditionFieldComplexType);
        var result = form101Helper.bankAccountValidation(currentEntity[context.bankFieldName](), currentEntity[context.branchFieldName](), account);

        switch (result)
        {
            case -1:    //invalid account
                context.message = global.resMsg[520];
                return false;
            case 0: //valid
                return true;
            case 1: //invalid empty bank
                context.message = global.resMsg[518];
                return false;
            case 2: //invalid empty branch
                context.message = global.resMsg[519];
                return false;
            case 3: //invalid empty account
                context.message = global.res[517];
                return false;
            case 4: //invalid length  of account
                context.message = helper.replaceDelimFromDict("{0}", global.resMsg[523], form101Helper.bankValidAccountLength(currentEntity[context.bankFieldName]()));
                break;
        }
    }
    //#endregion

    var validationHelper = {
        mustBeEmptyIfOtherFieldEmpty: mustBeEmptyIfOtherFieldEmpty,
        initializer: initializer,
        requiredIfValidator: requiredIfValidator,
        equalFieldsValidator: equalFieldsValidator,
        emailValidator: emailValidator,
        phoneValidator: phoneValidator,
        contactNumberValidator:contactNumberValidator,
        integerValidator: integerValidator,
        endDatetimeGreaterThanStartDatetimeValidator: endDatetimeGreaterThanStartDatetimeValidator,
        endDateGreaterThanStartDateValidator: endDateGreaterThanStartDateValidator,
        startDateSmallerThanEndDateValidator: startDateSmallerThanEndDateValidator,
        startTimeLessThenEndTimeWhenStartDateEqualToEndDate: startTimeLessThenEndTimeWhenStartDateEqualToEndDate,
        complexTypeEndDateGreaterThanStartDateValidator: complexTypeEndDateGreaterThanStartDateValidator,
        complexTypeStartDateSmallerThanEndDateValidator: complexTypeStartDateSmallerThanEndDateValidator,
        requiredAndNotZeroTime: requiredAndNotZeroTime,
        numericRangeValidator: numericRangeValidator,
        endDateLessThanToday: endDateLessThanToday,
        numeric: numeric,
        numericOrSpaces: numericOrSpaces,
        validateSingleField: validateSingleField,
        validateComplexType: validateComplexType,
        decimalNumeric: decimalNumeric,
        requiredIfCompanyPreferance: requiredIfCompanyPreferance,
        requiredIfCompanyParam: requiredIfCompanyParam,
        empIdValidator: empIdValidator,
        requiredValidator: requiredValidator,
        greaterThenEqualTo: greaterThenEqualTo,
        mustBeIfOtherField: mustBeIfOtherField,
        idValidation: idValidation,
        validMail: validMail,
        validURL: validURL,
        minLength: minLength,
        requireFieldInComplexType: requireFieldInComplexType,
        isIn: isIn,
        checkFileValidInComplexType: checkFileValidInComplexType,
        isDate: isDate,
        isExistKey: isExistKey,
        bankAccountValidation: bankAccountValidation
    };

    return validationHelper;
});