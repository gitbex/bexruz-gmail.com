﻿define(function datePickerControl(require) {

    var global = require('common/global');

    function vm() {
        var breezeModel;
        var breezePropery;
        var isNullVal = false;
        var old = null;
        var prevent = false;
        var valueAsDate = ko.observable();
        var obj = {                 
            controlType:global.enums.controlType.datePicker,
            format: global.cache.get(global.enums.cacheItems.DATE_FORMAT),
            datePickerId: ko.observable("defaultDatePicker"),
            minDate: ko.observable(),
            maxDate: ko.observable(new Date(new Date().getFullYear() + 200, 1, 1)),
            disableDates: ko.observable([]),
            isReadOnly: ko.observable(false),
            value: ko.computed({
                read: function readValue() {
                    try {
                        if (!global.isNull(valueAsDate())) 
                                return valueAsDate().clearTime().toString(global.consts.dateTimeFormatYMDTHMS);
                        else
                            return null;
                    }
                    catch (err) {
                        global.treatError(err);
                    }
                },
                write: function writeValueAsDate(newValue) {

                    try {
                        if (!global.isNull(newValue)) {
                            if (newValue instanceof Date)
                                valueAsDate(newValue);
                            else
                                valueAsDate(Date.parse(newValue.substring(0, 19)));
                        }
                        else valueAsDate(null);
                    }
                    catch (err) {
                        global.treatError(err);
                    }
                }
            }),
            valueAsDate: valueAsDate,
            content:
                '# if ($.inArray(+data.date, data.dates) != -1) { #' +

                             '<div class="k-state-disabled" disabled>#= data.value #</div>' +
                             '# } else { #' +
                             '#= data.value #' +
                             '# } #'
              ,
            close: onClose,
            change: onChange,
            enableDatePicker: enableDatePicker,
            formattedValue: null,
            initValue: initValue,
            initializeDatePicker: initializeDatePicker,
            activate: activate,
            compositionComplete: compositionComplete,
            onBlur: onBlur,
            onFocus: onFocus,
            customValueChanged: function customValueChanged() { },
            notExecuteCustomValueChanged: false,
            lastValue: ko.observable(''),
            disableNullValue: false,
            setValue: setValue,
            isBreezeElement : false
        };

        function setValue(value) {
            if (!global.isNull(value)) {
                obj.valueAsDate(value)
                $("#" + obj.datePickerId()).data("kendoDatePicker").value(value);
            }
        }

        function onBlur(s, e) {
            try {
                if (!global.isNull(e)) {
                    if (global.isNull($("#" + s.datePickerId()).data("kendoDatePicker")._value)
                        && e.target.value != '') {
                        e.target.value = obj.lastValue();
                        setValue(global.isNOE(e.target.value) ? null : new Date(e.target.value));
                        // e.target.value = '';
                    }
                    else
                        obj.valueAsDate($("#" + s.datePickerId()).data("kendoDatePicker")._value);
                }
                else {
                    //$(".k-edit-cell").find(":input");
                    //var v = s.originalEvent.srcElement.value;
                }
            }
            catch (err) {
                global.treatError(err);
            }
        }

        function onFocus(s, e) {
            try {
                var lastValue = '';

                if (!global.isNull(e)) {
                    lastValue = $("#" + s.datePickerId()).data("kendoDatePicker")._value;
                }
                else {
                    lastValue = s.target.value;
                }
                obj.lastValue(lastValue);
            }
            catch (err) {
                global.treatError(err);
            }
        }

        function onClose(e) {
            try {
                if (prevent) {
                    e.preventDefault();
                }
            }
            catch (err) {
                global.treatError(err);
            }
        }

        function onChange(e) {

            try {
                var oldValue = valueAsDate();
                if (!global.isNull(breezeModel) && obj.isBreezeElement) {
                    var aspect = breezeModel.entityAspect;
                    var currentModel = breezeModel;
                    while (!aspect) {   //for complexType objects (like employeeand inner tabs)
                        currentModel = currentModel.complexAspect.parent;
                        aspect = currentModel.entityAspect;                        
                    }
                    if(aspect.entityState != breeze.EntityState.Added)
                        aspect.setModified();
                    if (global.isNull(aspect.originalValues[breezePropery])) {
                        aspect.originalValues[breezePropery] = obj.value();
                    }
                }
                if (($.inArray(+new Date(e.sender._value), obj.disableDates()) != -1) || (global.isNull(e.sender._value) && obj.disableNullValue == true)) {
                    prevent = true;
                    setValue(oldValue);
                }
                else {
                    prevent = false;
                }

                if (obj.notExecuteCustomValueChanged != true) {
                    obj.customValueChanged(e.sender._value);
                }
            }
            catch (err) {
                global.treatError(err);
            }
        }

        function activate() {
            obj.formattedValue = ko.computed(
                function getFormattedDate() {
                    if (global.isNull(obj.valueAsDate()))
                        return '';
                    return obj.valueAsDate().toString(obj.format);
                });
        }

        function compositionComplete() {
            try {
                $(document).ready(function () {
                    $("#" + obj.datePickerId()).kendoMaskedTextBox({
                        mask: global.cache.get(global.enums.cacheItems.DATE_FORMAT).replace(/[a-zA-Z]/g, "9")
                    });
                });
            } catch (err) {
                global.treatError(err);
            }
        }

        function initValue(model, propertyName, notAsBreeze) {
            if (notAsBreeze) {//like in workRules(valueKoProperty is used)
                obj.isBreezeElement = false;
            }
            else {
                obj.isBreezeElement = true;
                breezeModel = model;
                breezePropery = propertyName;
            }
            var originalValue = model[propertyName]();
            model[propertyName] = obj.value;
            model[propertyName](originalValue);
            obj.value = model[propertyName];
        }

        function initializeDatePicker(options) {

            if (!global.isNull(options.isReadOnly)) {
                obj.isReadOnly(options.isReadOnly);
            }
            obj.datePickerId(options.id);
            if (!global.isNull(options.minDate)) {
                obj.minDate(options.minDate);
            }
            if (!global.isNull(options.maxDate)) {
                obj.maxDate(options.maxDate);
            }
            if (!global.isNull(options.yearRange)) {
                var years = options.yearRange.split(":");
                obj.minDate(new Date(years[0], 0, 1));
                obj.maxDate(new Date(years[1], 12, 0, 23, 59, 59));
            }
            if (!global.isNull(options.unAvailableDates)) {
                var disabledDates = [];
                for (var i = 0; i < options.unAvailableDates.length; i++) {
                    disabledDates.push(+new Date(options.unAvailableDates[i]));
                }
                obj.disableDates(disabledDates);
            }
            if (!global.isNull(options.disableNullValue)) {
                obj.disableNullValue = options.disableNullValue;
            }
            if (options.readOnlyKoProperty != null) {
                obj.isReadOnly = options.readOnlyKoProperty;
            }
            if (options.valueKoPropertyObj) {
                initValue(options.valueKoPropertyObj, options.valueKoPropertyName, 1/*not as Breeze object*/);
            }
        }

        function enableDatePicker(enable) {

            if ($("#" + obj.datePickerId()).length > 0 && !global.isNull(enable)) {
                $("#" + obj.datePickerId()).data("kendoDatePicker").enable(enable);
            }
        }

        return obj;
    }

    return vm;
});
















