﻿define(function memoryCacheModule(require) {

    var enums = require('common/enums/enums');
    var cacheItems = enums.cacheItems;

    //memoeyCache בעבור כל אוביקט הנישמר ב
    //:יש לבצע 3 פעולות
    //במידה ויש צורך observalbeProperties הכנסה למערכי 
    //set של פונקצית switch-case כתיבת קוד מתאים ב
    //get של פונקצית switch-case כתיבת קוד מתאים ב

    var harmonyStorageName = 'eHrm';
    var harmonyStorage;

    var observableArrayProperties = [
       cacheItems.DICT.name,
       cacheItems.DICTMSG.name
    ];

    initHarmonyStorage();

    function initHarmonyStorage() {
        harmonyStorageString = sessionStorage[harmonyStorageName];
        if (isNull(harmonyStorageString)) {
            sessionStorage[harmonyStorageName] = JSON.stringify({});
        }
        harmonyStorage = JSON.parse(sessionStorage[harmonyStorageName]);

        $.each(observableArrayProperties, function setObservalbeArrayField(i, fieldName) {
            harmonyStorage[fieldName] = ko.observableArray(harmonyStorage[fieldName]);
        });

    }

    function clearButSaveSystemParams() {
        var saveParams = [];
        $.each(enums.cacheItems, function (i, itemInCache) {
            if (itemInCache.cacheMode == enums.cacheMode.MEMORY_CACHE && itemInCache.isSystemParam) {
                saveParams.push({key:itemInCache,value: module.get(itemInCache)});
            }
        });
        sessionStorage[harmonyStorageName] = undefined;
        initHarmonyStorage();
        $.each(saveParams, function (i, savedItem) {            
            module.set(savedItem.key, savedItem.value);            
        });
    }

    var module = {
        clearButSaveSystemParams: clearButSaveSystemParams,
        set: function (key, value) {
            switch (key) {
                case cacheItems.USER:
                case cacheItems.CURCOMP:
                case cacheItems.CUSTOM_CONFIG:
                case cacheItems.MNG_DASHBOARD_PERMITIONS:
                case cacheItems.EMP_DASHBOARD_PERMITIONS:
                case cacheItems.DATE_FORMAT:
                case cacheItems.DATE_WITHOUT_YEAR_FORMAT:
                case cacheItems.DATE_FORMAT_YYYYMM: // 02.01.2018 lyn                    
                case cacheItems.CURRENCY_SYMBOL:
                case cacheItems.IS_REGION_EXIST:
                case cacheItems.IS_SECTION_EXIST:
                case cacheItems.IS_FACTORY_EXIST:
                case cacheItems.LOGO_MAIN:
                case cacheItems.LAST_LOGIN_SCREEN:
                case cacheItems.ATTENDANCE_RUN_PROCESS:
                case cacheItems.LOOKUPS:
                case cacheItems.CONTACT_TYPES:
                case cacheItems.USR_AUTO_APPROVE:
                case cacheItems.GRP_UPD_AUTO_APPROVE:
                case cacheItems.logoutShellEventHasAlreadyBeenCatched:
                case cacheItems.IsAfterReloadByCode:
                case cacheItems.NEED_RETRIVE_COMPANY_DATA_AGAIN:
                case cacheItems.SessionExpiryTime:
                case cacheItems.LAST_FORM_101_MAIN_VALUES:
                case cacheItems.FORM_101_YEARS_LIST:
                case cacheItems.LAST_WORK_SCHEDULE_WEEKLY_DATE:
                case cacheItems.TASK_MOUDLE_SRC_TABLE_NAME:
                case cacheItems.LAST_RUN_REPORT_DLL_NO:
                case cacheItems.CURRENT_TAX_YEAR:
                case cacheItems.ELEMENTS_TO_HIDE:
                case cacheItems.MAINTENACNE_LAST_DISPLAY_WRAPPER_MODE:
                case cacheItems.NOTIFIER_EVENTTYPES_LIST:
                case cacheItems.EXIST_USER_SECURE_COOKIE:
                case cacheItems.REPORT_FMT:
                case cacheItems.LAST_CREATED_INTERFACE:
                    updateProperty("set", key.name, value)
                    break;
                case cacheItems.DICT:
                case cacheItems.DICTMSG:
                    updateProperty("set", key.name, setDictionaryList(value))
                    break;
                case cacheItems.LOOKUPS_RECORDS_COUNT:
                    updateProperty("set", key.name, setDictionaryObject(value, "ElemName", "ElemCount"))
                    break;
                case cacheItems.TOOLTIPS:
                    updateProperty("set", key.name, setDictionaryObject(value, "FormControl_ID", "WordCustom"));
                case cacheItems.COMPANY_PERMISSIONS:
                case cacheItems.COMPANY_PREFERENCES:
                case cacheItems.COMPANY_PREFERENCES_PERMISSIONS:
                case cacheItems.COMPANY_PARAMS:
                case cacheItems.NOTIFIER_PARAMS:
                case cacheItems.FORMS_ELEMENT_SHOW_TYPE:
                
                    updateCaceItemProperty("set", cacheItems.CURCOMP, key.name, value)
                    break;
                case cacheItems.SESSION_ID:
                    updateCaceItemProperty("set", cacheItems.USER, key.name, value)
                    break;
                case cacheItems.LANGUAGES_LIST:
                    updateCaceItemProperty("set", cacheItems.LOOKUPS, key.name, value)
                    break;
                default: throw new Error("Cache item is not supported in memory cache: " + key);
            }
        },

        get: function (key) {
            switch (key) {
                case cacheItems.USER:
                case cacheItems.LOOKUPS:
                case cacheItems.MNG_DASHBOARD_PERMITIONS:
                case cacheItems.EMP_DASHBOARD_PERMITIONS:
                case cacheItems.LOOKUPS_RECORDS_COUNT:
                case cacheItems.COMPANY:
                case cacheItems.DICT:
                case cacheItems.DICTMSG:
                case cacheItems.TOOLTIPS:
                case cacheItems.CURCOMP:
                case cacheItems.CUSTOM_CONFIG:
                case cacheItems.DATE_FORMAT:                
                case cacheItems.DATE_WITHOUT_YEAR_FORMAT:
                case cacheItems.DATE_FORMAT_YYYYMM: // 02.01.2018 lyn                    
                case cacheItems.CURRENCY_SYMBOL:
                case cacheItems.IS_REGION_EXIST:
                case cacheItems.IS_SECTION_EXIST:
                case cacheItems.IS_FACTORY_EXIST:
                case cacheItems.MAINTENACNE_LAST_DISPLAY_WRAPPER_MODE:
                case cacheItems.LOGO_MAIN:
                case cacheItems.CONTACT_TYPES:
                case cacheItems.USR_AUTO_APPROVE:
                case cacheItems.GRP_UPD_AUTO_APPROVE:
                case cacheItems.LAST_LOGIN_SCREEN:
                case cacheItems.ATTENDANCE_RUN_PROCESS:
                case cacheItems.logoutShellEventHasAlreadyBeenCatched:
                case cacheItems.IsAfterReloadByCode:
                case cacheItems.NEED_RETRIVE_COMPANY_DATA_AGAIN:
                case cacheItems.SessionExpiryTime:
                case cacheItems.LAST_FORM_101_MAIN_VALUES:
                case cacheItems.FORM_101_YEARS_LIST:
                case cacheItems.LAST_WORK_SCHEDULE_WEEKLY_DATE:
                case cacheItems.TASK_MOUDLE_SRC_TABLE_NAME:
                case cacheItems.LAST_RUN_REPORT_DLL_NO:
                case cacheItems.CURRENT_TAX_YEAR:
                case cacheItems.ELEMENTS_TO_HIDE:
                case cacheItems.NOTIFIER_EVENTTYPES_LIST:
                case cacheItems.EXIST_USER_SECURE_COOKIE:
                case cacheItems.REPORT_FMT:
                case cacheItems.LAST_CREATED_INTERFACE:
                    return updateProperty("get", key.name);
                case cacheItems.COMPANY_PARAMS:
                case cacheItems.COMPANY_PERMISSIONS:
                case cacheItems.COMPANY_PREFERENCES:
                case cacheItems.COMPANY_PREFERENCES_PERMISSIONS:
                case cacheItems.NOTIFIER_PARAMS:
                case cacheItems.FORMS_ELEMENT_SHOW_TYPE:
                    return updateCaceItemProperty("get", cacheItems.CURCOMP, key.name, null)             
                case cacheItems.SESSION_ID:
                    return updateCaceItemProperty("get", cacheItems.USER, key.name, null)
                case cacheItems.LANGUAGES_LIST:
                    return updateCaceItemProperty("get", cacheItems.LOOKUPS, key.name, null)
                default: throw new Error("Cache item is not supported in memory cache: " + key);
            }
        },

        saveLookupAtCache: function (lookupName, lookupList) {
            switch (lookupName) {
                case enums.lookupName.LanguagesList:
                case enums.lookupName.AbsenceForUserUpdate:
                case enums.lookupName.AbsenceForGroupUpdate:
                case enums.lookupName.OrganizationLevelConstList:
                case enums.lookupName.OrganizationLevelDynamicList:
                    updateLookupItem("set", lookupName.cacheName, lookupList);
                    break;
                default: throw new Error("this lookup connot be saved not by lookupManager");
            }
        },

        isExistKey: function isExistKey(key) {
            switch (key) {
                case cacheItems.USER:
                case cacheItems.LOOKUPS:
                case cacheItems.LOOKUPS_RECORDS_COUNT:
                case cacheItems.COMPANY:
                case cacheItems.DICT:
                case cacheItems.DICTMSG:
                case cacheItems.TOOLTIPS:
                case cacheItems.CURCOMP:
                case cacheItems.CUSTOM_CONFIG:
                case cacheItems.DATE_FORMAT:
                case cacheItems.DATE_WITHOUT_YEAR_FORMAT:
                case cacheItems.DATE_FORMAT_YYYYMM: // 02.01.2018 lyn                    
                case cacheItems.CURRENCY_SYMBOL:
                case cacheItems.IS_REGION_EXIST:
                case cacheItems.IS_SECTION_EXIST:
                case cacheItems.IS_FACTORY_EXIST:
                case cacheItems.LOGO_MAIN:
                case cacheItems.CONTACT_TYPES:
                case cacheItems.USR_AUTO_APPROVE:
                case cacheItems.GRP_UPD_AUTO_APPROVE:
                case cacheItems.LAST_LOGIN_SCREEN:
                case cacheItems.ATTENDANCE_RUN_PROCESS:
                case cacheItems.COMPANY_PARAMS:
                case cacheItems.FORMS_ELEMENT_SHOW_TYPE:
                case cacheItems.COMPANY_PERMISSIONS:
                case cacheItems.COMPANY_PREFERENCES:
                case cacheItems.COMPANY_PREFERENCES_PERMISSIONS:
                case cacheItems.NOTIFIER_PARAMS:
                case cacheItems.MNG_DASHBOARD_PERMITIONS:
                case cacheItems.EMP_DASHBOARD_PERMITIONS:
                case cacheItems.LAST_WORK_SCHEDULE_WEEKLY_DATE:
                case cacheItems.LAST_RUN_REPORT_DLL_NO:
                case cacheItems.ELEMENTS_TO_HIDE:
                case cacheItems.NOTIFIER_EVENTTYPES_LIST:
                case cacheItems.EXIST_USER_SECURE_COOKIE:
                case cacheItems.REPORT_FMT:
                    if (observableArrayProperties.indexOf(key.name) > -1)
                        return harmonyStorage[key.name]().length > 0;
                    else
                        return !isNull(harmonyStorage[key.name]);
                    break;
                    //no case for SESSION_ID, LANGUAGES_LIST
                default:
                    return false;
            }
        }
    };

    function setDictionaryList(list, keyColumn, valueColumn) {
        try {
            var dictionaryList = [];
            var i;
            if (!isNull(keyColumn)) {
                for (i = 0; i < list.length; i++)
                    dictionaryList[list[i][keyColumn]] = list[i][valueColumn];
            }
            else {
                for (i = 0; i < list.length; i++)
                    dictionaryList[list[i].Code] = list[i].Descript;
            }
            return dictionaryList;
        }
        catch (err) {
            alert(err);
        }
    }

    function setDictionaryObject(list, keyColumn, valueColumn) {
        try {
            var dictionaryObject = {};
            var i;
            if (!isNull(keyColumn)) {
                for (i = 0; i < list.length; i++)
                    dictionaryObject[list[i][keyColumn]] = list[i][valueColumn];
            }
            else {
                for (i = 0; i < list.length; i++)
                    dictionaryObject[list[i].Code] = list[i].Descript;
            }
            return dictionaryObject;
        }
        catch (err) {
            alert(err);
        }
    }

    function updateProperty(method, property_name, value) {
        try {
            if (method == "set") {
                if (value != null) {
                    if ($.isFunction(harmonyStorage[property_name])) {
                        harmonyStorage[property_name](value);
                    }
                    else
                        harmonyStorage[property_name] = value;
                }
                else
                    delete harmonyStorage[property_name];

                //need unwrap observable fields before stringify it.
                JSONStorage = ko.toJS(harmonyStorage);
                sessionStorage[harmonyStorageName] = JSON.stringify(JSONStorage);
            }
            else {//method is get

                if ($.isFunction(harmonyStorage[property_name])) {//if it is observable or observableArray 
                    if (isNull(harmonyStorage[property_name]())) {
                        if (property_name == cacheItems.DICT.name || property_name == cacheItems.DICTMSG.name) {
                            //for first binding of pages will not faild
                            updateProperty('set', property_name, [])
                        }
                    }
                    return harmonyStorage[property_name]();
                }

                else {//regular property
                    if ((property_name == cacheItems.LOOKUPS.name || property_name == cacheItems.LOOKUPS_RECORDS_COUNT.name) && isNull(harmonyStorage[property_name])) {
                        updateProperty('set', property_name, {})
                    }
                    return harmonyStorage[property_name];
                }
            }
        }
        catch (err) {
            alert(err);
        }

    }

    function updateCaceItemProperty(method, cacheItem, property_name, value) {
        var item = updateProperty("get", cacheItem.name, null);
        if (method == "set") {
            if (isNull(item)) {
                item = {};
            }
            item[property_name] = value;
            updateProperty("set", cacheItem.name, item);
        }
        else
            return !isNull(item) ? item[property_name] : null;
    }

    function isNull(value) {
        if (value == null || value == 'undefined')
            return true;
        else
            return false;
    }
    return module;
});



