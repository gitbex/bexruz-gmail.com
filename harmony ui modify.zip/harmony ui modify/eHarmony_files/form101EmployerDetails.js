﻿define(function (require) {

    var comboVM = require('views/controls/combo/combo');
    var global = require('common/global');
    var employerCombo = new comboVM();

    function init(context, dataObject) {
        var data = dataObject.data;
        vm.data(data);
        employerCombo.initialize({ comboId: 'employerCombo', lookupName: global.enums.lookupName.Employers, cancelOptionLabel: true, width:'280px' }).done(function selectCurrent() {
            var needLoadEmployer = false;
            if (global.isNull(data.Unit_A().TikNikuimID())) {
                needLoadEmployer = true;
            }
            employerCombo.customSelectionChanged = loadEmployerData;
            employerCombo.changeSelectedItemById(data.Unit_A().TikNikuimID(), data.Unit_A().TikNikuimID);
            if (needLoadEmployer) {
                loadEmployerData({ Code: data.Unit_A().TikNikuimID() });
            }            
            if (employerCombo.data._data.length == 1) {
                employerCombo.isReadOnly(true);
            }
        });
    }

    function loadEmployerData(newId) {
        global.httpGet(global.enums.httpPath.Form101EmployerDetails, { deductionsPortfolio: newId.Code }).done(function viewDetails(details) {
            vm.data().Unit_A().TikNikuimID(details.TikNikuimID);
            vm.data().Unit_A().CompanyName(details.CompanyName);
            vm.data().Unit_A().CompanyAddress(details.CompanyAddress);
            vm.data().Unit_A().CompanyPhoneNumber(details.CompanyPhoneNumber);
        });
    }

    function detached() {
        employerCombo.customSelectionChanged = function () { };
        employerCombo.selectedId = ko.observable();
    }

    function compositionComplete() {
        $(document).ready(function () {
            global.displaySpin(false);
        });
    }

    var vm = {
        init: init,
        data: ko.observable(null),
        isValid: function () { return true; },
        employerCombo: employerCombo,
        detached: detached,
        global: global,
        compositionComplete: compositionComplete
    };
    return vm;
});