﻿define(function (require) {
    var global = require('common/global');
    var employerDetails = require('views/forms/form101/form101EmployerDetails');
    var dataContext = require('data/datacontext');
    var validationHelper = require('data/validationHelper');
    var router = require('plugins/router');
    var lookupManager = require('common/lookupManager');
    var customMessageWindow = require('views/combinedControls/customMessageWindow/customMessageWindow');

    var validationErrorsTabIndex;
    var saveResult = {
        ok: 'ok',
        okNotChangeMinTab: 'okNotChangeMinTab',
        notValid: 'notValid'
    };
    var views = {
        EmployerDetails: { path: 'views/forms/form101/form101EmployerDetails', data: 'Unit_A', tabIndex: 0 },
        EmployeeDetails: { path: 'views/forms/form101/form101EmployeeDetails', data: 'Unit_B', tabIndex: 1 },
        BankAccountDetails: { path: 'views/forms/form101/form101BankAccount', data: 'Unit_O', tabIndex: 2 },
        ChildrenDetails: { path: 'views/forms/form101/form101ChildrenDetails', data: 'Unit_C', tabIndex: 3 },
        CurrentProceeds: { path: 'views/forms/form101/form101CurrentProceeds', data: 'Unit_D', tabIndex: 4 },
        OtherProceeds: { path: 'views/forms/form101/form101OtherProceeds', data: 'Unit_E', tabIndex: 5 },
        SpouseDetails: { path: 'views/forms/form101/form101SpouseDetails', data: 'Unit_F', tabIndex: 6 },
        //{ path: 'views/forms/form101/form101ChangesDuringYear' },
        ExemptionReasons: { path: 'views/forms/form101/form101ExemptionReasons', data: 'Unit_H', tabIndex: 7 },
        CoordinationReasons: { path: 'views/forms/form101/form101CoordinationReasons', data: 'Unit_I', tabIndex: 8 },
        SaveAttachment: { path: 'views/forms/form101/form101SaveAttachments', data: 'Unit_J', tabIndex: 9 },
        Predication: { path: 'views/forms/form101/form101Predication', data: 'Unit_J', tabIndex: 10 }
    };

    // Override views
    if (global.isMobile()) {
        views.EmployerDetails.path = 'views/forms/form101Mobile/form101EmployerDetails';
        views.EmployeeDetails.path = 'views/forms/form101Mobile/form101EmployeeDetails';
        views.BankAccountDetails.path = 'views/forms/form101Mobile/form101BankAccount';
        views.ChildrenDetails.path = 'views/forms/form101Mobile/form101ChildrenDetails';
        views.CurrentProceeds.path = 'views/forms/form101Mobile/form101CurrentProceeds';
        views.OtherProceeds.path = 'views/forms/form101Mobile/form101OtherProceeds';
        views.SpouseDetails.path = 'views/forms/form101Mobile/form101SpouseDetails';
        views.ExemptionReasons.path = 'views/forms/form101Mobile/form101ExemptionReasons';
        views.CoordinationReasons.path = 'views/forms/form101Mobile/form101CoordinationReasons';
        views.SaveAttachment.path = 'views/forms/form101Mobile/form101SaveAttachments';
        views.Predication.path = 'views/forms/form101Mobile/form101Predication';
    }

    var vIndex = [
        'EmployerDetails',
        'EmployeeDetails',
        'BankAccountDetails',
        'ChildrenDetails',
        'CurrentProceeds',
        'OtherProceeds',
        'SpouseDetails',
        'ExemptionReasons',
        'CoordinationReasons',
        'SaveAttachment',
        'Predication'];

    function vm(allData, contextObj, maritalStatusList, isNew, comments, defaultData) {
        var visitedTabs = {};
        if (global.isNull(defaultData)) {
            defaultData = {};
        }
        var isFirstTimeUpdateUnit_B_ForThisFormVersionCurrentTime = true;//will use for: if user did changes in unit B,
        //but he already update the idCardFile this time - we don't want to force update the file again.
        //so the flag is in employeeDetails file. but, we need to init this flag by 'false' val every time when open form101 to edit.
        global.app.on(global.enums.events.SAVE_CANCEL_FORM101.name).then(saveAndCancel);
        var that = this;
        var context = contextObj;
        allData.data.entityAspect.setUnchanged();
        var minModifiedTabIndex = 0;

        //#region events

        function activate() {
            try {
             //   if (!context.xVerNo) context.xVerNo = 1; // 24/06/2018, back to original (before Abdub) - handling xVerNo=null in saving
            }
            catch (err) {
                global.treatError(err);
            }
        }

        function compositionComplete() {
            try {
                if (global.isNOE(that.currentSection())) {
                    if (isNew == 1) {
                        that.data.TabIndex(views.EmployerDetails.tabIndex);
                        requireCurrentPath();
                    }
                    else {
                        if (that.data.TabIndex() == views.EmployerDetails.tabIndex && global.isNOE(that.data.Unit_A().TikNikuimID()))//check if exist tiknikuim. in case not - neet to load &select 
                        {
                            global.httpGet(global.enums.httpPath.Form101EmployerDetails, { deductionsPortfolio: that.data.Unit_A().TikNikuimID() }).done(function viewDetails(details) {
                                that.data.Unit_A().TikNikuimID(details.TikNikuimID);
                                that.data.Unit_A().CompanyName(details.CompanyName);
                                that.data.Unit_A().CompanyAddress(details.CompanyAddress);
                                that.data.Unit_A().CompanyPhoneNumber(details.CompanyPhoneNumber);

                                continueLoadCurrentTabIndex();
                            });

                        }
                        else {
                            continueLoadCurrentTabIndex();
                        }
                    }
                }
                else {
                    //suitDesignOfMenu();
                    constructNavigationMenu();
                }
            }
            catch (err) {
                global.treatError(err);
            }
        }

        function continueLoadCurrentTabIndex() {
            that.data.TabIndex(getNextTabIndex());
            if (that.data.TabIndex() == views.SpouseDetails.tabIndex) {
                if (isNotMarried()) {
                    that.data.TabIndex(views.ExemptionReasons.tabIndex);
                }
            }
            else if (that.data.TabIndex() == views.BankAccountDetails.tabIndex && hasNoBankAccount()) {
                that.data.TabIndex(views.ChildrenDetails.tabIndex);
            }
            else if (that.data.TabIndex() == views.CurrentProceeds.tabIndex && that.data.Unit_B().PayrollJobType_ID() == global.enums.payrollJobType.Pensioner) {
                that.data.TabIndex(parseInt(that.data.TabIndex()) + 1);
            }
            if (that.data.TabIndex() != views.EmployeeDetails.tabIndex && global.isNOE(that.data.Unit_B().City_Code()))     //case tabindex not employeeDetails check if city&street are correct
            {
                //try to find city in lookup
                lookupManager.getLookupWithDefaultQuery(global.enums.lookupName.Tfs101CitiesList).done(function Tfs101CitiesListLoaded(response) {
                    try {
                        var item = Enumerable.From(response)
                            .Where(function (lu) { return lu.Descript == that.data.Unit_B().City() })
                            .Select(function (lu) { return lu })
                            .FirstOrDefault();
                        if (global.isNOE(item)) {
                            that.data.TabIndex(views.EmployeeDetails.tabIndex);
                            requireCurrentPath(true);
                        }
                        else {
                            that.data.Unit_B().City_Code(item.Code);

                            //try to find street in lookup
                            lookupManager.getLookupWithDefaultQuery(global.enums.lookupName.Tfs101CityStreetsList, '<Root><City>' + that.data.Unit_B().City_Code() + '</City></Root>').done(function Tfs101StreetListLoaded(response) {
                                try {
                                    var item = Enumerable.From(response)
                                        .Where(function (lu) { return lu.Code == that.data.Unit_B().StreetName() })
                                        .Select(function (lu) { return lu })
                                        .FirstOrDefault();
                                    if (global.isNOE(item))
                                        that.data.TabIndex(views.EmployeeDetails.tabIndex);
                                    requireCurrentPath(true);
                                }
                                catch (err) {
                                    global.treatError(err);
                                }
                            });
                        }
                    }
                    catch (err) {
                        global.treatError(err);
                    }
                });
            }
            else {
                requireCurrentPath(true);
            }
        }

        function isNotMarried() {
            return that.data.Unit_B().MaritalStatus() != "2";
        }

        function hasNoBankAccount() {
            return that.containsBankAccount == "0";
        }

        function getNextTabIndex() {
            return parseInt(that.data.TabIndex()) + 1;
        }

        function isChildrenDetailsTab() {
            return that.data.TabIndex() == views.ChildrenDetails.tabIndex;
        }

        function needToShowUserCreditsBeforeNext() {
            return that.currentSection().model.needShowUserCreditsContentBeforeNextOccurs();
        }

        function currentSectionIsNotLoaded() {
            return global.isNull(that.currentSection())
        }

        function isPensioner() {
            return that.data.Unit_B().PayrollJobType_ID() == global.enums.payrollJobType.Pensioner;
        }

        function next() {
            try {
                global.callMobileFunction('HidePdfBtn');

                if (!isChildrenDetailsTab() || (isChildrenDetailsTab() && !needToShowUserCreditsBeforeNext())) {
                    global.displaySpin(true);
                    if (currentSectionIsNotLoaded()) {
                        previous();
                    }
                    save().done(function (savingResult) {
                        console.log(savingResult);
                        try {
                            if (savingResult != saveResult.notValid) {
                                global.displaySpin(true);
                                if (that.currentSection().model.setForGoNext) {
                                    that.currentSection().model.setForGoNext();
                                }

                                var stepsCount = 1;
                                if (that.data.TabIndex() == views.OtherProceeds.tabIndex && isNotMarried()) {
                                    stepsCount = 2;
                                } else if (that.data.TabIndex() == views.EmployeeDetails.tabIndex &&
                                    hasNoBankAccount()) {
                                    stepsCount = 2;
                                } else if (that.data.TabIndex() == views.CurrentProceeds.tabIndex - 1 &&
                                    isPensioner()) {
                                    stepsCount = 2;
                                }
                                if (that.data.TabIndex() < views.Predication.tabIndex) {

                                    that.data.TabIndex(parseInt(that.data.TabIndex()) + stepsCount);

                                    allData.data.entityAspect.setUnchanged();
                                    //avoid tab-index changing to look like data-change, when entity is really not changed.

                                }
                                if (savingResult == saveResult.ok) {
                                    minModifiedTabIndex = that.data.TabIndex();
                                }
                                var attachment = ko.observableArray([]);
                                if (that.data.TabIndex() == views.SaveAttachment.tabIndex) {
                                    attachment = initAttachmentFiles(contextObj, dataObject);
                                    if (attachment().length == 0)
                                        that.data.TabIndex(parseInt(that.data.TabIndex()) + 1);
                                }
                                var newCurrentPath = views[vIndex[that.data.TabIndex()]].path;
                                require([newCurrentPath],
                                    function (section) {
                                        global.displaySpin(
                                            true); //every screen should shut off the spin in compositionComplete event
                                        if (!visitedTabs[vIndex[that.data.TabIndex()]]) {
                                            section.showLastAttachmentsControls = false;
                                        }
                                        visitedTabs[vIndex[that.data.TabIndex()]] = true;
                                        if (that.data.TabIndex() == views.SaveAttachment.tabIndex) {
                                            section.init(contextObj, dataObject, next);
                                        } else {
                                            section.init(contextObj,
                                                dataObject,
                                                maritalStatusList,
                                                isFirstTimeUpdateUnit_B_ForThisFormVersionCurrentTime);
                                        }
                                        that.data.hasValidationErrorsOnSave(false);
                                        if (that.currentSection().model.emptyCustomValidMessage) {
                                            that.currentSection().model.emptyCustomValidMessage();
                                        }
                                        that.currentSection({ model: section, view: newCurrentPath + '.html' });
                                    });
                                var menuIndex = that.data.TabIndex() == views.Predication.tabIndex
                                    ? views.SaveAttachment.tabIndex
                                    : that.data.TabIndex();

                                if (global.isMobile()) {
                                    setDropdownNavigationTitle(menuIndex)
                                } else {
                                    var menuIndexRemove = menuIndex - stepsCount == 9 ? 8 : menuIndex - stepsCount;
                                    var liList = document.getElementById("menuForm101").getElementsByTagName("li");
                                    $(liList[menuIndex]).find("span").first().addClass("form101currentTab");
                                    $(liList[menuIndexRemove]).find("span").first().removeClass("form101currentTab");
                                    $(liList[menuIndex]).find("span").last().addClass("displayInline");
                                    $(liList[menuIndexRemove]).find("span").last().removeClass("displayInline");
                                }
                            }
                            else {
                                if (!global.isNull(that.currentSection().model.setForStayAtTab))
                                    that.currentSection().model.setForStayAtTab();
                                if (savingResult == saveResult.notValid) {
                                    that.currentSection().model
                                        .isValid(
                                            false); //in case we came from form101saveattachments  -need isValid(false) for button "save" return to be enabled                   
                                }
                            }
                            global.displaySpin(false);
                        } catch (err) {
                            global.treatError(err);
                        }
                    });
                } else {
                    console.log("next() else body");
                }
            }
            catch (err) {
                global.treatError(err);
            }
        };

        function setDropdownNavigationTitle(option) {
            $("#selectedStage")[0].value = $("#selectedStage")[0][option].value;

            //document.getElementById('selectedStage').value = document.getElementById('selectedStage')[menuIndex].value;

            var disable = isNotMarried();
            disableNavigationOption(views.SpouseDetails.tabIndex, disable);

            var disable = hasNoBankAccount();
            disableNavigationOption(views.BankAccountDetails.tabIndex, disable);

        }

        function disableNavigationOption(option, disable) {
            $("#selectedStage")[0][option].disabled = disable;
        }

        function previous() {
            try {
                global.callMobileFunction('HidePdfBtn');

                var itemToGoTo = that.data.TabIndex() - 1;
                var attachment = ko.observableArray([]);
                if (itemToGoTo == views.SaveAttachment.tabIndex) {
                    attachment = initAttachmentFiles(contextObj, dataObject);
                    if (attachment().length == 0)
                        itemToGoTo = itemToGoTo - 1;
                }
                if (that.data.TabIndex() == views.ExemptionReasons.tabIndex) {
                    if (that.data.Unit_B().MaritalStatus() != 2) {
                        itemToGoTo = that.data.TabIndex() - 2;
                    }
                }
                else if (that.data.TabIndex() == views.ChildrenDetails.tabIndex && that.containsBankAccount == "0") {
                    itemToGoTo = that.data.TabIndex() - 2;
                }
                else if (that.data.TabIndex() == views.CurrentProceeds.tabIndex + 1 && that.data.Unit_B().PayrollJobType_ID() == global.enums.payrollJobType.Pensioner)
                    itemToGoTo = that.data.TabIndex() - 2;
                goToItem(itemToGoTo);
            }
            catch (err) {
                global.treatError(err);
            }
        };

        function backToForm101Main() {
            try {
                cancel();
            }
            catch (err) {
                global.treatError(err);
            }
        }

        function menuClick(item) {
            try {
                if (item - 1 == that.data.TabIndex() || (item - 2 == that.data.TabIndex() && (that.data.TabIndex() == views.SpouseDetails.tabIndex - 1 && that.data.Unit_B().MaritalStatus() != 2) || (that.containsBankAccount == "0" && that.data.TabIndex() == views.EmployeeDetails.tabIndex)))
                    //if (
                    //    ((item - 1 == that.data.TabIndex()) ||
                    //    (item == 6 && that.data.TabIndex() == 4 && that.data.Unit_B().MaritalStatus() != 2)
                    //    || item == 5 && that.data.TabIndex() == 4 && that.data.Unit_B().MaritalStatus() == 2) &&
                    //    (!(item == 5 && that.data.TabIndex() == 4 && that.data.Unit_B().MaritalStatus() != 2))
                    //    )
                    next();
                else
                    if (item < that.data.TabIndex())
                        goToItem(item);

            }
            catch (err) {
                global.treatError(err);
            }
        }

        //#endregion 

        //#region methods

        function initAttachmentFiles(context, dataObject) {
            var attachmentsList = ko.observableArray([]);
            dataObject.data.Unit_J().FormDate(null);
            var form101params = {
                TaxYear: context.xTaxYear,
                Emp_no: context.xEmpNo,
                Version: context.xVerNo
            };
            var uploadSupportType = new Array("*.pdf", "*.jpg");
            //#region unit B
            if (global.isNullOrEmpty(dataObject.data.Unit_B().Employee_ID_Attachment().Id())) {
                var attItem = { obj: dataObject.data.Unit_B().Employee_ID_Attachment(), descript: "פרטי עובד/ת", fieldDescript: "צילום תעודת זהות" };
                attachmentsList.push(attItem);
            }
            if (dataObject.data.Unit_B().MaritalStatus() == 5 && global.isNullOrEmpty(dataObject.data.Unit_B().MaritalStatus_Attachment().Id())) {
                var attItem = { obj: dataObject.data.Unit_B().MaritalStatus_Attachment(), descript: "פרטי עובד/ת", fieldDescript: "מצב משפחתי" };
                attachmentsList.push(attItem);
            }
            //#endregion

            //#region unit H
            if (dataObject.data.Unit_H().Unit_H_2() == true && global.isNullOrEmpty(dataObject.data.Unit_H().Unit_H_2_Attachment().Id())) {
                var attItem = { obj: dataObject.data.Unit_H().Unit_H_2_Attachment(), descript: "בקשת פטור או זיכוי ממס הכנסה", fieldDescript: "סעיף 2" };
                attachmentsList.push(attItem);
            }
            if (dataObject.data.Unit_H().Unit_H_3() == true && global.isNullOrEmpty(dataObject.data.Unit_H().Unit_H_3_Attachment().Id())) {
                var attItem = { obj: dataObject.data.Unit_H().Unit_H_3_Attachment(), descript: "בקשת פטור או זיכוי ממס הכנסה", fieldDescript: "סעיף 3" };
                attachmentsList.push(attItem);
            }
            if (dataObject.data.Unit_H().Unit_H_4() == true && dataObject.data.Unit_H().Unit_H_4_1() == 1 && global.isNullOrEmpty(dataObject.data.Unit_H().Unit_H_4_1_1_Attachment().Id())) {
                var attItem = { obj: dataObject.data.Unit_H().Unit_H_4_1_1_Attachment(), descript: "בקשת פטור או זיכוי ממס הכנסה", fieldDescript: "סעיף 4" };
                attachmentsList.push(attItem);
            }
            if (dataObject.data.Unit_H().Unit_H_4() == true && dataObject.data.Unit_H().Unit_H_4_1() == 2 && global.isNullOrEmpty(dataObject.data.Unit_H().Unit_H_4_1_2_Attachment().Id())) {
                var attItem = { obj: dataObject.data.Unit_H().Unit_H_4_1_2_Attachment(), descript: "בקשת פטור או זיכוי ממס הכנסה", fieldDescript: "סעיף 4" };
                attachmentsList.push(attItem);
            }
            if (dataObject.data.Unit_H().Unit_H_10() == true && global.isNullOrEmpty(dataObject.data.Unit_H().Unit_H_10_Attachment().Id())) {
                var attItem = { obj: dataObject.data.Unit_H().Unit_H_10_Attachment(), descript: "בקשת פטור או זיכוי ממס הכנסה", fieldDescript: "סעיף 10" };
                attachmentsList.push(attItem);
            }
            if (dataObject.data.Unit_H().Unit_H_11() == true && global.isNullOrEmpty(dataObject.data.Unit_H().Unit_H_11_Attachment().Id())) {
                var attItem = { obj: dataObject.data.Unit_H().Unit_H_11_Attachment(), descript: "בקשת פטור או זיכוי ממס הכנסה", fieldDescript: "סעיף 12" };
                attachmentsList.push(attItem);
            }
            if (dataObject.data.Unit_H().Unit_H_13() == true && global.isNullOrEmpty(dataObject.data.Unit_H().Unit_H_13_Attachment().Id())) {
                var attItem = { obj: dataObject.data.Unit_H().Unit_H_13_Attachment(), descript: "בקשת פטור או זיכוי ממס הכנסה", fieldDescript: "סעיף 14" };
                attachmentsList.push(attItem);
            }
            if (dataObject.data.Unit_H().Unit_H_14() == true && global.isNullOrEmpty(dataObject.data.Unit_H().Unit_H_14_Attachment().Id())) {
                var attItem = { obj: dataObject.data.Unit_H().Unit_H_14_Attachment(), descript: "בקשת פטור או זיכוי ממס הכנסה", fieldDescript: "סעיף 15" };
                attachmentsList.push(attItem);
            }
            if (dataObject.data.Unit_H().Unit_H_30() == true && global.isNullOrEmpty(dataObject.data.Unit_H().Unit_H_30_Attachment().Id())) {
                var attItem = { obj: dataObject.data.Unit_H().Unit_H_30_Attachment(), descript: "בקשת פטור או זיכוי ממס הכנסה", fieldDescript: "סעיף 11" };
                attachmentsList.push(attItem);
            }
            //#endregion

            //#region unit I
            if (dataObject.data.Unit_I().Unit_HI_1() == true && global.isNullOrEmpty(dataObject.data.Unit_I().Unit_HI_1_Attachment().Id())) {
                var attItem = { obj: dataObject.data.Unit_I().Unit_HI_1_Attachment(), descript: "בקשת תיאום מס", fieldDescript: "סעיף 1" };
                attachmentsList.push(attItem);
            }
            if (dataObject.data.Unit_I().Unit_HI_3() == true && global.isNullOrEmpty(dataObject.data.Unit_I().Unit_HI_3_Attachment().Id())) {
                var attItem = { obj: dataObject.data.Unit_I().Unit_HI_3_Attachment(), descript: dataObject.data.Unit_B().PayrollJobType_ID() == global.enums.payrollJobType.Pensioner ? 'אישורים מצ"ב' : "בקשת תיאום מס", fieldDescript: "סעיף 3" };
                attachmentsList.push(attItem);
            }
            if (dataObject.data.Unit_I().Unit_HI_2() == true) {
                for (var i = dataObject.gridsData.OtherSalaries.length - 1; i >= 0; i--) {
                    if (global.isNullOrEmpty(dataObject.gridsData.OtherSalaries[i].Attachment.Id)) {
                        var id = ko.observable(null);
                        var name = ko.observable(null);
                        var isValid = ko.observable(true);
                        var attItem = { obj: dataObject.gridsData.OtherSalaries[i].Attachment, descript: "בקשת תיאום מס", fieldDescript: "סעיף 2 - " + dataObject.gridsData.OtherSalaries[i].Name };
                        attachmentsList.push(attItem);
                    }
                }
            }
            //#endregion

            return attachmentsList;

        }

        function saveAndCancel() {
            save();
            //cancel();
            global.app.on(global.enums.events.FORM101_UPDATE_END.name).then(function () {
                cancel();
                global.app.off(global.enums.events.FORM101_UPDATE_END.name)
            });
            global.app.off(global.enums.events.SAVE_CANCEL_FORM101.name);
        }

        function cancel() {
            if (that.currentSection().model.deactivate)
                that.currentSection().model.deactivate();
            global.app.trigger(global.enums.events.CANCEL_FORM101.name);
        }

        function goToItem(itemToGoTo) {

            if (!global.isNull(that.currentSection().model.setDataForSaving)) {
                that.currentSection().model.setDataForSaving();
            }
            if (allData.data.entityAspect.entityState.isModified() ||
                that.data.TabIndex() == views.ChildrenDetails.tabIndex && dataObject.gridsData.isChildenGridChanged == true ||
                that.data.TabIndex() == views.CoordinationReasons.tabIndex && dataObject.gridsData.isSalariesGridChanged == true) {
                minModifiedTabIndex = that.data.TabIndex();
            }
            var menuIndex = itemToGoTo == views.Predication.tabIndex ? 9 : itemToGoTo;
            if (global.isMobile()) {
                setDropdownNavigationTitle(menuIndex)
            } else {
                var menuIndexRemove = that.data.TabIndex() == views.Predication.tabIndex ? 9 : that.data.TabIndex();
                var liList = document.getElementById("menuForm101").getElementsByTagName("li");
                $(liList[menuIndexRemove]).find("span").first().removeClass("form101currentTab");
                $(liList[menuIndexRemove]).find("span").last().removeClass("displayInline");
                $(liList[menuIndex]).find("span").first().addClass("form101currentTab");
                $(liList[menuIndex]).find("span").last().addClass("displayInline");
            }



            that.data.TabIndex(itemToGoTo);
            if (that.data.TabIndex() == views.SaveAttachment.tabIndex) {
                attachment = initAttachmentFiles(contextObj, dataObject);
                if (attachment().length == 0)
                    that.data.TabIndex(parseInt(that.data.TabIndex()) + 1);
            }
            var newCurrentPath = views[vIndex[that.data.TabIndex()]].path;
            require([newCurrentPath], function (section) {
                global.displaySpin(true);//every screen should shut off the spin in compositionComplete event
                if (!visitedTabs[vIndex[that.data.TabIndex()]]) {
                    section.showLastAttachmentsControls = false;
                }
                visitedTabs[vIndex[that.data.TabIndex()]] = true;
                if (that.data.TabIndex() == views.SaveAttachment.tabIndex) {
                    section.init(contextObj, dataObject, next);
                } else {
                    section.init(contextObj, dataObject, maritalStatusList, isFirstTimeUpdateUnit_B_ForThisFormVersionCurrentTime);
                }
                allData.data.entityAspect.setUnchanged();//must be the last action; for example, create new upload instance in init function, can change the entity-state
                if (that.currentSection().model.setForGoPrev) {
                    that.currentSection().model.setForGoPrev();
                }
                that.currentSection({ model: section, view: newCurrentPath + '.html' });
            });
        }

        function save() {
            var isFileSaved = true;
            var saveDfd;
            var saveDefer = global.system.defer(function saveFun(saveDfd) {


                //NEVER CHANGE ORDER OF THE FOLLOWING LOGIC!
                if (!global.isNull(that.currentSection().model.setDataForSaving)) {
                    that.currentSection().model.setDataForSaving();
                    console.log('setDataForSaving() ->' + 'true');
                }
                console.log('setDataForSaving() ->' + 'passed');
                if (!global.isNull(that.currentSection().model.forceDependenceRules)) {
                    that.currentSection().model.forceDependenceRules();
                    console.log('forceDependenceRules() ->' + 'true');
                }
                console.log('forceDependenceRules() ->' + 'passed');

                if (!global.isNull(that.currentSection().model.saveFiles)) {
                    isFileSaved = that.currentSection().model.saveFiles();
                    console.log('saveFiles() ->' + 'true');
                    if (isFileSaved == false) {
                        console.log('isFileSaved ->' + 'false');
                        saveDfd.resolve(saveResult.notValid);
                        return;
                    }
                }
                console.log('saveFiles() ->' + 'passed');

                if (allData.data.entityAspect.entityState.isModified() ||
                    that.data.TabIndex() == views.ChildrenDetails.tabIndex && dataObject.gridsData.isChildenGridChanged == true ||
                    that.data.TabIndex() == views.CoordinationReasons.tabIndex && dataObject.gridsData.isSalariesGridChanged == true) {
                    minModifiedTabIndex = that.data.TabIndex();
                    console.log('isModified() ->' + 'true');
                }
                console.log('isModified() ->' + 'passed');

                if (!global.isNull(views[vIndex[that.data.TabIndex()]].data)) {
                    var isValid = validationHelper.validateComplexType(that.data, views[vIndex[that.data.TabIndex()]].data);
                    var customizeIsValid = true;
                    if (!global.isNull(that.currentSection().model.isValid)) {
                        customizeIsValid = that.currentSection().model.isValid();
                    }
                    if (!isValid || !customizeIsValid) {
                        validationErrorsTabIndex = that.data.TabIndex();
                    }
                    that.data.hasValidationErrorsOnSave(!that.data.hasValidationErrorsOnSave());
                    that.data.hasValidationErrorsOnSave(that.data.entityAspect.hasValidationErrors);
                }
                if ((isValid && customizeIsValid) || validationErrorsTabIndex != that.data.TabIndex()) {
                    //if (that.data.TabIndex() == 0) {
                    //    if (isNew == "1") {
                    //        saveDfd.resolve(saveResult.ok);
                    //        return;
                    //    }
                    //    else {
                    //        saveDfd.resolve(saveResult.okNotChangeMinTab);//not need to save
                    //        return;
                    //    }
                    //}
                    if (that.data.TabIndex() < minModifiedTabIndex) {
                        saveDfd.resolve(saveResult.okNotChangeMinTab);
                        return;
                    }
                    var dataForSaving = dataContext.unWrapObject(dataObject.data);
                    dataForSaving.Unit_C.Children = dataObject.gridsData.childrenData;
                    if (that.data.Unit_I().Unit_HI_2()) {
                        dataForSaving.Unit_I.OtherSalaries = dataObject.gridsData.OtherSalaries;
                    }
                    else {
                        dataForSaving.Unit_I.OtherSalaries = [];
                    }
                    for (var i = views.Predication.tabIndex; i > that.data.TabIndex(); i--) {
                        if (/*new 101 version & saving now employee details screen */
                            /*new 101 version */((context.xVerNo == 0 || global.isNull(context.xVerNo)) &&
                            /*saving now employee details*/that.data.TabIndex() == views.EmployeeDetails.tabIndex &&
                            /*have lived chidren tab details - so we want it to be saved*/(views[vIndex[i]].tabIndex == views.ChildrenDetails.tabIndex || views[vIndex[i]].tabIndex == views.BankAccountDetails.tabIndex)) ||
                            /*new 101 version & saving now employer details screen */
                            (/*new 101 version */((context.xVerNo == 0 || global.isNull(context.xVerNo)) &&
                            /*saving now employer details*/that.data.TabIndex() == views.EmployerDetails.tabIndex &&
                                (/*have lived employee details or chidren tab details - so we want it to be saved*/views[vIndex[i]].tabIndex == views.ChildrenDetails.tabIndex || views[vIndex[i]].tabIndex == views.EmployeeDetails.tabIndex || views[vIndex[i]].tabIndex == views.BankAccountDetails.tabIndex)))) {
                            continue;
                        }
                        else {
                            defaultData[views[vIndex[i]].data] = dataForSaving[views[vIndex[i]].data];
                            if (i <= views.CoordinationReasons.tabIndex) {
                                dataForSaving[views[vIndex[i]].data] = null;
                            }
                        }

                    }
                    if (that.data.TabIndex() == views.EmployeeDetails.tabIndex && that.currentSection().model.customIsModified) {
                        isFirstTimeUpdateUnit_B_ForThisFormVersionCurrentTime = false;
                    }
                    if (that.data.Unit_B().MaritalStatus() != 2) {
                        dataForSaving[views.SpouseDetails.data] = null;
                        defaultData[views.SpouseDetails.data] = null;
                    }
                    for (var i = that.data.TabIndex(); i > views.EmployeeDetails.tabIndex; i--) {
                        defaultData[views[vIndex[i]].data] = null;
                    }
                    dataForSaving.DefaultData = defaultData;
                    var command = {
                        VersionNo: context.xVerNo,
                        Status: (that.data.TabIndex() == views.Predication.tabIndex ? 2 : 1),
                        IsNew: context.xVerNo == 0 || global.isNull(context.xVerNo) ? true : false,
                        FormData: dataForSaving
                    };
                    global.httpPost(global.enums.httpPath.Form101Saving, command).done(function updateContext(response) {
                        if (response.ErrorDictCode == 0) {
                            global.app.trigger(global.enums.events.FORM101_UPDATE_END.name);

                            context.xVerNo = !global.isNull(response.VersionID) ? response.VersionID : context.xVerNo;
                            if (that.data.TabIndex() == views.ChildrenDetails.tabIndex) {
                                dataObject.gridsData.isChildenGridChanged = false;
                            }
                            if (that.data.TabIndex() == views.CoordinationReasons.tabIndex) {
                                dataObject.gridsData.isSalariesGridChanged = false;
                            }
                            saveDfd.resolve(saveResult.ok);
                        }
                        else {
                            var errMsgString = (response.ErrorCodeDictSource == 0) ? global.res[response.ErrorDictCode] : global.resMsg[response.ErrorDictCode];
                            if (response.ErrorData != '') {
                                if (response.ErrorData == 'Required')
                                    response.ErrorData = global.res[517] + ': ';
                                errMsgString = response.ErrorData + errMsgString;
                            }
                            msgErrorShow(errMsgString);
                            saveDfd.resolve(saveResult.notValid);
                        }
                    });
                }
                else {
                    saveDfd.resolve(saveResult.notValid);
                }
            });

            return saveDefer.promise();

        }

        function msgErrorShow(errorString) {
            var errorMsg = errorString;
            global.customMessageWindow.buildMessage({ mode: global.enums.messageType.error, messageText: errorMsg, btnsMode: global.enums.btnsMode.ok });
            global.showDialog(global.customMessageWindow);
        }

        //#endregion


        this.compositionComplete = compositionComplete;
        this.activate = activate;
        this.data = allData.data;
        this.context = contextObj;
        this.comments = !global.isNull(comments) ? comments.CommentsList : null;
        this.hasComments = !global.isNull(comments) && !global.isNull(comments.CommentsList) && comments.CommentsList.length > 0;
        this.currentSection = ko.observable();
        this.global = global;
        this.previous = previous;
        this.next = next;
        this.save = save;
        this.composeComplete = ko.observable(true);
        this.formHeight = ko.observable();
        this.arrowDownImage = ko.observable(global.imagesManager.orange_arrowDown);
        this.arrowUpImage = ko.observable(global.imagesManager.orange_arrowUp);
        this.backToForm101Main = backToForm101Main;
        this.menuClick = menuClick;
        this.containsBankAccount = global.cache.getCompanyParamByFieldName("isBankDataStoredForm101");
        var dataObject = allData;
        dataObject.composeComplete = that.composeComplete;

        function requireCurrentPath(needStep1) {
            if (needStep1) {
                var attachment = ko.observableArray([]);
                if (that.data.TabIndex() == views.SaveAttachment.tabIndex) {
                    attachment = initAttachmentFiles(contextObj, dataObject);
                    if (attachment().length == 0)
                        that.data.TabIndex(parseInt(that.data.TabIndex()) + 1);
                }
                if (that.data.TabIndex() == 11)
                    that.data.TabIndex(views.Predication.tabIndex);
            }

            minModifiedTabIndex = that.data.TabIndex();
            dataObject.data.entityAspect.setUnchanged();
            var currentPath = views[vIndex[that.data.TabIndex()]].path;
            require([currentPath], function (section) {
                if (!visitedTabs[vIndex[that.data.TabIndex()]]) {
                    section.showLastAttachmentsControls = false;
                }
                visitedTabs[vIndex[that.data.TabIndex()]] = true;
                if (that.data.TabIndex() == views.SaveAttachment.tabIndex) {
                    section.init(contextObj, dataObject, next);
                } else {
                    section.init(contextObj, dataObject, maritalStatusList, isFirstTimeUpdateUnit_B_ForThisFormVersionCurrentTime);
                }
                that.currentSection({ model: section, view: currentPath + '.html' });
            });

            //design menu
            //suitDesignOfMenu();
            constructNavigationMenu();
        }

        function constructNavigationMenu() {
            var menuIndex = that.data.TabIndex() == views.Predication.tabIndex ? 9 : that.data.TabIndex();
            if (global.isMobile()) {
                setDropdownNavigationTitle(menuIndex);
                setNavigationPadding();
            } else {
                suitDesignOfMenu(menuIndex);
            }
        }

        function setNavigationPadding() {
            if ($("#topMenuContent").css('direction') == 'rtl') {
                $("#topMenuBtn").addClass('paddingLeft4 paddingRight12');
                $("#topMenuContent").addClass('paddingLeft12 paddingRight4');
            } else {
                $("#topMenuBtn").addClass('paddingLeft12 paddingRight4');
                $("#topMenuContent").addClass('paddingLeft4 paddingRight12');
            }
        }

        function suitDesignOfMenu(menuIndex) {
            var liList = document.getElementById("menuForm101").getElementsByTagName("li");
            for (var i = 0; i < liList.length; i++) {
                $(liList[i]).find("span").first().removeClass("form101currentTab");
                $(liList[i]).find("span").last().removeClass("displayInline");
            }
            $(liList[menuIndex]).find("span").first().addClass("form101currentTab");
            $(liList[menuIndex]).find("span").last().addClass("displayInline");
            var contentHeight = $(window).height() * 0.71 - 15;
            $("#form101MainContent").height(contentHeight + 'px');
            $("#form101RightBottom").height($("#form101Menu").height() - $("#menuForm101").height() + 'px');
        }

        function currentSectionMobile() {
            return this.currentSection();
        }

        // Mobile members
        this.selectedStage = ko.observable();
        this.stageChanged = function () {
            global.callMobileFunction('HidePdfBtn');
            this.menuClick(this.selectedStage());
        }
    }

    return vm;
});
