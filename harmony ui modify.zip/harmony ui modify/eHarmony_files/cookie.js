﻿define(function cookieModule(require) {

    var enums = require('common/enums/enums');
    var cookiesClient = {};
    var cookies = {};

    // getAllCookies(); // TFS 28189,25/07/2019: read cookie from SERVER, using getAllCookiesFromServer
    getAllCookiesFromServer();

    function isExistCookie(cookieToSearch) {
        return cookies[cookieToSearch.name] !== undefined;
    }

    function getAllCookiesFromServer() {
       
        console.log('Start getAllCookies FromServer ');

        // require should be inside function, via require(['common/serverWrapper'],fnc...)  
        // not as require('common/serverWrapper') in top under cookieModule(require) <- this way failed on stack

        require(['common/serverWrapper'], function changeDisplaySpinAfterRequire(serverWrapperModule) {
            serverWrapperModule.get(enums.httpPath.GetAllCookiesFromServer).done(function getAllCook(response) {
                if (response != null && response.length != 0) {
                    var cookieName = '';
                    var cookieValue = '';
                    $.each(response.split(';'), function createCookieObj(i, cookie) {
                        while (cookie.substring(0, 1) == " ") {
                            cookie = cookie.substring(1);
                        }
                        cookieName = cookie.substring(0, cookie.indexOf('='));
                        cookieValue = cookie.substring(cookie.indexOf('=') + 1);
                        try {
                            cookieValue = JSON.parse(cookieValue);
                        }
                        catch (err) {//value is not json string
                        }

                        cookies[cookieName] = cookieValue;
                    });
                    }
                    console.log('getAllCookies FromServer :' + response)
            });
        });
    }

    function getAllCookies() {
        console.log('=== START getAllCookies by document.cookie : ' + document.cookie)
        $.each(document.cookie.split(';'), function createCookieObj(i, cookie) {
            while (cookie.substring(0, 1) == " ") {
                cookie = cookie.substring(1);
            }
            var cookieName = cookie.substring(0,cookie.indexOf('='));
            var cookieValue =  cookie.substring(cookie.indexOf('=')+1);
            try {
                cookieValue = JSON.parse(cookieValue);
            }
            catch (err) {//value is not json string
            }
            cookiesClient[cookieName] = cookieValue;
        });
    }

    function deleteCookie(cookieToDelete) {
        set(cookieToDelete, '=; expires=Thu, 01 Jan 1970 00:00:01 GMT; path=/');
        delete cookies[cookieToDelete.name];
    }

    function set(cookieToSet, val) {
        document.cookie = cookieToSet.name + '=' + val;
    }

    function get(cookieToGet) {
        return cookies[cookieToGet.name];
    }
  
    var module = {
        isExistCookie: isExistCookie,
        set: set,
        deleteCookie: deleteCookie,
        get: get,
        isExistKey: isExistCookie
    }

    return module;
});