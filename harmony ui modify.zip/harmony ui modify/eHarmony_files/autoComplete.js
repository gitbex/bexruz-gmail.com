﻿define(function autoCompleteControl(require) {
    var global = require('common/global');
    var lookupManager = require('common/lookupManager');
    var dialog = require('plugins/dialog');
    var data = [];
    var int16Max = 32767;

    ko.bindingHandlers.kendoComboWidth = {
        update: function (element, valueAccessor) {
            var kendoComboBox = $(element).data("kendoComboBox");
            kendoComboBox.wrapper[0].style["width"] =
                ko.utils.unwrapObservable(valueAccessor());
        }
    };

    //need to init on real-time, because when combo is requires, dict have not been initialized yet.
    //but when you need to create instances – dict should already be initialized
    var optionLabelEnum = {
        empty: '',
        all: null
    };

    var webMaxCount;
    if (global.cache.isExistKey('WebMaxComboCount')) {
        webMaxCount = global.cache.getCompanyParamByFieldName('WebMaxComboCount');
    } else {
        webMaxCount = int16Max;
    }
    
    var user = global.cache.get(global.enums.cacheItems.USER);
    dataQuery =
      {
          EmpNo: user != null ? user.Id : null,
          UserNo: user != null ? user.Profile != null ? user.Profile.Code : null : null,
          ElemName: '',
          PageNo: 1,
          PageSize: webMaxCount,
          PagingBy: false,
          PagingOrder: false,
          SearchBy: 2,
          SearchVal: '',
          SearchExact: true,
          OtherParamsXML: ''
      };
    /* special codes of item in lookup list:
    0:
    -1:
    -2: mock-value
    -3:new item value for adding to list
    */
    var ViewModel = function (params) {
        if(!global.isNullOrEmpty(global.res)) {
            optionLabelEnum.all = global.res[298];
        }
        
        var eTableParams = {
            eTableCodeColumn: null,
            eTableDescriptColumn: null,
            eTableFormId: null
        };

        var templates = {
            codeDescript: function (item) {
                item["Display"] = item.Code + " | " + item.Descript;
                if (item.Code == '') { item["Display"] = obj.optionLabel.Descript; return obj.optionLabel.Descript; };
                return item.Code + obj.completeCodeSpaces().substr(item.Code.toString().length * 12) + " | " + item.Descript;
            },
            descriptOnly: function (item) {
                item["Display"] = item.Descript;
                return item.Descript;
            },
            codeOnly: function (item) {
                item["Display"] = item.Code;
                return item.Code;
            }
        }

        var listBoxIdSuffix = "_listbox";
        var containerListElement = null;
        var comboWidthElement = null;
        var initializeCalled = false;
        var isAfterInitOrFefresh = false;
        var isAfterGetLookupAgain = false;
        var missingItem = null;
        var isFirstTimeAfterInit = false;
        var obj = {
            getLookupAgain: getLookupAgain,
            getLookupDataFromDb: getLookupDataFromDb,
            forceInitData: false,
            promise: null,
            dfd: null,
            addItemToDataSource: AddSelectedItemToDataSource,
            controlType: global.enums.controlType.autoComplete,
            isShowPage: false,
            dataSource: ko.observable(),
            data: ko.observable(new kendo.data.DataSource({ data: data })),
            comboId: ko.observable(params != null && params.comboId != null ? params.comboId : "defaultComboId"),
            cacheMode: {},
            isReadOnly: ko.observable(false),
            needOpenLookupScreen: ko.observable(false),
            lookupName: '',
            extendedData: '',
            itemValue: 'Code',
            itemText: 'Display',
            itemSimpleText: 'Descript',
            selectedItem: ko.observable(),
            selectedId: ko.observable(),
            completeCodeSpaces: ko.observable(""),
            template: params && params.template ? templates[params.template] : function (item) {
                item["Display"] = item.Code + " | " + item.Descript;
                if (item.Code == '') { item["Display"] = obj.optionLabel.Descript; return obj.optionLabel.Descript; };
                return item.Code + obj.completeCodeSpaces().substr(item.Code.toString().length * 12) + " | " + item.Descript;
            },
            clearInput: clearInput,
            prevCode: ko.observable(),
            onChange: onChange,
            getXmlData: getXmlData,
            changeSelectedItem: changeSelectedItem,
            changeSelectedItemOnInit: changeSelectedItemOnInit,
            initialize: initialize,
            customSelectionChanged: function () { },
            comboInGridSelectionChanged: null,
            clear: clear,
            openLookupScreen: openLookupScreen,
            refreshWithNewExtendedData: refreshWithNewExtendedData,
            refreshWithOtherLookupname: refreshWithOtherLookupname,
            refreshExendedDataWithoutChangingSelectedItem: refreshExendedDataWithoutChangingSelectedItem,
            clearSelectedItem: clearSelectedItem,
            getItemByCode: getItemByCode,
            getItemByUniqueDescript: getItemByUniqueDescript,
            inputText: ko.observable(''),
            comboWidth: ko.observable('200px'),
            changeSelectedItemById: changeSelectedItemById,
            changeSelectedItemByIdOnInit: changeSelectedItemByIdOnInit,
            sortByDescript: false,
            sortDescOrder: false,
            bindComboEvents: bindComboEvents,
            compositionComplete: function () {
                try {
                    bindComboEvents();
                    if (initializeCalled) {
                        if ((global.isNull(obj.selectedItem()) || obj.selectedItem().Code != -2) && !global.isNull($("#" + obj.comboId()).data("kendoComboBox"))) {
                            $("#" + obj.comboId()).data("kendoComboBox").value(obj.selectedId());
                        }
                        else {
                            mockSelectedItemChanging(obj.selectedItem());
                        }
                        containerListElement = $("#" + obj.comboId() + listBoxIdSuffix).closest(".k-list-container");
                        comboWidthElement = $("#" + obj.comboId()).prev();
                    }
                }
                catch (err) {
                    global.treatError(err);
                }
            },
            sortDataWithCustomDefinitions: sortDataWithCustomDefinitions,
            optionLabel: false,
            setOptionLabel: setOptionLabel,
            lookupScreen: ko.observable(null),
            lookupId: ko.observable(null),
            isComboInETableGrid: false,
            initializeForETable: initializeForETable,
            openETableScreen: openETableScreen,
            needEtableButton: ko.observable(false),
            mockSelectedItemChanging: mockSelectedItemChanging,
            isSetDefaultValue: false,
        	isAdjustDropDownWidth: false,
            widgetId: ko.observable(null),
            preventRemoveDefultValueByX: true,
            findItemById: findItemById,
            openList: openList,           
            activate: activate
        };
        function openList() {
            try {
            	if (containerListElement) {
            		if (obj.isAdjustDropDownWidth)
            			containerListElement.css('maxWidth', comboWidthElement.innerWidth());
            		else
            			containerListElement.css('minWidth', comboWidthElement.innerWidth());
            	}
            	else {
            		containerListElement = $("#" + obj.comboId() + listBoxIdSuffix).closest(".k-list-container");
            		comboWidthElement = $("#" + obj.comboId()).prev();
            		containerListElement.css('minWidth', comboWidthElement.innerWidth());
            	}
            }
            catch (err) {
                global.treatError(err);
            }

        }

        function activate() {
            if (!isFirstTimeAfterInit) {
                getLookupAgain();
            }
            isFirstTimeAfterInit = false;
            if (missingItem) {
                addItemToDS(missingItem);
                missingItem = null;
            }
        }
        var dataQuery;

        var list = null;

        function setMaxLengthCode(data) {
            try {
                var dataForSearch = data ? data : obj.dataSource();
                var max = 0;
                if (dataForSearch && dataForSearch.length > 0)
                    if (dataForSearch && dataForSearch.length > 0)
                        max = Enumerable.From(dataForSearch)
                                        .Select(function (lu) { return lu.Code.toString().length })
                                        .Max();

                var spaces = "";
                for (i = 0; max && i < max; i++)
                    spaces = spaces + "&nbsp;&nbsp;";
                obj.completeCodeSpaces(spaces);
            }
            catch (err) {
                global.treatError(err);
            }

        }


        function setOptionLabel(arr) {
           if (obj.optionLabel != false)
               if (arr && obj.optionLabel != false)
                   arr.unshift(obj.optionLabel);
        }

        function getXmlData() {
            if (!global.isNullOrEmpty(obj.extendedData)) {
                var xmlObj = json2xml.convert(obj.extendedData, "Root");//xml:space='preserve'
                xmlObj = xmlObj.replace("<Root", "<Root xml:space='preserve'");
                return xmlObj;
            }
            return '';
        }

        function clearSelectedItem() {
            obj.selectedId(null);
            obj.selectedItem(null);
        }

        function getItemByCode(id) {

            var dataForSearch = global.isNull(obj.dataSource()) ? obj.data()._data : obj.dataSource();
            var item = Enumerable.From(dataForSearch)
                                                   .Where(function (lu) { return lu.Code == id })
                                                   .Select(function (lu) { return lu })
                                                   .FirstOrDefault();
            return item;
        }

        function getItemByUniqueDescript(id) {

            var dataForSearch = global.isNull(obj.dataSource()) ? obj.data()._data : obj.dataSource();
            var item = Enumerable.From(dataForSearch)
                                                   .Where(function (lu) { return lu.Descript == id })
                                                   .Select(function (lu) { return lu })
                                                   .FirstOrDefault();
            return item;
        }

        function retriveDefultItem(setDefault) {
            var item = null;
            if (!global.isNull(obj.lookupName) && !global.isNull(obj.lookupName.extraField) && obj.lookupName.extraField.code == global.enums.lookupExtraField.defaultValue.code) {
                item = lookupManager.getLookupDefaultSelection(obj.lookupName);
            }
            if (global.isNull(item)) {
                var currentDataSource;
                if (!global.isNull(obj.lookupName) && obj.lookupName.mode == global.enums.cacheOrDb.dbMode) {
                    currentDataSource = global.isNull(obj.data()) ? null : obj.data()._data;
                }
                else {
                    currentDataSource = obj.dataSource();
                }
                if (!global.isNull(currentDataSource)) {
                    if (!global.isNull(obj.optionLabel) && obj.optionLabel != false) {
                        if (setDefault) {
                            item = currentDataSource[1];
                        }
                        else {
                            item = obj.optionLabel;
                        }
                    }
                    else {
                        item = currentDataSource[0];
                    }
                }
                else {
                    item = null;
                }
            }
            return item;
        }


        //this function is very precarious !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        //It disrupts the entire logic of the combo!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        //It is intended for cases in which the combo becomes a visual element only. 
        //useage sample: views/reports/searchFilters.
        function mockSelectedItemChanging(item) {//mock item code must be -2.
            if (!global.isNull($("#" + obj.comboId()).data("kendoComboBox"))) {
                $("#" + obj.comboId()).data("kendoComboBox").value(item.Code);
                $("#" + obj.comboId()).data("kendoComboBox").text(item.Descript);
            }
            obj.selectedItem(item);
        }

        function completeFillDataSource(listSource, textStatus) {
            try {
                if (listSource.responseText != global.initiatedError) {
                    var result = jQuery.parseJSON(listSource.responseText);

                    setMaxLengthCode(result);
                    if (global.isNull(obj.selectedItem()) || obj.selectedItem() == false) {
                        if (!global.isNull(obj.selectedId()) && (isAfterInitOrFefresh || obj.isShowPage)) {
                            changeSelectedItemById(obj.selectedId());
                        }
                        else {
                            changeSelectedItem(null);
                        }
                        isAfterInitOrFefresh = false;
                        obj.isShowPage = false;
                    }
                    else {
                        if (isAfterInitOrFefresh || obj.isShowPage == true) {
                            changeSelectedItem(obj.selectedItem());
                        }
                        isAfterInitOrFefresh = false;
                        obj.isShowPage = false;
                    }
                    obj.dfd.resolve();
                }
            }
            catch (err) {
                global.treatError(err);
            }
        }

        function changeSelectedItem(newSelectedItem, selectedIdKoProperty, notAddMissingItem, setDefault, notExecCustomSelectionChanged) {

            if (!global.isNull(selectedIdKoProperty)) {
                obj.selectedId = selectedIdKoProperty;
            }
            if (!global.isNull(newSelectedItem) && newSelectedItem.Code === '' && $.isPlainObject(obj.optionLabel)) {
                newSelectedItem.Descript = obj.optionLabel.Descript;
            }
            if (!global.isNull(newSelectedItem) && newSelectedItem.Code == null && !global.isNOE(newSelectedItem.Descript) && $.isPlainObject(obj.optionLabel)) {
                newSelectedItem.Code = '';
                newSelectedItem.Descript = obj.optionLabel.Descript;
            }

            if (global.isNull(newSelectedItem)) {
                //in case control in grid, ang when open to edit it gets to this event with newSelectedItem==null - need to do nothing! otherwise it had chosen default value before user thought about it.... 
                if (obj.comboInGridSelectionChanged && ((!global.isNull(obj.optionLabel) && obj.optionLabel == false) || global.isNull(obj.optionLabel)))
                    return;
                //the second part of the condition, is becouse may be you send newSelectedItem, 
                //and you want that only if it is null- newSelectedItem will be set to default.
                //useage sample: views/reports/searchFilters/searchFiltersRangePopup.js
                newSelectedItem = retriveDefultItem(setDefault || obj.isSetDefaultValue);
            }
            if (!global.isNull(newSelectedItem)) {
                if (newSelectedItem.Code == -2) {
                    mockSelectedItemChanging(newSelectedItem);
                    obj.prevCode(obj.selectedId());
                    return;
                }
                var result = AddSelectedItemToDataSource(newSelectedItem, notAddMissingItem);
                if (!global.isNull(notAddMissingItem) && notAddMissingItem == true && !result)//empty selected item
                {
                    newSelectedItem.Code = "";
                    newSelectedItem.Descript = "";
                }
                obj.selectedItem(newSelectedItem);
                obj.selectedId(newSelectedItem.Code);
                if (!global.isNull($("#" + obj.comboId()).data("kendoComboBox"))) {
                    $("#" + obj.comboId()).data("kendoComboBox").value(obj.selectedId());
                }
                if (global.isNull(newSelectedItem.Code) || (obj.template != templates.codeOnly && global.isNullOrEmpty(newSelectedItem.Descript)) || (newSelectedItem.Code === "" && !obj.isReadOnly())) {
                    obj.inputText('');
                }
                else {
                    if (obj.template == templates.codeOnly)
                        obj.inputText(newSelectedItem.Code);
                    else if (obj.template == templates.descriptOnly)
                        obj.inputText(newSelectedItem.Descript);
                    else {
                        if (newSelectedItem.Code == "")
                            obj.inputText(newSelectedItem.Descript);
                        else
                            obj.inputText(newSelectedItem.Code + " | " + newSelectedItem.Descript);
                    }
                }
                //eTable logic
                if (!global.isNull(obj.widgetId()) && !global.isNull($("#" + obj.widgetId()).data())) {
                    $("#" + obj.widgetId()).data("kendoComboBox").value(newSelectedItem.Code);
                }
            }
            else {
                if (!global.isNull(obj.optionLabel)) {
                    if (!global.isNull($("#" + obj.comboId()).data("kendoComboBox")))
                        $("#" + obj.comboId()).data("kendoComboBox").value(obj.optionLabel.Code);
                    obj.selectedId(obj.optionLabel.Code);
                    obj.selectedItem(obj.optionLabel);
                    obj.inputText(obj.optionLabel.Descript);
                }
                else {
                    if (!global.isNull($("#" + obj.comboId()).data("kendoComboBox")))
                        $("#" + obj.comboId()).data("kendoComboBox").value("");
                    obj.selectedId(null);
                    obj.selectedItem(null);
                    obj.inputText('');
                }
            }
            if (obj.roInCaseOnlyOneOption && obj.data().data().length == 1) {
                obj.isReadOnly(true);
            }
            if (!global.isNull(newSelectedItem) && notExecCustomSelectionChanged != true) {
                obj.prevCode(obj.selectedId());
                //return - is becouse customSelectionChanged can be asynchronize
                if (obj.comboInGridSelectionChanged) {
                    obj.comboInGridSelectionChanged(newSelectedItem);
                }
                return obj.customSelectionChanged(newSelectedItem);
            }
        }

        function changeSelectedItemOnInit() {
            getLookupAgain();
            changeSelectedItem.apply(this, arguments);
        }

        //get the data for combo from chache or db
        function getLookupData(goToServerAnyCase) {

            if (!global.isNull(obj.lookupName))
                if (obj.lookupName.mode == global.enums.cacheOrDb.cacheMode) {

                    function getLookupFromCache() {


                        var user = global.cache.get(global.enums.cacheItems.USER);

                        if (document.location.toString().indexOf("#reports") >= 0) {
                            webMaxCount = int16Max
                        }
                        dataQuery =
                        {
                            EmpNo: user != null ? user.Id : null,
                            UserNo: user != null ? user.Profile != null ? user.Profile.Code : null : null,
                            ElemName: obj.lookupName.name,
                            PageNo: 1,
                            PageSize: webMaxCount,
                            PagingBy: obj.sortByDescript,
                            PagingOrder: obj.sortDescOrder,
                            SearchBy: 0,
                            SearchVal: '',
                            SearchExact: true,
                            OtherParamsXML: obj.getXmlData()
                        };


                        var deferred = global.system.defer(function(dfd) {
                            $(function() {
                                return lookupManager.getLookup(dfd,
                                    obj.dataSource,
                                    dataQuery,
                                    obj.lookupName,
                                    goToServerAnyCase);
                            });
                        });
                        return deferred.promise();
                    }

                    function getLookupFromCacheResult() {
                        setMaxLengthCode(obj.dataSource());
                        obj.setOptionLabel(obj.dataSource());
                        obj.data().data(obj.dataSource());
                        if (!isAfterGetLookupAgain) {
                            if (global.isNull(obj.selectedItem())) {
                                if (!global.isNull(obj.selectedId()) && isAfterInitOrFefresh) {
                                    changeSelectedItemById(obj.selectedId());
                                } else {
                                    changeSelectedItem(null);
                                }
                            } else {
                                changeSelectedItem(obj.selectedItem());
                            }
                        }
                        isAfterGetLookupAgain = false;
                        obj.dfd.resolve();
                    }

                    var promise = getLookupFromCache();

                    promise.done(getLookupFromCacheResult);


                } else {

                    var searchValue = '';

                    var user = global.cache.get(global.enums.cacheItems.USER);

                    if (document.location.toString().indexOf("#reports") >= 0) {
                        webMaxCount = int16Max
                    }

                    dataQuery =
                    {
                        EmpNo: user != null ? user.Id : null,
                        UserNo: user != null ? user.Profile != null ? user.Profile.Code : null : null,
                        ElemName: obj.lookupName.name,
                        PageNo: 1,
                        PageSize: webMaxCount,
                        PagingBy: obj.sortByDescript,
                        PagingOrder: obj.sortDescOrder,
                        SearchBy: 2,
                        SearchVal: searchValue,
                        SearchExact: true,
                        OtherParamsXML: obj.getXmlData()
                    };


                    var stringQuery = JSON.stringify({
                        GetLookupDataQuery: dataQuery,
                        LookupExtraField: global.isNull(obj.lookupName.extraField)
                            ? null
                            : obj.lookupName.extraField.code

                    });

                    var existsUrl;

                    if (obj.data().transport.options)
                        existsUrl = obj.data().transport.options.read.url;
                    //init datasource url again
                    if (existsUrl) {
                        obj.data().transport.options.read.url =
                            global.webApiConfig.getApiPath(global.enums.httpPath.Lookup.path + "?query=" + stringQuery);
                        obj.data().transport.options.read.complete = completeFillDataSource;
                        obj.data().fetch().done(function() {
                            setMaxLengthCode(obj.data().data());
                            if (global.isNull(obj.selectedItem())) {
                                if (!global.isNull(obj.selectedId()) && isAfterInitOrFefresh) {
                                    changeSelectedItemById(obj.selectedId());
                                }
                                changeSelectedItem(null);
                                isAfterInitOrFefresh = false;
                            } else {
                                if (isAfterInitOrFefresh) {
                                    changeSelectedItem(obj.selectedItem());
                                    isAfterInitOrFefresh = false;
                                }
                            }
                            obj.dfd.resolve();
                        });
                    }
                    //in the first time
                    else {


                        var dataSource = new kendo.data.DataSource({
                            type: "json",
                            serverFiltering: true,
                            transport: {
                                read: {
                                    url: global.webApiConfig.getApiPath(global.enums.httpPath.Lookup.path +
                                        "?query=" +
                                        stringQuery),
                                    complete: completeFillDataSource
                                },
                            },
                            requestEnd: function(e) {
                                try {
                                    setMaxLengthCode(e.response);
                                    obj.setOptionLabel(e.response);
                                } catch (err) {
                                    global.treatError(err);
                                }
                            }
                        });

                        obj.data(dataSource);
                    }
                }

        }


        function bindComboEvents() {


            var combo = $("#" + obj.comboId());
            if (!global.isNullOrEmpty(combo.data("kendoComboBox")) && combo.data("kendoComboBox").wrapper != null)
                combo.data("kendoComboBox").wrapper.find(".k-select").on("mousedown", arrow_mousedown);

            function arrow_mousedown(e) {

                if (obj.data().filter()) {
                    obj.data().filter([]);
                }

            }
        }

        function onChange(itemSender) {
            obj.prevCode(obj.selectedId());
            var searchValue = itemSender.sender.text();
            var selectedItem;
            var selectedId;

            if (global.isNull(this.dataItem())) {
                var existsValue = findItemByText(searchValue);
                if (existsValue) {
                    //select the item
                    if (existsValue == -2) {
                        mockSelectedItemChanging(obj.selectedItem());//if it was mock value- prevent (return old value to the input)
                        return;
                    }
                    itemSender.sender.value(existsValue);
                }
                else {

                    if (global.isNull(obj.selectedItem()) || obj.selectedItem().Code != -2) {//ensure current value is not mockValue
                        if (obj.comboInGridSelectionChanged) {
                            obj.comboInGridSelectionChanged(null, null, true);
                            return;
                        }
                        if (obj.enableAddNewValue) {
                            createAndSelectNewValue(searchValue)
                        }
                        else {
                            changeSelectedItem(obj.selectedItem(), null, null, null, true);
                        }

                        if (!global.isNull($("#" + obj.comboId()).data("kendoComboBox"))) {
                            $("#" + obj.comboId()).data("kendoComboBox").text(obj.template(obj.selectedItem()).replace(new RegExp('&nbsp;', 'g'), ''));
                        }

                        return;
                    }
                    else {
                        if (obj.selectedItem().Code == -2 && obj.preventRemoveDefultValueByX) {
                            mockSelectedItemChanging(obj.selectedItem());//if it was mock value- prevent (return old value to the input)
                        }
                        return;
                    }
                    if (obj.comboInGridSelectionChanged) {
                        obj.comboInGridSelectionChanged(obj.selectedItem(), itemSender, true, this.element.parent().parent());
                    }
                    return;
                }
            }


            if (!global.isNull(this.dataItem())) {
                if (this.dataItem().Code == -2) {
                    mockSelectedItemChanging(obj.selectedItem());
                    return;
                }
                selectedItem = { Code: this.dataItem().Code, Descript: this.dataItem().Descript };
                selectedId = selectedItem.Code;
            }

            obj.selectedItem(selectedItem);
            obj.selectedId(selectedId);
            obj.inputText(!global.isNull(selectedItem) && selectedItem.Code != '' ? selectedItem.Code + ' | ' + selectedItem.Descript : !global.isNull(selectedItem) && !global.isNull(selectedItem.Descript) ? selectedItem.Descript : '');
            if (obj.comboInGridSelectionChanged) {
                obj.comboInGridSelectionChanged(selectedItem, itemSender);
            }

            var fullObject = itemSender.sender.dataSource._data[itemSender.sender.selectedIndex];
            if (global.isNullOrEmpty(fullObject)) {
                fullObject = getItemByCode(obj.selectedId());
            }
            obj.customSelectionChanged(selectedItem, fullObject);


        }

        function findItemByText(text) {
            if (global.isNull(text) || text == "")
                return null;

            for (var i = 0; i < obj.data().view().length ; i++) {
                var item = obj.data().view()[i];
                if (item.Descript == text)
                    return item.Code;
            }
        }
        function findItemById(id) {
            if (global.isNull(id) || id == "")
                return null;

            for (var i = 0; i < obj.data().view().length; i++) {
                var item = obj.data().view()[i];
                if (item.Code == id)
                    return { Code: item.Code, Descript: item.Descript };
            }
        }
        
        function init(goToServerAnyCase) {

            var deferred = global.system.defer(function initPromise(initilizeDfd) {
                obj.dfd = initilizeDfd;

                if (!global.isNull(obj.lookupName) && !obj.isReadOnly() || obj.forceInitData) {
                    //get data for combo
                    if (obj.lookupName.mode == cacheOrDb.byCountMode) {

                        if (document.location.toString().indexOf("#reports") >= 0) {
                            webMaxCount = int16Max
                        }

                        dataQuery =
                         {
                             EmpNo: global.cache.get(global.enums.cacheItems.USER).Id,
                             UserNo: global.cache.get(global.enums.cacheItems.USER).Profile.Code,
                             ElemName: obj.lookupName.name,
                             PageNo: 0,
                             PageSize: webMaxCount,
                             PagingBy: obj.sortByDescript,
                             PagingOrder: obj.sortDescOrder,
                             SearchBy: 2,
                             SearchVal: '',
                             SearchExact: true,
                             OtherParamsXML: obj.getXmlData()
                         };

                        function getCount() {

                            var deferred = global.system.defer(function (dfd) {
                                $(function () {
                                    lookupManager.getCompatibleModeForLookup(dfd, dataQuery, obj, obj.lookupName);
                                });
                            });
                            return deferred.promise();
                        }

                        function result(res) {
                            getLookupData();
                        }
                        var promise = getCount();
                        promise.done(result);



                    }

                    else {
                        getLookupData(goToServerAnyCase);

                    }
                }
                else {
                    initilizeDfd.resolve();
                }
            });
            obj.promise = deferred.promise();
            return obj.promise;
        }

        function clear() {
            obj.dataSource([]);
            obj.data({});
            obj.selectedId(null);
            obj.selectedItem(null);
        }

        function AddSelectedItemToDataSource(selectedItem, notAddMissingItem) {

            var selected = selectedItem || obj.selectedItem();
            if (!(global.isNull(selected)) && !(global.isNull(selected.Code)) && !(global.isNull(selected.Descript))) {
                var item = Enumerable.From(obj.data().data())
                      .Where(function (lu) {
                          return lu.Code == selected.Code
                      })
                      .Select(function (lu) { return lu })
                      .ToArray();

                if (item.length == 0) {
                    if (global.isNull(notAddMissingItem) || notAddMissingItem == false) {
                        missingItem = selected;
                        if (obj.lookupName.mode != cacheOrDb.cacheMode || !lookupManager.checkExistLookup(obj.lookupName) || obj.enableAddNewValue) {
                            addItemToDS(missingItem);
                            missingItem = null;
                        }
                    }
                    return false;
                }
                return true;
            }
            return true;
        };

        function addItemToDS(item) {
            var tempData = obj.data().data();
            if (item.Code != -2) {//not mockValue
                tempData.unshift(item);
            }
            obj.data().data(tempData);
        }

        function changeSelectedItemById(itemCode, selectedIdKoProperty, notExecCustomSelectionChanged, setDefaultIfItemNotExist) {//this function can be used only after initialized
            if (!global.isNull(selectedIdKoProperty)) {
                obj.selectedId = selectedIdKoProperty;
            }
            if (initializeCalled) {
                var selectedItem = getItemByCode(itemCode);
                return changeSelectedItem(selectedItem, null, null, setDefaultIfItemNotExist, notExecCustomSelectionChanged);
            }
            else {
                throw Error('initializing has not finished yet, you cannot use this function.');
            }
        }

        function changeSelectedItemByIdOnInit() {
            getLookupAgain();
            changeSelectedItemById.apply(this, arguments);
        }

        function initialize(options) {
            isFirstTimeAfterInit = true;
            initializeCalled = true;
            isAfterInitOrFefresh = true;
            obj.selectedItem(null);
            obj.selectedId(null);
            if (options.dataSource) {
                clear();
            }
            clearInput();
            if (options.setDefaultValueParameter == true) {
                obj.isSetDefaultValue = true;
            }
            else {
                obj.isSetDefaultValue = false;
            }
            var size = $(window).width();

            if (global.isNull(options.width)) {
                obj.comboWidth('198px');
            }
            else {
                obj.comboWidth(options.width);
            }
            if (!global.isNull(options.isAdjustDropDownWidth)) {
            	obj.isAdjustDropDownWidth = options.isAdjustDropDownWidth;
            }
            if (!global.isNull(options.isReadOnly)) {
                obj.isReadOnly(options.isReadOnly);
            }
            if (!global.isNull(options.lookupName)) {
                obj.cacheMode = options.lookupName.mode;
            }
            obj.lookupName = options.lookupName;
            obj.extendedData = options.extendedData;
            obj.comboId(options.comboId);

            if (!global.isNull(options.sortByDescript))
                obj.sortByDescript = options.sortByDescript == '1';
            if (!global.isNull(options.sortDescOrder))
                obj.sortDescOrder = options.sortDescOrder;
            if (options.needLookupButton == true) {
                obj.needOpenLookupScreen(options.needLookupButton);
            }
            if (options.needEtableButton) {
                eTableParams.eTableCodeColumn = options.eTableCodeColumn;
                eTableParams.eTableDescriptColumn = options.eTableDescriptColumn;
                eTableParams.eTableFormId = options.eTableFormId;
                obj.needEtableButton(true);
            }
            if (options.selectedIdKoProperty != null) {
                obj.selectedId = options.selectedIdKoProperty;
            }
            if (options.selectedItemKoProperty != null) {
                obj.selectedItem = options.selectedItemKoProperty;
            }
            if (options.optionLabel != null) {
                obj.optionLabel = { Code: '', Descript: options.optionLabel };
            }
            if (!global.isNull(options.template)) {
                obj.template = templates[options.template];
            }
            if (options.forceInitData)
                obj.forceInitData = options.forceInitData;
            obj.enableAddNewValue = options.enableAddNewValue;
            obj.roInCaseOnlyOneOption = options.roInCaseOnlyOneOption;
            
            if (options.dataSource) {
                obj.dataSource(options.dataSource);
                var dataSource = new kendo.data.DataSource({
                    serverFiltering: false,
                    data: options.dataSource
                });
                obj.data(dataSource);
                obj.data().data(options.dataSource);
                return init();
            }

            if (!global.isNull(obj.lookupName) && options.lookupName.dependent != true || options.dependent != null) {
                // options.dependent param, is for case you want dependent-lookup to behavior like independent. useage sample: organization-tree-level, workCenter level
                return init();//init func return promise
            }
            else {
                return global.getEmptyPromise();
            }
        };

        function openLookupScreen() {
            require(
                   ["pages/lookupDB/lookupDB"],
                   function showLookupPopupAfterRequirePopupModule(lookupDB) {
                       try {
                           global.showDialog(new lookupDB(false, obj.selectedItem(), obj.lookupName, obj.extendedData))
                               .then(function (response) {
                                   if (response != null) {
                                       changeSelectedItem(response);
                                       // vm.operAutoComplete.customSelectionChanged = function () { refreshLinkedComboes(vm.operAutoComplete); }
                                       // if( obj.customSelectionChanged!=function () { refreshLinkedComboes(obj); }) 
                                       if (obj.extendedData && global.isNullOrEmpty(obj.extendedData.isTaskRep))
                                           obj.customSelectionChanged();
                                   }
                               });
                       }
                       catch (err) {
                           global.treatError(err);
                       }
                   });

        }

        function openETableScreen() {
            require(
                     ["views/combinedControls/eTable/eTable"],
                     function showETablePopupAfterRequireModule(eTableVM) {
                         try {

                             global.showDialog(new eTableVM(eTableParams.eTableFormId, obj.isComboInETableGrid, obj.getXmlData(), obj.selectedId()))
                                 .then(function handleeTableScreenClosedResult(response, isSelectedDeleted) {
                                     changeSelectedItem(null);
                                     if (obj.isComboInETableGrid) {
                                         if (!global.isNull(response)) {
                                             initializeForETable({},
                                                 { Code: response[eTableParams.eTableCodeColumn], Descript: response[eTableParams.eTableDescriptColumn] });
                                         }
                                         else {
                                             initializeForETable({});
                                         }
                                     }
                                     else {
                                         init(true).done(function () {
                                             if (!global.isNull(response)) {
                                                 changeSelectedItem({ Code: response[eTableParams.eTableCodeColumn], Descript: response[eTableParams.eTableDescriptColumn] });
                                                 if (obj.isComboInETableGrid == true) {
                                                 }
                                             }
                                         });
                                     }
                                 });
                         }
                         catch (err) {
                             global.treatError(err);
                         }
                     });
        }

        function refreshWithNewExtendedData(extendedData) {
            obj.selectedItem(null);
            isAfterInitOrFefresh = true;
            obj.extendedData = extendedData;


            return init();//.done(function changeSelectedItemAfterRefreshWithNewXml() {
            //    //must do it after init done, bcouse of if combo not have optionLebel,
            //    //so changeSelectedItem(null) - select the first item.
            //    //we need to select the first item of the new data
            //    if (global.isNull(obj.selectedItem())) {
            //        changeSelectedItem(null, null, null, obj.isSetDefaultValue);
            //    }
            //    else {
            //    }
            //});
        }


        function refreshExendedDataWithoutChangingSelectedItem(extendedData) {
            isAfterInitOrFefresh = true;
            obj.extendedData = extendedData;
            return init();
        }

        function sortDataWithCustomDefinitions(mode, direction) {
            obj.sortByDescript = mode.value;
            obj.sortDescOrder = direction.value;
            return init();
        }

        function initializeForETable(options, newSelectedItem) {
            obj.isComboInETableGrid = true;
            if (!global.isNull(options.needLookupButton)) {
                obj.needOpenLookupScreen = options.needLookupButton;
            }
            var dataQuery = {
                UserNo: global.cache.get(global.enums.cacheItems.USER).Profile.Code,
                QueryText: options.queryText,
                QueryType: options.queryType,
                CodeColumn: options.codeColumn,
                DescriptColumn: options.descriptColumn,
                XMLData: options.extendedData ? '<Root>' + options.extendedData + '</Root>' : null
            }

            if (options.needEtableButton) {
                eTableParams.eTableCodeColumn = options.eTableCodeColumn;
                eTableParams.eTableDescriptColumn = options.eTableDescriptColumn;
                eTableParams.eTableFormId = options.eTableFormId;
                obj.needEtableButton(true);
            }
            var dataSource = new kendo.data.DataSource({
                type: "json",
                serverFiltering: true,
                transport: {
                    read: {
                        url: global.webApiConfig.getApiPath(global.enums.httpPath.GetETableComboData.path + "?query=" + JSON.stringify(dataQuery))
                    },
                },
                requestEnd: function (e) {
                    try {
                        obj.setOptionLabel(e.response);
                        setMaxLengthCode(e.response);
                        if (!global.isNull(newSelectedItem)) {
                            changeSelectedItem(newSelectedItem);
                        }
                    }
                    catch (err) {
                        global.treatError(err);
                    }
                }
            });
            obj.data(dataSource);
        }

        function clearInput() {
            if (!global.isNull($("#" + obj.comboId()).data("kendoComboBox"))) {
                $("#" + obj.comboId()).data("kendoComboBox").text('');
            }
        }

        function refreshWithOtherLookupname(lookupName) {
            obj.lookupName = lookupName;
            return init(true);
        }
        function getLookupAgain() {
            if (obj.lookupName.mode == cacheOrDb.cacheMode) {
                if (lookupManager.checkExistLookup(obj.lookupName)) {
                    isAfterGetLookupAgain = true;
                    init();
                }
            }
        }
        function getLookupDataFromDb() {
            init(true);
        }
        function createAndSelectNewValue(value) {
            var newItem = { Code: '', Descript: '' };
            switch (obj.template) {
                case templates.codeOnly:
                case templates.descriptOnly:
                    newItem.Code = value;
                    newItem.Descript = value;
                    break;
                case templates.codeDescript:
                default:
                    newItem.Code = -3;
                    newItem.Descript = value;
                    break;
            }
            AddSelectedItemToDataSource(newItem);
            changeSelectedItem(newItem);
        }
        return obj;
    }
    ViewModel.optionLabelEnum = optionLabelEnum;
    return ViewModel;
});