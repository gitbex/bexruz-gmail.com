﻿define(function permissionsModule(require) {
    var cache = require('common/cache/cacheManager');

    ko.bindingHandlers.permission = {
        init: function (element, valueAccessor, allBindingsAccessor, viewModel, bindingContext) {
            var accessType = findAccessType(element, valueAccessor, allBindingsAccessor, viewModel, bindingContext)
            handleElementByPermission(element, accessType);
        },
        update: function (element, valueAccessor, allBindingsAccessor, viewModel, bindingContext) {
            var accessType = findAccessType(element, valueAccessor, allBindingsAccessor, viewModel, bindingContext)
            handleElementByPermission(element, accessType);

        }
    };

    function handleElementByPermission(element, accessType) {
        switch (accessType) {
            case cache.enums.accessType.notVisible.code:
                $(element).addClass("notVisible");

                $(element).find('INPUT,BUTTON').not('.permNotInherit').removeAttr("disabled")
                $(element).removeClass("readonly");
                if ($(element).is("INPUT") || $(element).is("span")) {
                    $(element).removeAttr('disabled');
                    //changeImgSrc(false, element);
                }
                break;
            case cache.enums.accessType.readonly.code:
                $(element).find('INPUT,BUTTON,textarea, .k-dropdown, .k-dropdown span').not('.permNotInherit').attr('disabled', 'disabled');
                $(element).addClass("readonly");
                $.each($(element).find(":image").not('.permNotInherit'), function changeImagesSrc(i, elementImg) {
                    $(elementImg).addClass("disabledWithoutBgColor");
                    changeImgSrc(true, elementImg);
                });
                $(element).find(".linkByPerm").addClass("disabled");
                if ($(element).is("INPUT") || $(element).is("span")) {
                    $(element).attr('disabled', 'disabled');
                    if ($(element).is(":image") && !$(element).hasClass('permNotInherit')) {
                        $(element).addClass("disabledWithoutBgColor");
                        changeImgSrc(true, element);
                    }

                }
                if ($(element).is(".linkByPerm")) {
                    $(element).addClass("disabled");
                }
                $(element).removeClass("notVisible");                

                var boundElems = $(element).find("[data-bind]");                
                $.each(boundElems, function changeElementAllow(i, subElement) {
                    var bindingStr = $(subElement).attr('data-bind');
                    if (bindingStr.indexOf('autoComplete') > -1 ||
                        bindingStr.indexOf('combo') > -1 ||
                        bindingStr.indexOf('datePicker') > -1 ||
                        bindingStr.indexOf('timeInput') > -1 ||
                        bindingStr.indexOf('numericTextBox') > -1 ||
                        bindingStr.indexOf('colorPickerSlider') > -1 ||
                        bindingStr.indexOf('multiSelect') > -1 ||
                        bindingStr.indexOf('selectDirectory') > -1 ||
                        bindingStr.indexOf('selectFile') > -1 ||
                        bindingStr.indexOf('uploadUC') > -1)
                        $(subElement).addClass('notRelevant');
                });               
                break;
            case cache.enums.accessType.autoApproval.code:
                $(element).find('INPUT,BUTTON').not('.permNotInherit').removeAttr("disabled")
                $(element).removeClass("readonly");
                $(element).removeClass("notVisible");
                if ($(element).is("INPUT") || $(element).is("span")) {
                    $(element).removeAttr('disabled');
                    //changeImgSrc(false, element);
                }
                break;
            default:
                $(element).removeAttr('disabled');
                $(element).removeClass("readonly");
                $(element).removeClass("notVisible");
                changeImgSrc(false, element);
        }
    }

    function changeImgSrc(needToDisable, element) {
        var src = $(element).attr('src');

        if (!src) {
            return false;
        }
        var versionIndex = '?v=';
        var version = src.split(versionIndex).pop();
        src = src.substr(0, src.lastIndexOf('?v='));
        var ext = src.split('.').pop();
        var newSrc = src.substr(0, src.lastIndexOf('.'));

        if (needToDisable == true) {
            if (newSrc.lastIndexOf('_disable') == -1)//image src is enabled - need to change to disabled src 
                newSrc = newSrc + '_disable.' + ext + versionIndex + version;
            else
                newSrc = src + versionIndex + version;
        }
        else {
            if (newSrc.lastIndexOf('_disable') == -1) {
                newSrc = src + versionIndex + version;
            }
            else {
                newSrc = (newSrc.substr(0, newSrc.lastIndexOf('_disable'))) + '.' + ext + versionIndex + version;
            }
        }
        $(element).attr('src', newSrc);



        //if (needToDisable == true) {
        //    if (src.indexOf('?') > 0) {//src is by condition
        //        newSrc = src.substring(src.indexOf(':') + 1, src.length);
        //    }
        //    else {
        //        newSrc = src + 'Disable';
        //    }
        //}
        //else {
        //    if (src.lastIndexOf('Disable') > -1) {
        //        newSrc = src.substring(0, src.length - 7);
        //    }
        //}
        //bindString = bindString.replace(src, newSrc);
        //$(element).data('bind', bindString);
    }


    function findAccessType(element, valueAccessor, allBindingsAccessor, viewModel, bindingContext) {
        var findAccessTypeForSpesificAttr = function (permissionAttribute, getAccessTypeFunc) {
            var specificAccessType = "";
            if (element.hasAttribute(permissionAttribute)) {
                var code = $(element).attr(permissionAttribute);
                if (viewModel.hasOwnProperty(code)) {
                    codeValue = jQuery.isFunction(viewModel[code]) ? viewModel[code]() : viewModel[code];
                    if (codeValue == cache.enums.permissionCodes.NO_PERMISSION.code)
                        specificAccessType = cache.enums.accessType.visible.code;
                    else if (codeValue == cache.enums.permissionCodes.ALWAYS_READ_ONLY.code)
                        specificAccessType = cache.enums.accessType.readonly.code;
                    else if (codeValue == cache.enums.permissionCodes.ALWAYS_NOT_VISIBLE.code)
                        specificAccessType = cache.enums.accessType.notVisible.code;
                    else
                        specificAccessType = getAccessTypeFunc(codeValue);

                }
            }
            return specificAccessType;
        }

        var permissionAccessType = findAccessTypeForSpesificAttr("permissionCode", getPermissionsAccessType);
        var companyAccessType = findAccessTypeForSpesificAttr("companyParamName", getCompanyPermissionsAccessType);
        var selfOnlyAccessType = findAccessTypeForSpesificAttr("checkSelfOnly", getSelfOnlyAccessType); //if the element depends on web user profile(9999):
        var companyPreferencePermissionAccessType = findAccessTypeForSpesificAttr("companyPreferenceName", getCompanyPreferencePermissionAccessType); //if the element depends on company Preference:          

        var accessType = null;

        accessType = permissionAccessType ? permissionAccessType : (companyAccessType ? companyAccessType : (selfOnlyAccessType ? selfOnlyAccessType : companyPreferencePermissionAccessType));
        var allAccessType = [permissionAccessType, companyAccessType, selfOnlyAccessType, companyPreferencePermissionAccessType]
        if (allAccessType.indexOf(cache.enums.accessType.notVisible.code) >= 0)
            accessType = cache.enums.accessType.notVisible.code;
        else if (allAccessType.indexOf(cache.enums.accessType.readonly.code) >= 0)
            accessType = cache.enums.accessType.readonly.code;

        return accessType;
    }

    function getCompanyPermissionsAccessType(paramName) {
        var accessType = cache.enums.accessType.notVisible.code;
        $.each(cache.get(cache.enums.cacheItems.COMPANY_PERMISSIONS), function (key, val) {
            if (val.Code == paramName) {
                accessType = val.AccessType;
                return false;//to stop the each
            }
        });
        return accessType;
    }

    function getCompanyPreferencePermissionAccessType(preferenceName) {

        if (preferenceName == cache.enums.companyPreferencesNames.alwaysReadOnly.name)
            return cache.enums.accessType.readonly.code;

        var accessType = cache.enums.accessType.notVisible.code;
        $.each(cache.get(cache.enums.cacheItems.COMPANY_PREFERENCES_PERMISSIONS), function (key, val) {
            if (val.Code == preferenceName) {
                accessType = val.AccessType;
                return false;//to stop the each
            }
        });
        return accessType;
    }

    function getSelfOnlyAccessType(state) {
        var accessType = cache.enums.accessType.notVisible.code;
        var profile = cache.get(cache.enums.cacheItems.USER).Profile.Code;
        if (profile == cache.enums.SystemUsers.WebUser.code) {
            if (state == cache.enums.selfOnlyState.SelfOnlyVisible.name)
                accessType = cache.enums.accessType.notVisible.code;
            else if (state == cache.enums.selfOnlyState.SelfOnlyReadonly.name)
                accessType = cache.enums.accessType.readonly.code;
        }
        else
            accessType = cache.enums.accessType.visible.code;
        return accessType;
    }


    function getPermissionsAccessType(code) {
        var accessType = cache.enums.accessType.notVisible.code;
        if (!cache.get(cache.enums.cacheItems.USER))
            return accessType;
        if (cache.get(cache.enums.cacheItems.USER).Profile.Code == 0)
            return cache.enums.accessType.visible.code;

        $.each(cache.get(cache.enums.cacheItems.USER).Permissions, function (key, val) {
            if (val.Code == code) {
                accessType = val.AccessType;
                return false;//to stop the each
            }
        });
        return accessType;
    }

    function getPermissionsAccessTypeName(code) {
        var permission = getPermissionsAccessType(code);
        switch (permission) {
            case 1:
                return 'readonly';
            case 3:
                return 'notVisible';
            default:
                return 'visible';
        }
    }

    function isVisible(permissionCode) {
        var existPermissionCode = 0;
        if (!cache.get(cache.enums.cacheItems.USER)) {
            return false;
        }

        if (permissionCode == cache.enums.permissionCodes.ALWAYS_NOT_VISIBLE.code)
            return false;

        if (permissionCode == cache.enums.permissionCodes.ALWAYS_READ_ONLY.code)
            return true;

        if (permissionCode == cache.enums.permissionCodes.NO_PERMISSION.code)
            return true;
     
        $.each(cache.get(cache.enums.cacheItems.USER).Permissions, function (key, val) {
            if (val.Code == permissionCode) {
                existPermissionCode = 1;
                return false;//to stop the each
            }
        });
        if (existPermissionCode == 0)
        	return false;

        if (cache.get(cache.enums.cacheItems.USER).Profile.Code == 0)
        	return true;

        return true;       
    }

    function isVisibleCompanyParam(companyParam) {

        var existCompanyPermission = 0;

        $.each(cache.get(cache.cacheItems.COMPANY_PERMISSIONS), function (key, val) {
            if (val.Code == companyParam) {
                existCompanyPermission = val.AccessType == 3 ? 0 : 1;
                return false;//stop each
            }
        });
        if (existCompanyPermission == 0)
            return false;
        return true;
    }

    function isVisibleCompanyPreference(companyPreference) {

        var existCompanyPreference = 0;

        $.each(cache.get(cache.cacheItems.COMPANY_PREFERENCES_PERMISSIONS), function (key, val) {
            if (val.Code == companyPreference) {
                existCompanyPreference = val.AccessType == 3 ? 0 : 1;
                return false;//stop each
            }
        });
        if (existCompanyPreference == 0)
            return false;
        return true;
    }

    function isReadOnlyCompanyPreference(companyPreference) {

        var isReadonlyFlag = 0;

        $.each(cache.get(cache.cacheItems.COMPANY_PREFERENCES_PERMISSIONS), function (key, val) {
            if (val.Code == companyPreference) {
                if (val.AccessType == cache.enums.accessType.readonly.code)
                    isReadonlyFlag = 1;
                return false;//to stop the each
            }
        });
        if (isReadonlyFlag == 0)
            return false;
        return true;
    }


    function isReadonly(permissionCode) {
        if (cache.get(cache.enums.cacheItems.USER).Profile.Code == 0)
            return false;

        if (permissionCode == cache.enums.permissionCodes.ALWAYS_READ_ONLY.code)
            return true;

        if (permissionCode == cache.enums.permissionCodes.ALWAYS_NOT_VISIBLE.code)
            return true;

        if (permissionCode == cache.enums.permissionCodes.NO_PERMISSION.code)
            return false;

        var isReadonlyFlag = 0;
        $.each(cache.get(cache.enums.cacheItems.USER).Permissions, function (key, val) {
            if (val.Code == permissionCode) {
                if (val.AccessType == cache.enums.accessType.readonly.code || val.AccessType == cache.enums.accessType.managerApprovalReadOnly.code)
                    isReadonlyFlag = 1;
                return false;//to stop the each
            }
        });
        if (isReadonlyFlag == 0)
            return false;
        return true;
    }

    function isAutoApproval(permissionCode) {
        var isAutoApprovalFlag = 0;
        $.each(cache.get(cache.enums.cacheItems.USER).Permissions, function (key, val) {
            if (val.Code == permissionCode) {
                if (val.AccessType == cache.enums.accessType.autoApproval.code)
                    isAutoApprovalFlag = 1;
                return false;//to stop the each
            }
        });
        if (isAutoApprovalFlag == 0)
            return false;
        return true;
    }
    function isSuperVisor() {
        if (cache.get(cache.enums.cacheItems.USER).Profile.Code == 0)
            return true;
        return false;
    }
    function getCompanyParam(paramName) {
        var ans = 0;
        $.each(cache.get(cache.enums.cacheItems.COMPANY_PARAMS), function (key, val) {
            if (val.FieldName == paramName) {
                ans = val.fieldvalue;
                return false;
            }
        });
        return ans;
    }

    function isManagerApproval(permissionCode) {//14
        if (cache.get(cache.enums.cacheItems.USER).Profile.Code == 0)
            return true;

        if (permissionCode == cache.enums.permissionCodes.ALWAYS_READ_ONLY.code)
            return false;

        if (permissionCode == cache.enums.permissionCodes.ALWAYS_NOT_VISIBLE.code)
            return false;

        if (permissionCode == cache.enums.permissionCodes.NO_PERMISSION.code)
            return false;

        var flag = 0;
        $.each(cache.get(cache.enums.cacheItems.USER).Permissions, function (key, val) {
            if (val.Code == permissionCode) {
                if (val.AccessType == cache.enums.accessType.managerApproval.code || val.AccessType == cache.enums.accessType.managerApprovalReadOnly.code)
                    flag = 1;
                return false;//to stop the each
            }
        });
        if (flag == 0)
            return false;
        return true;
    }

    var vm = {
        isSuperVisor: isSuperVisor,
        isVisible: isVisible,
        isVisibleCompanyParam: isVisibleCompanyParam,
        isReadonly: isReadonly,
        isAutoApproval: isAutoApproval,
        getCompanyParam: getCompanyParam,
        isVisibleCompanyPreference: isVisibleCompanyPreference,
        isReadOnlyCompanyPreference: isReadOnlyCompanyPreference,
        getPermissionsAccessTypeName: getPermissionsAccessTypeName,
        isManagerApproval: isManagerApproval,
        handleElementByPermission: handleElementByPermission
    }
    return vm;
});
