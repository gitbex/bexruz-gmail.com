﻿define(function datacontextModule(require) {
    var model = require('data/model');
    var clientModel = require('data/clientModel');
    var webApiConfig = require('common/webApiConfig');

    var queryOptions = new breeze.QueryOptions({
        mergeStrategy: breeze.MergeStrategy.OverwriteChanges
    });

    var dataService = new breeze.DataService({
        serviceName: (webApiConfig.port.lastIndexOf('/') == (webApiConfig.port.length - 1)) ? webApiConfig.port + "breeze/eHarmonyBreezeData" : webApiConfig.port + "/breeze/eHarmonyBreezeData",
        hasServerMetadata: false // don't ask the server for metadata
    });

    var validationOptions = new breeze.ValidationOptions({
        validateOnAttach: false,
        validateOnSave: true,
        validateOnQuery: false
    });

    var manager;
    var clientManager;

    var datacontext = {
        metadataStore: null,
        getEmployeeDataById: getEmployeeDataById,
        getEmployeeHistoryDataByIdAndDate: getEmployeeHistoryDataByIdAndDate,
        getTaskByNumerator: getTaskByNumerator,
        getWorkRulePayCode: getWorkRulePayCode,
        getWorkRuleDayType: getWorkRuleDayType,
        getDistributionList: getDistributionList,
        getDistributionListDetails:getDistributionListDetails,
        getWorkRulesCASickPay: getWorkRulesCASickPay,
        getWorkRuleConsecutiveAbsence: getWorkRuleConsecutiveAbsence,
        getWorkScheduleDayByDateAndShift: getWorkScheduleDayByDateAndShift,
        getTimeClassificationAbsenceByCode: getTimeClassificationAbsenceByCode,
        getTimeClassificationGeneralAndQuotaByCode: getTimeClassificationGeneralAndQuotaByCode,
        getWorkRuleQuotaByCode: getWorkRuleQuotaByCode,
        getWorkRuleQuotaSeniorityByCode: getWorkRuleQuotaSeniorityByCode,
        getManagementOTPByEmpNo:getManagementOTPByEmpNo,
        getWorkRuleBalanceTimeClassByCode: getWorkRuleBalanceTimeClassByCode,
        getTemplateDefById: getTemplateDefById,     
        saveModifiedEntity: saveModifiedEntity,
        createEntity: createEntity,
        clearEntity: clearEntity,
        deleteEntity: deleteEntity,
        saveAllChanges: saveAllChanges,
        validateEntity: validateEntity,
        validateAll: validateAll,
        createClientEntity: createClientEntity,
        clientMetadataStore: null,
        initialMetadataStore: initialMetadataStore,
        clearMetadataStore: clearMetadataStore,
        createInstance: createInstance,
        createClientInstance: createClientInstance,
        unWrapObject: unWrapObject
    };

    initBreezeManagers();
    clientModel.initialClientModelTypes(datacontext);

    //we call it after login when we know the selected language
    function initialMetadataStore() {
        //add models types
        model.initialMetadataStore(datacontext);
        //add client models types
        clientModel.initialMetadataStore(datacontext);
    }

    //we call it after login logout 
    function clearMetadataStore() {
        initBreezeManagers();
        clientModel.initialClientModelTypes(datacontext);
    }

    function initBreezeManagers() {
        manager = new breeze.EntityManager({
            dataService: dataService,
            validationOptions: validationOptions,
            queryOptions: queryOptions
        });
        datacontext.metadataStore = manager.metadataStore;
        manager.enableSaveQueuing(true);

        clientManager = new breeze.EntityManager({ validationOptions: validationOptions });
        datacontext.clientMetadataStore = clientManager.metadataStore;
    }

    return datacontext;

    //#region Private Members

    function getEmployeeDataById(empNo) {
        var param = JSON.stringify({
            EmpNo: empNo
        });
        return breeze.EntityQuery
            .from("Employee")
            .withParameters({ query: param })
            .using(manager).execute()
            .then(getEmployeeSucceeded)
        .fail(getEmployeeFail)

        function getEmployeeSucceeded(data) {
            return data.results[0];
        }

        function getEmployeeFail(err) {
            var e = err;
        }
    }

    function getTaskByNumerator(getTaskQuery) {
        var param = JSON.stringify(getTaskQuery);
        return breeze.EntityQuery
            .from("Tasks")
            .withParameters({ query: param })
            .using(manager).execute()
            .then(getTaskSucceeded)
        .fail(getTaskFail)

        function getTaskSucceeded(data) {
            return data.results[0];
        }

        function getTaskFail(err) {
            var e = err;
        }
    }

    function getWorkRuleConsecutiveAbsence(quety) {
        var param = JSON.stringify(quety);
        return breeze.EntityQuery
            .from("ConsecutiveAbsence")
            .withParameters({ query: param })
            .using(manager).execute()
            .then(getConsecutiveAbsenceSucceeded)
            .fail(getConsecutiveAbsenceFail)

        function getConsecutiveAbsenceSucceeded(data) {
            return data.results[0];
        }

        function getConsecutiveAbsenceFail(err) {
            var e = err;
        }
    }

    function getWorkRulesCASickPay(quety) {
        var param = JSON.stringify(quety);
        return breeze.EntityQuery
            .from("SickPay")
            .withParameters({ query: param })
            .using(manager).execute()
            .then(getWorkRulesCASickPaySucceeded)
            .fail(getWorkRulesCASickPayFail)

        function getWorkRulesCASickPaySucceeded(data) {
            return data.results[0];
        }
        function getWorkRulesCASickPayFail(err) {
            var e = err;
        }
    }

    function getDistributionListDetails(quety) {
        var param = JSON.stringify(quety);
        return breeze.EntityQuery
            .from("DistributionListDetails")
            .withParameters({ query: param })
            .using(manager).execute()
            .then(getDistributionListDetailsSucceeded)
            .fail(getDistributionListDetailsFail)

        function getDistributionListDetailsSucceeded(data) {
            return data.results[0];
        }

        function getDistributionListDetailsFail(err) {
            var e = err;
        }
    }

    function getDistributionList(quety) {
        var param = JSON.stringify(quety);
        return breeze.EntityQuery
            .from("DistributionList")
            .withParameters({ query: param })
            .using(manager).execute()
            .then(getDistributionListSucceeded)
            .fail(getDistributionListFail)

        function getDistributionListSucceeded(data) {
            return data.results[0].DistributionList[0];
        }

        function getDistributionListFail(err) {
            var e = err;
        }
    }

    function getWorkRuleDayType(quety) {
        var param = JSON.stringify(quety);
        return breeze.EntityQuery
            .from("DayType")
            .withParameters({ query: param })
            .using(manager).execute()
            .then(getDayTypeSucceeded)
            .fail(getDayTypeFail)

        function getDayTypeSucceeded(data) {
            return data.results[0];
        }

        function getDayTypeFail(err) {
            var e = err;
        }
    }

    function getWorkRulePayCode(query) {
        var param = JSON.stringify(query);
        return breeze.EntityQuery
            .from("PayCode")
            .withParameters({ query: param })
            .using(manager).execute()
            .then(getPayCodeSucceeded)
            .fail(getPayCodeFail)

        function getPayCodeSucceeded(data) {
            return data.results[0];
        }

        function getPayCodeFail(err) {
            var e = err;
        }
    }

    function getWorkScheduleDayByDateAndShift(getWorkScheduleDayQuery) {
        var param = JSON.stringify(getWorkScheduleDayQuery);
        return breeze.EntityQuery
            .from("WorkScheduleDays")
            .withParameters({ query: param })
            .using(manager).execute()
            .then(getWorkScheduleDaysSucceeded)
        .fail(getWorkScheduleDaysFail)

        function getWorkScheduleDaysSucceeded(data) {
            return data.results[0];
        }

        function getWorkScheduleDaysFail(err) {
            var e = err;
        }
    }

    function getTimeClassificationAbsenceByCode(getTimeClassificationByCodeQuery) {
        var param = JSON.stringify(getTimeClassificationByCodeQuery);
        return breeze.EntityQuery
            .from("TimeClassificationAbsence")
            .withParameters({ query: param })
            .using(manager).execute()
            .then(getTimeClassificationByCodeSucceeded)
        .fail(getTimeClassificationByCodeFail)

        function getTimeClassificationByCodeSucceeded(data) {
            return data.results[0];
        }

        function getTimeClassificationByCodeFail(err) {
            var e = err;
        }
    }

    function getTimeClassificationGeneralAndQuotaByCode(getTimeClassificationByCodeQuery) {
        var param = JSON.stringify(getTimeClassificationByCodeQuery);
        return breeze.EntityQuery
            .from("TimeClassificationGeneralAndQuota")
            .withParameters({ query: param })
            .using(manager).execute()
            .then(getTimeClassificationByCodeSucceeded)
        .fail(getTimeClassificationByCodeFail)

        function getTimeClassificationByCodeSucceeded(data) {
            return data.results[0];
        }

        function getTimeClassificationByCodeFail(err) {
            var e = err;
        }
    }

    function getWorkRuleQuotaByCode(query) {
        var param = JSON.stringify(query);
        return breeze.EntityQuery
            .from("Quota")
            .withParameters({ query: param })
            .using(manager).execute()
            .then(getWorkRuleQuotaByCodeSucceeded)
            .fail(getWorkRuleQuotaByCodeFail)

        function getWorkRuleQuotaByCodeSucceeded(data) {
            return data.results[0];
        }

        function getWorkRuleQuotaByCodeFail(err) {
            var e = err;
        }
    }

    function getWorkRuleQuotaSeniorityByCode(query) {
        var param = JSON.stringify(query);
        return breeze.EntityQuery
            .from("QuotaSeniority")
            .withParameters({ query: param })
            .using(manager).execute()
            .then(getWorkRuleQuotaByCodeSenioritySucceeded)
            .fail(getWorkRuleQuotaByCodeSeniorityFail)

        function getWorkRuleQuotaByCodeSenioritySucceeded(data) {
            return data.results[0];
        }

        function getWorkRuleQuotaByCodeSeniorityFail(err) {
            var e = err;
        }
    }

    function getWorkRuleBalanceTimeClassByCode(query) {
        var param = JSON.stringify(query);
        return breeze.EntityQuery
            .from("BalanceTimeClass")
            .withParameters({ query: param })
            .using(manager).execute()
            .then(getWorkRuleBalanceTimeClassByCodeSucceeded)
            .fail(getWorkRuleBalanceTimeClassByCodeFail)

        function getWorkRuleBalanceTimeClassByCodeSucceeded(data) {
            return data.results[0];
        }

        function getWorkRuleBalanceTimeClassByCodeFail(err) {
            var e = err;
        }
    }
    
    function getManagementOTPByEmpNo(query) {
        var param = JSON.stringify(query);
        return breeze.EntityQuery
            .from("ManagementOTP")
            .withParameters({ query: param })
            .using(manager).execute()
            .then(getManagementOTPByEmpNoSucceeded)
            .fail(getManagementOTPByEmpNoFail)

        function getManagementOTPByEmpNoSucceeded(data) {
            return data.results[0].Items[0];
        }

        function getManagementOTPByEmpNoFail(err) {
            var e = err;
        }
    }

    function createInstance(typeName) {
        var instanceType = datacontext.metadataStore.getEntityType(typeName);
        return instanceType.createInstance();
    }

    function createClientInstance(typeName, initialValues) {
        var instanceType = datacontext.clientMetadataStore.getEntityType(typeName);
        return instanceType.createInstance(initialValues);
    }

    function getEmployeeHistoryDataByIdAndDate(empNo, date, isNew) {
        var param = JSON.stringify({
            EmpNo: empNo,
            Date: date,
            IsNew: isNew
        });
        return breeze.EntityQuery
            .from("EmployeeHistory")
            .withParameters({ query: param })
            .using(manager).execute()
            .then(getEmployeeHistorySucceeded)
        .fail(getEmployeeHistoryFail)

        function getEmployeeHistorySucceeded(data) {
            return data.results[0];
        }

        function getEmployeeHistoryFail(err) {
            var e = err;
        }
    }

    function getTemplateDefById(patternNo) {
        var param = JSON.stringify(patternNo);
        return breeze.EntityQuery
            .from("GetMaintenanceTemplateDefinitionData")
            .withParameters({ query: param })
            .using(manager).execute()
            .then(getTemplateSucceeded)
            .fail(getTemplateFail)

        function getTemplateSucceeded(data) {
            return data.results[0];
        }

        function getTemplateFail(err) {
            var e = err;
        }
    }
   
    function saveModifiedEntity(entity) {
        var entitiesToSave;
        if (entity) {
            entitiesToSave = [];
            var entities = [];
            if (Array.isArray(entity)) {
                entities = entity;
            }
            else {
                entities.push(entity);
            }
            //we collect only the items that changed
            $.each(entities, function (key, item) {
                if (item.entityAspect.entityState.isModified()
                            || item.entityAspect.entityState.isDeleted()
                            || item.entityAspect.entityState.isAdded()
                            ) {
                    entitiesToSave.push(item);
                }
            });
        }
        return saveEntity(entitiesToSave);
    }

    function saveAllChanges() {
        return saveEntity();
    }

    function saveEntity(masterEntity) {
        if (masterEntity) {
            var entities = [];
            if (Array.isArray(masterEntity)) {
                entities = masterEntity;
            }
            else {
                entities.push(masterEntity);
            }
            return manager.saveChanges(entities);
        }
        else {

            return manager.saveChanges();
        }

        function saveFailed(error) {
            setErrorMessage(error);
            // Let them see it "wrong" briefly before reverting"
            setTimeout(function () { manager.rejectChanges(); }, 1000);
            throw error; // so caller can see failure
        }

        function setErrorMessage(error) {
            var statename = masterEntity.entityAspect.entityState.name.toLowerCase();
            var typeName = masterEntity.entityType.shortName;
            var msg = "Error saving " + statename + " " + typeName + ": ";

            var reason = error.message;

            if (error.entityErrors) {
                reason = getValidationErrorMessage(error);
            } else if (isConcurrencyError(error)) {
                reason =
                    "can't find " + typeName + "; another user may have deleted it.";
            }
            masterEntity.errorMessage(msg + reason);
        }

        function getValidationErrorMessage(error) {
            var firstError = error.entityErrors[0];
            return firstError.errorMessage;
        }
    }

    function createEntity(type, initialValues) {
        return manager.createEntity(type, initialValues);
    }

    function clearEntity(entity) {
        return manager.detachEntity(entity);

    }

    //---------
    function createClientEntity(type, initialValues) {
        return clientManager.createEntity(type, initialValues);
    }

    function saveNewEntity(entity) {
        return saveEntity(manager.addEntity(entity));
    }

    function deleteEntity(entity) {
        entity.entityAspect.setDeleted();
        return saveEntity(entity);
    }

    function isConcurrencyError(error) {
        var detail = error.detail;
        return detail && detail.ExceptionMessage &&
            detail.ExceptionMessage.match(/can't find/i);
    }

    // this function save the entity immediate after changes 
    // if you want this to work call it after init manager
    function configureManagerToSaveModifiedItemImmediately() {
        manager.entityChanged.subscribe(function (args) {
            if (args.entityAction === breeze.EntityAction.EntityStateChange) {
                var entity = args.entity;
                if (entity.entityAspect.entityState.isModified()) {
                    saveEntity(entity);
                }
            }
        });
    }

    function unWrapObject(entity) {
        var rawObject = {};
        var stype = entity.entityType || entity.complexType;
        stype.dataProperties.forEach(function (dp) {
            var prop = stype.getProperty(dp.name);
            var val = entity.getProperty(dp.name);
            if (prop.isComplexProperty) {
                rawObject[dp.name] = unWrapObject(val);
            }
            else {
                rawObject[dp.name] = val;
            }
        });
        return rawObject;
    }

    function validateEntity(entity) {
        if (entity.entityAspect.getValidationErrors().length > 0) {
            return false;
        }
        return true;
    }
    
    function validateAll(entity) {
        var isValid = true;
        var entitiesToValidate;
        if (entity) {
            var entities = [];
            if (Array.isArray(entity)) {
                entities = entity;
            }
            else {
                entities.push(entity);
            }

            $.each(entities, function (key, item) {
                if (item.entityAspect.getValidationErrors().length > 0) {
                    isValid = false;
                    return false;
                }
            });
        }
        return isValid;
    }

    //#endregion
});