﻿define(function form101MainView(require) {
	var global = require('common/global');
	global.abortAllAjax();
	//#region require modules
	var gridVM = require('views/controls/gridUC/gridkendoUC');
	var yearsCombo = require('views/controls/yearsCombo/yearsCombo');
	var combo = require('views/controls/combo/combo');
	var router = require('plugins/router');
	var form101 = require('views/forms/form101/form101');
	var customMessageWindow = require('views/combinedControls/customMessageWindow/customMessageWindow');
	var gridMessageWindow = require('views/combinedControls/gridMessageWindow/gridMessageWindow');
	var multiSelect = require('views/controls/multiSelect/multiSelect');
	var cacheManager = require('common/cache/cacheManager');
	var cache = global.cache;
	var filter = require('views/combinedControls/filter/filter');
	//#endregion require modules

	//#region private memebers
	var cacheItems = cacheManager.cacheItems;
	var PX = "px";

	//local enum
	var Form101ViewTypes = {
		employee: 0,
		salaryAccountant: 1
	};

	var form101EmployeeGrid = null;
	var form101SalaryAccountGrid = null;
	var currentUser = global.cache.get(global.enums.cacheItems.USER);

	var Get101FormsListQuery = {
		UserNo: cache.get(cache.enums.cacheItems.USER).Profile.Code,
		FromTaxYear: null,
		ToTaxYear: null,
		VersionStatus: -1,
		EmpNo: currentUser.Id,
		IsManagerMode: false,
		Filter: null,
		ColumnTypes: null,
		IsActive: 1,
		IsAllEmp: 0
	};
	var tokenPopup = null;
	var tokenVal = null;
	var currentCompany = global.cache.get(global.enums.cacheItems.CURCOMP);
	var clientId = currentCompany.id;
	var guid = global.cache.getCompanyParamByFieldName("GUID");
	var statusSignLicense = null;
	var queryValues;
	var datetimeFormat = global.cache.get(global.enums.cacheItems.DATE_FORMAT) + " HH:mm:ss";
	var enablePrintObs = ko.observable(false);
	var isAllRowsSelected = ko.observable(false);
	var statusFilterOptions = {
		cacheItem: cacheItems.LAST_STATUS_FILTER_EMP_IN_101,
		defaultDict: 3184,
		filterId: "employeesStatusFilterIn101",
		filterList: [
                { dictNo: 298, text: global.res[298], imgSrc: null, hasDivider: true, notDisplayFilterIcon: true, notDisplay: false, itemValue: 2 },//984
                { dictNo: 3184, text: global.res[3184], imgSrc: global.imagesManager.yellow, hasDivider: true, notDisplay: false, itemValue: 1 },
                { dictNo: 3185, text: global.res[3185], imgSrc: global.imagesManager.red, hasDivider: false, notDisplay: false, itemValue: 0 }
		],
		alignControl: 'horizontal'
	};
	//#endregion private memebers  

	//#region public memebers
	var vm = {
		form101frame: new form101(),
		form101Choosen: ko.observable(false),
		global: global,
		activate: activate,
		detached: detached,
		compositionComplete: compositionComplete,
		sendMail: sendMail,
		isPageReadOnly: false,
		form101Enable: global.cache.getCompanyParamByFieldName("isElectronicForm101"),
		form101CompanyPermission: global.enums.companyParamNames.IsElectronicForm101.name,
		viewChangesInExcel: viewChangesInExcel,
		currentForm101ViewType: ko.observable(Form101ViewTypes.employee),
		form101MainGrid: ko.observable(),
		titleText: ko.observable(global.res[4577]),
		totalCount: ko.observable('(0)'),
		fromTaxYear: new yearsCombo(),
		toTaxYear: new yearsCombo(),
		form101StatusCombo: new multiSelect(),
		yearsRangeError: ko.observable(''),
		form101Permission: global.enums.permissionCodes.FORM_101_PERMISSION.code,
		salaryAccountPermission: null,
		signButtonClick: signButtonClick,
		exportGridToExcel: exportGridToExcel,
		print101files: print101files,
		printTitle: ko.observable(global.resMsg[695]),
		enablePrintFiles: ko.computed(function () {
			return enablePrintObs();
		}),
		exportFileTypeList: ko.observableArray([
            { Code: global.enums.exportFileType.CSV_REPORT.id, Descript: 'CSV Report' },
            { Code: global.enums.exportFileType.XML.id, Descript: 'XML' },
            { Code: global.enums.exportFileType.CSV.id, Descript: 'CSV' },
		    { Code: global.enums.exportFileType.CSV_TO_SACHARMAIN.id,Descript: global.res[5474]
		}]),
		sendMailTypeList: ko.observableArray([{ Code: global.enums.sendEmailType.SelectedEmp.id, Descript: global.res[5452] }, { Code: global.enums.sendEmailType.AllEmp.id, Descript: global.res[5453] }]),
		statusTypeList: ko.observableArray([{ Code: global.enums.statusForm101Type.ElectronicForm.id, Descript: global.res[5458] }, { Code: global.enums.statusForm101Type.ManualForm.id, Descript: global.res[5459] }]),
		exportDataToFile: exportDataToFile,
		changeFormStatus: changeFormStatus,
		statusFilter: new filter(statusFilterOptions),
		isEnable101Manual: global.cache.getCompanyParamByFieldName("isEnable101ManualUpdateStatus")
	};
	//#endregion public memebers

	//#region events
	function activate(context) {
		try {
			global.abortAllAjax();
			if (vm.form101Enable != 1 || !global.permissions.isVisible(vm.form101Permission))
			{
			    vm.form101Choosen(true);//for unvisible content before back to home
			    customMessageWindow.buildMessage({ mode: global.enums.messageType.error, messageText: global.res[4577]  + ' - '+global.res[1774] });
			    global.showDialog(customMessageWindow);
			    router.navigate("#home");
			    return ;
			}



			vm.salaryAccountPermission = ko.computed(function getPermission() {
				if (global.permissions.isManagerApproval(vm.form101Permission)) {
					return global.enums.permissionCodes.NO_PERMISSION.code;
				}
				return global.enums.permissionCodes.ALWAYS_NOT_VISIBLE.code;
			});
			if (global.permissions.isVisible(vm.salaryAccountPermission())) {
				var screenParams = cacheManager.get(cacheItems.SCREEN_PARAMS);
				if (screenParams != null && screenParams.name == "documents" && screenParams.type == "form101") {
					vm.currentForm101ViewType(screenParams.value);
					Get101FormsListQuery.IsManagerMode = screenParams.value == Form101ViewTypes.salaryAccountant;
				}
				vm.isPageReadOnly = global.permissions.isReadonly(vm.form101Permission)
			}
			function cancel() {
				vm.form101Choosen(false);
				refreshGrid();
			}
			global.app.on(global.enums.events.CANCEL_FORM101.name).then(cancel);
			var lastValues = global.cache.get(global.enums.cacheItems.LAST_FORM_101_MAIN_VALUES);
			if (!global.isNull(lastValues)) {
				queryValues = JSON.parse(lastValues);
				$.extend(Get101FormsListQuery, queryValues);
				Get101FormsListQuery.EmpNo = currentUser.Id;
			}
			initGridVM();
			vm.yearsRangeError('');
			vm.form101StatusCombo.initialize({ multiSelectId: "form101StatusCombo", lookupName: global.enums.lookupName.Tfs101VerSts })
			vm.form101StatusCombo.customClose = onStatusChanged;
			/*.done(function initForm101StatusComboDone() {
                var selectedId = Get101FormsListQuery.VersionStatus == -1 ? null : Get101FormsListQuery.VersionStatus;
                vm.form101StatusCombo.changeSelectedItemById(selectedId);
            });*/
			vm.fromTaxYear.initialize({ id: "fromTaxYearForm101", title: global.res[614] + ' ' + global.res[683] + ':' });
			vm.fromTaxYear.customSelectionChanged = onFromDateChanged;
			vm.toTaxYear.initialize({ id: "toTaxYearForm101", title: global.res[615] + ' ' + global.res[683] + ':' });
			vm.toTaxYear.customSelectionChanged = onToDateChanged;
			global.httpGet(global.enums.httpPath.Form101CheckSignLicense)
                   .done(function form101CheckSignLicenseFinish(response) {
                   	statusSignLicense = response.Status;
                   });
			vm.statusFilter.filterSelectionChanged = onStatusSelectionChanged;
			initGridData();
		}
		catch (err) {
			global.treatError(err);
		}
	}

	function signButtonClick() {
		try {
			//build list of entities data to send to sign api
			var entitiesSelectedToSign = vm.form101MainGrid().getSelectedEntities();
			var entitiesDataToSign = [];
			var entityDataItem = null;
			for (var i = 0; i < entitiesSelectedToSign.length; i++) {
				if (entitiesSelectedToSign[i].VersionStatus == global.enums.form101status.ConfirmByAccountManager) {//סטאטוס "מאושר על ידי חשב" מאפשר חתימת הטופס ממסך הגריד לחשב
					entityDataItem = { TaxYear: entitiesSelectedToSign[i].TaxYear, Emp_no: entitiesSelectedToSign[i].Emp_No, Version: entitiesSelectedToSign[i].Version_ID, Status: entitiesSelectedToSign[i].VersionStatus };
					entitiesDataToSign.push(entityDataItem);
				}
			}
			if (entitiesDataToSign.length > 0) {
				global.httpGet(global.enums.httpPath.GetEmployeeSmartPhone).done(function GetEmployeeSmartPhoneDone(result) {
					try {
						var msg = "";
						if (statusSignLicense == global.enums.signingForm101Status.NoLicenseSAPI.toString())
							msg = global.resMsg[434] + "\n";
						if (global.isNull(result) || global.isNullOrEmpty(result.ReturnVal)) {
							msg += global.resMsg[435];
						}
						if (!global.isNOE(msg)) {
							customMessageWindow.buildMessage({ mode: global.enums.messageType.error, messageText: msg });
							global.showDialog(customMessageWindow);
							return;
						}
						if (global.isNull(tokenVal)) {
							getOTP(entitiesDataToSign, result.ReturnVal);
						}
						else {//valid
							TokenValid(entitiesDataToSign, result.ReturnVal);
						}
					}
					catch (err) {
						global.treatError(err);
					}
				});
			}
			else {  //no items relevant to sign or no items were checked
				customMessageWindow.buildMessage({ mode: global.enums.messageType.warning, messageText: global.resMsg[423] });
				global.showDialog(customMessageWindow);
			}
		}
		catch (err) {
			global.treatError(err);
		}
	}

	function initGridVM() {
		if (vm.currentForm101ViewType() == Form101ViewTypes.employee) {
			if (global.isNull(form101EmployeeGrid)) {
				form101EmployeeGrid = new gridVM({ remote: true, gridId: "form101EmployeeGrid", httpType: "POST", editable: false, filterable: { extra: false }, dataURL: global.enums.httpPath.Get101FormsList, pageable: false });
			}
			vm.form101MainGrid(form101EmployeeGrid);
		}
		else {
			if (global.isNull(form101SalaryAccountGrid)) {
				form101SalaryAccountGrid = new gridVM({ remote: true, gridId: "form101SalaryAccountGrid", httpType: "POST", editable: false, dataURL: global.enums.httpPath.Get101FormsList });
			}
			vm.form101MainGrid(form101SalaryAccountGrid);
		}
	}

	function initGridData() {
		var years = global.cache.get(global.enums.cacheItems.FORM_101_YEARS_LIST);
		if (global.isNull(years)) {
			global.httpGet(global.enums.httpPath.GetTaxYearsRange).then(function GetTaxYearsRangeFinished(result) {
				global.cache.set(global.enums.cacheItems.FORM_101_YEARS_LIST, result);
				if (!global.isNull(result) && result.length > 0) {
					setData(result);
				}
			});
		}
		else {
			setData(years);
		}
	}

	function setData(years) {
		var lastYear = years[years.length - 1];
		Get101FormsListQuery.FromTaxYear = global.isNull(Get101FormsListQuery.FromTaxYear) ? lastYear : Get101FormsListQuery.FromTaxYear;
		Get101FormsListQuery.ToTaxYear = global.isNull(Get101FormsListQuery.ToTaxYear) ? lastYear : Get101FormsListQuery.ToTaxYear;
		initGrid();
		vm.fromTaxYear.setDataSource(years, Get101FormsListQuery.FromTaxYear);
		vm.toTaxYear.setDataSource(years, Get101FormsListQuery.ToTaxYear);
	}

	function detached() {
		try {
			if (vm.form101MainGrid())
				vm.form101MainGrid().clear();
			var valuesToSave = {
				FromTaxYear: Get101FormsListQuery.FromTaxYear,
				ToTaxYear: Get101FormsListQuery.ToTaxYear,
				VersionStatus: Get101FormsListQuery.VersionStatus,
			};
			var values = JSON.stringify(valuesToSave);
			global.cache.set(global.enums.cacheItems.LAST_FORM_101_MAIN_VALUES, values);
			global.app.off(global.enums.events.CANCEL_FORM101.name);
		}
		catch (err) {
			global.treatError(err);
		}
	}

	function onStatusChanged(item) {
		try {
			if (global.isNull(vm.form101MainGrid().getGrid())) {
				return;
			}
			var status = vm.form101StatusCombo.getSelectedIDs().toString();
			status = status.length > 0 ? status : undefined;
			Get101FormsListQuery.VersionStatus = global.isNullOrEmpty(status) ? -1 : status;
			vm.form101MainGrid().setPageNo(1);
			refreshGrid();
		}
		catch (err) {
			global.treatError(err);
		}
	}

	function onFromDateChanged(value) {
		try {
			if (!global.isNullOrEmpty(value)) {
				if (value > vm.toTaxYear.selectedItem()) {
					vm.yearsRangeError(global.resMsg[172]);
				}
				else {
					vm.yearsRangeError('');
					Get101FormsListQuery.FromTaxYear = value;
					vm.form101MainGrid().setPageNo(1);
					refreshGrid();
				}
			}
		}
		catch (err) {
			global.treatError(err);
		}
	}

	function onToDateChanged(value) {
		try {
			if (!global.isNullOrEmpty(value)) {
				if (value < vm.fromTaxYear.selectedItem()) {
					vm.yearsRangeError(global.resMsg[172]);
				}
				else {
					vm.yearsRangeError('');
					vm.form101MainGrid().setPageNo(1);
					Get101FormsListQuery.ToTaxYear = value;
					refreshGrid();
				}
			}
		}
		catch (err) {
			global.treatError(err);
		}
	}

	function open101FormClick(e) {
		try {
			e.preventDefault();
			var target = $(e.currentTarget);
			var grid = vm.form101MainGrid().getGrid();
			var tr = target.closest("tr");
			var dataItem = grid.dataItem(tr);
			//against ifuin
			var isNewVersion, xVerNo;
			if (dataItem.Version_ID == null || dataItem.Version_ID == 0) {
				isNewVersion = 1;
				xVerNo = null;
			}
			else {
				isNewVersion = 0;
				xVerNo = dataItem.Version_ID;
			}
			var parameters = {
			    xVerNo: xVerNo, xIsAccountManager: Get101FormsListQuery.IsManagerMode ? "1" : "0",
			    pIsNewVersion: isNewVersion, xVerStatus: dataItem.VersionStatus,
			    xEmpNo: dataItem.Emp_No, xTaxYear: dataItem.TaxYear,
			    xVerStatusName: dataItem.VerStatus_Name
			};
			if (Get101FormsListQuery.IsManagerMode && global.cache.getCompanyParamByFieldName("LockToAnotherMngForm101") == 1)
			{
			    var dataQuery = {
			        TaxYear: parameters.xTaxYear,
			        Emp_no: parameters.xEmpNo,
			        Version: parameters.xVerNo,
			        Status: parameters.xVerStatus
			    };
			    return global.httpGet(global.enums.httpPath.Form101IsLockByManager, { query: JSON.stringify(dataQuery) }).
                    done(function handleResponse(response) {
                        handleCheckLockByMngResponse(response, parameters)
                    });
			}
			else {
			    vm.form101frame.init(parameters);
			    vm.form101Choosen(true);
			}

		}
		catch (err) {
			global.treatError(err);
		}
	}
	function handleCheckLockByMngResponse(response, parameters) {
	    try {
	        if (!global.isNull(response) && response.Status != 0 && !global.isNullOrEmpty(response.Message)) {
	            customMessageWindow.buildMessage({ mode: global.enums.messageType.error, messageText: response.Message });
	            global.showDialog(customMessageWindow);
	        }
	        if (!global.isNull(response) && !global.isNull(response.Data) && response.Data.length > 0) {
	            var isLocked = response.Data[0].isLocked;
	            if (isLocked == 0)
	            {
	                vm.form101frame.init(parameters);
	                vm.form101Choosen(true);
                }
	            else {
	                var mngData = ''; var warnMsg = '';
	                if (!global.isNullOrEmpty(response.Data[0].MngEmp_no))
	                    mngData = response.Data[0].MngEmp_no + ', ' + response.Data[0].MngEmp_name;
	                warnMsg = global.helper.replaceDelimFromDict("{0}", global.resMsg[688], parameters.xEmpNo);
	                warnMsg = warnMsg + ' '+global.helper.replaceDelimFromDict("{1}", global.resMsg[691], mngData);
	                customMessageWindow.buildMessage({ mode: global.enums.messageType.warning, messageText: warnMsg });
	                global.showDialog(customMessageWindow);
	            }

	        }

	    }
	    catch (err) {
	        global.treatError(err);
	    }
	}
	function setColumnsAndTitleByViewType() {
		var ul = $("#form101ViewType");
		if (global.permissions.isVisible(vm.salaryAccountPermission())) {
			var spans = ul.find("span");
			$(spans).removeClass("whiteColorFontSpan");
			$(spans).parents('li').removeClass("blueBackgroundSpan");
			$(spans).addClass("headerGrid-att-ro");
			var spanInLi = ul.find("span[data-value='" + vm.currentForm101ViewType() + "']");
			$(spanInLi).removeClass("headerGrid-att-ro");
			$(spanInLi).addClass("whiteColorFontSpan");
			$(spanInLi).parents('li').addClass("blueBackgroundSpan");
			ul.find("li").click(function form101ViewTypeChanged() {
				try {
					var spanInLi = $(this).find("span");
					var val = $(spanInLi).attr("data-value");
					var screenParams = { name: "documents", type: "form101", value: val };
					cacheManager.set(cacheItems.SCREEN_PARAMS, screenParams);
					if (vm.currentForm101ViewType() != val) {
						changeTabsDisplay(spanInLi, val);
						vm.form101MainGrid().clear();
						if (vm.yearsRangeError() != '') {
							vm.yearsRangeError('');
							vm.fromTaxYear.selectedItem(Get101FormsListQuery.FromTaxYear);
							vm.toTaxYear.selectedItem(Get101FormsListQuery.ToTaxYear);
						}
						Get101FormsListQuery.IsManagerMode = val == Form101ViewTypes.salaryAccountant;
						if (val == Form101ViewTypes.salaryAccountant) {
							var status = vm.form101StatusCombo.getSelectedIDs().toString();
							status = status.length > 0 ? status : undefined;
							Get101FormsListQuery.VersionStatus = global.isNullOrEmpty(status) ? -1 : status;
						}
						initGridVM();
						initGridData();
					}
				}
				catch (err) {
					global.treatError(err);
				}
			});
		}
	}

	function compositionComplete(view) {
		try {
			if (vm.form101Enable != 1 || !global.permissions.isVisible(vm.form101Permission)) return;
			setColumnsAndTitleByViewType();
			isAllRowsSelected(false);
		}
		catch (err) {
			global.treatError(err);
		}
	}

	function sendMail(s, e) {
		if (!global.isNull(s.Code)) {
			var dataToSendMail = {};
			var maxVersionPerEmpToSendMail = {};
			var entiti
			var entityDataItem = null;
			var faild = 0;
			var currentYear = cacheManager.get(cacheItems.CURRENT_TAX_YEAR);
			if (s.Code == 0) {
				//build list of entities data to send to sign api
				var entitiesToSendMail = vm.form101MainGrid().getSelectedEntities();
				if (entitiesToSendMail.length > 0) {
					var gridData = vm.form101MainGrid().getDataView();
					for (var i = 0; i < entitiesToSendMail.length; i++) {
						if (entitiesToSendMail[i].TaxYear == currentYear) {
							//if version that was checked is not of current year- mail will not be send
							var currentEmp = entitiesToSendMail[i].Emp_No;
							if (global.isNull(dataToSendMail[currentEmp])) {
								$.each(gridData, function getLatest(idx, dataItem) {
									//if version that was checked is not the latest version - get the status of lateset version
									if (dataItem.Emp_No == currentEmp) {
										var mailData = {
											VersionStatus: entitiesToSendMail[i].VersionStatus,
											Comment: null,
											EmailString: entitiesToSendMail[i].Email,
											Emp_Name: entitiesToSendMail[i].Emp_name
										};
										if (mailData.VersionStatus == 3) {
											mailData.Comment = entitiesToSendMail[i].VersionComment;
										}
										if (!maxVersionPerEmpToSendMail[currentEmp]) {
											maxVersionPerEmpToSendMail[currentEmp] = dataItem.Version_ID;
											dataToSendMail[currentEmp] = mailData;
										}
										else if (maxVersionPerEmpToSendMail[currentEmp] < dataItem.Version_ID) {
											maxVersionPerEmpToSendMail[currentEmp] = dataItem.Version_ID;
											dataToSendMail[currentEmp] = mailData;
										}
									}
								});
							}
						}
						else {
							faild++;
						}
					}
					if (faild > 0) {
						if (faild == entitiesToSendMail.length) {
							global.customMessageWindow.buildMessage({ mode: global.enums.messageType.warning, messageText: global.resMsg[671] });
							global.showDialog(customMessageWindow);
						}
						else {
							global.customMessageWindow.buildMessage({ mode: global.enums.messageType.warning, messageText: global.resMsg[450] });
							global.showDialog(customMessageWindow).then(function stopSpin() {
								continueSendingLogic(dataToSendMail, entitiesToSendMail, faild);
							});
						}
					}
					else {
						continueSendingLogic(dataToSendMail, entitiesToSendMail, faild);
					}
				}
				else {
					customMessageWindow.buildMessage({ mode: global.enums.messageType.error, messageText: global.resMsg[678] });
					global.showDialog(customMessageWindow);
				}
			}
			else { //send to all emp
				global.customMessageWindow.buildMessage({ mode: global.enums.messageType.warning, messageText: global.resMsg[671] });
				global.showDialog(customMessageWindow).then(function continueSend() {
					global.displaySpin(true);
					Get101FormsListQuery.IsAllEmp = 1;
					//email for all emp will be only for current year
					Get101FormsListQuery.FromTaxYear = currentYear;
					Get101FormsListQuery.ToTaxYear = currentYear;
					global.httpPost(global.enums.httpPath.Get101FormsList, Get101FormsListQuery).done(function afterGetAllEmpForm101Versions(response) {
						if (!global.isNull(response) && !global.isNull(response.results) && response.results.length > 0) { //if SP return data of emp						
							for (var i = 0; i < response.totalCount; i++) {
								if (response.results[i].SendMail) {
									var currentEmp = response.results[i].Emp_No;
									if (global.isNull(dataToSendMail[currentEmp])) {
										var mailData = {
											VersionStatus: response.results[i].VersionStatus,
											Comment: null,
											EmailString: response.results[i].Email,
											Emp_Name: response.results[i].Emp_name
										};
										if (mailData.VersionStatus == 3) {
											mailData.Comment = response.results[i].VersionComment;
										}
										if (!maxVersionPerEmpToSendMail[currentEmp]) {
											maxVersionPerEmpToSendMail[currentEmp] = response.results[i].Version_ID;
											dataToSendMail[currentEmp] = mailData;
										}
									}
								}
								else
									faild++;
							}
							var command = {
								MailDataList: dataToSendMail
							};
							if (faild < response.totalCount) {
								global.httpPost(global.enums.httpPath.SendStatusMail, command).done(function unDisplaySpin(result) {
									setTimeout(function sendAllWaitTosucceed() {
										global.displaySpin(false);
										var mssgText1 = global.helper.replaceDelimFromDict("{0}", global.resMsg[675], (response.totalCount - faild));
										var mssgText2 = global.helper.replaceDelimFromDict("{1}", global.resMsg[680], response.totalCount);
										customMessageWindow.buildMessage({ mode: global.enums.messageType.info, messageText: global.resMsg[183] + '\n' + mssgText1 + ' ' + mssgText2 });
										global.showDialog(customMessageWindow).then(function stopSpin() { global.displaySpin(false); });

									}, 2000);
								});
							}
							else {
								global.displaySpin(false);
								customMessageWindow.buildMessage({ mode: global.enums.messageType.info, messageText: global.resMsg[679] });
								global.showDialog(customMessageWindow);
							}
						}
					});
				});
			}
		}
	}

	function continueSendingLogic(dataToSendMail, entitiesToSendMail, faild) {
		if (faild < entitiesToSendMail.length) {
			global.displaySpin(true);
			var command = {
				MailDataList: dataToSendMail
			};
			global.httpPost(global.enums.httpPath.SendStatusMail, command).done(function unDisplaySpin(result) {
				setTimeout(function sendSelectedWaitTosucceed() {
					global.displaySpin(false);
					if (result.Status != 0) {
						if (result.Message.length > 0) {
							var epmList = result.Message.split(','); //get emp_no without email data as array							
							var gridColumns = ko.observableArray([]); //schema for grid as array
							var dataGrid = ko.observableArray([]); //grid data
							for (var i = 0; i < epmList.length; i++) {
								for (j = 0; j < entitiesToSendMail.length; j++) {
									if (epmList[i] == entitiesToSendMail[j].Emp_No) {
										dataGrid.push({ Emp_No: entitiesToSendMail[j].Emp_No, Emp_Name: entitiesToSendMail[j].Emp_name })
										break;
									}
								}
							}
							gridColumns = ko.observableArray([{ field: 'Emp_No', title: global.res[114], filterable: true }, { field: 'Emp_Name', title: global.res[377], filterable: true }]);
							var mssgText1 = global.helper.replaceDelimFromDict("{0}", global.resMsg[675], (entitiesToSendMail.length - faild - epmList.length));
							var mssgText2 = global.helper.replaceDelimFromDict("{1}", global.resMsg[677], entitiesToSendMail.length)

							gridMessageWindow.buildMessage({ mode: global.enums.messageType.warning, messageText: mssgText1 + ' ' + mssgText2, data: dataGrid(), gridSchema: gridColumns() });
							gridMessageWindow.showDetailsLableText(global.resMsg[676])
							global.showDialog(gridMessageWindow).then(function stopSpin() {
								global.displaySpin(false);
							});
						}
					}
					else {
						customMessageWindow.buildMessage({ mode: global.enums.messageType.info, messageText: global.resMsg[183] });
						global.showDialog(customMessageWindow).then(function stopSpin() {
							global.displaySpin(false);
						});
					}
				}, 2000);
			});
		}
	}

	function exportGridToExcel() {
		vm.form101MainGrid().exportToExcel();
	}

	function viewChangesInExcel() {
		global.displaySpin(true);
		var empNo = null;
		var entitiesSelectedToExport = vm.form101MainGrid().getSelectedEntities();
		if (entitiesSelectedToExport.length > 1) {
			customMessageWindow.buildMessage({ mode: global.enums.messageType.info, messageText: global.resMsg[578] });
			global.showDialog(customMessageWindow);
			global.displaySpin(false);
			return;
		}
		else if (entitiesSelectedToExport.length == 1) {
			empNo = entitiesSelectedToExport[0].Emp_No;
		}
		var query = { Emp_no: empNo, FromTaxYear: Get101FormsListQuery.FromTaxYear, ToTaxYear: Get101FormsListQuery.ToTaxYear, IsReport: true };
		global.httpGet(global.enums.httpPath.GetForm101CompareVersions, { query: JSON.stringify(query) }).done(function afterGetForm101CompareVersions(response) {
			if (!global.isNOE(response)) {//response is filename. server already created the file by the cjanges in datatable returned from GetForm101CompareVersions
				global.downloadFile(response, "", global.enums.copyFileToDestinationType.general, "text/csv");
				global.displaySpin(false);
			}
			else {
				customMessageWindow.buildMessage({ mode: global.enums.messageType.error, messageText: global.resMsg[579] });
				global.showDialog(customMessageWindow);
				global.displaySpin(false);
			}
		});
	}

	//#endregion

	//#region methods
	function TokenValid(signData, phoneNum) {
		var query = {
			ClientId: clientId,
			GUID: guid,
			MobileNumber: phoneNum,
			Token: tokenVal,
			emp_no: currentUser.Id

		};
		global.httpGet(global.enums.httpPath.TokenValid, { query: JSON.stringify(query) }).done(function getTokenFinish(result) {
			if (result.TokenValidResult == true) {
				sign(signData);
			}
			else {
				getOTP(signData);
			}
		});
	}

	function getOTP(signData, phoneNum) {
		require(["views/forms/form101/TokenPopup/tokenPopup"], function showPopupAfterRequirePopupModule(newTokenPopupVM) {
			var dialogPromise;
			if (global.isNull(tokenPopup)) {
				tokenPopup = new newTokenPopupVM();
			}
			tokenPopup.init(phoneNum);
			dialogPromise = global.showDialog(tokenPopup).then(function closePopup(resp) {
				if (global.isNull(resp))
					return;
				if (resp.result.Status != 0) {//"Wrong OTP!"
					customMessageWindow.buildMessage({ mode: global.enums.messageType.error, messageText: resp.result.Description });
					global.showDialog(customMessageWindow);
				}
				else//ok
				{
					tokenVal = resp.result.Token;
					sign(signData);
				}
			});
		});
	}

	function sign(entitiesDataToSign) {
		global.displaySpin(true);
		var command = {
			FormParametersList: entitiesDataToSign,
			EmpNo: currentUser.Id
		};
		global.httpPost(global.enums.httpPath.Form101SignPdfList, command)
                   .done(function (response) {
                   	try {
                   		var data = response;
                   		if (!global.isNullOrEmpty(data)) {
                   			var warningMsg = "";
                   			if (entitiesDataToSign.length != entitiesDataToSign.length)  //some of selected items were not in relevant status to be signed
                   				warningMsg = global.resMsg[424] + "\n";
                   			if (data.FailedCount && data.FailedCount > 0) //returned with failure - display error
                   			{
                   				if (data.Status[0] == global.enums.signingForm101Status.NoLicenseSAPI.toString()) {
                   					customMessageWindow.buildMessage({ mode: global.enums.messageType.error, messageText: warningMsg + global.resMsg[434] });
                   					global.showDialog(customMessageWindow);
                   				}
                   				else if (data.FailedCount == entitiesDataToSign.length)//whole list has failed in signing FailedSigningBySAPI- show the error. otherwize(only half list failed) - not show error but succeeded
                   				{
                   					customMessageWindow.buildMessage({ mode: global.enums.messageType.error, messageText: warningMsg + global.resMsg[417], detailsArray: data.ErrorMessage });
                   					global.showDialog(customMessageWindow);
                   				}
                   			}
                   			else {   //in case whole list have succeeded signing - display message "success"
                   				customMessageWindow.buildMessage({ mode: global.enums.messageType.info, messageText: warningMsg + global.resMsg[415] });
                   				global.showDialog(customMessageWindow);
                   			}
                   		}
                   		refreshGrid();
                   	}
                   	catch (err) {
                   		global.treatError(err);
                   	}
                   });
	}

	function changeTabsDisplay(spanInLi, val) {
		$(spanInLi).removeClass("headerGrid-att-ro");
		$(spanInLi).addClass("whiteColorFontSpan");
		$(spanInLi).parents('li').addClass("blueBackgroundSpan");
		var toggle = $("#form101ViewType").find("span[data-value='" + vm.currentForm101ViewType() + "']");
		$(toggle).removeClass("whiteColorFontSpan");
		$(toggle).parents('li').removeClass("blueBackgroundSpan");
		$(toggle).addClass("headerGrid-att-ro");
		vm.currentForm101ViewType(val);
	}

	function initColumnsAndSchema() {
	    

		var columns;
		var schema;
		var size = (window.innerWidth * 90 / 100) / 100;
		if (vm.currentForm101ViewType() == Form101ViewTypes.employee) {
			columns = [
                { field: 'TaxYear', title: global.res[683], width: 8 * size + PX, filterable: false },
                {
                	field: 'VerStatus_Name', template: function getVerStatusNameTemplate(dataItem) {
                		var color;
                		var imgUrl;
                		switch (dataItem.VersionStatus) {
                			case 0:
                			case 1:
                				color = "OrangeColor";
                				imgUrl = global.imagesManager.workRulesEdit;
                				break;
                			case 2:
                				color = "blueColor";
                				imgUrl = global.imagesManager.form101PreMngAppr;
                				break;
                			case 3:
                				color = "redColor";
                				imgUrl = global.imagesManager.form101StatMngDeny;
                				break;
                			case 5:
                				color = "greenColor";
                				imgUrl = global.imagesManager.form101StatMngAppr;
                				break;
                			case 6:
                				color = "greenColor";
                				imgUrl = global.imagesManager.form101Pdf;
                				break;
                			case 7:
                				color = "greenColor";
                				imgUrl = global.imagesManager.hand_green;
                			case 10:
                			case 11:
                				color = "blackColor";
                				break;
                			default:
                				break;
                		}
                		return (dataItem.VersionStatus == 10 || dataItem.VersionStatus == 11) ?
                                 "<p " + color + " class='marginT3'>" + dataItem.VerStatus_Name + "</p>" :
                            "<img class='open_101_form imgBtnCursor' src='" + imgUrl + "' alt='' />&nbsp;" + "<a  href='#' class='open_101_form " + color + "'>" + dataItem.VerStatus_Name + "</a>";
                	},
                	title: global.res[15], width: 10 * size + PX, filterable: false
                },
        //{ field: 'UpdatedByStr', title: global.res[1386], width: 15 * size + PX, filterable: false },
        { field: 'UpdatedBy', title: global.res[2664], width: 15 * size + PX, filterable: false },
        { field: 'UpdatedDate', title: global.res[2663], width: 15 * size + PX, filterable: false, template: function form101DateTemplate(container) { return form101EmployeeGrid.ParseDateFormat(container, "UpdatedDate", datetimeFormat) } },
        { field: 'VersionComment', title: global.res[1382], width: 15 * size + PX, filterable: false },
        {
        	field: 'Version_ID', title: global.res[49], template: function getVersionIDTemplate(dataItem) {
        		return "v." + dataItem.Version_ID + " " + dataItem.EditMode;
        	},
        	width: 10 * size + PX, filterable: false
        },
			];
			schema = {
				data: "results",
				total: "totalCount",
				model: {
					id: "Numerator",
					fields: {
						VerStatus_Name: { editable: false },
						//UpdatedByStr: { editable: false }, 
						UpdatedBy: { editable: false },
						UpdatedDate: { editable: false },
						VersionComment: { editable: false },
						Version_ID: { editable: false }
					}
				}
			};
		}
		else {
		    var isGridRO = vm.isPageReadOnly;
			columns = [
                {
                    field: "check_row", title: "<input id='checkAll', type='checkbox', class='check_row headerbox' />", filterable: false, sortable: false, menu: false, width: 3 * size + PX,
                    template: function chkBoxTemplate(dataItem) {
                        if (!isGridRO)
                            return "<input type='checkbox' class='check_row checkbox' />"
                        else return "";
                    }
                },
                             {
                                 field: 'Emp_No', template: function noTemplate(dataItem) {
                                     return (!isGridRO && dataItem.VersionStatus > 1 && dataItem.VersionStatus != 10) ? "<a href='#' class='open_101_form'>" + dataItem.Emp_No + "</a>" :
									   "<label style='font-weight:normal'>" + dataItem.Emp_No + "</label>";

                             	}, title: global.res[114], width: 6 * size + PX
                                 , filterable: {
                                 	ui: function (element) {
                                 		element.kendoNumericTextBox({
                                 			format: "#",
                                 			decimals: 0,
                                 		});
                                 	}
                                 }
                             },
                             {
                             	field: 'Emp_name', template: function noTemplate(dataItem) {
                             	    return (!isGridRO && dataItem.VersionStatus > 1 && dataItem.VersionStatus != 10 && dataItem.VersionStatus != 11) ? "<a href='#' class='open_101_form'>" + dataItem.Emp_name + "</a>" :"<label style='font-weight:normal'>" + dataItem.Emp_name + "</label>";
                             	}, title: global.res[115], width: 12 * size + PX
                             },
                             {
                                 field: 'Employee_ID', title: global.res[2053], width: 8 * size + PX,
                             	template: function employeeIdTemplate(dataItem) {
                             		return dataItem.Employee_ID != 0 ? "<div>" + dataItem.Employee_ID + "</div>" : ""
                             	}
                             },
			                 { field: 'Employee_ID_type', title: global.res[2529], width: 4 * size + PX },
                             { field: 'TaxYear', title: global.res[683], width: 8 * size + PX },
                             { field: 'DepartmentName', title: global.res[1], width: 10 * size + PX },
                             { field: 'StationName', title: global.res[4], width: 10 * size + PX },
                             {
                             	field: 'VerStatus_Name', template: function getVerStatusNameTemplate(dataItem) {
                             		var color;
                             		var imgUrl;

                             		switch (dataItem.VersionStatus) {
                             			case 0:
                             			case 1:
                             				color = "OrangeColor";
                             				imgUrl = global.imagesManager.workRulesEdit;
                             				break;
                             			case 2:
                             				color = "blueColor";
                             				imgUrl = global.imagesManager.form101PreMngAppr;
                             				break;
                             			case 3:
                             				color = "redColor";
                             				imgUrl = global.imagesManager.form101StatMngDeny;
                             				break;
                             			case 5:
                             				color = "greenColor";
                             				imgUrl = global.imagesManager.form101StatMngAppr;
                             				break;
                             			case 6:
                             				color = "greenColor";
                             				imgUrl = global.imagesManager.form101Pdf;
                             				break;
                             			case 7:
                             				color = "greenColor";
                             				imgUrl = global.imagesManager.hand_green;
                             				break;
                             			case 10:
                             			case 11:
                             				color = "blackColor";
                             				break;
                             			default:
                             				break;
                             		}
                             		return (dataItem.VersionStatus == 10 || dataItem.VersionStatus == 11) ?
											 "<p " + color + ">" + dataItem.VerStatus_Name + "</p>" :
											 dataItem.VersionStatus > 1 ? "<img class='open_101_form imgBtnCursor' src='" + imgUrl + "' alt='' />&nbsp;" +
                                             (!isGridRO ? "<a  href='#' class='open_101_form " + color + "'>" + dataItem.VerStatus_Name + "</a>" : "<span class='" + color + "' style='font-weight:normal'>" + dataItem.VerStatus_Name + "</span>") +
                                            (dataItem.VersionStatus == 2 || dataItem.VersionStatus == 5 ? "<img class='changeStatusToEdit floutR' title='" + global.res[4989] + "' src='" + global.imagesManager.actionsStackButtonsUndo + "' alt='' />" : "") :
									        "<img src='" + imgUrl + "' alt='' />&nbsp;" + "<label class='" + color + "' style='font-weight:normal'>" + dataItem.VerStatus_Name + "</label>";
                             	},
                             	title: global.res[15], width: 10 * size + PX
                             },
                             {
                             	field: 'Version_ID', title: global.res[49], template: function getVersionIDTemplate(dataItem) {
                             		return "v." + dataItem.Version_ID + " " + dataItem.EditMode;
                             	},
                             	width: 10 * size + PX
                             },
                             //{ field: 'UpdatedByStr', title: global.res[1386], width: 15 * size + PX, filterable: false },
                             { field: 'UpdatedBy', title: global.res[2664], width: 10 * size + PX },
                             { field: 'UpdatedDate', title: global.res[2663], width: 10 * size + PX, template: function form101DateTemplate(container) { return form101SalaryAccountGrid.ParseDateFormat(container, "UpdatedDate", datetimeFormat) } },
                             { field: 'VersionComment', title: global.res[1382], width: 10 * size + PX },
			];
			schema = {
				data: "results",
				total: "totalCount",
				model: {
					id: "Numerator",
					fields: {
						check_row: {},
						Emp_No: { type: global.enums.types.number },
						Emp_name: { type: global.enums.types.string },
						Employee_ID: { type: global.enums.types.string },
						TaxYear: { type: global.enums.types.number },
						DepartmentName: { type: global.enums.types.string },
						StationName: { type: global.enums.types.string },
						VerStatus_Name: { type: global.enums.types.string },
						UpdatedBy: { type: global.enums.types.string },
						UpdatedDate: { type: global.enums.types.date },
						VersionComment: { type: global.enums.types.string },
						Version_ID: { type: global.enums.types.string },
						Email: { type: global.enums.types.string },
						SendMail: { type: global.enums.types.boolean },
						Employee_ID_type: { type: global.enums.types.string, editable: false }
					}
				}
			};
		}
		vm.form101MainGrid().gridOptions.columns = columns;
		vm.form101MainGrid().serverSorting = false;
		vm.form101MainGrid().schema = schema;
	}

	function initGrid() {
		vm.form101MainGrid().setGridOptionsSetting({ columnMenu: false });
		initColumnsAndSchema();
		//build columnTypes array for all filterable columns
		var columnsTypes = [];
		$.each(vm.form101MainGrid().gridOptions.columns, function setColumns(key, val) {
			try {
				if (val.filterable == null || (val.filterable != null && val.filterable.ui)) {
					var cell = { "Name": val.field, "Type": vm.form101MainGrid().schema.model.fields[val.field].type };
					columnsTypes.push(cell);
				}
			}
			catch (err) {
				global.treatError(err);
			}
		});
		Get101FormsListQuery.ColumnTypes = columnsTypes;
		Get101FormsListQuery.IsActive = global.isNOE(global.cache.get(cacheItems.LAST_STATUS_FILTER_EMP_IN_101)) ? 1 : global.cache.get(cacheItems.LAST_STATUS_FILTER_EMP_IN_101).itemValue;
		vm.form101MainGrid().dataQuery = Get101FormsListQuery;
		vm.form101MainGrid().addEventAfterBind = addEventAfterBind;
		vm.form101MainGrid().beforeRequestStart = beforeRequestStart;
		vm.form101MainGrid().gridcheckboxStateChanged = gridCheckboxStateChanged;
		vm.form101MainGrid().setDataSource();
	}

	function beforeRequestStart(e) {
		var grid = vm.form101MainGrid().getGrid();
		if (!vm.form101MainGrid().dataQuery.IsManagerMode) {
			vm.form101MainGrid().dataQuery.VersionStatus = -1;
		}
	}

	function addEventAfterBind() {
		global.displaySpin(false);
		vm.totalCount(' (' + vm.form101MainGrid().getGrid().dataSource.total() + ')');
		var open101Form = $("#" + vm.form101MainGrid().gridId() + " .open_101_form");
		if (open101Form && open101Form.length) {
			open101Form.unbind("click", open101FormClick);
			open101Form.bind("click", open101FormClick);
		}
		$("#form101SalaryAccountGrid").off("click", ".changeStatusToEdit");
		$("#form101SalaryAccountGrid").on("click", ".changeStatusToEdit", function (e) {
			changeStatusOfFileToEdit(e);
		});
		// $("#form101MainGrid .kGridContentWrap").height($("#form101MainGrid").height() - 80 + 'px');
	}

	function gridCheckboxStateChanged(ui) {
		if (ui.hasClass("headerbox")) {//in case header was checked - check its status
			if (ui.is(':checked')) {
				enablePrintObs(true);
				isAllRowsSelected(true);
				vm.printTitle(global.res[710]);
			}
			else {
				enablePrintObs(false);
				isAllRowsSelected(false);
				vm.printTitle(global.resMsg[695]);
			}
		}
		else {//in case checkbox of specific row has checked - check whole grid selected rows count
			enablePrintObs(this.getSelectedEntities().length > 0);
			vm.printTitle(this.getSelectedEntities().length > 0 ? global.res[710] : global.resMsg[695]);
		}
	}

	function refreshGrid() {
		try {
			global.displaySpin(true);
			vm.form101MainGrid().rebind();
			isAllRowsSelected(false);
		}
		catch (err) {
			global.treatError(err);
		}
	}

	function print101files() {
		//build list of entities data to send their 101 pdf files to print
		var entitiesSelected = vm.form101MainGrid().getSelectedEntities();
		var entitiesDataToPrint = [];
		var entityDataItem = null;
		for (var i = 0; i < entitiesSelected.length; i++) {
			if (entitiesSelected[i].VersionStatus == global.enums.form101status.WatingToAccountManager ||
                entitiesSelected[i].VersionStatus == global.enums.form101status.ConfirmByAccountManager ||
                entitiesSelected[i].VersionStatus == global.enums.form101status.SignedByelectronicSignature ||
                entitiesSelected[i].VersionStatus == global.enums.form101status.FinalConfirmByUser) {
				entityDataItem = {
					TaxYear: entitiesSelected[i].TaxYear, Emp_no: entitiesSelected[i].Emp_No, Version: entitiesSelected[i].Version_ID, Status: entitiesSelected[i].VersionStatus
				};
				entitiesDataToPrint.push(entityDataItem);
			}
		}
		if (entitiesDataToPrint.length != entitiesSelected.length) {
			customMessageWindow.buildMessage({ mode: global.enums.messageType.info, messageText: global.resMsg[553] });
			global.showDialog(customMessageWindow);
		}
		if (entitiesDataToPrint.length > 0) {
			global.httpPost(global.enums.httpPath.Print101PdfFiles, entitiesDataToPrint)
               .then(function returnFromGetForm10PdfToPrint(response) {
               	var port = (global.webApiConfig.port != "") ? global.webApiConfig.port : "/";
               	var port = (port.slice(-1) != "/") ? port + "/" : port;
               	var url = '';
               	url = global.webApiConfig.getHostPath() + port + "/" + global.consts.tempFilesPath + cache.get(cache.enums.cacheItems.SESSION_ID) + '/' + response.fileName;
               	window.open(url, "_blank");
               });
		}
	}

	function changeStatusOfFileToEdit(e) {
		try {
			//get selected row data
			var dataItem = vm.form101MainGrid().getGrid().dataItem($(event.target).closest("tr"))
			var rowIsChecked = $(e.currentTarget).closest("tr").find('.check_row').is(':checked');//check if checkbox of row is checked.
			if (!rowIsChecked)//in case user didn't check the row - don't change its status
			{
				customMessageWindow.buildMessage({ mode: global.enums.messageType.info, messageText: global.resMsg[555] });
				global.showDialog(customMessageWindow);
				return;
			}
			if (dataItem.VersionStatus == global.enums.form101status.WatingToAccountManager ||
                dataItem.VersionStatus == global.enums.form101status.ConfirmByAccountManager) {
				var Form101ChangeStatusCommand =
                {
                	TaxYear: dataItem.TaxYear,
                	Emp_no: dataItem.Emp_No,
                	Version: dataItem.Version_ID,
                	VersionStatus: global.enums.form101status.Edit,
                	UpdatedBy: currentUser.Id,
                	VersionComment: "",
                	MustSendMail: true
                };
				global.displaySpin(true);
				global.httpPost(global.enums.httpPath.Form101ChangeStatus, Form101ChangeStatusCommand)
                         .done(function (result) {
                         	try {
                         		global.displaySpin(false);
                         		if (result.Status == 1)//error in send mail - emp has no mail address
                         		{
                         			customMessageWindow.buildMessage({ mode: global.enums.messageType.info, messageText: result.Message });
                         			global.showDialog(customMessageWindow);
                         		}
                         		else {
                         			//display succeeded message
                         			customMessageWindow.buildMessage({ mode: global.enums.messageType.info, messageText: global.resMsg[183] });
                         			global.showDialog(customMessageWindow);
                         		}
                         		refreshGrid();
                         	}
                         	catch (err) {
                         		global.treatError(err);
                         	}
                         });
			}
		}
		catch (err) {
			global.treatError(err);
		}
	}

	function exportDataToFile(s, e) {
	    if (!global.isNull(s.Code)) {
	        var entitiesSelectedToExport = [],
	            entitiesDataToExport = [],
                xmlStr = "";

	        if (s.Code == global.enums.exportFileType.CSV_TO_SACHARMAIN.id) {
	            xmlStr = "<Root><FromTaxYear>" + Get101FormsListQuery.FromTaxYear + "</FromTaxYear><ToTaxYear>" + Get101FormsListQuery.ToTaxYear + "</ToTaxYear><Emp_no>" + Get101FormsListQuery.EmpNo + "</Emp_no><UserNo>" + Get101FormsListQuery.UserNo + "</UserNo><VersionStatus>" + Get101FormsListQuery.VersionStatus + "</VersionStatus><IsActive>" + Get101FormsListQuery.IsActive + "</IsActive></Root>";
	            openExportPayrollPopUp(xmlStr);
	            return;
	        }

			entitiesSelectedToExport = vm.form101MainGrid().getSelectedEntities();
			if (entitiesSelectedToExport.length == 0) {
				customMessageWindow.buildMessage({ mode: global.enums.messageType.info, messageText: global.resMsg[555] });
				global.showDialog(customMessageWindow);
				return;
			}
			
			if (isAllRowsSelected()) { //user select all rows in the grid
				customMessageWindow.buildMessage({ mode: global.enums.messageType.question, messageText: global.resMsg[685] + '\n' + global.resMsg[469], btnsMode: global.enums.btnsMode.yesNoCancel });
				global.showDialog(customMessageWindow).then(function handleCountRowsExportGrid(dialogResult) {
					try {
						if (dialogResult == global.enums.customMsgWindowResult.yes) { //send all 
							xmlStr = "<Root><FromTaxYear>" + Get101FormsListQuery.FromTaxYear +
								"</FromTaxYear><ToTaxYear>" + Get101FormsListQuery.ToTaxYear +
								"</ToTaxYear><Emp_no>" + Get101FormsListQuery.EmpNo +
								"</Emp_no><UserNo>" + Get101FormsListQuery.UserNo + "</UserNo><VersionStatus>" + Get101FormsListQuery.VersionStatus +
								"</VersionStatus><FilterStatement>ExtraData</FilterStatement><IsActive>" + Get101FormsListQuery.IsActive + "</IsActive></Root>"; //ExtraData will replaced by filter grid data in controller
							var command = {
								FormatOption: s.Code,
								EmpList: entitiesDataToExport,
								OtherParamsXML: xmlStr,
								ColumnTypes: Get101FormsListQuery.ColumnTypes,
								Filter: Get101FormsListQuery.Filter
							}
							ExportForm101(command, s.Code)
						}
						else if (dialogResult == global.enums.customMsgWindowResult.cancel) {
							return;
						}
						else if (dialogResult == global.enums.customMsgWindowResult.no) { //only one page
							var entityDataItem = null;
							for (var i = 0; i < entitiesSelectedToExport.length; i++) {
								entityDataItem = {
									TaxYear: entitiesSelectedToExport[i].TaxYear, Emp_no: entitiesSelectedToExport[i].Emp_No, Version: entitiesSelectedToExport[i].Version_ID, Status: entitiesSelectedToExport[i].VersionStatus
								};
								entitiesDataToExport.push(entityDataItem);
							}
							var command = {
								FormatOption: s.Code,
								EmpList: entitiesDataToExport,
								OtherParamsXML: ''
							}
							ExportForm101(command, s.Code)
						}
					}
					catch (err) {
						global.treatError(err);
					}
				});
			}
			else { //send only selected rows
				customMessageWindow.buildMessage({ mode: global.enums.messageType.info, messageText: global.resMsg[685], btnsMode: global.enums.btnsMode.ok });
				global.showDialog(customMessageWindow)
				var entityDataItem = null;
				for (var i = 0; i < entitiesSelectedToExport.length; i++) {
					entityDataItem = {
						TaxYear: entitiesSelectedToExport[i].TaxYear, Emp_no: entitiesSelectedToExport[i].Emp_No, Version: entitiesSelectedToExport[i].Version_ID, Status: entitiesSelectedToExport[i].VersionStatus
					};
					entitiesDataToExport.push(entityDataItem);
				}
				var command = {
					FormatOption: s.Code,
					EmpList: entitiesDataToExport,
					OtherParamsXML: ''
				}
				ExportForm101(command, s.Code)
			}
		}
	}

	function openExportPayrollPopUp(xmlStr) {
	    require(["views/forms/form101/Export101Popup/ExportToPayrollPopup"], function (newPopupVM) {
	        try {
	            var popUp = new newPopupVM(),
                    dialogPromise = global.showDialog(popUp);
	            dialogPromise.then(function (result) {
	                try {
	                    if (!global.isNull(result)) {
	                        var exportPayRollType = result,
                                command = {
                                    FormatOption: exportPayRollType,
                                    EmpList: [],
                                    OtherParamsXML: xmlStr
                                };
	                        ExportForm101(command, exportPayRollType)
	                    }
	                } catch (err) {
	                    global.treatError(err)
	                }
	            }); //dialogPromise
	        } catch (err) {
	            n.treatError(err)
	        }
	    })
	}
	function ExportForm101(command, code) {
		try {
			global.displaySpin(true);
			global.httpPost(global.enums.httpPath.ExportForm101DataToFile, command).then(function returnFromExportForm101DataToFile(response) {
				if (!global.isNOE(response))
				    global.downloadFile(response, "", global.enums.copyFileToDestinationType.form101ExportedDataFiles, (code == 0 ? "text/xml" : "text/csv"));
				else {
				    customMessageWindow.buildMessage({ mode: global.enums.messageType.info, messageText: global.res[833], btnsMode: global.enums.btnsMode.ok });
				    global.showDialog(customMessageWindow)
                }
				global.displaySpin(false);
			});			
		}
		catch (err) {
			global.displaySpin(false);
			global.treatError(err);
		}
	}

	function changeFormStatus(s, e) {
		if (!global.isNull(s.Code)) {
			var entitiesSelected = vm.form101MainGrid().getSelectedEntities();
			if (entitiesSelected.length == 0) {
				customMessageWindow.buildMessage({ mode: global.enums.messageType.info, messageText: global.resMsg[555] });
				global.showDialog(customMessageWindow);
				return;
			}
			else {
				var entitiesDataToChange = [];
				var entityDataItem = null;
				for (var i = 0; i < entitiesSelected.length; i++) {
					if (s.Code == 0 && entitiesSelected[i].VersionStatus == 11) { //from Manual => Electronic
						entityDataItem = {
							TaxYear: entitiesSelected[i].TaxYear, Emp_no: entitiesSelected[i].Emp_No, Version: null, Status: null
						};
						entitiesDataToChange.push(entityDataItem);
					}
					else if (s.Code == 1 && entitiesSelected[i].VersionStatus == 10) { //from Electronic => Manual
						entityDataItem = {
							TaxYear: entitiesSelected[i].TaxYear, Emp_no: entitiesSelected[i].Emp_No, Version: null, Status: null
						};
						entitiesDataToChange.push(entityDataItem);
					}
				}
				if (entitiesDataToChange.length < entitiesSelected.length && entitiesDataToChange.length > 0) { //selected data with mixed status
					var strStatus = s.Code == 1 ? "'" + global.res[5489] + "'" : "'" + global.res[5459] + "'";
					var msg = global.helper.replaceDelimFromDict("{0}", global.resMsg[684], strStatus + ".");
					var msg2 = msg + "\n" + global.resMsg[689];
					customMessageWindow.buildMessage({
						mode: global.enums.messageType.info, messageText: isAllRowsSelected() ? msg2 : msg
					});
					global.showDialog(customMessageWindow).done(function continueForm101ChangeStatus(result) {
						var command = {
							StatusOption: s.Code == 1 ? 11 : 10, //ElectronicForm 0, ManualForm 1
							EmpList: entitiesDataToChange
						}
						global.httpPost(global.enums.httpPath.ChangeForm101Status, command).done(function returnFromChangeStatus(response) {
							if (!global.isNOE(response))
								refreshGrid();
						});
					});
				}
				else if (entitiesDataToChange.length == entitiesSelected.length && entitiesDataToChange.length > 0) { //selected data with same status
					var command = {
						StatusOption: s.Code == 1 ? 11 : 10, //ElectronicForm 0, ManualForm 1
						EmpList: entitiesDataToChange
					}
					if (isAllRowsSelected()) {
						customMessageWindow.buildMessage({ mode: global.enums.messageType.info, messageText: global.resMsg[689] });
						global.showDialog(customMessageWindow).done(function continueChangeStatus(result) {
							global.httpPost(global.enums.httpPath.ChangeForm101Status, command).done(function returnFromChangeStatus(response) {
								if (!global.isNOE(response))
									refreshGrid();
							});
						});
					}
					else {
						global.httpPost(global.enums.httpPath.ChangeForm101Status, command).done(function returnFromChangeStatus(response) {
							if (!global.isNOE(response))
								refreshGrid();
						});
					}
				}
				else { //all selected data not fit to selected action
					var strStatus = s.Code == 1 ? "'" + global.res[5489] + "'" : "'" + global.res[5459] + "'";
					var msg = global.helper.replaceDelimFromDict("{0}", global.resMsg[683], strStatus);
					customMessageWindow.buildMessage({ mode: global.enums.messageType.info, messageText: msg });
					global.showDialog(customMessageWindow);
					return;
				}
			}
		}
	}

	function onStatusSelectionChanged() {
		var statusOption = vm.statusFilter.selectedFilterWholeItem();
		Get101FormsListQuery.IsActive = statusOption.itemValue;
		refreshGrid();
	}
	//#endregion

	return vm;
});