﻿//this javascript page must use global.dict(), global.dictMsg - if needed - and mustn't use global.res, global.resMsg

define(function comboControl(require) {
    var global = require('common/global');
    var lookupManager = require('common/lookupManager');
    var dialog = require('plugins/dialog');

    ko.bindingHandlers.kendoDropDownListWidth = {
        update: function setWidthOfCombo(element, valueAccessor) {
            try {
                var dropdownlist = $(element).data("kendoDropDownList");
                if (!global.isNOE(dropdownlist)) 
                    dropdownlist.wrapper[0].style["width"] =
                        ko.utils.unwrapObservable(valueAccessor());                                  
            }
            catch (err) {
                global.treatError(err);
            }
        }
    };

    //need to init on real-time, because when combo is requires, dict have not been initialized yet.
    //but when you need to create instances – dict should already be initialized
    var optionLabelEnum = {
        empty: '',
        all: null
    };
    var listBoxIdSuffix = "_listbox";

    var ViewModel = function (templateName) {
        optionLabelEnum.all = global.dict()[298];
        var data = [];
        var dataQuery;
        var eTableParams = {
            eTableCodeColumn: null,
            eTableDescriptColumn: null,
            eTableFormId: null,
        }
        var initDfd = null;
        var comboInETableLookupName = null;

        var initializeCalled = false;
        var templates = {
            codeDescript: function template(item) {
                item["Display"] = !global.isNull(item.Descript) ? item.Code + " | " + item.Descript : item.Code;
                return item == null || item.Code == null || item.Code.toString() == "" ?
                obj.optionLabel() : !global.isNullOrEmpty(item.Descript) ? item.Code + obj.completeCodeSpaces().substr(item.Code.toString().length * 12) + " | " + item.Descript : item.Code;
            },
            descriptOnly: function (item) {
                item["Display"] = item.Descript;
                return item == null || item.Code == null || item.Code.toString() == "" ?
                obj.optionLabel() : item.Descript;
            },
            codeOnly: function (item) {
                item["Display"] = item.Code;
                return item == null || item.Code == null || item.Code.toString() == "" ?
                obj.optionLabel() : item.Code;
            }
        }
        var containerListElement = null;
        var comboWidthElement = null;
        var isAfterGetLookupAgain = false;
        var missingItem = null;
        var obj = {
            getLookupAgain: getLookupAgain,
            openList: openList,
            controlType: global.enums.controlType.combo,
            initializeForETable: initializeForETable,
            isSetDefaultValue: false,
            dataSource: ko.observable(),
            data: new kendo.data.DataSource({ data: data }),
            comboId: ko.observable("defaultComboId"),
            optionLabel: ko.observable(""),
            cacheMode: {},
            isReadOnly: ko.observable(false),
            needOpenLookupScreen: ko.observable(false),
            lookupName: '',
            extendedData: '',
            itemValue: 'Code',
            itemText: 'Display',
            itemSimpleText: 'Descript',
            selectedItem: ko.observable(),
            selectedId: ko.observable(),
            sortByDescript: false,
            sortDescOrder: false,
            mockSelectedItemChanging: mockSelectedItemChanging,
            completeCodeSpaces: ko.observable(""),
            template: templateName ? templates[templateName] : function template(item) {
                item["Display"] = !global.isNull(item.Descript) ? item.Code + " | " + item.Descript : item.Code;
                return item == null || item.Code == null || item.Code.toString() == "" ?
                obj.optionLabel() : !global.isNullOrEmpty(item.Descript) ? item.Code + obj.completeCodeSpaces().substr(item.Code.toString().length * 12) + " | " + item.Descript : item.Code;
            },
            changeSelectedItemByExtraField: changeSelectedItemByExtraField,
            dataLoaded: function comboLoaded() { },
            sortDataWithCustomDefinitions: sortDataWithCustomDefinitions,
            onChange: onChange,
            getXmlData: getXmlData,
            changeSelectedItem: changeSelectedItem,
            changeSelectedItemOnInit: changeSelectedItemOnInit,
            changeSelectedItemById: changeSelectedItemById,
            changeSelectedItemByIdOnInit: changeSelectedItemByIdOnInit,
            initialize: initialize,
            customSelectionChanged: function customSelectionChanged() { },
            comboInGridSelectionChanged: function comboInGridSelectionChanged() { },
            prevCode: ko.observable(),
            clear: clear,
            openLookupScreen: openLookupScreen,
            refreshWithNewExtendedData: refreshWithNewExtendedData,
            clearSelectedItem: clearSelectedItem,
            getItemByCode: getItemByCode,
            inputText: ko.observable(''),
            comboWidth: ko.observable('200px'),
            sortDataWithCustomDefinitions: sortDataWithCustomDefinitions,
            isComboInETableGrid: false,
            specificUrl: null,
            openETableScreen: openETableScreen,
            widgetId: ko.observable(null),
            needEtableButton: ko.observable(false),
            clearInput: clearInput,
            getItemByUniqueDescript: getItemByUniqueDescript,
            dataBound: dataBound,
            forceInitData: false,          
            compositionComplete: compositionComplete,
            activate: activate,
            isTitleVisible: false,
            AddSelectedItemToDataSource: AddSelectedItemToDataSource
        };

        function activate() {
            getLookupAgain();
            if (missingItem) {
                addItemToDS(missingItem);
                missingItem = null;
            }
        }

        function compositionComplete() {
            try {
                containerListElement = $("#" + obj.comboId() + listBoxIdSuffix).closest(".k-list-container");
                comboWidthElement = $("#" + obj.comboId()).prev();
                if (!global.isNull($("#" + obj.comboId()).data("kendoDropDownList")) && obj.isTitleVisible) {
                    $("#" + obj.comboId()).data("kendoDropDownList").wrapper[0].title = obj.selectedItem().Descript;
                }
            }
            catch (err) {
                global.treatError(err);
            }
        }

        function setMaxLengthCode() {
            try {
                var dataForSearch = obj.dataSource();
                var max = 0;
                if (dataForSearch && dataForSearch.length > 0)
                    max = Enumerable.From(dataForSearch)
                                   .Select(function (lu) { return lu.Code.toString().length })
                                   .Max();

                //var max=0;
                //for ( var i = 0; i < dataForSearch.length; i++)
                //    if (dataForSearch[i].Code.toString().length > max)
                //        max = dataForSearch[i].Code.toString().length;
                var spaces = "";
                for (i = 0; max && i < max; i++)
                    spaces = spaces + "&nbsp;&nbsp;";
                obj.completeCodeSpaces(spaces);
            }
            catch (err) {
                global.treatError(err);
            }

        }

        function dataBound(e) {

            var $dropDown = $(e.sender.element),
              dataWidth = $dropDown.data("kendoDropDownList").list.width(),
              listWidth = dataWidth + 20,
              containerWidth = listWidth + 20;

            //if (listWidth > e.sender.wrapper.width())
            //    $dropDown.data("kendoDropDownList").list.width(containerWidth);
            //else
            if (listWidth <= e.sender.wrapper.width()) {
                if (obj.comboId() == "profilesCombo") {

                    var width = $dropDown.data("kendoDropDownList").list.width();
                    $dropDown.data("kendoDropDownList").list.width(width + 20 + 'px');
                    $($dropDown.data("kendoDropDownList").list).css({ 'min-width': '12em' });
                }
            }
            // }
        }

        function getXmlData() {
            if (!global.isNullOrEmpty(obj.extendedData)) {
                var xmlObj = json2xml.convert(obj.extendedData, "Root");
                xmlObj = xmlObj.replace("<Root", "<Root xml:space=\"preserve\"");
                return xmlObj;//;xml:space='preserve'
            }
            return '';
        }

        function clearSelectedItem() {
            obj.selectedId(null);
            obj.selectedItem(null);
        }

        function getItemByCode(id) {

            var dataForSearch = global.isNull(obj.dataSource()) ? obj.data._data : obj.dataSource();
            var item = Enumerable.From(dataForSearch)
                                                   .Where(function (lu) { return lu.Code == id })
                                                   .Select(function (lu) { return lu })
                                                   .FirstOrDefault();
            return item;

        }

        function retriveDefultItem(setDefault) {
            var item = null;

            if (setDefault) {
                if (!global.isNull(obj.lookupName.extraField) && obj.lookupName.extraField.code == global.enums.lookupExtraField.defaultValue.code) {
                    item = lookupManager.getLookupDefaultSelection(obj.lookupName);
                }
                if (global.isNull(item)) {//global.isNull(obj.lookupName.extraField) || getLookupDefaultSelection return null                  
                    if (obj.lookupName.mode == global.enums.cacheOrDb.dbMode) {
                        item = global.isNull(obj.data()) ? null : obj.data()._data[0];
                    }
                    else {
                        item = global.isNull(obj.dataSource()) ? null : obj.dataSource()[0];
                    }
                }

            }
            else {

                if (!global.isNullOrEmpty(obj.lookupName) && obj.lookupName.mode == global.enums.cacheOrDb.dbMode) {
                    item = global.isNull(obj.data) ? null : obj.optionLabel() != '' ? { Code: '', Descript: obj.optionLabel() } : obj.data._data[0];
                }
                else {
                    item = global.isNull(obj.dataSource()) ? null : obj.optionLabel() != '' ? { Code: '', Descript: obj.optionLabel() } : obj.dataSource()[0];
                }

            }

            return item;
        }
        //this function is very precarious !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        //It disrupts the entire logic of the combo!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        //It is intended for cases in which the combo becomes a visual element only. 
        //useage sample: views/reports/searchFilters.
        function mockSelectedItemChanging(item) {
            if (!global.isNull($("#" + obj.comboId()).data("kendoDropDownList"))) {
                $("#" + obj.comboId()).data("kendoDropDownList").value(item.Code);
                $("#" + obj.comboId()).data("kendoDropDownList").text(item.Descript);
            }
            obj.selectedItem(item);
        }

        function changeSelectedItem(newSelectedItem, selectedIdKoProperty, notAddMissingItem, setDefault, notExecCustomSelectionChanged, selectedFullObject) {
            obj.prevCode(obj.selectedId());
            if (!global.isNull(newSelectedItem) && (newSelectedItem.Code === null || newSelectedItem.Code === undefined)) {
                newSelectedItem = null;
            }

            if (selectedIdKoProperty != null) {
                obj.selectedId = selectedIdKoProperty;
            }

            if (global.isNull(newSelectedItem)) {
                newSelectedItem = retriveDefultItem(setDefault || obj.isSetDefaultValue);
            }
            if (!global.isNull(newSelectedItem)) {
                if (newSelectedItem.Code == -2 && obj.lookupName.name != "WebUserProfileTypes") {
                    mockSelectedItemChanging(newSelectedItem);
                    return;
                }
                if (newSelectedItem.Code != '') {
                    if (global.isNull(notAddMissingItem) || notAddMissingItem == false) {
                        AddSelectedItemToDataSource(newSelectedItem);
                    }
                    obj.selectedId(newSelectedItem.Code);
                    obj.selectedItem({ Code: newSelectedItem.Code, Descript: newSelectedItem.Descript });
                    if (!global.isNull($("#" + obj.comboId()).data("kendoDropDownList"))) {
                        $("#" + obj.comboId()).data("kendoDropDownList").value(obj.selectedId());
                    }
                    //eTable logic
                    if (!global.isNull(obj.widgetId()) && !global.isNull($("#" + obj.widgetId()).data())) {
                        $("#" + obj.widgetId()).data("kendoDropDownList").value(newSelectedItem.Code);
                    }

                    //readonly logic
                    if (global.isNull(newSelectedItem.Code) || global.isNullOrEmpty(newSelectedItem.Descript)) {
                        obj.inputText('');
                    }
                    else {
                        obj.inputText(global.helper.createInputViewInsteadCombo(newSelectedItem.Code, newSelectedItem.Descript, obj.lookupName ? obj.lookupName.codeIsVal : null));

                    }
                }
                else {
                    if (!global.isNull($("#" + obj.comboId()).data("kendoDropDownList"))) {
                        $("#" + obj.comboId()).data("kendoDropDownList").select(0)
                    }
                    obj.selectedId(newSelectedItem.Code);
                    obj.selectedItem({ Code: newSelectedItem.Code, Descript: newSelectedItem.Descript });
                    obj.inputText('');
                }

                if (!global.isNull($("#" + obj.comboId()).data("kendoDropDownList")) && obj.isTitleVisible) {
                    $("#" + obj.comboId()).data("kendoDropDownList").wrapper[0].title = obj.selectedItem().Descript;
                }

                if (!global.isNull(newSelectedItem) && notExecCustomSelectionChanged != true) {
                    //return - is becouse customSelectionChanged can be asynchronize
                    return obj.customSelectionChanged(newSelectedItem, selectedFullObject);
                }                
            }
            else {
                obj.inputText(obj.optionLabel());
            }

        }

        function changeSelectedItemOnInit() {
            getLookupAgain();
            changeSelectedItem.apply(this, arguments);
        }

        function getLookup(goToServerAnyCase) {
            var user = global.cache.get(global.enums.cacheItems.USER);
            dataQuery =
             {
                 EmpNo: user != null ? user.Id : null,
                 UserNo: user != null ? user.Profile != null ? user.Profile.Code : null : null,
                 ElemName: obj.lookupName.name,
                 PageNo: 0,
                 PageSize: 200,
                 PagingBy: obj.sortByDescript,
                 PagingOrder: obj.sortDescOrder,
                 SearchBy: 2,
                 SearchVal: '',
                 SearchExact: true,
                 OtherParamsXML: obj.getXmlData()
             };

            var deferred = global.system.defer(function getLookupPromiseFunc(dfd) {

                window.dd = obj.data;
                return lookupManager.getLookup(dfd, obj.dataSource, dataQuery, obj.lookupName, goToServerAnyCase);

            });
            return deferred.promise();
        }


        function onChange(itemSender) {
            try {
                obj.prevCode(obj.selectedId());
                var prevDesc = obj.selectedItem().Descript;
                var selectedId = null;
                var selectedItem = null;
                if (!global.isNull(this.dataItem()) && !global.isNull(this.dataItem().Code) && this.dataItem().Code !== "") {
                    if (this.dataItem().Code == -2 && obj.lookupName.name!="WebUserProfileTypes") {
                        mockSelectedItemChanging(obj.selectedItem());
                        return;
                    }
                    selectedItem = { Code: this.dataItem().Code, Descript: this.dataItem().Descript };
                }
                else {
                    selectedItem = { Code: itemSender.sender.value(), Descript: itemSender.sender.text().replace(/&nbsp;/gi, " ") };
                }

                obj.selectedId(selectedItem.Code);
                obj.selectedItem(selectedItem);
                obj.inputText(global.helper.createInputViewInsteadCombo(selectedItem.Code, selectedItem.Descript, obj.lookupName ? obj.lookupName.codeIsVal : null));
                obj.comboInGridSelectionChanged(selectedItem, itemSender);
                var selectedFullObject = itemSender.sender.dataSource._data[itemSender.sender.selectedIndex - (global.isNullOrEmpty(obj.optionLabel() ? 0 : 1))];
                obj.customSelectionChanged(selectedItem, selectedFullObject, obj.prevCode(), prevDesc);
                
                if (!global.isNull($("#" + obj.comboId()).data("kendoDropDownList")) && obj.isTitleVisible) {                 
                    $("#" + obj.comboId()).data("kendoDropDownList").wrapper[0].title = obj.selectedItem().Descript;
                }
            }
            catch (err) {
                global.treatError(err);
            }
        }

        function init(goToServerAnycase) {
            var defer = global.system.defer(function loadData(dfd) {
                initDfd = dfd;

                if ((!obj.isReadOnly() || obj.forceInitData) && !global.isNull(obj.lookupName)) {
                    //get lookup data
                    function result() {
                        setMaxLengthCode();
                        obj.data.data(obj.dataSource());
                        if (!isAfterGetLookupAgain) {
                            if (global.isNull(obj.selectedItem())) {
                                if (!global.isNull(obj.selectedId())) {
                                    changeSelectedItemById(obj.selectedId());
                                }
                                else {
                                    changeSelectedItem(null);
                                }
                                obj.isSetDefaultValue = false;
                            }
                        }
                        isAfterGetLookupAgain = false;
                        obj.dataLoaded();
                        initDfd.resolve();
                    }
                    var promise = getLookup(goToServerAnycase);
                    promise.done(result);
                }
            });
            return defer.promise();
        }

        function clear() {
            obj.data.data([]);
            obj.selectedId(null);
            obj.selectedItem({});
        }

        function AddSelectedItemToDataSource(selectedItem) {

            var selected = selectedItem || obj.selectedItem();
            if (!(global.isNull(selected)) && !(global.isNull(selected.Code))
                && !(global.isNull(selected.Descript)) && selected.Code.toString()!= "") {
                var item = Enumerable.From(obj.data.data())
                      .Where(function whereLoopOverData(lu) {
                          return lu.Code == selected.Code
                      })
                      .Select(function selectLoopOverSelectedItemArray(lu) { return lu })
                      .ToArray();

                if (item.length == 0) {
                    missingItem = selected;
                    if (!global.isNullOrEmpty(obj.lookupName) && (obj.lookupName.mode != cacheOrDb.cacheMode || !lookupManager.checkExistLookup(obj.lookupName))) {
                        addItemToDS(missingItem);
                        missingItem = null;
                    }

                }
            }
        };
        function addItemToDS(item) {
            var tempData = obj.data.data();
            if (item.Code != -2) {//not mockValue
                tempData.unshift(item);
            }
            obj.data.data(tempData);
        }
        function changeSelectedItemById(itemCode, selectedIdKoProperty, notExecCustomSelectionChanged) {//this function can be used only after initialized
            if (!global.isNull(selectedIdKoProperty)) {
                obj.selectedId = selectedIdKoProperty;
            }
            if (initializeCalled) {
                var selectedItem = getItemByCode(itemCode);
                changeSelectedItem(selectedItem, null, null, null, notExecCustomSelectionChanged);              
            }
            else {
                throw Error('initializing has not finished yet, you cannot use this function.');
            }
        }

        function changeSelectedItemByIdOnInit() {
            getLookupAgain();
            changeSelectedItemById.apply(this, arguments);
        }

        function changeSelectedItemByExtraField(itemExtraField, selectedIdKoProperty, notExecCustomSelectionChanged) {//this function can be used only after initialized
            if (!global.isNull(selectedIdKoProperty)) {
                obj.selectedId = selectedIdKoProperty;
            }
            if (initializeCalled) {
                var selectedItem =
                     Enumerable.From(obj.data.data()).
                                                     Where(function (item) { return item[obj.lookupName.extraField.name] == itemExtraField })
                                                       .Select(function (lu) { return lu })
                                                     .ToArray()[0];

                changeSelectedItem(selectedItem, null, null, null, notExecCustomSelectionChanged);
            }
            else {
                throw Error('initializing has not finished yet, you cannot use this function.');
            }
        }

        function initialize(options) {
            initializeCalled = true;
            obj.selectedItem(null);
            obj.selectedId(null);
            clearInput();
            if (options.setDefaultValueParameter == true) {
                obj.isSetDefaultValue = true;
            }
            else {
                obj.isSetDefaultValue = false;
            }
            if (!global.isNull(options.isReadOnly) && global.isNullOrEmpty(options.readOnlyKoProperty)) {
                //change obj.isReadOnly only if readOnlyKoProperty is not going to be changed.
                //this prevents problems when the inserted readOnlyKoProperty is ko.computed without a read method
                obj.isReadOnly(options.isReadOnly);
            }
            if (!global.isNull(options.lookupName)) {
                obj.cacheMode = options.lookupName.mode;
            }
            obj.lookupName = options.lookupName;
            obj.extendedData = options.extendedData;
            obj.comboId(options.comboId);

            if (!global.isNull(options.sortByDescript))
                obj.sortByDescript = options.sortByDescript == '1';
            if (!global.isNull(options.needLookupButton)) {
                obj.needOpenLookupScreen = options.needLookupButton;
            }

            if (options.needEtableButton) {
                eTableParams.eTableCodeColumn = options.eTableCodeColumn;
                eTableParams.eTableDescriptColumn = options.eTableDescriptColumn;
                eTableParams.eTableFormId = options.eTableFormId;
                obj.needEtableButton(true);
            }
            if (options.selectedIdKoProperty != null) {
                obj.selectedId = options.selectedIdKoProperty;
            }
            if (options.selectedItemKoProperty != null) {
                obj.selectedItem = options.selectedItemKoProperty;
            }
            if (options.readOnlyKoProperty != null) {
                obj.isReadOnly = options.readOnlyKoProperty;
            }
            var size = $(window).width();
            if (global.isNull(options.width)) {
                obj.comboWidth('200px');
            }
            else {
                obj.comboWidth(options.width);
            }
            if (!global.isNull(options.template)) {
                obj.template(templates[options.template]);
            }
            if (options.forceInitData)
                obj.forceInitData = options.forceInitData;
            if (!global.isNull(options.cancelOptionLabel) && options.cancelOptionLabel == true) {
                obj.optionLabel("");
            }
            else {
                if (options.optionLabelDescript != null) {
                    obj.optionLabel(options.optionLabelDescript);
                }
                else {
                    obj.optionLabel(" ");
                }
            }
             // combo can be without lookup
            if (!global.isNull(options.dataSource)) {
                obj.dataSource(options.dataSource);
                obj.data.data(obj.dataSource());
            }

            return init();
        };

        function openLookupScreen() {
            require(
                     ["pages/lookupDB/lookupDB"],
                     function showLookupPopupAfterRequirePopupModule(lookupDB) {
                         try {
                             global.showDialog(new lookupDB(false, obj.selectedItem(), obj.lookupName, obj.extendedData))
                                 .then(function handleLookupScreenClosedResult(response) {
                                     if (response != null) {
                                         obj.selectedId(response.Code);
                                         obj.customSelectionChanged();
                                     }
                                 });
                         }
                         catch (err) {
                             global.treatError(err);
                         }
                     });
        }

        function openETableScreen() {
            require(
                     ["views/combinedControls/eTable/eTable"],
                     function showETablePopupAfterRequireModule(eTableVM) {
                         try {

                             global.showDialog(new eTableVM(eTableParams.eTableFormId, obj.isComboInETableGrid, getXmlData()))
                                 .then(function handleeTableScreenClosedResult(eTableResponse) {
                                     if (!obj.lookupName.disableReload) {
                                         var reloadDataPromise = obj.isComboInETableGrid ? initializeForETable({}) : getLookup(true);
                                         reloadDataPromise.done(function () { selectAccordingToETable(eTableResponse) });
                                     }
                                     else
                                         selectAccordingToETable(eTableResponse);
                                 });
                         }
                         catch (err) {
                             global.treatError(err);
                         }
                     });
        }
        function selectAccordingToETable(eTableResponse) {
            if (!obj.lookupName.disableReload)
                obj.data.data(obj.dataSource());
            if (!global.isNull(eTableResponse)) {
                changeSelectedItem({ Code: eTableResponse[eTableParams.eTableCodeColumn], Descript: eTableResponse[eTableParams.eTableDescriptColumn] }, null, null, null, null, eTableResponse)//);
                if (obj.isComboInETableGrid == true) {
                    $('#' + obj.widgetId()).data("kendoDropDownList").trigger("change")
                }
            }
        }
        function refreshWithNewExtendedData(extendedData, setDefaultValueParameter) {
            //if (setDefaultValueParameter == true || obj.optionLabel == '') {
            //    obj.isSetDefaultValue = true;
            //}
            //else {
            //    obj.isSetDefaultValue = false;
            //}
            obj.selectedItem(null);
            //obj.selectedId(null);            
            obj.extendedData = extendedData;
            return init(true);
        }

        function initializeForETable(options) {
            obj.isComboInETableGrid = true;
            if (!global.isNull(options.needLookupButton)) {
                obj.needOpenLookupScreen = options.needLookupButton;
            }
            if (options.needEtableButton) {
                eTableParams.eTableCodeColumn = options.eTableCodeColumn;
                eTableParams.eTableDescriptColumn = options.eTableDescriptColumn;
                eTableParams.eTableFormId = options.eTableFormId;
            }
            dataQuery = {
                UserNo: global.cache.get(global.enums.cacheItems.USER).Profile.Code,
                QueryText: options.queryText,
                QueryType: options.queryType,
                CodeColumn: options.codeColumn,
                DescriptColumn: options.descriptColumn,
                XMLData: options.extendedData ? '<Root>' + options.extendedData + '</Root>' : null
            }
            if (global.isNull(comboInETableLookupName)) {
                comboInETableLookupName = 'eTable' + options.formId + options.fieldName;
            }
            var lookup = lookupManager.getLookupFromCache({ cacheName: comboInETableLookupName });
            if (!global.isNull(lookup)) {
                obj.dataSource(lookup);
                obj.data.data(obj.dataSource());
                return global.system.defer(function resolveDefer(dfd) {
                    dfd.resolve();
                }).promise();
            }
            else {
                var url = global.webApiConfig.getApiPath(global.enums.httpPath.GetETableComboData.path + '?query=' + JSON.stringify(dataQuery));
                return global.http.get(url)
                .done(function insertDataFromServerToCombo(response) {
                    obj.dataSource(response);
                    obj.data.data(obj.dataSource());
                    var lookupNameObj = {
                        cacheName: comboInETableLookupName,
                        cacheMode: global.enums.cacheOrDb.cacheMode,
                    };
                    obj.specificUrl = url;
                    lookupManager.saveLookupAtCache(lookupNameObj, response);
                });
            }


        }

        function clearInput() {
            if (!global.isNull($("#" + obj.comboId()).data("kendoDropDownList"))) {
                $("#" + obj.comboId()).data("kendoDropDownList").text('');
            }
        }

        function sortDataWithCustomDefinitions(mode, direction) {
            obj.sortByDescript = mode.value;
            obj.sortDescOrder = direction.value;
            return init();
        }

        function getItemByUniqueDescript(descript) {
            var dataForSearch = global.isNull(obj.dataSource()) ? obj.data._data : obj.dataSource();
            var item = Enumerable.From(dataForSearch)
                                                   .Where(function (lu) { return lu.Descript == descript })
                                                   .Select(function (lu) { return lu })
                                                   .FirstOrDefault();
            return item;
        }

        function openList() {
            try {
                if (containerListElement) {
                    containerListElement.css('minWidth', comboWidthElement.innerWidth());
                }
                else {
                    containerListElement = $("#" + obj.comboId() + listBoxIdSuffix).closest(".k-list-container");
                    comboWidthElement = $("#" + obj.comboId()).prev();
                    containerListElement.css('minWidth', comboWidthElement.innerWidth());

                }
            }
            catch (err) {
                global.treatError(err);
            }
        }

        function getLookupAgain() {
            if (obj.lookupName && lookupManager.checkExistLookup(obj.lookupName)) {
                isAfterGetLookupAgain = true;
                init();
            }
        }

        return obj;
    }
    ViewModel.optionLabelEnum = optionLabelEnum;
    return ViewModel;
});


