﻿define(function form101HelperModule(require) {
    var global = require('common/global');

    function placetooltip() {
        var allTooltips = $(".tooltipFrom101");
        $.each(allTooltips, function () {
            var showTooltip = $(this).find(".showTooltip");
            if ($(this).position().left < showTooltip.width())
                showTooltip.css({ "margin-right": $(this).position().left - showTooltip.width() - $(this).width() - 30 + "px", "margin-top": "10px" });
            if (($("#form101Content").height() - $(this).position().top - $(this).height() - $(window).height() * 0.05) < showTooltip.height())
                showTooltip.css({ "margin-top": ($("#form101Content").height() - $(this).position().top) - showTooltip.height() - $(window).height() * 0.05 - 10 + "px" });
        });
    }

    function bankAccountValidation(bank, branch, account) {
        var nSum = 0;
        var sStrBranch1 = [];
        var sStrBranch2 = [];
        var sStrBranch3 = [];
        //  STU - סניף
        //  ABCDEFGH-X     חשבון
        if (bank == null || bank == 'undefined' || bank === '' || bank === "")
            return 1;
        if (branch == null || branch == 'undefined' || branch === '' || branch === "")
            return 2;
        if (account == null || account == 'undefined' || account === '' || account === "")
            return 3;

        var sAccount = account.toString();
        var sSnif = branch.toString();
        //  bank : 10,13,34
        //  BCDEFG-HX -       חשבון
        //  765432 -           מכפילים
        //  STU  -                   סניף
        //  10 9 8  -                מכפלים
        var nNum;
        var validAccountLength = bankValidAccountLength(bank);
        if (validAccountLength == -1)//bank is not supported - return valid
            return 0;
        if (sAccount.length > validAccountLength)
            return 4;
        if (bank == 10 || bank == 13 || bank == 34) {
            sAccount = (("0").repeat(validAccountLength) + sAccount).slice(-validAccountLength);//8
            var sCheck = sAccount.substr(6, 2);
            var nCheck = parseFloat(sCheck);
            sSnif = (("0").repeat(3) + sSnif).slice(-3);
            sAccount = sSnif + sAccount;
            var index = 10;
            // CENTURA SOURCE: Set nJ=0
            var i = 0;
            nSum = 0;
            while (index >= 2) {
                // CENTURA SOURCE: Set nNum=SalStrToNumber(SalStrMidX( sAccount,nJ,1))
                nNum = parseFloat(sAccount.substr(i, 1));
                nSum += nNum * index;
                index--;
                // CENTURA SOURCE: Set nJ=nJ+1
                i++;
            }
            nSum += nCheck;
            nSum = nSum % 100;
            if (nSum == 90 || nSum == 70 || nSum == 60 || nSum == 20 || nSum == 72)
                return 0;
            else
                return -1;
        }
        //  bank  4               IAHAV    
        //  DEFGH-X -       חשבון
        //  654321-           מכפילים
        //  STU  -                   סניף
        //  9 8 7  -                מכפלים

        if (bank == 4) {
            sAccount = (("0").repeat(validAccountLength) + sAccount).slice(-validAccountLength);//6
            sSnif = (("0").repeat(3) + sSnif).slice(-3);
            sAccount = sSnif + sAccount;
            var index = 9;
            var i = 0;
            nSum = 0;
            while (index >= 1) {
                nNum = parseFloat(sAccount.substr(i, 1));
                nSum += nNum * index;
                index--;
                i++;
            }
            nSum = nSum % 11;
            if (nSum == 0 || nSum == 2) {
                return 0;
            }
            return -1;
        }

        /* bank : 12                                                         HAPOALIM                                                1.2

         D E F G H-X -       חשבון
         6 5 4  3 2  1-           מכפלים
         S T U  -                  סניף     
         9 8 7  -               מכפלים
         בנק הפועלים בלבד עובד לשיטה 0,2,4,6 חוקית בכל הסניפים
        */

        if (bank == 12) {
            sAccount = (("0").repeat(validAccountLength) + sAccount).slice(-validAccountLength);//6
            sSnif = (("0").repeat(3) + sSnif).slice(-3);
            sAccount = sSnif + sAccount;
            var index = 9;
            var i = 0;
            nSum = 0;
            while (index >= 1) {
                nNum = parseFloat(sAccount.substr(i, 1));
                nSum += nNum * index;
                index--;
                i++;
            }
            nSum = nSum % 11;
            if ((nSum == 0 || nSum == 2 || nSum == 4 || nSum == 6)) {
                return 0;
            }
            return -1;
        }

        //  bank : 11,17
        //  ABCDEFG-HX -       חשבון
        //  987654321-           מכפילים
        if (bank == 11 || bank == 17) {
            sAccount = (("0").repeat(validAccountLength) + sAccount).slice(-validAccountLength);//9
            var index = 9;
            // CENTURA SOURCE: Set nJ=0
            var i = 0;
            nSum = 0;
            while (index >= 1) {   // CENTURA SOURCE: Set nNum=SalStrToNumber(SalStrMidX( sAccount,nJ,1))
                nNum = parseFloat(sAccount.substr(i, 1));
                nSum += nNum * index;
                index--;
                // CENTURA SOURCE: Set nJ=nJ+1
                i++;
            }
            nSum = nSum % 11;
            if (nSum == 0) {
                return 0;
            }
            if ((bank == 17 || bank == 11) && (nSum == 2 || nSum == 4)) {
                return 0;
            }
            return -1;
        }
        //  bank: 20
        //  DEFGH-X -       חשבון
        //  654321-           מכפילים
        //  STU  -                   סניף
        //  9 8 7  -                מכפלים
        if (bank == 20) {
            sAccount = (("0").repeat(validAccountLength) + sAccount).slice(-validAccountLength);//6
            if (branch > 400) {
                sSnif = (branch - 400).toString();
            }
            sSnif = (("0").repeat(3) + sSnif).slice(-3);
            sAccount = sSnif + sAccount;
            var index = 9;
            // CENTURA SOURCE: Set nJ=0
            var i = 0;
            nSum = 0;
            while (index >= 1) {   // CENTURA SOURCE: Set nNum=SalStrToNumber(SalStrMidX( sAccount,nJ,1)) 
                nNum = parseFloat(sAccount.substr(i, 1));
                nSum += nNum * index;
                index--;
                // CENTURA SOURCE: Set nJ=nJ+1
                i++;
            }
            nSum = nSum % 11;
            if (nSum == 0 || nSum == 2 || nSum == 4) {
                return 0;
            }
            return -1;
        }
        //  bank : 31,52
        //  ABCDEFGH-X -       חשבון
        //  987654321-           מכפילים
        if (bank == 31 || bank == 52) {
            sAccount = (("0").repeat(validAccountLength) + sAccount).slice(-validAccountLength);//9
            var index = 9;
            // CENTURA SOURCE: Set nJ=0
            var i = 0;
            nSum = 0;
            while (index >= 1) {
                // CENTURA SOURCE: Set nNum=SalStrToNumber(SalStrMidX( sAccount,nJ,1))
                nNum = parseFloat(sAccount.substr(i, 1));
                nSum += nNum * index;
                index--;
                // CENTURA SOURCE: Set nJ=nJ+1
                i++;
            }
            nSum = nSum % 11;
            if (nSum == 0 || nSum == 6) {
                return 0;
            }
            sAccount = sAccount.substr(3, 6);
            index = 6;
            // CENTURA SOURCE: Set nJ=0
            i = 0;
            nSum = 0;
            while (index >= 1) {
                // CENTURA SOURCE: Set nNum=SalStrToNumber(SalStrMidX( sAccount,nJ,1))
                nNum = parseFloat(sAccount.substr(i, 1));
                nSum += nNum * index;
                index--;
                // CENTURA SOURCE: Set nJ=nJ+1
                i++;
            }
            return (nSum == 0 || nSum == 6) ? 0 : -1;
        }
            //  bank: 09
            //  IHGFEDCBA -       חשבון
            //  987654321-          מכפלים
        else if (bank == 9) {
            sAccount = (("0").repeat(validAccountLength) + sAccount).slice(-validAccountLength);//9
            var index = 9;
            var i = 0;
            nSum = 0;
            while (index >= 1) {
                nNum = parseFloat(sAccount.substr(i, 1));
                nSum += nNum * index;
                index--;
                i++;
            }
            nSum = nSum % 10;
            return (nSum == 0) ? 0 : -1;
        }
        //  bank: 22
        //  ABCDEFGH-X -       חשבון
        //  32765432-           מכפילים
        //  X- ספרת בקורת
        if (bank == 22) {
            sAccount = (("0").repeat(validAccountLength) + sAccount).slice(-validAccountLength);//9
            nNum = parseFloat(sAccount.substr(0, 1));
            nSum += nNum * 3;
            nNum = parseFloat(sAccount.substr(1, 1));
            nSum += nNum * 2;
            nNum = parseFloat(sAccount.substr(2, 1));
            nSum += nNum * 7;
            nNum = parseFloat(sAccount.substr(3, 1));
            nSum += nNum * 6;
            nNum = parseFloat(sAccount.substr(4, 1));
            nSum += nNum * 5;
            nNum = parseFloat(sAccount.substr(5, 1));
            nSum += nNum * 4;
            nNum = parseFloat(sAccount.substr(6, 1));
            nSum += nNum * 3;
            nNum = parseFloat(sAccount.substr(7, 1));
            nSum += nNum * 2;
            nSum = nSum % 11;
            nSum = 11 - nSum;
            nNum = parseFloat(sAccount.substr(8, 1));
            return (nSum == nNum) ? 0 : -1;
        }
        else if (bank == 25) {
            sAccount = (("0").repeat(validAccountLength) + sAccount).slice(-validAccountLength);//9
            nNum = parseFloat(sAccount.substr(0, 1));
            nSum += nNum * 3;
            nNum = parseFloat(sAccount.substr(1, 1));
            nSum += nNum * 2;
            nNum = parseFloat(sAccount.substr(2, 1));
            nSum += nNum * 7;
            nNum = parseFloat(sAccount.substr(3, 1));
            nSum += nNum * 6;
            nNum = parseFloat(sAccount.substr(4, 1));
            nSum += nNum * 5;
            nNum = parseFloat(sAccount.substr(5, 1));
            nSum += nNum * 4;
            nNum = parseFloat(sAccount.substr(6, 1));
            nSum += nNum * 3;
            nNum = parseFloat(sAccount.substr(7, 1));
            nSum += nNum * 2;
            nSum = nSum % 11;
            nSum = 11 - nSum;
            nNum = parseFloat(sAccount.substr(8, 1));
            if ((nSum == 10 && nNum == 0) || (nSum == 11 && nNum == 1)) {
                return 0;
            }
            return -1;
        }
        else if (bank == 46) {
            if (sAccount.length <= 6) {
                sAccount = (("0").repeat(6) + sAccount).slice(-6);
                sSnif = (("0").repeat(3) + sSnif).slice(-3);
                sAccount = sSnif + sAccount;
                var index = 9;
                var j = 0;
                nSum = 0;
                while (index >= 1) {
                    nNum = parseFloat(sAccount.substr(j, 1));
                    nSum += nNum * index;
                    index--;
                    j++;
                }
                //  !! סניפים בהם שארית 2 , 0                        
                sStrBranch1[1] = "154,166,178,181,183,191,192,";
                sStrBranch1[2] = "503,505,507,515,516,527,539,";
                var nKvuzaSnif = 0;
                var i = 1;
                while (i <= 2) {
                    if (sStrBranch1[i] != "") {
                        if (sStrBranch1[i].lastIndexOf(branch.toString() + ",") > -1)//(sStrBranch1[i]).Scan(Convert.ToString(branch, 0) + ",") > -1)
                        {
                            nKvuzaSnif = 1;
                            break;
                        }
                    }
                    i++;
                }
                nSum = nSum % 11;
                if (nSum == 0) {
                    return 0;
                }
                else {
                    if (nKvuzaSnif == 1) {
                        if (nSum == 2) {
                            return 0;
                        }
                    }
                }
            }
            sAccount = (("0").repeat(validAccountLength) + sAccount).slice(-validAccountLength);//9
            var index1 = 9;
            var j1 = 0;
            nSum = 0;
            while (index1 >= 1) {
                nNum = parseFloat(sAccount.substr(j1, 1));
                nSum += nNum * index1;
                index1--;
                j1++;
            }
            nSum = nSum % 11;
            if (nSum == 0) {
                return 0;
            }
            else {
                sAccount = sAccount.substr(3, 6);
                index1 = 6;
                j1 = 0;
                nSum = 0;
                while (index1 >= 1) {
                    nNum = parseFloat(sAccount.substr(j1, 1));
                    nSum += nNum * index1;
                    index1--;
                    j1++;
                }
                if (nSum == 0) {
                    return 0;
                }
                else {
                    return -1;
                }
            }
        }
            //  bank : 14
            //  DEFGH-X -       חשבון
            //  654321-          מכפלים
            //  STU  -           סניף
            //  9 8 7  -         מכפלים
            //  or
            //  ABCDEFGH-X -      חשבוןŸ
            //  987654321-        מכפלים                
        else if (bank == 14) {
            if (sAccount.length <= 6) {
                sAccount = (("0").repeat(6) + sAccount).slice(-6);
                sSnif = (("0").repeat(3) + sSnif).slice(-3);
                sAccount = sSnif + sAccount;
                var index = 9;
                var j = 0;
                nSum = 0;
                while (index >= 1) {
                    nNum = parseFloat(sAccount.substr(j, 1));
                    nSum += nNum * index;
                    index--;
                    j++;
                }
                //  !! סניפים בהם שארית 2 , 0'
                sStrBranch1[1] = "347,365,385,";
                //  !! סניפים בהם שארית 4 , 2 , 0
                sStrBranch2[1] = "361,362,363,";
                var nKvuzaSnif = 0;
                if (sStrBranch1[1].lastIndexOf(branch.toString() + ",") > -1)//(sStrBranch1[1]).Scan(Convert.ToString(branch, 0) + ",") > -1)
                {
                    nKvuzaSnif = 1;
                }
                if (nKvuzaSnif == 0) {
                    if (sStrBranch2[1].lastIndexOf(branch.toString() + ",") > -1)//(sStrBranch2[1]).Scan(Convert.ToString(branch, 0) + ",") > -1)
                    {
                        nKvuzaSnif = 2;
                    }
                }
                nSum = nSum % 11;
                if (nSum == 0) {
                    return 0;
                }
                else {
                    if (nKvuzaSnif != 0) {
                        if ((nSum == 2 && nKvuzaSnif == 1) || (((nSum == 2 || nSum == 4)) && nKvuzaSnif == 2)) {
                            return 0;
                        }
                    }
                }
            }
            sAccount = (("0").repeat(validAccountLength) + sAccount).slice(-validAccountLength);//9
            var index1 = 9;
            var j1 = 0;
            nSum = 0;
            while (index1 >= 1) {
                nNum = parseFloat(sAccount.substr(j1, 1));
                nSum += nNum * index1;
                index1--;
                j1++;
            }
            nSum = nSum % 11;
            if (nSum == 0) {
                return 0;
            }
            else {
                sAccount = sAccount.substr(3, 6);
                var index = 6;
                var j = 0;
                nSum = 0;
                while (index >= 1) {
                    nNum = parseFloat(sAccount.substr(j, 1));
                    nSum += nNum * index;
                    index--;
                    j++;
                }
                if (nSum == 0) {
                    return 0;
                }
                else {
                    return -1;
                }
            }
        }

        return -1;
    }

    function bankValidAccountLength(bank) {
        switch (bank) {
            case "10":
            case "13":
            case "34":
                return 8;
            case "4":
            case "12":
            case "20":
                return 6;
            case "11":
            case "19":
            case "31":
            case "52":
            case "9":
            case "22":
            case "25":
            case "46":
            case "14":
                return 9;
            default:
                return -1;

        }
    }

    function removeFileFromDB(uploadObj, entity) {
        if (!global.isNOE(entity) && $.isFunction(entity.Id) && !global.isNOE(entity.complexAspect.originalValues.Id)) {
            uploadObj.removeCurrentFileFromDb(entity.complexAspect.originalValues.Id);
            entity.Name(null);
        }
        else if (!global.isNOE(entity) && !$.isFunction(entity.Id) && !global.isNOE(entity.Id)//specific for Unit_I other salaries attachments
           && !global.isNOE(entity.Name)) {
            uploadObj.removeCurrentFileFromDb(entity.Id);
            entity.Id = null;
            entity.Name = null;
        }
    }

    function removeSpecFileFromDbByID(params) {
        var command = {
            AttachmentId: params.attachedId,
            TaxYear: params.TaxYear,
            Emp_no: params.Emp_no,
            VersionNo: params.Version
        };
        global.httpPost(global.enums.httpPath.Form101RemoveAttachmentFile, command);
    }

    var helper = {
        placeTooltip: placetooltip,
        bankAccountValidation: bankAccountValidation,
        bankValidAccountLength: bankValidAccountLength,
        removeFileFromDB: removeFileFromDB,
        removeSpecFileFromDbByID: removeSpecFileFromDbByID
    };
    return helper;
});