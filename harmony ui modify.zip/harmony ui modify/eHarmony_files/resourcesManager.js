﻿define(function resourcesManagerModule(require) {
    var http = require('plugins/http');
    var errorManager = require('common/errorManager');
    var helper = require('common/helper');
    var enums = require('common/enums/enums');
    var webApiConfig = require('common/webApiConfig');
    var cacheManager = require('common/cache/cacheManager');
    var cacheItems = cacheManager.cacheItems;
    require('common/kendoWidgets');
    var LtrCss = require.toUrl('content/bootstrap.min.css');
    var RtlCss = require.toUrl('content/bootstrap-rtl.min.css');
    var RtlHarmonyCss = require.toUrl('content/harmony-rtl.css');
    var LtrHarmonyCss = require.toUrl('content/harmony.css');
    var RtlKandoCss = require.toUrl('../../Scripts/kendoui/css/kendo.rtl.min.css');
    var GlobalCss = require.toUrl('content/global.css');
    var KendoCss = require.toUrl('content/kendo.default.min.css');

    var resourcesManager = {

        loadResources: loadResources,

        initialLanguage: initialLanguage,

        getMessageByKey: function (msgKey) {

            return getByKey(cacheItems.DICTMSG, msgKey);
        },
        getValueByKey: function (key) {

            return getByKey(cacheItems.DICT, key);
        },
        getValueByMultipleKeys: function (keys) {
            var value = "";
            if (keys == null)
                return value;
            var keysArr = keys.split('&');
            for (var key in keysArr)
                value += getByKey(cacheItems.DICT, keysArr[key]) + " ";
            return value.slice(0, -1);
        },

        addCssAccordingLanguageDirection: addCssAccordingLanguageDirection,
        addCss: addCss
    };

    return resourcesManager;

    function getByKey(dictType, key) {

        var dict = cacheManager.get(dictType);
        var requiredValue = dict[key];
        //error tracking: checks if this key exists in the dictMsg
        if (helper.isNull(requiredValue)) {
            throw new Error("problem with the get msg from the " + dictType.name + " of the recources.\n" +
            "The key is not valid, key:" + key);
        }
        else {
            return requiredValue;
        }
    }

    function loadResources(languageCode, needToSendCompanyId) {
        var companyId = '0';//0 - is good for portal before enter to company and for in-house too
        if (needToSendCompanyId) {
            companyId = cacheManager.get(enums.cacheItems.CURCOMP).id;
        }
        var needLoadTooltip = false;
        if (cacheManager.isExistKey(enums.cacheItems.CURCOMP)) {
            needLoadTooltip = true;
        }
        var resourcesQuery = JSON.stringify({ LanguageId: languageCode, CompanyId: companyId, NeedLoadTooltip: needLoadTooltip });
        return http.get(webApiConfig.getApiPath(enums.httpPath.GetResources.path), { query: resourcesQuery }).done(function getResourcesSucceed(response) {
            initialLanguage(response, languageCode, needLoadTooltip);
        })
    }

    function initialLanguage(resources, languageCode, isLoadTooltip) {
        try {
            cacheManager.set(cacheItems.DICT, resources.Dict);
            cacheManager.set(cacheItems.DICTMSG, resources.DictMessage);
            if (isLoadTooltip && resources.Tooltips) {
                cacheManager.set(cacheItems.TOOLTIPS, resources.Tooltips);               
            }

            helper.dict(cacheManager.get(cacheItems.DICT));//need take from cache, cache set the resources to behave as Dictionary
            helper.dictMsg(cacheManager.get(cacheItems.DICTMSG));

            cacheManager.set(cacheItems.LAST_LANGUAGE, languageCode);
            cacheManager.set(cacheItems.LAST_LANGUAGE, languageCode);
            addCssAccordingLanguageDirection(languageCode);
        }
        catch (err) {
            errorManager.treatError(err);
        }
    }

    function addCssAccordingLanguageDirection(languageCode) {
        var dir = cacheManager.getLanguageDir(languageCode);
        $("body").attr("dir", dir); // put here the relevant ltr or rtl 
        //the reload css of bootstrap against the "dir" type above
        removeDirectionCss();
        addCss(KendoCss);
        if (dir != null && dir.toLowerCase() == "rtl") {
            addCss(LtrCss);
            addCss(RtlCss);
            addCss(GlobalCss);
            addCss(RtlHarmonyCss);
            addCss(RtlKandoCss);
            $("body").addClass('k-rtl');
        }
        else {
            addCss(LtrCss);
            addCss(GlobalCss);
            addCss(LtrHarmonyCss);
            if ($("body").hasClass('k-rtl'))
                $("body").removeClass('k-rtl');
        }
    }

    function addCss(fileName) {
        var cssTag = document.createElement("link");
        cssTag.setAttribute("rel", "stylesheet");
        cssTag.setAttribute("href", fileName)
        cssTag.setAttribute("class", "__directionCss");
        document.getElementsByTagName("head")[0].appendChild(cssTag)
    }

    function removeDirectionCss() {
        $(".__directionCss").remove();

    }


});