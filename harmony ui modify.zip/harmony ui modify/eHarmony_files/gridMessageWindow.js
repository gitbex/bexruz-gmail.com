﻿define(function gridMessageWindowControl(require) {
	var global = require('common/global');
	var enums = require('common/enums/enums');
	var imagesManager = require('common/imagesManager');
	var resourcesManager = require('common/resourcesManager');
	var cacheManager = require('common/cache/cacheManager');
	var dialogManager = require('common/dialogManager');
	var configurationManager = require('common/configurationManager');
	var gridVM = require('views/controls/gridUC/gridkendoUC');
	var actionsStackButtons = require('views/combinedControls/actionsStackButtons/actionsStackButtons');
	var isExistDict;
	var dialog = require('plugins/dialog');
	var layoutName;
	var global;
	var dataGrid = new kendo.data.ObservableArray([]);
	var widthPartOfFull = 0.4;

	function buildMessage(options) {
	    
		if (options.pHeight) {
			$(".popupHeight").height(options.pHeight);
		}
		if (options.pWidthPartOfFull) {
		    widthPartOfFull = options.pWidthPartOfFull;
		}
		if (options.layoutName && options.global) {
			global = options.global;
			layoutName = options.layoutName;
		}
		var btnOkText = (!global.isNOE(options.okText)) ? options.okText : global.res[302];
		//build buttons
		vm.okText(btnOkText);
		vm.continueText(global.res[2855]);
		vm.backText(global.res[5444]);
		vm.showDetailsLableText(global.res[998]);

		vm.imgClose(imagesManager.actionsStackButtonsCollapse);

		//building title text
		if (options.title)  //specific title
			vm.title(options.title);
		else {
			if (isExistDict) {
				switch (options.mode) {
					case enums.messageType.info:
						vm.title(resourcesManager.getValueByKey(4221));//Information
						break;
					case enums.messageType.error:
						vm.title(resourcesManager.getValueByKey(118));//Error
						break;
					case enums.messageType.warning:
						vm.title(resourcesManager.getValueByKey(4503));//Warning
						break;
					case enums.messageType.question:
						vm.title(resourcesManager.getValueByKey(4502));//Question
						break;
					default:
						break;
				}
			}
			else {  //case failure before Dict have been loaded
				switch (options.mode) {
					case enums.messageType.info:
						vm.title("Information");
						break;
					case enums.messageType.error:
						vm.title("Error");
						break;
					case enums.messageType.warning:
						vm.title("Warning");
						break;
					case enums.messageType.question:
						vm.title("Question");
						break;
					default:
						break;
				}
			}
		}

		switch (options.mode) {
			case enums.messageType.info:
				vm.headerImg(imagesManager.info);
				break;
			case enums.messageType.error:
				vm.headerImg(imagesManager.error);
				break;
			case enums.messageType.warning:
				vm.headerImg(imagesManager.notice);
				break;
			case enums.messageType.question:
				vm.headerImg(imagesManager.question);
				break;
			default:
				vm.headerImg(imagesManager.info);
				break;
		}

		//building details text
		if (options.detailsArray) {
			//load grid
			vm.isOpening(false);
			
		}
		else {
			vm.needShowDetails(false);
			vm.details(null);
			vm.isOpening(false);
		}
		vm.popupWidth($(window).width() * widthPartOfFull + 'px');
		//check if error occured & if it is login sql error - show systematic error in message parameter
		if (options.exceptionType && options.exceptionType == enums.exceptionTypes.ConnectSQL) {
			vm.messageColor("Red");
			vm.isOpening(false);
		}
		if (options.messageColor)
			vm.messageColor(options.messageColor);

		vm.message(('' + options.messageText).replace('\r\n', '<br/>').replace('\n', '<br/>'));//replace new line & environment.new_line in c# to tag <br> of html

		//building buttons
		switch (options.btnsMode) {
		    case enums.btnsMode.continueBack:
		        vm.msgOkWindow(false);
		        vm.msgContinueBackWindow(true);
		        break;
			default:
			    vm.msgOkWindow(true);
			    vm.msgContinueBackWindow(false);
				break;
		}

		if (options.isCustom) {
			vm.customAction(options.customDelegate);
			vm.msgCustomWindow(true);
			vm.customText(options.customText);
		}
		else {
			vm.msgCustomWindow(false);//clear last time            
		}

		if (options.windowId)
			vm.windowId(options.windowId);

		//showing details by Config param
		var configParam;
		try {
			configParam = configurationManager.getConfigParam(enums.configParams.MODE_OF_RUNNING_APP);
		}
		catch (err) { }
		if (!options.detailsMustDisplay && vm.needShowDetails()) { // added to display attend details per row, e.g. OVERLAP
			if (options.mode == enums.messageType.error && configParam == 2)   //release - not show details error messages
			{
				vm.needShowDetails(false);
				vm.isOpening(false);
			}
		}
			
		if (options.data) {
			if (options.data.length > 0) {
				dataGrid = options.data;
				initGrid(options.gridSchema);
				if (vm.resultGrid.isBoundDOM == true) {
					vm.resultGrid.setDataSource(options.data, true);
				}				
			}			
		}
	}

	function initGrid(gridSchema) {	
		vm.resultGrid.setGridOptionsSetting({ columnMenu: false });	
		var columns = [];
		var fields = {};
		for (i = 0; i < gridSchema.length; i++) {
			var column = {
				field: gridSchema[i].field,
				title: gridSchema[i].title,
				width: gridSchema[i].title.length * 3 / 5 + "em",
				filterable: gridSchema[i].filterable,
				sortable: false,
				menu: false,				
				template: '<span>#=' + gridSchema[i].field + '#</span>'
			};
			columns.push(column);
			fields[gridSchema[i].field] = { type: global.enums.types.string }
		}		
		vm.resultGrid.gridOptions.columns = columns;
		vm.resultGrid.schema = {
			model: {				
				fields: fields
			}
		};
		if (dataGrid != null) {
			vm.resultGrid.setDataSource(dataGrid, true);
		}		
	}

	function showDetailsClick() {
		try {
			if (vm.isOpening()) {
				vm.isOpening(false);
			}
			else {
				vm.isOpening(true);
			}
		}
		catch (err) {
		}
	}

	function closeWindow(e, sender) {
		try {
			var btnId = sender.currentTarget.id;
			var userAnswer = null;
			switch (btnId) {				
				case "okBtn":			
					userAnswer = enums.customMsgWindowResult.ok;
					break;
			    case "continueBtn":
			        userAnswer = enums.customMsgWindowResult.continue;
			        break;
				default:
					break;
			}
			if (layoutName)
				layout({ name: layoutName, set: true });
			dialogManager.closeDialog(vm, userAnswer);
		}
		catch (err) {
			//implement
		}
	}

	function layout(option) {
		var layout = global.enums.cacheItems.MESSAGE_LAYOUT;
		layout.name = option.name;
		var mess = $(".messageBox");
		if (option.get) {
			var getLayout = global.cache.get(layout);
			if (getLayout != null) {
				var oLayout = JSON.parse(getLayout);
				mess.height(oLayout.height);
				mess.width(oLayout.width);
				if (mess.find("#scrollDiv").length)
					mess.find("#scrollDiv").height(oLayout.height * 80 / 100);
				if (mess.find("#gridMessage-content").length)
					mess.find("#gridMessage-content").height(oLayout.height);
			}
		}
		else if (option.set) {
			var layoutSet = kendo.stringify({ height: mess.height(), width: mess.width() });
			global.cache.set(layout, layoutSet);
		}
	}

	function exportToExcel() {
		vm.resultGrid.exportToExcel();
	}

	function compositionComplete() {
		try {
			if (layoutName)
				layout({ name: layoutName, get: true });

			if ($('#formPDFFrame') && $('#formPDFFrame').length > 0)
				$('#outerFrame')[0].style.display = '';

			setTimeout(function () { $(".firstButton:visible").focus(); }, 10);
		}
		catch (err) {
			global.treatError(err);
		}

	}
	var vm = {
		title: ko.observable(),
		msgOkWindow: ko.observable(false),	
		msgCustomWindow: ko.observable(false),
		msgContinueBackWindow: ko.observable(false),
		showDetailsLableText: ko.observable(),
		imgClose: ko.observable(),
		message: ko.observable(),
		details: ko.observable(''),
		showDetailsClick: showDetailsClick,
		closeWindow: closeWindow,
		isOpening: ko.observable(false),
		buildMessage: buildMessage,		
		okText: ko.observable(),	
		closeText: ko.observable(),
		continueText: ko.observable(),
		backText: ko.observable(),
		needShowDetails: ko.observable(false),
		compositionComplete: compositionComplete,
		popupWidth: ko.observable($(window).width() * widthPartOfFull + 'px'),
		customAction: ko.observable(function () { }),
		customText: ko.observable(''),
		headerImg: ko.observable(''),
		windowId: ko.observable("defaultId"),
		messageColor: ko.observable('Black'),
		resultGrid: new gridVM({ gridId: "resultGrid", pageable: false, sortable: false, filterable: true, editable: false }),		
		actionsStackButtonsControl: new actionsStackButtons(
            {
            	excelFunc: exportToExcel
            })
	};

	return vm;

});