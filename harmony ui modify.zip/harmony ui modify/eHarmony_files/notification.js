﻿define(function notification(require) {
    var global = require('common/global');
    var cacheManager = require('common/cache/cacheManager');
    var counter = 0;


    var notification;   

    function showNotification(options) {
        var noteElem = document.createElement("span");
        noteElem.style.display = 'none';        
        noteElem.id = 'notification' + ++counter;
        $('#shellDiv').append($(noteElem));
        var lastLang = cacheManager.get(cacheManager.cacheItems.LAST_LANGUAGE);
        var _right = 0;
        var _left = 0;
        var _float = 'right';
        if (lastLang == 3) {
            _right = 30
            _float = 'left';
            _left = $(window).width() - 750;
        }
        else {
            _right = $(window).width() - 450;
            _float = 'right';
        }
        notification = $(noteElem).kendoNotification({
        	position: {
        		pinned: true,
        		top: $(window).height() - 225,
        		right: _right,
        		left: _left
        	},
        	autoHideAfter: 0,
        	stacking: "down",
        	templates: [{
        		type: "info",
        		template: " <div class='new-mail' style='width:300px !important;padding-left:10px !important; padding-right:10px !important;'><img src='" + global.imagesManager.tagTypeActiveGreen + "' /><img style='float:" + _float + " !important; padding-top:10px;' src='" + global.imagesManager.organizationLevelClose + "' /><h3>#= title #</h3><p>#= message #</p></div>"
        	}, {
        		type: "error",
        		template: " <div class='wrong-pass' style='width:300px !important;padding-left:10px !important; padding-right:10px !important;'><img src='" + global.imagesManager.error + "'  /><img style='float:" + _float + " !important; padding-top:10px;' src='" + global.imagesManager.organizationLevelClose + "' /><h3>#= title #</h3> <p>#= message #</p></div>"
        	}, {
				type: "other",
				template: " <div class='new-mail' style='width:700px !important; padding-left:10px !important; padding-right:10px !important;'><img style='float:" + _float + " !important; padding-top:10px;' src='" + global.imagesManager.organizationLevelClose + "' /><h5>#= title #</h5> <p>#= message #</p></div>"
            }]

        }).data("kendoNotification");
      

        notification.show({
            title: options.Title,
            message: options.Message
        }, options.Type);
    }
    
    var notificationVM = {       
        showNotification: showNotification

           };

 


    return notificationVM;
});