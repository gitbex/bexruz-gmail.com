﻿define(function tempData(require) {

    var tempData = {
        //for clicking on my document in home page- this variable holds the parameters for selected report
        reportData: null,
    };
    return tempData;
});
