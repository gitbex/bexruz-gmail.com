﻿define(function filterControl(require) {

    var global = require('common/global');

    var vm = function (options) {

        var obj = {
            global: global,
            list: ko.observableArray([]),
            filterId: ko.observable("defaultFilter"),
            filterClick: filterClick,
            selectedFilterItem: ko.observable(''),
            selectedFilterDict: ko.observable(),
            selectedFilterWholeItem: ko.observable(),
            compositionComplete: compositionComplete,
            filterSelectionChanged: function () { },
            title: ko.observable(global.res[15]),
            cacheItem: ko.observable(null),
            hasIcon: ko.observable(false),
            isFiltered: ko.observable(false),
            isAfterClosePopup: ko.observable(false),
            activate: activate,
            changeFilterItemView: changeFilterItemView,
            alignControl: ko.observable('vertical')
        };

        var defaultFilteredDicts = [315, 1383];
        obj.alignCSS = ko.pureComputed(function () {
            return this.alignControl() == 'vertical' ? 'col-md-12' : 'col-md-5 float-last paddingTop10';
        }, obj);

        function activate() {

            var lastSelectedFilterDict;
            var lastSelectedFilterItem;

            if (options) {
                obj.filterId(global.isNullOrEmpty(options.filterId) ? "defaultFilter" : options.filterId);
                obj.list(options.filterList);
                obj.hasIcon(options.hasIcon ? options.hasIcon : false);
                obj.alignControl(global.isNOE(options.alignControl) ? 'vertical' : options.alignControl);
                if (!global.isNullOrEmpty(options.cacheItem)) {
                    obj.cacheItem(options.cacheItem);
                    if (!global.isNOE(global.cache.get(options.cacheItem)))
                        lastSelectedFilterDict = global.cache.get(options.cacheItem).dictNo;
                }
                if (!global.isNullOrEmpty(options.title)) {
                    obj.title(options.title);
                }
                if (obj.isAfterClosePopup() == false && !global.isNullOrEmpty(options.anotherValueCondition) && !global.isNullOrEmpty(options.anotherValue)
                    && lastSelectedFilterDict == options.anotherValueCondition) {
                    lastSelectedFilterItem = options.anotherValue;
                }
                else {
                    if (global.isNullOrEmpty(lastSelectedFilterDict) || typeof lastSelectedFilterDict !== 'string' || lastSelectedFilterDict.indexOf('&') == -1) {
                        lastSelectedFilterItem = global.res[lastSelectedFilterDict];
                    }
                    else {
                        var dictsList = lastSelectedFilterDict.split('&');
                        lastSelectedFilterItem = '';
                        for (var i = 0; i < dictsList.length; i++) {
                            lastSelectedFilterItem += global.res[dictsList[i]] + " & ";
                        }

                        lastSelectedFilterItem = lastSelectedFilterItem.substring(0, lastSelectedFilterItem.lastIndexOf('&'));
                    }
                }
                obj.isAfterClosePopup(false);

                lastSelectedFilterItem = removeItemFromOption(lastSelectedFilterDict, lastSelectedFilterItem);

                if (!global.isNullOrEmpty(lastSelectedFilterItem)) {
                    obj.selectedFilterDict(lastSelectedFilterDict);
                    obj.selectedFilterItem(lastSelectedFilterItem);
                    var filteredItem = Enumerable.From(obj.list())
                                                 .Where(function (lu) { return lu.dictNo == lastSelectedFilterDict && lu.notDisplay == false })
                                                 .Select(function (lu) { return lu })
                                                 .FirstOrDefault();
                    obj.isFiltered(!(global.isNullOrEmpty(filteredItem)) && (global.isNullOrEmpty(filteredItem.notDisplayFilterIcon) || filteredItem.notDisplayFilterIcon == false));
                }
                else {

                    obj.selectedFilterDict(options.defaultDict);
                    obj.selectedFilterItem(global.res[options.defaultDict]);
                    if ($.inArray(options.defaultDict, defaultFilteredDicts) != -1) {
                        obj.isFiltered(true);
                    }
                }
                if (obj.list().length > 0) {
                    $.each(obj.list(), function (k, v) {
                        if (k == obj.list().length - 1) {
                            obj.list()[k].notDisplayEndLine = true;
                        }
                        else {
                            obj.list()[k].notDisplayEndLine = false;
                        }
                    });
                }

            }
        }

        function compositionComplete() {
            //add event of select one of the options of filter
            $("#" + obj.filterId() + " .filterRecord").click(
                    function selectedFilterItemChanged(ui) {
                        onSelectedFilterItemChanged();
                    });

        }

        function removeItemFromOption(itemDic, item) {
            var text = item;
            if (options && options.remove) {
                $.each(options.remove, function (k, v) {
                    var filteredItem = getFilteredItem(v);
                    if (!global.isNull(filteredItem)) {
                        filteredItem.notDisplay = true;
                    }
                    if (itemDic == v)
                        text = "";
                });
            }
            return text;
        }

        function getFilteredItem(dictNo) {
            var filteredItem = Enumerable.From(obj.list())
                              .Where(function (lu) { return lu.dictNo == dictNo })
                               .Select(function (lu) { return lu })
                               .FirstOrDefault();
            return filteredItem;
        }

        function filterClick(sender, e) {
            obj.selectedFilterItem(sender.text);
            obj.selectedFilterDict(sender.dictNo);
            obj.selectedFilterWholeItem(sender);
            if (!global.isNullOrEmpty(sender.notDisplayFilterIcon) && sender.notDisplayFilterIcon == true) {
                obj.isFiltered(false);
            }
            else {
                obj.isFiltered(true);
            }
        }

        //noly change view without really filter
        function changeFilterItemView(text, dict, notDisplayFilterIcon) {
            filterClick({ text: text, dict: dict, notDisplayFilterIcon: notDisplayFilterIcon });
        }

        function onSelectedFilterItemChanged() {

            if (!global.isNull(obj.cacheItem())) {
                global.cache.set(obj.cacheItem(), obj.selectedFilterWholeItem());
            }
            obj.filterSelectionChanged();

        }

        return obj;
    };

    return vm;
});