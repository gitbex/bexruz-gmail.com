﻿define(function uploadImgControl(require) {
    var global = require('common/global');
    var customMessageWindow = require('views/combinedControls/customMessageWindow/customMessageWindow');
    var dialog = require('plugins/dialog');
    var validationHelper = require('data/validationHelper');
    var helper = require('common/helper');
    var fileValidMessages = global.enums.fileValidMessage;
    //get default path to the file's folder, temp folder and default file.
    //if hasImage property is false displaying the default img, otherwise displaying the fileName value.
    //on upload, if there is an fileName send this name to server and the file has been saved with this name otherwise the server creates a new name by GUID.
    //the upload method on server upload the file to temp folder and return the name of the file.
    function ViewModel(uploadUcId, AttachmentType, AttachmentId, AttachmentCategoty, AttachmentName, AttachmentCategoryKey, supportType, isReadOnly, validationField, breezeObject, breezeFieldName, errorFieldToEmpty, isPayrollAccountant, updateGridAttachmentsFunc) {
        if (!global.isNull(validationField)) {
            validationField(fileValidMessages.valid);
        }
        if (isPayrollAccountant == undefined)
            isPayrollAccountant = false;

        var options = {
            uploadUcId: uploadUcId,
            AttachmentType: AttachmentType,
            AttachmentCategoty: AttachmentCategoty,
            AttachmentId: AttachmentId ? AttachmentId : ko.observable(null),
            AttachmentName: AttachmentName ? AttachmentName : ko.observable(null),
            AttachmentCategoryKey: AttachmentCategoryKey ? AttachmentCategoryKey.id : 0,
            supportType: supportType,
        }
        var uploadFiles = function (path, data) {
            var response = $.ajax({
                url: path,
                data: data,
                type: 'POST',
                cache: false,
                contentType: false,
                processData: false,
                enctype: 'multipart/form-data',
                async: false,
            });

            return response;
        }

        var path = ko.observable(null);
        var fileName = ko.observable().extend({ notify: 'always' });
        var dateFormat = global.cache.get(global.enums.cacheItems.DATE_FORMAT);

        var heldDataForSave = null;
        var heldNameForSave = null;
        var heldFileToUpload = null;
        var heldError = fileValidMessages.valid;
        function activate() {
            try {
                obj.deleteFile = ko.computed(function () {
                    return !obj.AttachmentName() && !obj.fileName();
                });
                obj.deleteSrc = ko.computed(function deleteSrc() {
                    return obj.isPayrollAccountant() ? global.imagesManager.actionsStackButtonsDeleteDisable : global.imagesManager.actionsStackButtonsDelete;
                });
            }
            catch (err) {
                global.treatError(err);
            }
        }

        var obj = {
            activate: activate,

            getValidStatus: getValidStatus,
            AttachmentId: options.AttachmentId,
            IsValidType: validationField,
            descript: ko.observable(""),
            isReadOnly: ko.observable(isReadOnly ? true : false),
            /*contol properties*/
            download: download,
            uploadUcId: ko.observable(options.uploadUcId ? options.uploadUcId : "defaultId"),
            onUpdateGridAttachmentsFunc: global.isNull(updateGridAttachmentsFunc) ? function onUpdateGridAttachmentsFunc() { } : updateGridAttachmentsFunc,
            openUpload: openUpload,
            upload: upload,
            isImageChange: false,
            reload: reload,
            temporaryHoldSavingData: temporaryHoldSavingData,
            clear: clear,
            message: helper.replaceDelimFromDict("{0}", global.resMsg[428], supportType),
            clearSelectedFile: clearSelectedFile,
            global: global,
            browseText: ko.observable("browse...!"),
            /*init from the users of the control*/
            onFileChanged: onFileChanged,
            AttachmentName: ko.observable(options.AttachmentName ? options.AttachmentName() : ""),
            hasFile: ko.computed(function () {
                if (uploadUcId == "attendanceIdAttachment")
                    return false;
                else
                    return !(!options.AttachmentId());
            }),
            fileName: ko.observable(''),
            supportType: ko.observable(options.supportType.toString()),
            form101params: null,
            formAttendanceParams: null,
            processAttachment: null, // 13.01.2019 lyn for processApprAttachPopup
            isDisabled: ko.observable(false),
            fileColor: ko.observable("black"),
            attachmentClass: ko.observable("blueFont"),
            removeCurrentFileFromDb: removeCurrentFileFromDb,
            deleteFile: null,
            isPayrollAccountant: ko.observable(isPayrollAccountant),
            deleteSrc: null,
            showImg: ko.observable(true),
            isValidFileName: isValidFileName,
            hasImage: ko.observable(false)
        };

        const max_size = 4000000;
        var max_width;
        var max_height;
        var resize_ratio;

        obj.fileColor = ko.computed(function () { obj.isDisabled() ? "gray" : "black" });
        obj.attachmentClass = ko.computed(function () { obj.isDisabled() ? "blueFontDisabled" : "blueFont"; });
        if (obj.uploadUcId() == "attendanceIdAttachment") {
            obj.showImg(false);
        }

        function isValidFileName(fname) {
            var rg1 = /^[^\\/:\*\?\+\#"<>\|&]+$/;//forbidden invalid chars in filename \ / : * ? " < > | & + #
            return rg1.test(fname);
        }

        function onFileChanged() {
            heldDataForSave = null;
            heldNameForSave = null;
            heldError = fileValidMessages.valid;
            var uploadFiles = $("#" + obj.uploadUcId())[0].children.file1.files;
            inputField = $("#" + obj.uploadUcId())[0].children[0];
            form = $("#" + obj.uploadUcId())[0].parentNode.parentNode;

            if (uploadFiles[0]) {
                var message = "";
                //check if filname is valid
                if (!isValidFileName(uploadFiles[0]['name'])) {
                    message = global.resMsg[363];
                    heldError = fileValidMessages.invalidType;
                    customMessageWindow.buildMessage({ mode: global.enums.messageType.error, messageText: message });
                    global.showDialog(customMessageWindow);
                    return;
                }

                if ((/image/i).test(uploadFiles[0].type)) {
                    processfile(uploadFiles[0]);
                }

                obj.fileName(uploadFiles[0]['name']);
                obj.AttachmentName(uploadFiles[0]['name'])

                if (obj.uploadUcId() == "attendanceIdAttachment") {
                    var result = upload();
                    obj.fileName(null);
                    if (!result) {
                        switch (obj.IsValidType()) {
                            case fileValidMessages.invalidType:
                                message = global.resMsg[363];
                                break;
                            case fileValidMessages.invalidSize:
                                message = global.resMsg[494];
                                break;
                        }
                        customMessageWindow.buildMessage({ mode: global.enums.messageType.error, messageText: message });
                        global.showDialog(customMessageWindow);
                    }
                    else
                        obj.onUpdateGridAttachmentsFunc();
                }
            }

            if (!global.isNull(breezeObject)) {
                validationField(fileValidMessages.valid);
                var oldId = AttachmentId();
                AttachmentId(-2);
                validationHelper.validateSingleField(breezeObject, breezeFieldName);
                AttachmentId(oldId);
            }

            if (!global.isNull(errorFieldToEmpty)) {
                errorFieldToEmpty('');
            }
        }

        //remove the file.
        function clear() {
            obj.hasImage(false);
            obj.fileName(null);
            //exec the function.
            obj.onFileChanged();
        }

        function clearSelectedFile() {
            obj.hasImage(false);
            obj.fileName(null);
            obj.AttachmentId(null);
            obj.AttachmentName(null);
            var div = $("#" + obj.uploadUcId());
            div[0].children.file1.value = '';

        }

        //set for the default, such as first time.
        function reload() {
            //path(filesPath);
            obj.isImageChange = false;
        }

        function openUpload() {
            $("#" + obj.uploadUcId()).find("input").click();
        }

        function upload(isForHold) {

            //if (!global.isNull(AttachmentId)) {
            //    if (AttachmentId() == -1) {
            //        AttachmentId(null);
            //    }
            //}
            if (obj.isDisabled()) {
                if (!global.isNull(validationField)) {
                    validationField(fileValidMessages.valid);//empty previous checking result
                }
                removeCurrentFileFromDb();//need remove last saved file if there
                options.AttachmentId(null);
                options.AttachmentName(null);
                return false;
            }
            else {
                if (global.isNull(heldDataForSave)) {
                    if (!global.isNull(validationField) && heldError != fileValidMessages.valid && !obj.deleteFile()) {
                        validationField(heldError);
                        return false;
                    }
                    var div = $("#" + obj.uploadUcId());
                    var file = div.length > 0 ? div[0].children.file1 : null;
                    if (!file || !file.files) return;
                    ///* Create a FormData instance */
                    var formData = new FormData();
                    /* Add the file */
                    var fileToUpload = file.files[0];
                    if (!fileToUpload || obj.deleteFile()) {
                        if (!global.isNull(validationField)) {
                            validationField(fileValidMessages.valid);//empty previous checking result
                        }
                        return false;
                    }
                    //in case when the selected file is not an file.
                    //if (!fileToUpload.type.match(/.*\/[A-Za-z]+$/)) {
                    //    customMessageWindow.buildMessage(global.enums.messageType.warning, global.resources(437));
                    //    global.dialog.show(customMessageWindow);
                    //    file.value = null;
                    //    return false;
                    //}
                    //if (obj.fileName())//if there is name, send to server the name - the img will be saved with this name.
                    //    formData.append("fileName", obj.fileName().substr(0, obj.fileName().lastIndexOf(".")));

                        return setTheNewImg(formData, fileToUpload, isForHold);
                }
                else {
                    if (!isForHold) {
                        var heldData = heldDataForSave;
                        heldDataForSave = null;
                        return setTheNewImg(heldData);
                    }
                    else
                        return;
                }
                //empty the file, for case that the user choose the same file,the onChange event exec again.
                file.value = null;
            }
        }

        function removeCurrentFileFromDb(attachedId) {
            if (obj.hasFile()) {
                if (options.AttachmentCategoty && options.AttachmentCategoty.id == 2)//form101
                {
                    var command = {
                        AttachmentId: options.AttachmentId(),
                        TaxYear: obj.form101params.TaxYear,
                        Emp_no: obj.form101params.Emp_no,
                        VersionNo: obj.form101params.Version
                    };
                    global.httpPost(global.enums.httpPath.Form101RemoveAttachmentFile, command);
                }
            }
            else if (attachedId && options.AttachmentCategoty && options.AttachmentCategoty.id == 2)//remove deleted file.used in saving form101 after delete saved file by garbage icon
            {
                var command = {
                    AttachmentId: attachedId,
                    TaxYear: obj.form101params.TaxYear,
                    Emp_no: obj.form101params.Emp_no,
                    VersionNo: obj.form101params.Version
                };
                return global.httpPost(global.enums.httpPath.Form101RemoveAttachmentFile, command);
            }

        }

        function getValidStatus() {
            if (heldDataForSave)
                return fileValidMessages.valid;
            var div = $("#" + obj.uploadUcId());
            var file = div.length > 0 ? div[0].children.file1 : null;
            if (!file || !file.files) return fileValidMessages.missing;

            var fileToUpload = file.files[0];
            if (!fileToUpload) {
                return fileValidMessages.missing;
            }
            var fileExtension = fileToUpload.name.substr(fileToUpload.name.lastIndexOf('.') + 1, fileToUpload.name.length).toLowerCase();
            if (!global.isNull(global.enums.AttachmentFileExtension[fileExtension]) && global.enums.AttachmentFormat[global.enums.AttachmentFileExtension[fileExtension].format]) {
                if (fileToUpload.size > 4194304) {
                    return fileValidMessages.invalidSize;
                }
                else {
                    return fileValidMessages.valid;
                }
            }
            else {
                return fileValidMessages.invalidType;
            }
        }

        //set the selected img from upload.
        function setTheNewImg(formData, fileToUpload, isForHold) {
            if (heldFileToUpload)
                fileToUpload = heldFileToUpload;
            if (fileToUpload) {
                var fileExtension = fileToUpload.name.substr(fileToUpload.name.lastIndexOf('.') + 1, fileToUpload.name.length).toLowerCase();
                if (global.enums.AttachmentFileExtension[fileExtension]) {
                    var attFormat = global.enums.AttachmentFormat[global.enums.AttachmentFileExtension[fileExtension].format].id;
                    if (!global.isNull(validationField)) {
                        validationField(fileValidMessages.valid);//empty previous checking result
                    }
                }
                else {
                    if (isForHold) {
                        heldError = fileValidMessages.invalidType;
                    }
                    validationField(fileValidMessages.invalidType);
                    //if (global.isNull(AttachmentId())) {
                    //    //in Attachment breeze entity has 2 validations - required field&file type
                    //    //after checking if user attached file(require) , breeze checks if the type is incorrect
                    //    //But: when user attached incorrect type file, the required validation is displayed :( 
                    //    //so we prevent this behaviour by inserting -1 value to Attachment Id, and then the correct validation is displayed.
                    //    AttachmentId(-1);
                    //}
                    return false;
                }
            }

            if (obj.uploadUcId() == "attendanceIdAttachment") {
                if (!global.isNull(fileToUpload)) {
                    var today = new Date();
                    formData.append("AttFormat", attFormat);
                    formData.append("AttachmentName", fileToUpload.name);
                    formData.append("AttStoreType", 0);
                    formData.append("AttPath", $("#" + obj.uploadUcId()).find("input").val() ? $("#" + obj.uploadUcId()).find("input").val() : fileToUpload.name);
                    formData.append("AttFile", fileToUpload);
                    formData.append("AttachmentId", options.AttachmentId ? options.AttachmentId() : null);
                    formData.append("UpdatedBy", global.cache.get(global.cache.enums.cacheItems.USER).Id);
                    if (obj.formAttendanceParams)//formAttendance
                    {
                        formData.append("AbsenceCode", obj.formAttendanceParams.AbsenceCode);
                        formData.append("OldAbsenceCode", -1);
                        formData.append("Emp_no", obj.formAttendanceParams.EmpNo ? obj.formAttendanceParams.EmpNo : global.cache.get(global.cache.enums.cacheItems.USER).Id);
                        var fromDateOnly = new Date(obj.formAttendanceParams.FromDate).toString(global.consts.yearFirstDateFormat);
                        formData.append("FromDate", fromDateOnly);
                        var toDateOnly = new Date(obj.formAttendanceParams.ToDate).toString(global.consts.yearFirstDateFormat);
                        formData.append("ToDate", toDateOnly);
                    }
                    if (obj.processAttachment) // 13.01.2019 Lyn
                    {
                        formData.append("Emp_no", obj.processAttachment.EmpNo);
                        formData.append("Pnum", obj.processAttachment.Pnum);
                        formData.append("Snum", obj.processAttachment.Snum);
                        formData.append("SstartDate", obj.processAttachment.SstartDate); // 03.02.2019
                    }
                    if (!isForHold) {
                        var response;
                        if (obj.processAttachment) // 13.01.2019 Lyn
                            response = uploadFiles(global.webApiConfig.getApiPath(global.enums.httpPath.HomePageSaveProcessAttachment.path), formData)
                        else
                            response = uploadFiles(global.webApiConfig.getApiPath(global.enums.httpPath.PostAttendanceAttachment.path), formData)
                    }
                    else {
                        heldDataForSave = formData;
                        heldNameForSave = fileToUpload.name;
                    }
                }
                else {
                    var response = uploadFiles(global.webApiConfig.getApiPath(global.enums.httpPath.PostAttendanceAttachment.path), formData)

                }
            }
            else {
                if (!global.isNull(fileToUpload)) {
                    obj.hasImage(true);
                    formData.append("AttType", options.AttachmentType ? options.AttachmentType : global.enums.AttachmentType.Other.id);
                    formData.append("AttFormat", attFormat);
                    formData.append("AttachmentName", fileToUpload.name);
                    formData.append("AttStoreType", 0);
                    //when store in server send AttStoreType= 1, and AttPath , in db send AttStoreType=0, and AttFile
                    //formData.append("AttPath", $("#" + obj.uploadUcId()).find("input").val() ? $("#" + obj.uploadUcId()).find("input").val() : fileToUpload.name);
                    formData.append("AttFile", fileToUpload);
                    formData.append("CategoryLvl", options.AttachmentCategoty ? '1,' + options.AttachmentCategoty.id : global.enums.AttachmentCategoty.General.id);
                    formData.append("CategoryCode", options.AttachmentCategoty && options.AttachmentCategoryKey ? options.AttachmentCategoty.id + "," + options.AttachmentCategoryKey : "2,2");
                    formData.append("TreeLevel", options.TreeLevel ? options.TreeLevel : global.enums.OrgTreeLevel.Emp.id);
                    formData.append("TreeCode", options.TreeCode ? options.TreeCode : global.cache.get(global.cache.enums.cacheItems.USER).Id);
                    formData.append("AttachmentId", null);
                    if (obj.form101params && options.AttachmentCategoty && options.AttachmentCategoty.id == 2)//form101
                    {
                        formData.append("TaxYear", obj.form101params.TaxYear ? obj.form101params.TaxYear : 0);
                        formData.append("Emp_no", obj.form101params.Emp_no ? obj.form101params.Emp_no : 0);
                        formData.append("Version", obj.form101params.Version ? obj.form101params.Version : 0);
                    }

                    if (!isForHold) {
                        var response = uploadFiles(global.webApiConfig.getApiPath(global.enums.httpPath.PostForm101Attachment.path), formData)

                    }
                    else {
                        heldDataForSave = formData;

                    }

                }
                else {
                    if (heldFileToUpload)
                        var response = uploadFiles(global.webApiConfig.getApiPath(global.enums.httpPath.PostForm101Attachment.path), formData)
                    else
                        var response = uploadFiles(global.webApiConfig.getApiPath(global.enums.httpPath.PostFile.path), formData)

                }
            }
            if (!isForHold) {
                if (response.status != 200) {/*error*/
                    reload();
                    return;
                }
                var results = $.parseJSON(response.responseText);
                if (results.ErrorMessage != "OK") {
                    global.treatError(results.ErrorMessage);
                }
                var result;
                if (fileToUpload) {
                    obj.AttachmentName(fileToUpload.name);
                    result = {
                        Attachment_ID: results.AttachmentId ? results.AttachmentId : null,
                        AttachmentName: fileToUpload.name,
                        // AttachmentType: options.AttachmentType ? options.AttachmentType.id : global.enums.AttachmentType.Other.id
                    };
                }
                else {
                    obj.AttachmentName(heldNameForSave);
                    result = {
                        Attachment_ID: results.AttachmentId ? results.AttachmentId : null,
                        AttachmentName: heldNameForSave,
                        // AttachmentType: options.AttachmentType ? options.AttachmentType.id : global.enums.AttachmentType.Other.id
                    };
                    heldNameForSave = null;
                }
                return result;

                //exec the function.
                obj.onFileChanged();
            }
            else {
                heldDataForSave = formData;
                heldNameForSave = fileToUpload.name;
                heldFileToUpload = fileToUpload;
            }
        }

        //convert from URI to file object
        function dataURItoBlob(dataURI) {
            // convert base64/URLEncoded data component to raw binary data held in a string
            var byteString;
            if (dataURI.split(',')[0].indexOf('base64') >= 0)
                byteString = atob(dataURI.split(',')[1]);
            else
                byteString = unescape(dataURI.split(',')[1]);

            // separate out the mime component
            var mimeString = dataURI.split(',')[0].split(':')[1].split(';')[0]

            // write the bytes of the string to an ArrayBuffer
            var ab = new ArrayBuffer(byteString.length);
            var ia = new Uint8Array(ab);
            for (var i = 0; i < byteString.length; i++) {
                ia[i] = byteString.charCodeAt(i);
            }

            // write the ArrayBuffer to a blob
            var bb = new Blob([ia.buffer], { type: mimeString });
            return bb;
        }

        function processfile(file) {

            resize_ratio = max_size / file.size;

            // read the files
            var reader = new FileReader();
            reader.readAsArrayBuffer(file);

            reader.onload = function (event) {
                // blob stuff
                var blob = new Blob([event.target.result]); // create blob...
                window.URL = window.URL || window.webkitURL;
                var blobURL = window.URL.createObjectURL(blob); // and get it's URL

                // helper Image object
                var image = new Image();
                image.src = blobURL;
                image.onload = function () {
                    // have to wait till it's loaded
                    var resized = resizeMe(image); // send it to canvas

                    var blobBin = atob(resized.split(',')[1]);
                    var array = [];
                    for (var i = 0; i < blobBin.length; i++) {
                        array.push(blobBin.charCodeAt(i));
                    }
                    var blob = new Blob([new Uint8Array(array)], { type: 'image/png' });
                    var file = new File([blob], obj.AttachmentName());
                    heldFileToUpload = file;
                }
            };
        }

        function resizeMe(img) {

            max_width = img.width * resize_ratio;
            max_height = img.height * resize_ratio;

            var canvas = document.createElement('canvas');

            var width = img.width;
            var height = img.height;

            // calculate the width and height, constraining the proportions
            if (width > height) {
                if (width > max_width) {
                    //height *= max_width / width;
                    height = Math.round(height *= max_width / width);
                    width = max_width;
                }
            } else {
                if (height > max_height) {
                    //width *= max_height / height;
                    width = Math.round(width *= max_height / height);
                    height = max_height;
                }
            }

            // resize the canvas and draw the image data into it
            canvas.width = width;
            canvas.height = height;
            var ctx = canvas.getContext("2d");
            ctx.drawImage(img, 0, 0, width, height);

            return canvas.toDataURL("image/jpeg", 0.7); // get the data from canvas as 70% JPG (can be also PNG, etc.)

        }

        //reduce file size.
        function reduceImgSize(reader, formData, fileToUpload) {
            var fileType = fileToUpload.type;
            var file = new Image();
            file.src = reader.result;

            file.onload = function () {
                var maxWidth = 960,
                    maxHeight = 960,
                    fileWidth = file.width,
                    fileHeight = file.height;

                if (fileWidth > fileHeight) {
                    if (fileWidth > maxWidth) {
                        fileHeight *= maxWidth / fileWidth;
                        fileWidth = maxWidth;
                    }
                }
                else {
                    if (fileHeight > maxHeight) {
                        fileWidth *= maxHeight / fileHeight;
                        fileHeight = maxHeight;
                    }
                }

                var canvas = document.createElement('canvas');
                canvas.width = fileWidth;
                canvas.height = fileHeight;

                var ctx = canvas.getContext("2d");
                ctx.drawImage(this, 0, 0, fileWidth, fileHeight);

                // The resized file ready for upload
                var dataURL = canvas.toDataURL(fileType);
                //get file object
                var blob = dataURItoBlob(dataURL);
                blob.name = fileToUpload.name;
                return setTheNewImg(formData, blob);
            }
        }

        function download() {
            var query;
            if (options.AttachmentCategoty.id == 2)//form101 - need to send IsDecrypt=true
                query = { AttachmentId: options.AttachmentId().toString(), IsDecrypt: true }
            else
                query = { AttachmentId: options.AttachmentId().toString(), IsDecrypt: false }
            global.httpGet(global.enums.httpPath.GetFile, { query: JSON.stringify(query) })
             .done(function (result) {
                 if (!global.isNullOrEmpty(result)) {
                     global.viewFileInNewWindow(result.AttName, global.consts.tempFilesPath + global.cache.get(global.cache.enums.cacheItems.SESSION_ID));
                 }
             });
        }

        function temporaryHoldSavingData() {
            upload(true);

        }
        return obj;
    }
    return ViewModel;
});