﻿define(function cacheManagerModule(require) {

    this.cookie = require('common/cache/cookie');
    this.localStorageManager = require('common/cache/localStorageManager');
    this.memoryCache = require('common/cache/memoryCache');
    var enums = require('common/enums/enums');

    var that = this;
    var module = {
        clearSessionStorageWithoutSystemParams: that.memoryCache.clearButSaveSystemParams,
        enums: enums,
        cacheItems: enums.cacheItems,
        set: function set(cacheItem, val) {
            switch (cacheItem.cacheMode) {
                case enums.cacheMode.MEMORY_CACHE:
                    memoryCache.set(cacheItem, val);
                    break;
                case enums.cacheMode.LOCAL_STORAGE:
                    localStorageManager.set(cacheItem, val);
                    break;
                case enums.cacheMode.COOKIE:
                    cookie.set(cacheItem, val);
                    break;
            }
        },

        get: function get(cacheItem) {

            switch (cacheItem.cacheMode) {
                case enums.cacheMode.MEMORY_CACHE:
                    return memoryCache.get(cacheItem);
                case enums.cacheMode.LOCAL_STORAGE:
                    return localStorageManager.get(cacheItem);
                case enums.cacheMode.COOKIE:
                    return cookie.get(cacheItem);
            }
        },
        setPropOfLocalStorageItem: that.localStorageManager.setPropOfItem,
        getPropOfLocalStorageItem: that.localStorageManager.getPropOfItem,
        codingSpecificCompanyParams: function codingSpecificCompanyParams(decodeOrEncode, companyParamName, fieldValue) {
            switch (companyParamName) {
                case "ServerHost":
                case "CommIP":
                case "FTPpath":
                case "FTPServer":
                case "NotifierIP":
                case "SynergyCommServer":
                case "TranFileDir":
                case "BackUpFileDir":
                case "TemplateFileDir":
                case "RdyFileDir":
                case "EmpPicFilesDir":
                case "SYsemac_address":
                    if (decodeOrEncode == 1)    /*decode*/
                        return  decodeURIComponent(escape(atob(fieldValue)));
                    else    /*encode*/
                        return btoa(unescape(encodeURIComponent(fieldValue)));
                default:return fieldValue;
            }
        },
        getCompanyParamByFieldName: function getCompanyParamByFieldName(companyParamName, isByFieldGrp) {
            try {
                var companyParams = memoryCache.get(cacheItems.COMPANY_PARAMS);

               // var  companyParams = helper.codingSpecificComapnyParamsFromServer(1/*DEcode*/, memoryCache.get(cacheItems.COMPANY_PARAMS));

                if (typeof isByFieldGrp === "undefined" || isByFieldGrp === null) {
                    isByFieldGrp = 0;
                }
                var i;
                for (i = 0; i < companyParams.length; i++)
                    if (isByFieldGrp == 1) {
                        if (companyParams[i].FieldGroup == companyParamName)
                            return companyParams[i].fieldvalue;
                    }
                    else {
                        if (companyParams[i].FieldName == companyParamName)
                            return module.codingSpecificCompanyParams(1/*decode*/, companyParamName, companyParams[i].fieldvalue);
                    }
                return null;
            }
            catch (err) {
                alert("getCompanyParamByFieldName :" + err);
            }
        },

        getCompanyParamFieldNameByFldGroup: function getCompanyParamFieldNameByFldGroup(companyFldGroup) {
            try {
                var companyParams = memoryCache.get(cacheItems.COMPANY_PARAMS);

                var i;
                for (i = 0; i < companyParams.length; i++)
                    if (companyParams[i].FieldGroup == companyFldGroup)
                        return companyParams[i].FieldName;
                return null;
            }
            catch (err) {
                alert(err);
            }
        },

        getCompanyPreferenceByName: function getCompanyPreferenceByName(preferenceName, isByFldBehaviorName) {
            var behavior;
            var isByAliasPreferenceName;
            // isByFldBehaviorName=1 - take by field content for fld=BehaviorName, it's better than add everytime to enums.companyPreferencesNames
            // isByFldBehaviorName=0 - take by enums->companyPreferencesNames 
            if (typeof isByFldBehaviorName === "undefined" || isByFldBehaviorName === null) {
                isByAliasPreferenceName = true;
            }
            else
                isByAliasPreferenceName = !isByFldBehaviorName;

            $.each(memoryCache.get(enums.cacheItems.COMPANY_PREFERENCES), function (key, val) {
                if ((isByAliasPreferenceName == true && val.BehaviorName == preferenceName.name) || (isByAliasPreferenceName == false && val.BehaviorName == preferenceName)) {
                    behavior = val.Value;
                    return false;//to stop the each
                }
            });
            return behavior;
        },

        getCompanyPreferncesSpecListByName: function getCompanyPreferncesSpecListByName(preferenceName, preferenceName2) {
            var listCompanyPrefNamesValues = [];
            var entityDataItem = null
            $.each(memoryCache.get(enums.cacheItems.COMPANY_PREFERENCES), function (key, val) {
                if (val.BehaviorName.indexOf(preferenceName) >= 0) {
                    var empNo = val.BehaviorName.substr(val.BehaviorName.lastIndexOf('_') + 1);//get empNo val
                    var behave2 = module.getCompanyPreferenceByName(preferenceName2 + "_" + empNo, 1);
                    entityDataItem = { val1: val.Value, val2: behave2, emp: empNo, AdditionalDetails: val.AdditionalDetails };
                    listCompanyPrefNamesValues.push(entityDataItem);
                }
            });
            return listCompanyPrefNamesValues;
        },

        getNotifierParamByFieldName: function getNotifierParamByFieldName(notifParamName, fieldGrp) {
            try {
                var notifierParams = memoryCache.get(cacheItems.NOTIFIER_PARAMS);
                var isByFieldGrp = 1;
                var valFieldGroup='';
                var isGrpNullOrEmpty=false;

                if (typeof fieldGrp === "undefined" || fieldGrp === null) {
                    isByFieldGrp = 0;
                }
                var i;
                for (i = 0; i < notifierParams.length; i++) {
                    valFieldGroup=notifierParams[i].FieldGroup;
                    if (valFieldGroup == null || valFieldGroup == 'undefined' || valFieldGroup == '')
                        isGrpNullOrEmpty = true;

                    if (isByFieldGrp == 1 && !isGrpNullOrEmpty) {
                        if (notifierParams[i].FieldGroup.toUpperCase() == fieldGrp.toUpperCase() && notifierParams[i].FieldName.toUpperCase() === notifParamName.toUpperCase())
                            return notifierParams[i].fieldvalue;
                    }
                    else {
                        if (notifierParams[i].FieldName.toUpperCase() == notifParamName.toUpperCase())
                            return notifierParams[i].fieldvalue;
                    }
                }
                return null;
            }
            catch (err) {
                alert("getNotifierParamByFieldName :" + err);
            }
        },

        getLanguageDir: function getLanguageDir(languageId) {
            var languages = memoryCache.get(enums.cacheItems.LANGUAGES_LIST);
            var dir = 'ltr';
            if (languages != null && languages.length > 0) {
                $.each(languages, function (key, val) {
                    if (val.Code == languageId) {
                        dir = val.Lang_Direction != null ? val.Lang_Direction : 'ltr';
                        return false;//to stop the each
                    }
                });
            }
            return dir;
        },

        getLanguageName: function getLanguageName(languageId) {
            var languages = memoryCache.get(enums.cacheItems.LANGUAGES_LIST);
            var name = '';
            if (languages != null && languages.length > 0) {
                $.each(languages, function (key, val) {
                    if (val.Code == languageId) {
                        name = val.Descript;
                        return false;//to stop the each
                    }
                });
            }
            return name;
        },

        getLanguageHelp: function getLanguageHelp(languageId) {
            var languages = memoryCache.get(enums.cacheItems.LANGUAGES_LIST);
            var help = '';
            if (languages != null && languages.length > 0) {
                $.each(languages, function (key, val) {
                    if (val.Code == languageId) {
                        help = val.Lang_HelpURL;
                        return false;//to stop the each
                    }
                });
            }
            return help;
        },

        saveLookupAtCache: function saveLookupAtCache(lookupName, lookupList) {
            memoryCache.saveLookupAtCache(lookupName, lookupList);
        },

        isExistKey: function isExistKey(key) {
            switch (key.cacheMode) {
                case enums.cacheMode.MEMORY_CACHE:
                    return memoryCache.isExistKey(key);
                case enums.cacheMode.LOCAL_STORAGE:
                    return localStorageManager.isExistKey(key);
                case enums.cacheMode.COOKIE:
                    return cookie.isExistKey(key);
            }
        },
        deleteCookie: that.cookie.deleteCookie
    };
    return module;
});