﻿define(function multiSelectControl(require) {
    var global = require('common/global');
    var lookupManager = require('common/lookupManager');
    var Enumerable = require('Enumerable');

    // var dialog = require('plugins/dialog');

    function ViewModel() {
        var data = [];
        var dataQuery;
        var initDfd = null;
        var compositionCompleteDefer;
        var compositionCompletePromise = global.system.defer(function loadData(dfd) {
            compositionCompleteDefer = dfd;
        }).promise();
        var initPromise = global.system.defer(function init(dfd) {
            initDfd = dfd;
        }).promise()
        var controlOptions;
        var optionLabelCode = "-1";
        var initializeCalled = false;
        var selectedItems;
        var selectedIds;
        var selectedCodes;
        var isOpen = false;
        var compositionCompleteCalled;
        var activateControlIntervalId;



        var vm = this;

        vm.multiSelectId = ko.observable("defaultMultiSelectId");
        vm.isReadOnly = ko.observable(false);
        vm.dataSource = ko.observableArray();
        vm.extendedData = '';
        vm.itemValue = 'Code';
        vm.itemText = 'Display';
        vm.selectedId = ko.observable();
        vm.compositionComplete = compositionComplete;
        vm.optionLabelDescript = null;
        //vm.onChange= onChange;
        vm.initialize = initialize;
        vm.activate = activate;
        vm.comboWidth = '';
        vm.lookupName = '';
        vm.cacheMode = '';
        vm.sortByDescript = false;
        vm.sortDescOrder = false;
        vm.getXmlData = getXmlData;
        vm.extendedData = '';
        vm.click = function click() {
            vm.wasChanged = true;
        };
        vm.beforeopen = function beforeopen() { };
        vm.itemChange = itemChange;
        vm.open = open;
        vm.beforeclose = function beforeclose() { };
        vm.customClose = function customClose() { };
        vm.checkAll = function checkAll() { };
        vm.uncheckAll = function uncheckAll() { };
        vm.optgrouptoggle = function optgrouptoggle() { };
        vm.noneSelectedText = global.dict()[4356];
        vm.selectedText = "# " + global.dict()[2253];
        vm.selectedList = 1;
        vm.getSelectedIDs = getSelectedIDs;
        vm.getSelectedItems = getSelectedItems;
        vm.selectedIDsString = ko.observable('');
        vm.selectedCodes = selectedCodes;
        vm.getSelectedIDsString = getSelectedIDsString;
        vm.readOnlyDisplaySelected = ko.observable('');
        vm.controlType = global.enums.controlType.multiSelect;
        vm.wasChanged = false;
        vm.initValue = initValue;
        vm.changeSelectedCodes = changeSelectedCodes;
        vm.containImages = false;
        vm.refresh = refresh;
        vm.changePosition = changePosition;
        vm.selectFirstElement = selectFirstElement;
        vm.titleText = ko.observable('');

        var firstInit;

        controlOptions = {
            noneSelectedText: vm.noneSelectedText,
            header: false,
            selectedText: vm.selectedText,
            selectedList: vm.selectedList,
            afterInit: afterInit,
            click: vm.click,
            beforeopen: beforeOpen,
            open: vm.open,
            change: vm.itemChange,
            beforeclose: vm.beforeclose,
            close: close,
            checkAll: vm.checkAll,
            uncheckAll: vm.uncheckAll,
            optgrouptoggle: vm.optgrouptoggle,
            //displaySelectedCodes: vm.displaySelectedCodes,
            selectedCodes: vm.selectedCodes,
            selectedText: function (numChecked, numTotal, checkedItems) {
                if ($(checkedItems[0]).val() == "-1")
                    return vm.optionLabelDescript;
                else {
                    var checkedCodes = $.map(checkedItems, function (item) { return item['data-value'] });
                    return checkedCodes.toString();
                }
            },
            checkAllText: global.dict()[2305],
            uncheckAllText: global.dict()[4013]
        };

        function compositionComplete() {
            try {
                if (!compositionCompleteCalled) {
                    compositionCompleteCalled = true;
                    $(document).ready(function documentReady() {
                        compositionCompleteDefer.resolve();
                        $.when(compositionCompletePromise, initPromise).done(function loadingCompleted() {
                            controlOptions.displaySelectedCodes = vm.displaySelectedCodes;
                            controlOptions.selectedCodes = vm.selectedCodes;
                            controlOptions.multiSelectId = vm.multiSelectId();
                            activateControlIntervalId = setInterval(activateControl, 100);
                        });
                    });
                }
            } catch (err) {
                global.treatError(err);
            }
        }

        function itemChange(obj) {
            try {
                var multiSelectItems = $("input[name='multiselect_" + vm.multiSelectId() + "']");
                if (obj.value == "-1" && obj.checked == true) {//all checked
                    $.each(multiSelectItems, function (i, option) {
                        if (option.value == "-1") {
                            option.checked = true;
                            vm.dataSource()[i].isSelected(true);
                            vm.dataSource()[i].selected = true;
                        }
                        else {
                            option.checked = false;
                            vm.dataSource()[i].isSelected(false);
                            vm.dataSource()[i].selected = false;
                        }
                    });
                }
                else if (obj.value != "-1" && obj.checked == true) { //all UN-checked
                    if (vm.multiSelectId() != 'availableDays') {
                        $.each(multiSelectItems, function (i, option) {
                            if (option.value == "-1") {
                                option.checked = false;
                                vm.dataSource()[i].isSelected(false);
                                vm.dataSource()[i].selected = false;
                            }
                        });
                    }

                    else {
                        switch (obj.value) {
                            case "0": // all
                            case "20": // NON working day
                            case "21": // Working day 
                                $.each(multiSelectItems, function (i, option) {
                                    if (option.value != obj.value) {
                                        option.checked = false;
                                        vm.dataSource()[i].isSelected(false);
                                        vm.dataSource()[i].selected = false;
                                    }
                                });
                                break;
                            default: // for other working day
                                $.each(multiSelectItems, function (i, option) {
                                    if (['0', '20', '21'].indexOf(option.value) != -1) {
                                        option.checked = false;
                                        vm.dataSource()[i].isSelected(false);
                                        vm.dataSource()[i].selected = false;
                                    }
                                });
                                break;
                        }

                    }
                }
            }

            catch (err) {
                global.treatError(err);
            }
        }

        function activateControl() {
            try {
                var ms = getMultiSelect();
                var readOnlyTxt = "";
                if (ms.length > 0) {
                    clearInterval(activateControlIntervalId);
                    if (controlOptions.header) {
                        ms.multiselect(controlOptions).multiselectfilter();
                        $('#' + vm.multiSelectId() + '_menu .ui-multiselect-filter')[0].childNodes['0'].nodeValue = global.res[297] + ': ';
                        $('#' + vm.multiSelectId() + '_menu .ui-multiselect-filter').css('direction', global.getCurrentDir().toLowerCase());
                        $('#' + vm.multiSelectId() + '_menu .ui-multiselect-filter input').attr('placeHolder', '');
                        $('li:contains("Uncheck all")').remove();
                        $('li:contains("Check all")').remove();
                    }
                    else {
                        ms.multiselect(controlOptions);
                    }
                    $(".multiSelectControl.caseAllow").css("display", "block");
                    var texts = vm.multiSelectId();
                    if (!global.isNullOrEmpty(vm.multiSelectId()))
                        readOnlyTxt = $('#' + vm.multiSelectId()).next("button")[0].textContent;
                    else
                        readOnlyTxt = $('#multiSelect button').text();
                    //vm.readOnlyDisplaySelected($('#multiSelect button').text()) --08/04/2018, WI=24170 alexa commented for case FEW multiselect on page, planOT
                    vm.readOnlyDisplaySelected(readOnlyTxt);
                }
            } catch (err) {
                global.treatError(err);
            }
        }

        function closeClick(e) {
            try {
                //controlOptions.close(e);
                getMultiSelect().multiselect('close');
            }
            catch (err) {
                global.treatError(err);
            }
        }

        function open() {
            try {
                $('#' + vm.multiSelectId()).multiselect("open");
            } catch (err) {
                global.treatError(err);
            }
        }

        function activate() {
            try {
                compositionCompleteCalled = false;
            } catch (err) {
                global.treatError(err);
            }
        }

        function close(sender, attr) {
            try {
                var list = sender.target;
                var multiSelectItems = $('#' + vm.multiSelectId() + '_menu').find('label').children('input');
                if (multiSelectItems != null && multiSelectItems.length > 0) {
                    for (var i = 0; i < multiSelectItems.length; i++) {
                        vm.dataSource()[i].isSelected(multiSelectItems[i].checked);
                    }
                }
                var selectedIDsString = getSelectedIDsString();
                updateMultiSelectTitle();
                vm.customClose(selectedIDsString);
                vm.selectedIDsString(selectedIDsString);
            }
            catch (err) {
                global.treatError(err);

            }
        }

        function beforeOpen() {
            try {
                return vm.beforeopen();
            }
            catch (err) {
                global.treatError(err);

            }
        }

        function onItemClick(checkbox, selector) {
            alert("value " + checkbox.val() + ", is checked: " + checkbox.prop("checked"));
        }

        function onComplete(selector) {
            var values = "";
            for (i = 0; i < selector.options.length; i++) {
                if (selector.options[i].selected && (selector.options[i].value != "")) {
                    if (values != "") values += ";";
                    values += selector.options[i].value;
                }
            }
            alert(values);
        }

        //getting in this method every refresh of control - happens when changing check status by code
        function afterInit() {
            try {
                //this code has made mistakes in checkboxes status, so put in comment
                //var multiSelectItems = $("input[name='multiselect_" + vm.multiSelectId() + "']");
                ////multiselect_NonWorkingDays
                //$.each(multiSelectItems, function (i, option) {
                //    if (option.checked == true) {
                //        vm.dataSource()[i].isSelected(true);
                //        vm.dataSource()[i].selected = true;
                //    }
                //});

                if (firstInit)  //only once add the close button
                {
                    $('#' + vm.multiSelectId() + '_menu').append("<input type='image' src='" + global.imagesManager.actionsStackButtonsCollapse + "' class='close' />");
                    $('#' + vm.multiSelectId() + '_menu .close').bind("click", closeClick);

                    firstInit = false;
                }

                //add background-image for each item                
                if (vm.containImages == true) {
                    var multiSelectItems = $("input[name='multiselect_" + vm.multiSelectId() + "']");
                    $.each(multiSelectItems, function (i, option) {
                        if (vm.multiSelectId() == 'statusSentEventsId') {
                            $('#ui-multiselect-' + vm.multiSelectId() + '-option-' + i).parent().append("<div class='height20 width9em floutR' style='background:url(" + global.enums.notifSentStatusImages[i] + ") no-repeat'></div>");
                        }
                        else if (vm.multiSelectId() == 'autoJobSentStatusId') {
                            $('#ui-multiselect-' + vm.multiSelectId() + '-option-' + i).parent().append("<div class='height20 width9em floutR' style='background:url(" + global.enums.autoJobSentStatusImages[i] + ") no-repeat'></div>");
                        }
                        else if (vm.multiSelectId() == 'jobHistorySentStatusId') {
                            $('#ui-multiselect-' + vm.multiSelectId() + '-option-' + i).parent().append("<div class='height20 width9em floutR' style='background:url(" + global.enums.autoJobHistorySentStatusImages[i] + ") no-repeat'></div>");
                        }
                        else {
                            $('#ui-multiselect-' + vm.multiSelectId() + '-option-' + i).parent().append("<div class='height20 width4em floutR' style='background:url(" + global.enums.filterStatusImages[option.value].imagePath + ") no-repeat'></div>");
                        }
                    });

                }

            }
            catch (err) {
                global.treatError(err);
            }
        }

        function initSelectedItem() {
            var thisComboId = vm.multiSelectId();
            var selectedCodesArr = vm.selectedIDsString();//.split(",");
            if (global.isNullOrEmpty(selectedCodesArr))
                return;

            if (typeof selectedCodesArr !== 'string') {
                return;
            }

            $.each(vm.dataSource(), function initSelectedItemEach(index, item) {
                reg = new RegExp("\\b" + item.Code + "\\b");
                //if (selectedCodesArr.indexOf(item.Code) != -1) {			
                if (selectedCodesArr.search(reg) != -1) {
                    item.isSelected(true);
                    item.selected = true;
                }
                else {
                    item.isSelected(false);
                    item.selected = false;
                }
            });
        }

        function initialize(options, selectedCode) {
            initializeCalled = true;
            if (options.selectedCode != null) {
                vm.selectedCodes = options.selectedCode;
                vm.selectedIDsString(options.selectedCode);
            }
            if (!global.isNull(options.lookupName)) {
                vm.cacheMode = options.lookupName.mode;
            }
            vm.lookupName = options.lookupName;
            vm.multiSelectId(options.multiSelectId);
            if (options.selectedKoProperty != null) {
                vm.selectedId = options.selectedKoProperty;
            }
            if (options.readOnlyKoProperty != null) {
                vm.isReadOnly = options.readOnlyKoProperty;
            }
            else {
                vm.isReadOnly = ko.observable(false);
            }
            if (options.isReadOnly) {
                vm.isReadOnly(options.isReadOnly);
            }
            controlOptions.header = options.header;
            vm.extendedData = options.extendedData;
            if (!global.isNull(options.displaySelectedCodes)) {
                vm.displaySelectedCodes = options.displaySelectedCodes;
            }
            if (!global.isNull(selectedCode)) {
                vm.selectedText = selectedCode;
            }
            if (!global.isNull(options.optionLabelDescript))
                vm.optionLabelDescript = options.optionLabelDescript;

            if (!global.isNull(options.containImages))
                vm.containImages = options.containImages;

            if (!global.isNull(options.sortByDescript))
                vm.sortByDescript = options.sortByDescript;

            initData();
        };

        function getMultiSelect() {
            return $("#" + vm.multiSelectId());
        }

        function getXmlData() {
            if (!global.isNullOrEmpty(vm.extendedData)) {
                var xmlObj = vm.extendedData;//json2xml.convert(vm.extendedData, "Root");
                xmlObj = xmlObj.replace("<Root", "<Root xml:space='preserve'");
                return xmlObj;//;xml:space='preserve'
            }
            return '';
        }

        function getSelectedItems() {
            var seletedItem = Enumerable.From(vm.dataSource())
                .Where(function whereOnFilterDataSource(lu) { return lu.isSelected() == true })
                .Select(function selectOnFilterDataSource(lu) { return lu })
                .ToArray();
            return seletedItem;
        }

        function getSelectedIDs() {
            if (!getMultiSelect().multiselect())//prior to multiselect initialization 
                return vm.selectedCodes;
            var selectedElements = getMultiSelect().multiselect("getChecked");
            var selectedIds = [];
            $.each(selectedElements, function addToArr(i, element) {
                selectedIds.push(element.value);
            });
            //var seletedIds = Enumerable.From(vm.dataSource())
            //                                               .Where(function whereOnFilterDataSource(lu) { return lu.isSelected() == true })
            //                                               .Select(function selectOnFilterDataSource(lu) { return lu.Code })
            //                                               .ToArray();
            return selectedIds;
        }

        function getSelectedIDsString() {
            return getSelectedIDs().toString();
        }

        function updateMultiSelectTitle() {
            var titleRes = "";
            $.each(vm.dataSource(), function getTitle(index, value) {
                if (value.isSelected()) {
                    titleRes += value.Descript + ",";
                }
            });
            vm.titleText(titleRes);
        }

        function afterLoading(fromRefresh) {
            if (!global.isNull(vm.optionLabelDescript)) {
                vm.dataSource.unshift({ Code: optionLabelCode, Descript: vm.optionLabelDescript });
                initValue("-1");
            }
            clearAll();
            initSelectedItem();
            updateMultiSelectTitle();
            if (!fromRefresh)
                firstInit = true;
            initDfd.resolve();
        }

        function initData(fromRefresh, goToServerAnyCase) {
            if (!global.isNull(vm.lookupName)) {
                //get lookup data
                var getLookupPromise = getLookup(goToServerAnyCase);
                getLookupPromise.done(function afterGetLookupDone() { return afterLoading(fromRefresh) });
            }
        };

        function clearAll() {
            $.each(vm.dataSource(), function setSelectedToSource(index, value) {
                value.isSelected = ko.observable(false);
            });
            /* var multiSelectItems = $("input[name='multiselect_" + vm.multiSelectId() + "']");
            //multiselect_NonWorkingDays
            $.each(multiSelectItems, function (i, option) {
                vm.dataSource()[i].isSelected(false);
                option.checked = false;
            });*/
        }

        function getLookup(goToServerAnyCase) {
            var user = global.cache.get(global.enums.cacheItems.USER);
            dataQuery =
                {
                    EmpNo: user != null ? user.Id : null,
                    UserNo: user != null ? user.Profile != null ? user.Profile.Code : null : null,
                    ElemName: vm.lookupName.name,
                    PageNo: 0,
                    PageSize: 200,
                    PagingBy: vm.sortByDescript,
                    PagingOrder: vm.sortDescOrder,
                    SearchBy: 2,
                    SearchVal: '',
                    SearchExact: true,
                    OtherParamsXML: vm.getXmlData()
                };

            var deferred = global.system.defer(function getLookupPromiseFunc(dfd) {
                return lookupManager.getLookup(dfd, vm.dataSource, dataQuery, vm.lookupName, goToServerAnyCase);
            });
            return deferred.promise();
        }

        function initValue(newVal) {
            vm.selectedIDsString(newVal);
            vm.selectedCodes = newVal;
            clearAll();
            initSelectedItem();
            if (getMultiSelect().multiselect()) {// multiselect initializated
                getMultiSelect().multiselect("setOption", "displaySelectedCodes", newVal);
                getMultiSelect().multiselect("setOption", "selectedCodes", newVal);
                var multiSelectItems = $("input[name='multiselect_" + vm.multiSelectId() + "']");
                //multiselect_NonWorkingDays
                $.each(multiSelectItems, function (i, option) {
                    if (option.checked == true) {
                        vm.dataSource()[i].isSelected(true);
                        vm.dataSource()[i].selected = true;
                    }
                    else {
                        vm.dataSource()[i].isSelected(false);
                        vm.dataSource()[i].selected = false;
                    }
                });
            }
            vm.readOnlyDisplaySelected($('#multiSelect button').text());
        }

        function changeSelectedCodes(newVal) {
            vm.selectedIDsString(newVal);
            vm.selectedCodes = newVal;
            clearAll();
            initSelectedItem();
            if (getMultiSelect().multiselect()) {// multiselect initializated
                getMultiSelect().multiselect("setOption", "displaySelectedCodes", newVal);
                getMultiSelect().multiselect("setOption", "selectedCodes", newVal);
                var multiSelectItems = $("input[name='multiselect_" + vm.multiSelectId() + "']");
                //multiselect_NonWorkingDays
                $.each(multiSelectItems, function (i, option) {
                    if (vm.dataSource()[i].isSelected() == true) {
                        option.checked = true;
                    }
                    else {
                        option.checked = false;
                    }
                });
            }
            //vm.readOnlyDisplaySelected($('#multiSelect button').text());
        }

        function refresh(needInitialize) {
            if (!global.isNOE(needInitialize))
                initData(needInitialize, true);
            else
                initData(true, true);
            var refreshPromise = global.system.defer(function refreshDataFunc(dfd) {
                initDfd = dfd;
            }).promise().done(function afterRefreshDone() {
                getMultiSelect().multiselect("refresh")
            });
            return refreshPromise;
        }

        //special method for changing position of multi select menu
        //in case using this control without the combo - then need to position the menu popup relative to other control
        //such as implemented in navBar control
        function changePosition(position) {
            $('#' + vm.multiSelectId() + '_menu').css('top', position.top);
            $('#' + vm.multiSelectId() + '_menu').css('left', position.left);
            $('#' + vm.multiSelectId() + '_menu').css('width', position.width);
        }

        function selectFirstElement() {
            var item = vm.dataSource()[0];
            initValue(item.Code);
            updateMultiSelectTitle();
        }

        return vm;
    }
    return ViewModel;
});