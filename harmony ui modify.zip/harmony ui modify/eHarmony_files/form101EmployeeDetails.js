﻿define(function (require) {

    //#region require
    var uploadUC = require('views/controls/uploadUC/uploadUC');
    var datePicker = require('views/controls/datePicker/datePicker');
    var global = require('common/global');
    var validationHelper = require('data/validationHelper');
    var dataContext = require('data/datacontext');
    var combo = require('views/controls/combo/combo');
    var autoComplete = require('views/controls/autoComplete/autoComplete');
    var form101Helper = require('views/forms/form101/form101Helper');
    //#endregion require

    //#region widgets
    var immigration = new datePicker();
    var birthday = new datePicker();
    immigration.initializeDatePicker({ id: 'immigration' });
    birthday.initializeDatePicker({ id: 'birthday', maxDate: new Date() });
    var areaCodeCombo = new combo();
    areaCodeCombo.itemText = 'Code';
    areaCodeCombo.initialize({ comboId: "areaCodeCombo", lookupName: global.enums.lookupName.Form101AreaCodes, width: '5em' });
    var mobileAreaCodeCombo = new combo();
    mobileAreaCodeCombo.itemText = 'Code';
    mobileAreaCodeCombo.initialize({ comboId: "mobileAreaCodeCombo", lookupName: global.enums.lookupName.Form101AreaCodes, width: '5em' });
    var hmoNameCombo = new combo(global.enums.comboTemplates.descriptOnly);
    hmoNameCombo.initialize({ comboId: "hmoNameCombo", lookupName: global.enums.lookupName.Form101HMONames, width: '8em' });
    var cityCombo = new autoComplete();
    var streetCombo = new autoComplete();
    var countryCombo = new autoComplete();
    //#endregion widgets

    //#region local variables and flags
    var myCallbackIndex;
    var isIdCardFileHasBeenUpdatedThisTime = false;
    var isCityCodeChangedBySelectingDescInInit = false;
    var lastSelectedCityCode = null;
    var attachLabelP1_TZ = 'יש לצרף צילום תעודת זהות כולל ספח. '
    var attachLabelP1_darkon = 'יש לצרף צילום דרכון. '
    var attachLabelP2 = 'אם צורף בעבר, יש לצרף צילום רק אם היו שינויים בפרטים'
    //#endregion local variables and flags


    function init(context, dataObject, maritalStatusData, isFirstTimeUpdateThisUnitForThisFormVersion) {
        var tempIsModified = dataObject.data.entityAspect.entityState.isModified();
        if (isFirstTimeUpdateThisUnitForThisFormVersion == true) {
            isIdCardFileHasBeenUpdatedThisTime = false;
        }
        var uploadSupportType = new Array("*.pdf", "*.jpg");
        var data = dataObject.data;
        if (!global.isNullOrEmpty(data.Unit_B().Employee_ID())) {
            while (data.Unit_B().Employee_ID().length >= 1 && data.Unit_B().Employee_ID().length < 9) {
                data.Unit_B().Employee_ID('0' + data.Unit_B().Employee_ID());
            }
        }
        var form101params = {
            TaxYear: context.xTaxYear,
            Emp_no: context.xEmpNo,
            Version: context.xVerNo
        };
        vm.data(data);
        immigration.initValue(data.Unit_B(), 'ImmigrationDate');
        birthday.initValue(data.Unit_B(), 'BirthDate');
        areaCodeCombo.changeSelectedItemById(vm.data().Unit_B().AreaCode(), vm.data().Unit_B().AreaCode);
        mobileAreaCodeCombo.changeSelectedItemById(vm.data().Unit_B().MobileAreaCode(), vm.data().Unit_B().MobileAreaCode);
        hmoNameCombo.changeSelectedItemById(vm.data().Unit_B().HMO_Code(), vm.data().Unit_B().HMO_Code);
        if (!vm.showLastAttachmentsControls) {
            vm.Employee_ID_Attachment = new uploadUC("Employee_ID_Attachment", 2, vm.data().Unit_B().Employee_ID_Attachment().Id, global.enums.AttachmentCategoty.Form101, vm.data().Unit_B().Employee_ID_Attachment().Name, global.enums.AttachmentCategotyLvl.UnitB, uploadSupportType, null, vm.data().Unit_B().Employee_ID_Attachment().IsValidType, vm.data().Unit_B(), "Employee_ID_Attachment");
            vm.Employee_ID_Attachment.form101params = form101params;
            vm.MaritalStatus_Attachment = new uploadUC("MaritalStatus_Attachment", 3, vm.data().Unit_B().MaritalStatus_Attachment().Id, global.enums.AttachmentCategoty.Form101, vm.data().Unit_B().MaritalStatus_Attachment().Name, global.enums.AttachmentCategotyLvl.UnitB, uploadSupportType, null, vm.data().Unit_B().MaritalStatus_Attachment().IsValidType, vm.data().Unit_B(), "MaritalStatus_Attachment");
            vm.MaritalStatus_Attachment.form101params = form101params;
        }
        vm.MaritalStatus_Attachment.isDisabled = ko.computed(function isMaritalSatatusAttachmentDisabled() { return !(vm.data().Unit_B().MaritalStatus() == "5") });
        vm.maritalStatusList(maritalStatusData);

        var extended = null;
        // darkon - TZ handling
        if (global.isNullOrEmpty(data.Unit_B().rdbPassportType())) {
            if( ! global.isNullOrEmpty( data.Unit_B().rdbIsrCitizen() ) ) 
                data.Unit_B().rdbPassportType(data.Unit_B().rdbIsrCitizen())
            else
                data.Unit_B().rdbPassportType("0");
        }

        /*---------------------------------------
       / ==== DEFINE : COUNTRY combo ==========
       ----------------------------------------- */

       extended = { IncludeIsrael: 0 };
        if (!global.isNOE(data.Unit_B().Country_Code()))
           extended.includeCode= dataObject.data.Unit_B().Country_Code();
       else if (!global.isNOE(data.Unit_B().Country()))//check if desc has value
           extended.includeDesc= encodeURIComponent(dataObject.data.Unit_B().Country().replace('\"', '\''));

       countryCombo.initialize({
           comboId: "countryCombo", lookupName: global.enums.lookupName.Form101CountriesList,
           optionLabel: autoComplete.optionLabelEnum.empty, sortByDescript: true,
           extendedData: extended, selectedIdKoProperty: data.Unit_B().Country_Code
       }).done(function afterCountryComboInitialized() {
           countryCombo.comboWidth('240px');
       });
        
        /*---------------------------------------
        / ==== DEFINE : CITY combo ==========
        ----------------------------------------- */
        if (!global.isNOE(data.Unit_B().City_Code()))
            extended = { includeCode: dataObject.data.Unit_B().City_Code() };
        else if (!global.isNOE(data.Unit_B().City()))//check if desc has value
            extended = { includeDesc: encodeURIComponent(dataObject.data.Unit_B().City().replace('\"', '\'')) };
        isCityCodeChangedBySelectingDescInInit = true;
        cityCombo.initialize({
            comboId: "cityCombo", lookupName: global.enums.lookupName.Tfs101CitiesList, optionLabel: autoComplete.optionLabelEnum.empty, sortByDescript: true, extendedData: extended
        }).done(function afterCityComboInitialized() {
            setTimeout(function waitBeforeSelectCity() {
                cityCombo.comboWidth('240px');
                cityCombo.customSelectionChanged = citySelectionChanged;
                if (!global.isNOE(data.Unit_B().City_Code())) {
                    cityCombo.changeSelectedItemById(data.Unit_B().City_Code(), data.Unit_B().City_Code);
                }
                else
                    if (global.isNOE(data.Unit_B().City_Code()) && !global.isNOE(data.Unit_B().City())) {
                        var itemToSelect = cityCombo.getItemByUniqueDescript(data.Unit_B().City());
                        if (!global.isNOE(itemToSelect)) {
                            vm.data().Unit_B().City_Code(itemToSelect.Code);
                            cityCombo.changeSelectedItemById(data.Unit_B().City_Code(), data.Unit_B().City_Code);
                        }
                    }
            }, 300);
        });
        streetCombo.initialize({
            comboId: "streetCombo", lookupName: global.enums.lookupName.Tfs101CityStreetsList, optionLabel: autoComplete.optionLabelEnum.empty, extendedData: { City: global.isNOE(data.Unit_B().City_Code()) ? '' : data.Unit_B().City_Code(), includeCode: encodeURIComponent(vm.data().Unit_B().StreetName() && vm.data().Unit_B().StreetName().replace('\"', '\'')) },
            template: "codeOnly"
        });

        if (global.isNOE(vm.data().Unit_B().Kibbutz_member()/*status edit*/) || !vm.data().Unit_B().Kibbutz_member()/*status new*/)
        	vm.data().Unit_B().Kibbutz_member("0");//default falus is "לא"
       
        dataObject.data.entityAspect.propertyChanged.subscribe(forceLoadNewIdCardFile);
        myCallbackIndex = dataObject.data.entityAspect.propertyChanged._subscribers.length - 1;
        if (!tempIsModified) {
            dataObject.data.entityAspect.setUnchanged();
        }
        vm.showLastAttachmentsControls = true;
    }

    function setAttachLabel(passportType) {
        var spanText = attachLabelP1_TZ + attachLabelP2;
        if (passportType == 1)
            spanText = attachLabelP1_darkon + attachLabelP2;
        if ($("#attachLabel").text() != spanText)
            $("#attachLabel").text(spanText);
    }
   
    function compositionComplete() {
        $(document).ready(function () {
            setAttachLabel(vm.data().Unit_B().rdbPassportType());
            $("#id").mask('999900000');
            $('#phone').mask('0000000');
            $('#mobile').mask('0000000');
            $('#zipCode').mask('0000000');
            if (vm.data().Unit_B().SendSalaryToEmail())
            	$("#emailLbl").addClass("requireLabel");
            else
            	$("#emailLbl").removeClass("requireLabel");

            setTimeout(function waitToShutSpinDisplayed() { global.displaySpin(false) }, 200);
        });
    }

    function citySelectionChanged(active) {
        var empCityCode = vm.data().Unit_B().City_Code();
        var empStreetName = vm.data().Unit_B().StreetName();
        var encodeStreetName = !global.isNullOrEmpty(empStreetName) ? empStreetName.replace('\"', '\'') : "";
        
        if (!global.isNOE(cityCombo.selectedItem()) && !global.isNOE(cityCombo.selectedItem().Code)) {
            global.displaySpin(true);
           
            if (global.isNullOrEmpty(lastSelectedCityCode)) // first time on load 
                lastSelectedCityCode = cityCombo.selectedId();
            streetCombo.refreshWithNewExtendedData({ City: cityCombo.selectedId(), includeCode: encodeURIComponent(encodeStreetName) }).done(function () {
                //28/11/2018 Ale - use changeSelectedItem instead changeSelectedItemById 
                //if citycode not changed (when jumping next/prev between Units )
                if (lastSelectedCityCode == cityCombo.selectedId())
                    streetCombo.changeSelectedItem({ Code: empStreetName, Descript: "", Display: empStreetName }, vm.data().Unit_B().StreetName);
                else
                    //reset to empty street || same streenname if exists in re-selected city
                    streetCombo.changeSelectedItemById(empStreetName, vm.data().Unit_B().StreetName);

                lastSelectedCityCode = cityCombo.selectedId();
                if (isCityCodeChangedBySelectingDescInInit)
                    isCityCodeChangedBySelectingDescInInit = false;
                global.displaySpin(false);
                }
            );
        }
    }

    function forceLoadNewIdCardFile(params) {

        //if user did changes in his details we want to force him to load new idCardFile.            

        if (isIdCardFileHasBeenUpdatedThisTime != true && //if current time he has already update this file once - he doesn't have to do it again (isIdCardFileHasBeenUpdatedThisTime=true)
            params.propertyName.indexOf('Unit_B.Employee_ID_Attachment') < 0 &&//also, not cause absurdity that change idCardFile will forcr the user to change it again, and so on...
            params.propertyName != "Unit_B.HMO_Member" && params.propertyName != "Unit_B.HMO_Code" &&//changes at hmo values not relative to idCardFile, so no need to track them
            params.propertyName != "Unit_B.BirthDate" && params.propertyName != "Unit_B.ImmigrationDate" &&
            params.propertyName != "Unit_B.PhoneNumber" && params.propertyName != "Unit_B.AreaCode" && params.propertyName != "Unit_B.MobilePhoneNumber" &&
            params.propertyName != "Unit_B.MobileAreaCode" && params.propertyName != "Unit_B.Kibbutz_member" && params.propertyName != "Unit_B.Email" &&
            params.propertyName != "Unit_B.StreetName" && params.propertyName != "Unit_B.SendSalaryToEmail" &&
            !isCityCodeChangedBySelectingDescInInit) {//in case got here cause of initializing City_Code() value by selecting item by Descript in Init - no forcing delete of Id card attachment
           vm.Employee_ID_Attachment.clearSelectedFile();
        }
    }

    function activate() {
        try {

        }
        catch (err) {
            global.treatError(err);
        }
    }


    function isValid() {
        return validationHelper.validateSingleField(vm.data(), 'Unit_B');
    }

    function forceDependenceRules() {
        if (vm.data().Unit_B().MaritalStatus() != 2) {//not married
            vm.data().Unit_H().Unit_H_5(false); //part h.5.comments  
            vm.data().Unit_H().Unit_H_11(false);
            vm.data().Unit_F(dataContext.createClientInstance('Form101Unit_F'));

        }
        else {//married
            vm.data().Unit_H().Unit_H_6(false);//part h.6.comments    
            if (vm.data().Unit_B().Sex() == 0) {//Male
                vm.data().Unit_H().Unit_H_7(false);//part h.7.comments               
            }
        }

        if (((vm.data().Unit_H().Unit_H_7() && vm.data().Unit_B().Sex() == 0)
            || (vm.data().Unit_B().Sex() == 1 && vm.data().Unit_B().MaritalStatus() == 2))
            && !(vm.data().Unit_H().Unit_H_9())) {
            vm.data().Unit_H().Unit_H_8(false);
        }
        var birthDate = Date.parse(vm.data().Unit_B().BirthDate());
        var spouseBirthDate = Date.parse(vm.data().Unit_F().SpouseBirthDate());
        if (!global.isNull(birthDate)) {
            if (((birthDate.getFullYear() + 16) > vm.data().TaxYear() ||
               (birthDate.getFullYear() + 18) < vm.data().TaxYear()) &&
                (global.isNull(spouseBirthDate) ||
                (spouseBirthDate.getFullYear() + 16) > vm.data().TaxYear() ||
                (spouseBirthDate.getFullYear() + 18) < vm.data().TaxYear())) {
                vm.data().Unit_H().Unit_H_12(false);
            }
        }
        if (vm.data().Unit_B().rdbPassportType() != vm.data().Unit_B().rdbIsrCitizen())
            vm.data().Unit_B().rdbIsrCitizen(vm.data().Unit_B().rdbPassportType()); // 0-TZ+isr citizen; 1-darkon+NOT isr

        if (vm.data().Unit_B().rdbIsrCitizen() == 0) { //olgak 12.01.15 - bug 12399
            vm.data().Unit_B().rdbIsrCitizen("0");
            vm.data().Unit_H().Unit_H_1(true);
        }
        else {
            // not israeli
            vm.data().Unit_B().rdbIsrCitizen("1");
            vm.data().Unit_H().Unit_H_1(false);
            vm.data().Unit_H().Unit_H_4(false);
        }    	      
    }
    function normalId(e, s) {
        var text;
        if (!global.isNOE(s))
            text = s.currentTarget.value;
        else
            text = vm.data().Unit_B().Employee_ID();
        if (!global.isNOE(text) && text.length >= 1 && text.length < 9) {
            while (text.length < 9) {
                text = '0' + text;
            }
            vm.data().Unit_B().Employee_ID(text);
        }
    }

    function setDataForSaving() {
        //not cause state that setDataForSaving will force user to load idCarsFileAgain.
        //NOTICE!!! if in future, this function will change fields that are really changes (not like HMO_Name that is only symbol and not data)-
        //you must be care to insert the new codeLines BEFORE empty callback.       
        vm.data().entityAspect.propertyChanged._subscribers[myCallbackIndex].callback = function () { };
        var tempIsModified = vm.data().entityAspect.entityState.isModified();
        vm.customIsModified = tempIsModified;
        
        // handling foreign citizen
        if (vm.data().Unit_B().rdbPassportType() == "1" && !global.isNOE(vm.data().Unit_B().Passport_ID())) {
            var numFromPassportId = vm.data().Unit_B().Passport_ID().replace(/\D/g, ""); // take just numeric part from string
            if (global.isNullOrEmpty(numFromPassportId)) {
                return alert(global.res[5573]); //'Darkon should include Numeric characters'
            }
            if (numFromPassportId.length > 9)
                numFromPassportId = numFromPassportId.substring(0, 9);
            vm.data().Unit_B().Employee_ID(numFromPassportId);
        }
        else
            vm.data().Unit_B().Passport_ID(""); // for save xml tag

        normalId();
        //console.log('empId=' + vm.data().Unit_B().Employee_ID() + '\nPasspId=' + vm.data().Unit_B().Passport_ID())

        if (vm.data().Unit_B().HMO_Member() == "1") {
            vm.data().Unit_B().HMO_Name(vm.hmoNameCombo.selectedItem().Descript);
        }
        else {
            vm.data().Unit_B().HMO_Name(null);
        }
        
        // set entity for correct validation
        vm.data().Unit_B().Country_Code(countryCombo.selectedItem().Code);
        vm.data().Unit_B().Country(countryCombo.selectedItem().Descript);
        //set City&Street name
        vm.data().Unit_B().City_Code(cityCombo.selectedItem().Code);
        vm.data().Unit_B().City(cityCombo.selectedItem().Descript);
        vm.data().Unit_B().StreetName(streetCombo.selectedItem().Code);

        if (!tempIsModified) {
            vm.data().entityAspect.setUnchanged();
        }
    }

    function enableHMOCombo() { return vm.data().Unit_B().HMO_Member() == 1; }

    function saveFiles() {
        if (!global.isNOE(vm.data().Unit_B().Employee_ID_Attachment()) && global.isNOE(vm.data().Unit_B().Employee_ID_Attachment().Id()) && !global.isNOE(vm.data().Unit_B().Employee_ID_Attachment().complexAspect.originalValues.Id) && vm.data().Unit_B().Employee_ID_Attachment().ForceGetPreviousAttachment() == true)
            vm.data().Unit_B().Employee_ID_Attachment().ForceGetPreviousAttachment(false);
        form101Helper.removeFileFromDB(vm.Employee_ID_Attachment, vm.data().Unit_B().Employee_ID_Attachment());
        var isAllFilesSave = true;
        var response = vm.Employee_ID_Attachment.upload();
        if (response) {
            vm.data().Unit_B().Employee_ID_Attachment().Id(response.Attachment_ID);
            vm.data().Unit_B().Employee_ID_Attachment().Name(response.AttachmentName);
            isIdCardFileHasBeenUpdatedThisTime = true;
        }
        else
            if (global.isNull(response)) {
                isAllFilesSave = false;
            }

        form101Helper.removeFileFromDB(vm.MaritalStatus_Attachment, vm.data().Unit_B().MaritalStatus_Attachment());
        response = vm.MaritalStatus_Attachment.upload();
        if (response) {
            vm.data().Unit_B().MaritalStatus_Attachment().Id(response.Attachment_ID);
            vm.data().Unit_B().MaritalStatus_Attachment().Name(response.AttachmentName);
        }
        else
            if (global.isNull(response)) {
                isAllFilesSave = false;
            }
        return isAllFilesSave;
    }
    function beforeBroswePrev() {

    }
    function hmoMemberChange(e, sender) {
        if (sender.currentTarget.checked == true && sender.currentTarget.value == "0") {
            vm.data().Unit_B().HMO_Member("0");
            vm.hmoNameCombo.changeSelectedItem(null);
        }
    }

    function sendSalaryChange(e, s) {
    	if (s.currentTarget.checked) 
    		$("#emailLbl").addClass("requireLabel");    	
    	else
    		$("#emailLbl").removeClass("requireLabel");    	
    }
    
    function rdbPassportTypeChange(e, s) {
        var isIsraeliCitizen = (s.currentTarget.value == "0") ? "0" : "1";
        vm.data().Unit_B().rdbIsrCitizen(isIsraeliCitizen);
        setAttachLabel(s.currentTarget.value);
    }

    function setForGoNext() {
        vm.showLastAttachmentsControls = false;
        cityCombo.customSelectionChanged = function () { };
        streetCombo.selectedId = ko.observable(vm.data().Unit_B().StreetName());
    }
    function setForGoPrev() {
        vm.Employee_ID_Attachment.temporaryHoldSavingData();
        vm.MaritalStatus_Attachment.temporaryHoldSavingData();
        cityCombo.customSelectionChanged = function () { };
        streetCombo.selectedId = ko.observable(vm.data().Unit_B().StreetName());
    }
    var vm = {
        showLastAttachmentsControls: false,
        Employee_ID_Attachment: null,
        immigration: immigration,
        birthday: birthday,
        data: ko.observable(dataContext.createClientInstance('Form101Unit_B')),
        init: init,
        isFirstTime: true,
        isValid: isValid,
        saveFiles: saveFiles,
        forceDependenceRules: forceDependenceRules,
        compositionComplete: compositionComplete,
        activate: activate,
        normalId: normalId,
        setDataForSaving: setDataForSaving,
        maritalStatusList: ko.observableArray([]),
        MaritalStatus_Attachment: null,
        areaCodeTemplate: function areaCodeTemplate(item) {
            return item.Code + '  ' + item.Descript;
        },
        areaCodeCombo: areaCodeCombo,
        mobileAreaCodeCombo: mobileAreaCodeCombo,
        hmoNameCombo: hmoNameCombo,
        hmoMemberChange: hmoMemberChange,
        customIsModified: false,
        setForGoNext: setForGoNext,
        setForGoPrev: setForGoPrev,
        onlyNumbersValidator: function (e) {
            var key = window.event ? event.keyCode : event.which;
            if (event.keyCode == 8 || event.keyCode == 46
                || event.keyCode == 37 || event.keyCode == 39) {
                return true;
            }
            else if (key < 48 || key > 57) {
                return false;
            }
            else return true;
        },
        cityCombo: cityCombo,
        streetCombo: streetCombo,
        countryCombo:countryCombo,
        global: global,
        isSendSalaryToEmail: ko.observable(global.cache.getCompanyParamByFieldName("SendSalaryToEmailForm101") == 1 ? true : false),
        sendSalaryChange: sendSalaryChange,
        rdbPassportTypeChange: rdbPassportTypeChange
    };

    return vm;
});