﻿define(function (require) {
    var global = require('common/global');
    var datePicker = require('views/controls/datePicker/datePicker');
    var dataContext = require('data/datacontext');
    var validationHelper = require('data/validationHelper');
    var lookupManager = require('common/lookupManager');


    function ViewModel() {
    	var options = null;
    	function init(params) {
    		options = params;
    		if (options.xVerNo == 0)
    		{ loadFrame(options); }
    		else {
    			var oneEmpQuery = {
    				TaxYear: options.xTaxYear,
    				Emp_no: options.xEmpNo,
    				Version: options.xVerNo,
    			};
    			// check real Status, becouse it maybe changed by another manager when current mng(or EMP itself) hold opened grid
    			global.httpGet(global.enums.httpPath.Form101MainEmpData, { query: JSON.stringify(oneEmpQuery) }).done(function getForm101DataSucceed(result) {
    				try {
    					if (result.Data[0] != undefined)
    						if (result.Data[0].VersionStatus != options.xVerStatus) {
    							options.xVerStatus = result.Data[0].VersionStatus;
    							options.xVerStatusName = result.Data[0].VersionStatusName;
    						};
    					loadFrame(options);
    				}
    				catch (err) {
    					global.treatError(err);
    					loadFrame(options);
    				}
    			});
    		}
    	}

        function openForNewAndUpdate(context) {
            //context contains needed parameters from record in grid:xVerNo, pIsNewVersion, xVerStatus, numerator(formId) 
            //context.xVerNo, etc
            var dataQuery = {
                TaxYear: context.xTaxYear,
                Emp_no: context.xEmpNo,
                Version: context.xVerNo == 0 ? null : context.xVerNo,
                Status: context.xVerStatus

            };
            global.httpGet(global.enums.httpPath.Form101Data, { query: JSON.stringify(dataQuery) }).done(function getForm101DataSucceed(result) {
                try {
                    var dataObject = {
                        data: null,
                        gridsData: {
                            childrenData: [],
                            OtherSalaries: [],
                            isChildenGridChanged: false,
                            isSalariesGridChanged: false,
                            rejectCreditsData: [],
                            acceptCreditsData: [],

                        }
                    };
                    var defaultData = {};
                    if (context.pIsNewVersion == 1) {
                        defaultData.TaxYear = context.xTaxYear;
                        defaultData.TabIndex = 0;
                    }
                    else if (context.xVerStatus == global.enums.form101status.RejectedByAccountManager) {//WI#21734 - when form101 is rejected, get in first screen employeeDetails and not predication screen
                        defaultData.TaxYear = result.Data.TaxYear;
                        defaultData.TabIndex = 0;
                    }
                    else {
                        defaultData.TaxYear = result.Data.TaxYear;
                        defaultData.TabIndex = result.Data.TabIndex;
                    }
                    defaultData.Unit_A = dataContext.createClientInstance('Form101Unit_A', result.Data.Unit_A);

                    //#region init unit B entity
                    result.Data.Unit_B.Employee_ID_Attachment = dataContext.createClientInstance('Form101Attachment', result.Data.Unit_B.Employee_ID_Attachment);
                    result.Data.Unit_B.MaritalStatus_Attachment = dataContext.createClientInstance('Form101Attachment', result.Data.Unit_B.MaritalStatus_Attachment);
                    result.Data.Unit_B.Emp_no = context.xEmpNo;
                    if (!global.isNull(result.Data.Unit_B.BirthDate)) {
                        result.Data.Unit_B.BirthDate = result.Data.Unit_B.BirthDate;
                    }
                    if (!global.isNull(result.Data.Unit_B.ImmigrationDate)) {
                        result.Data.Unit_B.ImmigrationDate = result.Data.Unit_B.ImmigrationDate;
                    }
                    defaultData.Unit_B = dataContext.createClientInstance('Form101Unit_B', result.Data.Unit_B);
                    //#endregion init unit B

                    //#region try take default data when data is null
                    if (!global.isNull(result.Data.DefaultData)) {
                        if (global.isNull(result.Data.Unit_C)) {
                            result.Data.Unit_C = result.Data.DefaultData.Unit_C;
                        }
                        if (global.isNull(result.Data.Unit_D)) {
                            result.Data.Unit_D = result.Data.DefaultData.Unit_D;
                        }
                        if (global.isNull(result.Data.Unit_E)) {
                            result.Data.Unit_E = result.Data.DefaultData.Unit_E;
                        }
                        if (global.isNull(result.Data.Unit_F)) {
                            result.Data.Unit_F = result.Data.DefaultData.Unit_F;
                        }
                        if (global.isNull(result.Data.Unit_H)) {
                            result.Data.Unit_H = result.Data.DefaultData.Unit_H;
                        }
                        if (global.isNull(result.Data.Unit_I)) {
                            result.Data.Unit_I = result.Data.DefaultData.Unit_I;
                        }
                        if (global.isNull(result.Data.Unit_O)) {
                            result.Data.Unit_O = result.Data.DefaultData.Unit_O;
                        }
                    }
                    //#endregion try take default data when data is null

                    //#region init unit C entity
                    if (!global.isNull(result.Data.Unit_C)) {
                        dataObject.gridsData.childrenData = !global.isNull(result.Data.Unit_C.Children) ? result.Data.Unit_C.Children : [];
                        delete result.Data.Unit_C.Children;
                        defaultData.Unit_C = dataContext.createClientInstance('Form101Unit_C', result.Data.Unit_C);

                        //init credits gridsdata(reject&accept) by children data field CreditRequsetStatus
                        if (!global.isNOE(dataObject.gridsData.childrenData) && dataObject.gridsData.childrenData.length > 0) {
                            $.each(dataObject.gridsData.childrenData, function eachChild(index, item) {
                                if (item.CreditRequsetStatus == global.enums.requestStatus.Reject) {
                                    dataObject.gridsData.rejectCreditsData.push({
                                        Child_ID: item.Child_ID, ChildName: item.ChildName, ChildBirthDate: item.ChildBirthDate, ChildIndex: index
                                    })
                                }

                                if (item.CreditRequsetStatus == global.enums.requestStatus.Accept) {
                                    dataObject.gridsData.acceptCreditsData.push({
                                        Child_ID: item.Child_ID, ChildName: item.ChildName, ChildBirthDate: item.ChildBirthDate, ChildIndex: index
                                    })
                                }
                            });
                        }
                    }
                    //#endregion init unit C entity

                    //#region init unit D entity
                    if (!global.isNull(result.Data.Unit_D)) {
                        if (!global.isNull(result.Data.Unit_D.PeriodStartDate) && Date.parse(result.Data.Unit_D.PeriodStartDate) >= new Date(context.xTaxYear, 0, 1)) {
                            result.Data.Unit_D.PeriodStartDate = result.Data.Unit_D.PeriodStartDate;
                        }
                        else {
                            result.Data.Unit_D.PeriodStartDate = new Date(context.xTaxYear, 0, 1).clearTime().toString(global.consts.dateTimeFormatYMDTHMS);
                        }
                    }
                    else {
                        result.Data.Unit_D = { PeriodStartDate: new Date(context.xTaxYear, 0, 1).clearTime().toString(global.consts.dateTimeFormatYMDTHMS) };
                    }
                    defaultData.Unit_D = dataContext.createClientInstance('Form101Unit_D', result.Data.Unit_D);
                    //#endregion init unit D entity

                    //#region init unit E entity
                    if (!global.isNOE(result.Data.Unit_E))
                        result.Data.Unit_E.Unit_E_Attachment = dataContext.createClientInstance('Form101Attachment', result.Data.Unit_E.Unit_E_Attachment);

                    defaultData.Unit_E = dataContext.createClientInstance('Form101Unit_E', result.Data.Unit_E);
                    //#endregion init unit E entity

                    //#region init unit F entity
                    if (!global.isNull(result.Data.Unit_F)) {
                        if (!global.isNull(result.Data.Unit_F.SpouseBirthDate)) {
                            result.Data.Unit_F.SpouseBirthDate = result.Data.Unit_F.SpouseBirthDate;
                        }
                        if (!global.isNull(result.Data.Unit_F.SpouseImmigrationDate)) {
                            result.Data.Unit_F.SpouseImmigrationDate = result.Data.Unit_F.SpouseImmigrationDate;
                        }
                    }
                    defaultData.Unit_F = dataContext.createClientInstance('Form101Unit_F', result.Data.Unit_F);
                    //#endregion init unit F entity

                    //#region init unit H entity
                    if (!global.isNull(result.Data.Unit_H)) {
                        result.Data.Unit_H.Unit_H_2_Attachment = dataContext.createClientInstance('Form101Attachment', result.Data.Unit_H.Unit_H_2_Attachment);
                        result.Data.Unit_H.Unit_H_3_Attachment = dataContext.createClientInstance('Form101Attachment', result.Data.Unit_H.Unit_H_3_Attachment);
                        result.Data.Unit_H.Unit_H_4_1_1_Attachment = dataContext.createClientInstance('Form101Attachment', result.Data.Unit_H.Unit_H_4_1_1_Attachment);
                        result.Data.Unit_H.Unit_H_4_1_2_Attachment = dataContext.createClientInstance('Form101Attachment', result.Data.Unit_H.Unit_H_4_1_2_Attachment);
                        result.Data.Unit_H.Unit_H_5_Attachment = dataContext.createClientInstance('Form101Attachment', result.Data.Unit_H.Unit_H_5_Attachment);
                        result.Data.Unit_H.Unit_H_10_Attachment = dataContext.createClientInstance('Form101Attachment', result.Data.Unit_H.Unit_H_10_Attachment);
                        result.Data.Unit_H.Unit_H_11_Attachment = dataContext.createClientInstance('Form101Attachment', result.Data.Unit_H.Unit_H_11_Attachment);
                        result.Data.Unit_H.Unit_H_13_Attachment = dataContext.createClientInstance('Form101Attachment', result.Data.Unit_H.Unit_H_13_Attachment);
                        result.Data.Unit_H.Unit_H_14_Attachment = dataContext.createClientInstance('Form101Attachment', result.Data.Unit_H.Unit_H_14_Attachment);
                        result.Data.Unit_H.Unit_H_30_Attachment = dataContext.createClientInstance('Form101Attachment', result.Data.Unit_H.Unit_H_30_Attachment);
                        if (!global.isNull(result.Data.Unit_H.Unit_H_3_1)) {
                            result.Data.Unit_H.Unit_H_3_1 = result.Data.Unit_H.Unit_H_3_1;
                        }
                        if (!global.isNull(result.Data.Unit_H.Unit_H_3_1)) {
                            result.Data.Unit_H.Unit_H_3_1 = result.Data.Unit_H.Unit_H_3_1;
                        }
                        if (!global.isNull(result.Data.Unit_H.Unit_H_4_3)) {
                            result.Data.Unit_H.Unit_H_4_3 = result.Data.Unit_H.Unit_H_4_3;
                        }
                        if (!global.isNull(result.Data.Unit_H.Unit_H_4_4)) {
                            result.Data.Unit_H.Unit_H_4_4 = result.Data.Unit_H.Unit_H_4_4;
                        }
                        if (!global.isNull(result.Data.Unit_H.Unit_H_13_1)) {
                            result.Data.Unit_H.Unit_H_13_1 = result.Data.Unit_H.Unit_H_13_1;
                        }
                        if (!global.isNull(result.Data.Unit_H.Unit_H_13_2)) {
                            result.Data.Unit_H.Unit_H_13_2 = result.Data.Unit_H.Unit_H_13_2;
                        }
                        defaultData.Unit_H = dataContext.createClientInstance('Form101Unit_H', result.Data.Unit_H);

                    }
                    //#endregion init unit D entity

                    //#region init unit I entity
                    if (!global.isNull(result.Data.Unit_I)) {
                        result.Data.Unit_I.Unit_HI_1_Attachment = dataContext.createClientInstance('Form101Attachment', result.Data.Unit_I.Unit_HI_1_Attachment);
                        result.Data.Unit_I.Unit_HI_3_Attachment = dataContext.createClientInstance('Form101Attachment', result.Data.Unit_I.Unit_HI_3_Attachment);

                        dataObject.gridsData.OtherSalaries = !global.isNull(result.Data.Unit_I.OtherSalaries) ? result.Data.Unit_I.OtherSalaries : [];
                        delete result.Data.Unit_I.OtherSalaries;
                        defaultData.Unit_I = dataContext.createClientInstance('Form101Unit_I', result.Data.Unit_I);
                    }
                    //#endregion init unit I entity

                    //#region init unit O entity
                    if (!global.isNull(result.Data.Unit_O)) {
                        defaultData.Unit_O = dataContext.createClientInstance('Form101Unit_O', result.Data.Unit_O);
                    }
                    //#endregion init unit O entity
                    dataObject.data = dataContext.createClientEntity('Form101DTO', defaultData);
                    var currentView = 'views/forms/form101/form101Wrapper.html';
                    lookupManager.saveLookupAtCache(global.enums.lookupName.Form101AreaCodes, result.AreaCodeList);
                    lookupManager.saveLookupAtCache(global.enums.lookupName.Form101HMONames, result.HMOList);

                    require(["views/forms/form101/form101Wrapper"], function loadFrameSucceed(wrapper) {
                        var currentViewModel = new wrapper(dataObject, context, result.MaritalStatusList, context.pIsNewVersion, result.Comments, result.Data.DefaultData);
                        vm.currentForm101Screen({ view: currentView, model: currentViewModel });
                    });
                }
                catch (err) {
                    global.treatError(err);
                }
            });
        }

        function loadFrame(context) {
            if (options.xIsAccountManager == "1") {
                loadFrameToAccountManager(options);
            }
            else
                loadFrameToUser(options);
        }
        function loadFrameToUser(context) {
            switch (context.xVerStatus.toString()) {
                case global.enums.form101status.New.toString():
                case global.enums.form101status.Edit.toString():
                case global.enums.form101status.RejectedByAccountManager.toString():
                    openForNewAndUpdate(context);
                    break;
                default:
                    openCurrentForm101Screen(context);
            }
        }
        function loadFrameToAccountManager(context) {
                openCurrentForm101Screen(context);
        }

        function openCurrentForm101Screen(context) {
            if (global.isMobile()) {
                currentView = 'views/forms/form101Mobile/form101ViewScreen.html';
                require(["views/forms/form101Mobile/form101ViewScreen"], function loadFrameSucceed(frame) {
                    currentViewModel = new frame(context);
                    vm.currentForm101Screen({ view: currentView, model: currentViewModel });
                });
            } else {
                currentView = 'views/forms/form101/form101ViewScreen.html';
                require(["views/forms/form101/form101ViewScreen"], function loadFrameSucceed(frame) {
                    currentViewModel = new frame(context);
                    vm.currentForm101Screen({ view: currentView, model: currentViewModel });
                });
            }
        }
        function activate(context1) {

            //context.xVerStatus
            //context.pIsNewVersion
            //context.xVerNo
            //context.xEmpNo
            //context contains needed parameters from record in grid:xVerNo, pIsNewVersion, xVerStatus, numerator(formId) 
            //context.xVerNo, etc




        }

        function cancel() {
            global.app.trigger(global.enums.events.CANCEL_FORM101.name);
        }
        var vm = {
            //formWrapper: ko.observable(null),
        	activate: activate,
			init: init,
            currentForm101Screen: ko.observable(null),
            deactivate: function (a) {
                vm.currentForm101Screen(null);
            }
        };


        return vm;
    }
    return ViewModel;
});