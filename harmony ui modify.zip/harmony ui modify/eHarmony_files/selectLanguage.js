﻿//this javascript page must use global.dict(), global.dictMsg - if needed - and mustn't use global.res, global.resMsg

define(function selectLanguageControl(require) {

    var global = require('common/global');
    var lookupManager = require('common/lookupManager');
    var cacheManager = require('common/cache/cacheManager');

    var vm = function () {

        var obj = {
            global: global,
            list: ko.observableArray(),
            selectLanguageId: ko.observable("defaultLanguage"),
            selectedLanguage: ko.observable(null),
            changeSelectedLanguage: changeSelectedLanguage,
            changeLanguageByCode:changeLanguageByCode,
            initializeLanguageList: initializeLanguageList
        };

        function changeSelectedLanguage(language) {
            obj.selectedLanguage(language);
        }

        function changeLanguageByCode(langCode) {
            var language = Enumerable.From(obj.list())
                                      .Where(function (lu) { return lu.Code == langCode })
                                      .Select(function (lu) { return lu }).FirstOrDefault();
            if (!global.isNull(language)) {
                obj.selectedLanguage(language);
            }
        }

        function initializeLanguageList(lookupName) {

            //get lookup data
            var promise = getLookup(lookupName);
            promise.done(result);
            function result() {

            }

            function getLookup(lookupName) {

                var query;
                var user = global.cache.get(global.enums.cacheItems.USER);

                query =
                 {
                     EmpNo: user != null ? user.Id : null,
                     UserNo: user != null ? user.Profile != null ? user.Profile.Code : null : null,
                     ElemName: lookupName.name,
                     PageNo: 0,
                     PageSize: 200,
                     PagingBy: true,
                     SearchBy: 2,
                     SearchVal: '',
                     SearchExact: true,
                     OtherParamsXML: ''
                 };

                var deferred = global.system.defer(function getLookupPromiseFunc(dfd) {
                    return lookupManager.getLookup(dfd, obj.list, query, lookupName);
                });
                return deferred.promise();
            }
        };

        return obj;
    };

    return vm;
});