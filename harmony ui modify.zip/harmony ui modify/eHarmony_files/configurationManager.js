﻿define(function configurationManagerModule(require) {
    var errorManager = require('common/errorManager');
    var cacheManager = require('common/cache/cacheManager');
    var cacheItems = cacheManager.cacheItems;
    var enums = require('common/enums/enums');
    var configParams = enums.configParams;

    function getConfigParam(param) {
        var config = cacheManager.get(cacheItems.CUSTOM_CONFIG);
        if (config == null) {
            throw new Error("custom configuration is null");
        }
        else {
            switch (param) {
                case configParams.MAIN_CHARSET:
                    return config.Language.Maincharset;
                case configParams.LANGUAGE:
                    return config.Language.Language;
                case configParams.IS_PORTAL:
                    return config.GlobalParams.IsPortal;
                case configParams.HELP_PATH:
                    return config.GlobalParams.HelpPath;
                case configParams.LOGO_PATH:
                    return config.GlobalParams.LogoPath;
                case configParams.EXPIRE_SESSION_TIME:
                    return config.ExpiryTime;
                case configParams.SAVE_LAYOUT:
                    return config.SaveLayout;
                case configParams.LOG_PATH:
                    return config.harmonySrvLogPath;
                case configParams.RESPONSE_COMP_OF_PORTAL:
                    return config.GlobalParams.ResponseCompanyOfPortal;
                case configParams.BILLING_SERVER:
                    return config.Billing.Server;
                case configParams.MODE_OF_RUNNING_APP:
                    return config.GlobalParams.ModeOfRunningApp;
                case configParams.EHARMONY_DOCS_PATH:
                    return config.eHarmonyDocsPath;
                case configParams.ISL_DOWNLOAD_URL:
                    return config.GlobalParams.ISLDownloadURL;
                case configParams.REPORT_URL_PATH:
                    return config.GlobalParams.ReportServerLocation;
                case configParams.REPORT_CODES_WS:
                    return config.GlobalParams.ReportsCodesForWS;
                case configParams.REPORT_WS_URL:
                    return config.GlobalParams.ReportsWSUrl;
                case configParams.WEB_CONTAINS_101:
                    return config.GlobalParams.WebContains101;
                default: return null;

            }
        }
    }

    try{
        var module = {           
            getConfigParam: getConfigParam
        }

        return module;
    }
    catch (err) {
        errorManager.treatError(err);
    }


});