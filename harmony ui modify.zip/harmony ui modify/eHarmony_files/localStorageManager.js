﻿define(function localStorageManagerModule(require) {

    var enums = require('common/enums/enums');
    var cacheItems = enums.cacheItems;

    var harmonyStorageName = 'eHrm';
    var harmonyStorage;
    initHarmonyStorage();

    function initHarmonyStorage() {
        harmonyStorageString = localStorage[harmonyStorageName];
        if (isNull(harmonyStorageString)) {
            localStorage[harmonyStorageName] = JSON.stringify({});
        }
        harmonyStorage = JSON.parse(localStorage[harmonyStorageName]);
    }

    var module = {
        setPropOfItem: updateLocalStorageItemProperty,
        getPropOfItem: getLocalStorageItemProperty,
        set: function set(key, val) {
            if (val == null) {
                delete harmonyStorage[key.name];
                localStorage[harmonyStorageName] = JSON.stringify(harmonyStorage);
                return;
            }
            switch (key) {
                case cacheItems.LAST_LANGUAGE:
                case cacheItems.LAST_USER:
                case cacheItems.ATTENDANCE_LAST_SORT_DEFINITIONS_FOR_TASK_POPUP:
                case cacheItems.LAST_ORG_LEVEL_EMP:
                case cacheItems.LAST_ORG_LEVEL_WEEKLY:
                case cacheItems.LAST_ORG_LEVEL_DAILY:
            	case cacheItems.LAST_ORG_LEVEL_ATT:
            	case cacheItems.LAST_ORG_LEVEL_APPR_MANAGER:
				case cacheItems.LAST_ORG_CODE_APPR_MANAGER:
                case cacheItems.LAST_ABS_ATTEND_FILTER_ATT:
                case cacheItems.ReportParams:
                case cacheItems.COMPANY_ORG_TREE:
                case cacheItems.COMPANY_ORG_TREE_PB:
                case cacheItems.MAINTENANCE_LAST_VALUES:
                case cacheItems.SCREEN_PARAMS:
                    harmonyStorage[key.name] = JSON.stringify(val);
                    localStorage[harmonyStorageName] = JSON.stringify(harmonyStorage);
                    break;

                case cacheItems.LASTCOMP:
                case cacheItems.LAST_STATUS_FILTER_EMP:
                case cacheItems.LAST_STATUS_FILTER_PENDING_REP:
                case cacheItems.LAST_VIEW_FILTER_MNG_APPR_REQ:
                case cacheItems.LAST_STATUS_FILTER_ATT:
                case cacheItems.LAST_VIEW_FILTER_ATT:
                case cacheItems.LAST_WORK_SCHEDULE_DAILY_SORT:
                case cacheItems.LAST_WORK_SCHEDULE_DAILY_SHOW:
                case cacheItems.GRID_LAYOUT:
                case cacheItems.SPLITTER_LAYOUT:
                case cacheItems.MESSAGE_LAYOUT:
                case cacheItems.LAST_DAILY_REPORTING_OPER:
                case cacheItems.LAST_DAILY_REPORTING_ACTION:
                case cacheItems.LAST_DAILY_REPORTING_MACHINE:
                case cacheItems.LAST_DAILY_REPORTING_LEVEL:
                case cacheItems.LAST_DAILY_REPORTING_BUDGET:
                case cacheItems.LAST_DAILY_REPORTING_SUB_BUDGET:
                case cacheItems.LAST_ATTENDANCE_ON_DUTY_CODES:
                case cacheItems.SALARY_IO_EXPORT_LAST_VALUES:
                case cacheItems.ATTENDANCE_IO_EXPORT_LAST_VALUES:
                case cacheItems.LAST_DOCUMENT_TYPE:
            	case cacheItems.LAST_STATUS_FILTER_EMP_DOCUMENT:
            	case cacheItems.LAST_START_DATE_EMP_ATTEND_MNG:
            	case cacheItems.LAST_END_DATE_EMP_ATTEND_MNG:
                case cacheItems.ADS_USER:
                case cacheItems.LOGOUT_HAS_OCCURED:
                case cacheItems.LAST_STATUS_FILTER_EMP_IN_101:
                case cacheItems.USER_HAS_PROFILE:
                case cacheItems.HEADER_DISPLAY_MODE:
                    harmonyStorage[key.name] = val;
                    localStorage[harmonyStorageName] = JSON.stringify(harmonyStorage);
                    break;
                default: throw new Error("Cache item is not supported in local storage: " + key.name);
            }


        },
        get: function get(key) {
            switch (key) {
                case cacheItems.LAST_LANGUAGE:
                case cacheItems.LAST_USER:
                case cacheItems.ATTENDANCE_LAST_SORT_DEFINITIONS_FOR_TASK_POPUP:
                case cacheItems.LAST_ORG_LEVEL_ATT:
                case cacheItems.LAST_ORG_LEVEL_EMP:
                case cacheItems.LAST_ORG_LEVEL_WEEKLY:
            	case cacheItems.LAST_ORG_LEVEL_DAILY:
            	case cacheItems.LAST_ORG_LEVEL_APPR_MANAGER:
            	case cacheItems.LAST_ORG_CODE_APPR_MANAGER:
                case cacheItems.LAST_ABS_ATTEND_FILTER_ATT:
                case cacheItems.ReportParams:
                case cacheItems.COMPANY_ORG_TREE:
                case cacheItems.COMPANY_ORG_TREE_PB:
                case cacheItems.MAINTENANCE_LAST_VALUES:
                case cacheItems.SCREEN_PARAMS:
                    return isNull(harmonyStorage[key.name]) ? null : JSON.parse(harmonyStorage[key.name]);

                case cacheItems.LASTCOMP:
                case cacheItems.LAST_STATUS_FILTER_PENDING_REP:
                case cacheItems.LAST_VIEW_FILTER_MNG_APPR_REQ:
                case cacheItems.LAST_STATUS_FILTER_EMP:
                case cacheItems.LAST_STATUS_FILTER_ATT:
                case cacheItems.LAST_VIEW_FILTER_ATT:
                case cacheItems.LAST_WORK_SCHEDULE_DAILY_SORT:
                case cacheItems.LAST_WORK_SCHEDULE_DAILY_SHOW:
                case cacheItems.GRID_LAYOUT:
                case cacheItems.SPLITTER_LAYOUT:
                case cacheItems.MESSAGE_LAYOUT:
                case cacheItems.LAST_DAILY_REPORTING_OPER:
                case cacheItems.LAST_DAILY_REPORTING_ACTION:
                case cacheItems.LAST_DAILY_REPORTING_MACHINE:
                case cacheItems.LAST_DAILY_REPORTING_LEVEL:
                case cacheItems.LAST_DAILY_REPORTING_BUDGET:
                case cacheItems.LAST_DAILY_REPORTING_SUB_BUDGET:
                case cacheItems.LAST_ATTENDANCE_ON_DUTY_CODES:
                case cacheItems.SALARY_IO_EXPORT_LAST_VALUES:
                case cacheItems.ATTENDANCE_IO_EXPORT_LAST_VALUES:
                case cacheItems.LAST_DOCUMENT_TYPE:
            	case cacheItems.LAST_STATUS_FILTER_EMP_DOCUMENT:
            	case cacheItems.LAST_START_DATE_EMP_ATTEND_MNG:
            	case cacheItems.LAST_END_DATE_EMP_ATTEND_MNG:
                case cacheItems.ADS_USER:
                case cacheItems.LOGOUT_HAS_OCCURED:
                case cacheItems.LAST_STATUS_FILTER_EMP_IN_101:
                case cacheItems.USER_HAS_PROFILE:
                case cacheItems.HEADER_DISPLAY_MODE:
                    return harmonyStorage[key.name];

                default: throw new Error("Cache item is not supported in local storage: " + key.name);
            }


        },

        isExistKey: function isExistKey(key) {
            switch (key) {
                case cacheItems.LAST_LANGUAGE:
                case cacheItems.LAST_USER:
                case cacheItems.ATTENDANCE_LAST_SORT_DEFINITIONS_FOR_TASK_POPUP:
                case cacheItems.LAST_ORG_LEVEL_ATT:
                case cacheItems.LAST_ORG_LEVEL_EMP:
                case cacheItems.LAST_ORG_LEVEL_WEEKLY:
            	case cacheItems.LAST_ORG_LEVEL_DAILY:
            	case cacheItems.LAST_ORG_LEVEL_APPR_MANAGER:
            	case cacheItems.LAST_ORG_CODE_APPR_MANAGER:
                case cacheItems.LAST_ABS_ATTEND_FILTER_ATT:
                case cacheItems.LASTCOMP:
                case cacheItems.LAST_STATUS_FILTER_PENDING_REP:
                case cacheItems.LAST_VIEW_FILTER_MNG_APPR_REQ:
                case cacheItems.LAST_STATUS_FILTER_EMP:
                case cacheItems.LAST_STATUS_FILTER_ATT:
                case cacheItems.LAST_VIEW_FILTER_ATT:
                case cacheItems.LAST_WORK_SCHEDULE_DAILY_SORT:
                case cacheItems.LAST_WORK_SCHEDULE_DAILY_SHOW:
                case cacheItems.LAST_DAILY_REPORTING_OPER:
                case cacheItems.LAST_DAILY_REPORTING_ACTION:
                case cacheItems.LAST_DAILY_REPORTING_MACHINE:
                case cacheItems.LAST_DAILY_REPORTING_LEVEL:
                case cacheItems.LAST_DAILY_REPORTING_BUDGET:
                case cacheItems.LAST_DAILY_REPORTING_SUB_BUDGET:
                case cacheItems.LAST_ATTENDANCE_ON_DUTY_CODES:
                case cacheItems.SALARY_IO_EXPORT_LAST_VALUES:
                case cacheItems.ATTENDANCE_IO_EXPORT_LAST_VALUES:
                case cacheItems.LAST_DOCUMENT_TYPE:
            	case cacheItems.LAST_STATUS_FILTER_EMP_DOCUMENT:
            	case cacheItems.LAST_START_DATE_EMP_ATTEND_MNG:
            	case cacheItems.LAST_END_DATE_EMP_ATTEND_MNG:
                case cacheItems.ADS_USER:
                case cacheItems.ReportParams:
                case cacheItems.COMPANY_ORG_TREE:
                case cacheItems.COMPANY_ORG_TREE_PB:
                case cacheItems.MAINTENANCE_LAST_VALUES:
                case cacheItems.LOGOUT_HAS_OCCURED:
                case cacheItems.LAST_STATUS_FILTER_EMP_IN_101:
                case cacheItems.USER_HAS_PROFILE:
                case cacheItems.HEADER_DISPLAY_MODE:
                    return !isNull(harmonyStorage[key.name])

                    break;
                default:
                    return false;
            }
        }
    };
    return module;

    function isNull(value) {
        if (value == null || value == 'undefined')
            return true;
        else
            return false;
    }

    function regularObjectAsObservable(regularObject) {
        if ($.isPlainObject(regularObject)) {
            $.each(regularObject, function (k, v) {
                regularObject[k] = ko.observable(v);
            });
        }
    }
    function observableObjectAsRegular(observableObject) {
        if ($.isPlainObject(observableObject)) {
            $.each(observableObject, function (k, v) {
                observableObject[k] = v();
            });
        }
    }

    function updateLocalStorageItemProperty(cacheItem, property_name, value) {
        var item = module.get(cacheItem);
        if (isNull(item)) {
            item = {};
        }
        item[property_name] = value;
        module.set(cacheItem, item);

    }
    function getLocalStorageItemProperty(cacheItem, property_name) {
        var item = module.get(cacheItem);
        return !isNull(item) ? item[property_name] : null;
    }
});