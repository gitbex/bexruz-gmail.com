﻿(function ($) {
    var kendo = window.kendo,
        ui = kendo.ui,
        Widget = ui.Widget,
        proxy = $.proxy,
        CHANGE = "change",
        PROGRESS = "progress",
        ERROR = "error",
        NS = ".generalInfo";

    var MaskedDatePicker = Widget.extend({
        init: function (element, options) {
            var that = this;
            Widget.fn.init.call(this, element, options);

            $(element).kendoMaskedTextBox({ mask: that.options.dateOptions.mask || "00/00/0000" })
            .kendoDatePicker({
                format: that.options.dateOptions.format || "MM/dd/yyyy",
                parseFormats: that.options.dateOptions.parseFormats || ["MM/dd/yyyy", "MM/dd/yy"]
            })
            .closest(".k-datepicker")
            .add(element)
            .removeClass("k-textbox");
        },
        options: {
            name: "MaskedDatePicker",
            dateOptions: {}
        },
        destroy: function () {
            var that = this;
            Widget.fn.destroy.call(that);

            kendo.destroy(that.element);
        },
        value: function (value) {
            var datepicker = this.element.data("kendoDatePicker");

            if (value === undefined) {
                return datepicker.value();
            }

            datepicker.value(value);
        }
    });

    ui.plugin(MaskedDatePicker);

})(window.kendo.jQuery);

(function ($) {
    var ui = kendo.ui,
     MyMask = kendo.ui.DatePicker.extend({
         init: function (element, options) {
             var extended = $.extend(this.options, options);
             kendo.ui.DatePicker.prototype.init.call(this, element, extended);
             $(element).inputmask("mask", extended);
         },
         options: {
             name: "MyMaskedDatePicker",
             mask: "99/99/9999",
             showMaskOnHover: true,
             clearMaskOnLostFocus: true
         }
     });

    ui.plugin(MyMask);

})(jQuery);