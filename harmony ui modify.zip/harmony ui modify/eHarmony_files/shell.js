﻿define(function shellPage(require) {

    var http = require('plugins/http');
    var router = require('plugins/router');
    var app = require('durandal/app');
    var permission = require('common/permission');
    var errorManager = require('common/errorManager');
    var cacheManager = require('common/cache/cacheManager');
    var system = require('durandal/system');
    var global = require('common/global');
    var datacontext = require('data/datacontext');
    var res = require('common/resourcesManager');
    var configurationManager = require('common/configurationManager');
    var enums = require('common/enums/enums');
    var customMessageWindow = require('views/combinedControls/customMessageWindow/customMessageWindow');
    var notification = require('views/controls/notification/notification');
    var dataContext = require('data/dataContext');
    var autoComplete = require('views/controls/autoComplete/autoComplete');

    if (!global.cache.isExistKey(global.enums.cacheItems.LOGIN_DETAILS_COOKIE)) {
        global.isPerformenceImmedientLogin(false);
    }

    try {
        var cache = global.cache;
        var isTextProcessHasMesssage = false;
        var isFirstForcedLogout = true;
        var iteration;
        
        var helpCombo = new autoComplete({ template: global.enums.comboTemplates.descriptOnly });        

        //calculate height of each section

        //convert pictures from file to bytearray
        //used this method for converting all employees pictures(in iis folder) to bytearray in DB
        function convertPicture() {
            try {
                global.httpGet(global.enums.httpPath.ConvertPicture).then(function ConvertPictureDone() { });
            }
            catch (err) {
                global.treatError(err);
            }
        }


        function saveLayout() {
            try {
                if (!global.isLayoutsSave())
                    return;
                global.displaySpin(true);
                var layout = global.cache.get(global.enums.cacheItems.GRID_LAYOUT);
                if (layout == "") {
                    global.displaySpin(false);
                    return;
                }
                var layouts = [];
                for (var prop in layout) {

                    layouts.push(
                      {
                          GridName: prop,
                          Layout: layout[prop],
                      });
                }

                var LayoutsCommand =
                    {
                        GridLayouts: layouts
                    };
                return global.httpPost(global.enums.httpPath.SaveGridsLayouts, LayoutsCommand)
                    .then(function () {
                        global.displaySpin(false);
                    });

            }
            catch (err) {
                global.treatError(err);
                global.displaySpin(false);
            }
        }


        function saveReplacementMng() {
            var incReplacement;
            if (vm.isHeaderExpanded) {
                incReplacement = ($("#chbIncludeReplaceMng").is(":checked")) ? 1 : 0;
            }
            else {
                incReplacement = ($("#chbIncludeReplaceMng2").is(":checked")) ? 1 : 0;
            }

            //change styling when page NOT FULLY reloaded
            if (incReplacement == 1) {
                $('#captReplacMng').attr('class', 'blueFontDisabled');
                vm.captIncludeReplaceMng(captOn);
            }
            else {
                $('#captReplacMng').attr('class', 'headerCompanyName');
                vm.captIncludeReplaceMng(captOff);
            }

            var saveCommand = { Code: incReplacement };
            return global.httpPost(global.enums.httpPath.SaveReplacementMng, saveCommand)
                .done(function () {
                    var netoHash;
                    if (window.location.hash.indexOf('/') == -1)
                        netoHash = window.location.hash;
                    else
                        netoHash = window.location.hash.substring(0, window.location.hash.indexOf('/'));
                    /*
                    ==== Handling refresh active page after switchbutton ===
                    1. don't reload PAGES [maintenance] && [reports], becouse there are not contect grid with emp list directly
                       in Reports the result seen in src-dest OR [...] for fromEmp/toEmp
                    2. if exists REFRESH button and grid on active screen -> just refresh grid by apply  $("#refreshImgBtn").click()
                       it's very effective for HOME>Approve Updates(Reports), Employees, GroupUpdate, Schedular pages
                    3. if NOT exists REFRESH button -> router.navigate with optional param Date.now(). 
                        Without this param impossible reload current page - by history.js it returns without navigate
                    4. in case very complicated cases - it's always possible to RELOAD FULL page by
                        window.location.reload();
                    */

                        if (netoHash != '#maintenance' && netoHash != '#reports') {
                        // get again empcount in case page not rloaded, e.g. HOME||Emp to use futer in Reports
                        global.httpGet(global.enums.httpPath.GetEmpLookupRecordsCount).done(function getScalarValueDone(result) {
                            if (!global.isNull(result)) {
                                var empCnt=parseInt(result.ReturnVal);
                                var currentUser = cache.get(cache.enums.cacheItems.USER);
                                if (currentUser.empLookupCount != empCnt){
                                    currentUser.empLookupCount = empCnt;
                                    cache.set(cache.enums.cacheItems.USER, currentUser);
                                }
                            }
                            if ($("#refreshImgBtn").length == 1 && $(".k-grid"))
                                $("#refreshImgBtn").click();
                            else {
                                $(".k-grid").each(function (idx, kGrid) {
                                    var dataObj = $(kGrid).data();
                                    for (mData in dataObj) {
                                        if (Object.prototype.toString.call(dataObj[mData]) != '[object String]') {
                                            if ("destroy" in dataObj[mData]) {
                                                dataObj[mData].destroy();
                                            }
                                        }
                                    }
                                });
                                router.navigate(netoHash + '/' + Date.now(), { replace: true, trigger: true });
                            }
                        });
                        

                            
                        }
                            // for maintenance & reports : if exists combo fromEmp -> reload page
                        else {
                            if($("#fromEmpComboCtrl").length !=0)
                                window.location.reload();
                        }
                    }
            );
        }
        var isRouterActivated = false;
        var captOn = 'ON';
        var captOff = 'OFF';
        var strHelpUrl = '';
        var defaultPage = "";
        //routing array
        var routingPaths = {
            login: { path: 'pages/login/login', hash: 'login', nav: true },
            employees: { path: 'pages/employeesAndTags/employeesAndTags', hash: 'employees', nav: true },
            attendance: { path: 'pages/attendance/attendance', hash: 'attendance', nav: true },
            home: { path: 'pages/home/home', hash: 'home', nav: true },
            reports: { path: 'pages/reports/reports', hash: 'reports', nav: true },
            maintenanceorg: { path: 'pages/maintenanceOrg/maintenance', hash: 'maintenanceOrg', nav: true },
            iosalaryexport: { path: 'views/maintenanceOrg/interfaces/salaryIOExport/salaryIOExport', hash: 'salaryIOExport' },
            maintenance: { path: 'pages/maintenance/maintenance', hash: 'maintenance', nav: true },
            workschedule: { path: 'pages/workSchedule/workSchedule', hash: 'workSchedule', nav: true },

            form101: { path: 'pages/documents/documents', hash: 'documents', param: global.enums.documentType.form101 },
            form106: { path: 'pages/documents/documents', hash: 'documents', param: global.enums.documentType.form106 },
            payroll: { path: 'pages/documents/documents', hash: 'documents', param: global.enums.documentType.paycheck },
            empdocs: { path: 'pages/documents/documents', hash: 'documents', param: global.enums.documentType.employee },
            form101Main: { path: 'pages/forms/form101/form101Main', hash: 'form101Main', nav: true },

            documents: { path: 'pages/documents/documents', hash: 'documents', nav: true },
            homeMobile: { path: 'pages/homeMobile/homeMobile', hash: 'homeMobile', nav: true },
            form101Mobile: { path: 'pages/forms/form101Mobile/form101Mobile', hash: 'form101Mobile', nav: true },
            form106Mobile: { path: 'pages/forms/form106Mobile/form106Mobile', hash: 'form106Mobile', nav: true },
            payrollMobile: { path: 'pages/forms/payrollMobile/payrollMobile', hash: 'payrollMobile', nav: true },
        }

        var vm = {
            logoutProcess: logoutProcess,
            visiblePage: ko.observable(false),
            contentHeight: ko.observable(''),
            headerHeight: ko.observable(),
            footerHeight: ko.observable(''),
            homeMenuPermission: global.enums.permissionCodes.MENU_HOME.code,
            manualEditMenuPermission: global.enums.permissionCodes.MENU_MANUAL_EDIT.code,
            employeesMenuPermission: global.enums.permissionCodes.MENU_EMPLOYEES.code,
            visitorsMenuPermission: global.enums.permissionCodes.MENU_VISITORS.code,
            workScheduleMenuPermission: global.enums.permissionCodes.MENU_WORK_SCHEDULE.code,
            reportsMenuPermission: global.enums.permissionCodes.MENU_REPORTS.code,
            maintenanceMenuPermission: global.enums.permissionCodes.MENU_MAINTENANCE.code,
            mealCouponMenuPermission: global.enums.permissionCodes.MENU_MEAL_COUPON.code,
            documentsMenuPermission: global.enums.permissionCodes.MENU_DOCUMENTS.code,
            headerHiAndName: ko.observable(''),
            headerLogout: ko.observable(''),
            headerDepartment: ko.observable(''),
            headerUserProfile: ko.observable(''),
            visibleCompany: ko.observable(false),
            headerCompanyName: ko.observable(''),
            headerCompanyId: ko.observable(''),
            shouldShowNav: ko.observable(true),
            chbIncludeReplaceMng: ko.observable(false),
            visibleSecondMngSwitch: ko.observable(false),
            captIncludeReplaceMng: ko.observable(captOff),
            router: router,
            menuItems: ko.observableArray(),
            setRouter: setRouter,
            isPortal: ko.observable(false),
            search: function search() {
                app.showMessage('Search not yet implemented...');
            },
            onRouter: onRouter,

            activate: shellPageActivate,
            writeExample: writeMenu,
            global: global,
            visibleProcess: ko.observable(false),
            processText: ko.observable(),
            textProcess: ko.observable(''),
            textPdf: ko.observable(''),
            srcIOExportFile: ko.observable(''),
            srcIOPdfFile: ko.observable(''),
            srcIOExportErrorFile: ko.observable(''),
            srcIOExportFileOnly: ko.observable(''),
            srcIOExportErrorFileOnly: ko.observable(''),
            srcIOExportFileSize: ko.observable(0),
            srcIOExportErrorFileSize: ko.observable(0),
            txtIOExportFile: ko.observable(''),
            txtIOPdfFile: ko.observable(''),
            txtIOExportErrorFile: ko.observable(''),
            IOExportDir: ko.observable('IOExport'),
            fileContentType: ko.observable('text/plain'),
            pdfContentType: ko.observable('application/pdf'),
            mainLogo: ko.observable(''),
            downloadExportFile: downloadExportFile,
            downloadPdfFile   : downloadPdfFile,
            global: global,
            remark: { OK: 'OK', FAILED: 'FAILED' },
            enums: enums,
            configurationManager: configurationManager,
            compositionComplete: compositionComplete,
            helpPath: '',
            isSupportLinkCheck: ko.observable(false),
            isContactSupervisorLinkVisible: ko.observable(false),
            isHelpLinkVisible: ko.observable(false),
            supportLinkURL: ko.observable(''),
            contactSupervisorLinkURL: ko.observable(''),
            helpLinkURLCustomized: ko.observable(''), // by/for Customer, compParam:webHelpFile
            helpLinkURLMain: ko.observable(''), // main help by synel
            islUrl: ko.observable(''),
            saveLayout: saveLayout,
            saveReplacementMng: saveReplacementMng,
            convertPicture: convertPicture,
            showAbout: showAbout,
            isDT: ko.observable(false),
            showAboutText: ko.observable(''),
            logoutClicked: logoutClicked,
            setHeaderDisplayMode: setHeaderDisplayMode,
            isHeaderExpanded: ko.observable(''),
            isLayoutsSave: ko.observable(false), // default declaration
            openNav: function () {
                $("#sidenav").css('width', '250px');
                $("#sidenavBackground").css('width', '100%');
            },
            closeNav: function () {
                $("#sidenav").css('width', '0');
                $("#sidenavBackground").css('width', '0');
            },
            // helpSearch related attributes
            helpCombo: helpCombo,
            isHelpInitialized: false,
            isHelpHebrew: false,
            isHelpClick: false,
            isHelpEventsOrdered: false
        };

        return vm;
    }
    catch (err) {
        global.treatError(err);
    }

    function compositionComplete() {
        try {
            if (global.isMobileApp()) {
                $("#harmonyMenu").css('display', 'none');
            }            

            $(document).click(function (e, h) {
                $("#aboutWebSiteShell").hide();
            });
            $(document).keydown(function (e) {
                if (e.keyCode == 8 && e.target.tagName != 'INPUT' && e.target.tagName != 'TEXTAREA') {
                    e.preventDefault();
                }
            });
            global.displaySpin(false);
        }
        catch (err) {
            global.treatError(err);
            global.displaySpin(false);
        }
    }

    function initHelp() {
        if (!vm.isHelpInitialized) {
            // help input box
            var input = $('input[aria-owns=helpSearch_listbox]');
            // help dropdown result list
            var list = $('#helpSearch-list');

            // events to work only input and list area
            list.on('mousedown', function (e) { vm.isHelpClick = true; });
            input.on('keydown', function (e) {
                // select result if 'Enter' pressed
                if (e.keyCode === 13) {
                    vm.isHelpClick = true;
                }
            });

            input.focusout(function () {
                input.val('');
                vm.helpCombo.clearSelectedItem();
            });

            // places the above keydown event to the first place on keydown events array for input
            // will be initiated only first focus, 
            // in order to make sure that events will be reordered after DOM fully rendered
            input.focus(function () {
                if (!vm.isHelpEventsOrdered) {
                    var inputEventList = $._data(input[0], 'events');
                    inputEventList.keydown.unshift(inputEventList.keydown.pop());
                    vm.isHelpEventsOrdered = true;
                }
            });

            input.addClass('help-search-input');
            input.attr('placeholder', global.dict()[5641]);

            // only one time initialized
            isHelpInitialized = true;
        }
    }

    function shellPageActivate() {
        try {
            cacheManager.set(global.enums.cacheItems.logoutShellEventHasAlreadyBeenCatched, false);
            if (global.explorerType() == global.enums.explorerType.NOTIE) {
                jQuery(function ($) {
                    // /////
                    // CLEARABLE INPUT
                    function tog(v) { return v ? 'addClass' : 'removeClass'; }
                    $(document).on('focusin input', '[type=text]:not([readonly]):not(.timeInput):not(.eye.onEye)', function () {
                        $(this)[tog(this.value)]('x');
                    }).on('mousemove', '.x', function (e) {
                        if ((global.getCurrentDir() == global.enums.directions.LTR && $("#form101Content").length == 0) || ($(this).hasClass("k-input") && $(this).parent().hasClass("k-picker-wrap")))
                            $(this)[tog(this.offsetWidth - 18 < e.clientX - this.getBoundingClientRect().left)]('onX');
                        else
                            $(this)[tog(this.offsetWidth - 18 < this.getBoundingClientRect().right - e.clientX)]('onX');
                    }).on('click', '.onX', function () {
                        $(this).removeClass('x onX').val('').change();
                        $(this).trigger('input');
                    }).on('focusout', 'input[type=text]', function () {
                        $(this).removeClass('x onX');
                    });

                    $(document).on('focusin keyup', 'input[type=password]:not([readonly])', function () {
                        $(this)[tog(this.value)]('eye');
                    }).on('mousemove', '[type=password].eye', function (e) {
                        if ((global.getCurrentDir() == global.enums.directions.LTR && $("#form101Content").length == 0))
                            $(this)[tog(this.offsetWidth - 18 < e.clientX - this.getBoundingClientRect().left)]('onEye');
                        else
                            $(this)[tog(this.offsetWidth - 18 < this.getBoundingClientRect().right - e.clientX)]('onEye');
                    }).on('mousedown', '.onEye', function () {
                        //$(this).removeClass('eye onEye').val('').change();
                        //$(this).trigger('input');
                        var passwordElement = $(this);
                        var newElement = passwordElement.clone();
                        newElement.attr('type', 'text');
                        newElement.removeClass('onEye');
                        passwordElement[0].style.visibility = "hidden";
                        if ($(newElement).hasClass('form101password')) {
                            $(newElement)[0].style.background = 'none';
                            $(newElement)[0].style.padding = '2';
                        }
                        newElement.insertBefore(passwordElement);
                        newElement.mouseout(function () {
                            newElement.remove();
                            passwordElement[0].style.visibility = "visible";
                            passwordElement.focus();
                        });
                        newElement.mouseup(function () {
                            newElement.remove();
                            passwordElement[0].style.visibility = "visible";
                            passwordElement.focus();

                        });

                    }).on('focusout', 'input[type=password]:not([readonly])', function () {
                        $(this).removeClass('eye onEye');
                    });
                });
            }

            //change text of loader
            global.displaySpin(true);
            //app.on(global.enums.events.LOGOUT_SHELL.name).then(function onLogOutShellFunc(message) {
            //    try {
            //        if (cacheManager.get(global.enums.cacheItems.logoutShellEventHasAlreadyBeenCatched) != true) {
            //            cacheManager.set(global.enums.cacheItems.logoutShellEventHasAlreadyBeenCatched, true);
            //            if (window.location.href.indexOf('HTTP_TXTUSERID') > -1) {
            //                //login is from back-office, params are at href.
            //                //reload is by change href, becose must remove the params for prevent re-auto-login.

            //            }
            //            else {
            //                window.location.reload();
            //            }
            //        }
            //    }
            //    catch (err) {
            //        global.treatError(err);
            //    }
            //});  

            // -------------------------------- Help Search Data Retrieval From APi -------------------------------- //
            vm.isHelpHebrew = global.cache.getLanguageHelp(global.cache.get(enums.cacheItems.LAST_LANGUAGE)) === 'https://help.synel.co.il/';
            vm.helpCombo.initialize({ comboId: 'helpSearch', width: '170px' });
            if (vm.isHelpHebrew && !(vm.helpCombo.data()._data.length > 0)) {
                var url = 'http://ppsales.helpdocsonline.com/search/fly_api';
                var query = {
                    action: 'search',
                    type: 'lite',
                    api_key: '4bc56015327077e3184ace7aff9a0d742af2271374db',
                    keyword: ''
                };

                http.jsonp(url, query).done(function(result){
                    for(var i=0; i < result.data.length; i++) {
                        var item = {Code: result.data[i].permalink, Descript: result.data[i].title};
                        vm.helpCombo.data().add(item);                  
                    }                   

                    vm.helpCombo.customSelectionChanged = function (item) {
                        // helpSearch inputbox
                        var el = $('input[aria-owns=helpSearch_listbox]');

                        // when keydown or mousedown on helpSearch elements
                        if (vm.isHelpClick) {
                            window.open('http://help.synel.co.il/' + item.Code);
                            vm.isHelpClick = false;
                        }
                        
                        // clear the input box and result
                        el.val('');
                        el.blur();
                        vm.helpCombo.clearSelectedItem();                  
                    };                      
                }); 
            }
            // ------------------------------------------------------------------------------------------------------ //        

            app.off(global.enums.events.EXPIRE_SESSION.name);
            app.on(global.enums.events.EXPIRE_SESSION.name).then(function (params) {               
                logoutProcess({ logoutReason: params.logoutReason });
            });
            app.on(global.enums.events.FORCED_SESSION_LOGOUT.name).then(forcedLogoutProcess);

            vm.mainLogo(global.cache.get(global.enums.cacheItems.LOGO_MAIN));

            http.post(global.webApiConfig.getApiPath(global.enums.httpPath.CheckUserLogin.path)).done(function checkUserLoginSucceed(response) {
                try {
                    if (response == true) {//events: 2, 3, 7, 5
                        if (!global.isNull(cache.get(cache.enums.cacheItems.USER).Profile)) {//3, 5, 6, 7
                            if (cacheManager.get(global.enums.cacheItems.IsAfterReloadByCode) == true) {//6, 7
                                cacheManager.set(global.enums.cacheItems.IsAfterReloadByCode, false);
                                global.cache.clearSessionStorageWithoutSystemParams();
                                global.logOut(false);
                            }
                            else {//3, 5
                                global.dict(cacheManager.get(cacheItems.DICT));//need take from cache, cache set the resources to behave as Dictionary
                                global.dictMsg(cacheManager.get(cacheItems.DICTMSG));
                                global.res = global.dict();
                                global.resMsg = global.dictMsg();
                                global.helper.startHandleDataTooltip(global.cache.get(cacheItems.TOOLTIPS));
                                initLocalization();
                                app.on(global.enums.events.CALL_PROCESSING.name).then(processing);
                                app.on(global.enums.events.ON_ROUTE.name).then(onRoute);
                                vm.visiblePage(true);
                                if (!global.isMobileApp()) global.displaySpin(false);
                                var lastLang = cache.get(cache.cacheItems.LAST_LANGUAGE);
                                res.addCssAccordingLanguageDirection(lastLang);
                                strHelpUrl = global.getCurrentLangHelpUrl();
                                datacontext.initialMetadataStore();

                                vm.isPortal(configurationManager.getConfigParam(global.enums.configParams.IS_PORTAL));
                                /* set showAbout text with values from companyParam */
                                vm.showAboutText(global.dict()[4861] + ': ' + cacheManager.getCompanyParamByFieldName('Version') + "<br/>" +
                                    cacheManager.getCompanyParamByFieldName('VersionNo') + "<br/>" +
                                    global.dict()[4862] + ': ' + window.VersionCookie);
                                vm.isLayoutsSave(cacheManager.getCompanyParamByFieldName('SaveLayout') == '1');
                                if (!vm.isPortal()) {
                                	$("#aboutWebSiteShell").addClass("aboutWebSiteNotPortal");
                                	vm.showAboutText(vm.showAboutText() + "<br/>" +
                                    "<span class = 'loginAboutSpan'>" + global.dictMsg()[565] + "</span>");
                                }
                                else {
                                	$("#aboutWebSiteShell").addClass("aboutWebSitePortal");
                                }
                                var currentUser = cache.get(cache.enums.cacheItems.USER);

                                var getLookupCountQuery = { EmpNo: currentUser.Id, UserNo: currentUser.Profile.Code };
                                var lookupsCountPromise = global.httpGet(global.enums.httpPath.GetLookupsCount, { query: JSON.stringify(getLookupCountQuery) }).done(function (result) {
                                    global.cache.set(global.enums.cacheItems.LOOKUPS_RECORDS_COUNT, result.LookupsCountList);
                                });

                                var getEmployeeHeaderDataQuery = {
                                    EmpNo: currentUser.Id,
                                    PermGroup: currentUser.Profile.Code
                                };
                                // == for replacement mng WI=21492 / 21682 ==
                                var getReplacementSwitchPromise = global.httpGet(global.enums.httpPath.GetReplacementManagerSwitchEnabled).done(function (result) {
                                    vm.visibleSecondMngSwitch(result.Status == 1);
                                    if (result.Status != 0) {
                                        vm.chbIncludeReplaceMng(result.Message == "1") //1- ON, 0-OFF
                                        if (result.Message == "1")
                                            vm.captIncludeReplaceMng(captOn);
                                    }
                                });

                                var getEmployeeHeaderDataPromise = global.httpGet(global.enums.httpPath.GetEmployeeHeaderData, { query: JSON.stringify(getEmployeeHeaderDataQuery) })
                                    .done(function GetEmployeeHeaderDataSucceed(response) {
                                        try {
                                            var currentUser = cache.get(cache.enums.cacheItems.USER);
                                            var currentCompany = global.cache.get(global.enums.cacheItems.CURCOMP);
                                            currentUser.PatternNo = response.EmployeeHeaderData.PatternNo;
                                            currentUser.empName = response.EmployeeHeaderData.Emp_name;
                                            currentUser.department = { Code: response.EmployeeHeaderData.Department, Descript: response.EmployeeHeaderData.str_Department };
                                            currentUser.station = { Code: response.EmployeeHeaderData.Station, Descript: response.EmployeeHeaderData.str_station };

                                            currentUser.workRule = { Code: response.EmployeeHeaderData.empAgreement, Descript: response.EmployeeHeaderData.str_empAgreement };
                                            currentUser.empGroup = global.getItemByCodeDescript(response.EmployeeHeaderData.empGroup, response.EmployeeHeaderData.str_EmpGroup);
                                            currentUser.empLookupCount = response.EmpLookupRecordsCount;
                                            currentUser.isSecondMng = response.IsSecondMng;
                                            // WI=15070, profile 9998/9999

                                            //currentUser.permGroupType = currentUser.Profile.permGroupType;
                                            if (global.isNullOrEmpty(currentUser.Profile.permGroupType)) {

                                                global.httpGet(global.enums.httpPath.GetPermGroupType).done(function getScalarValueDone(result) {
                                                    if (!global.isNull(result)) {
                                                        currentUser.Profile.permGroupType = parseInt(result.ReturnVal);
                                                    }
                                                });
                                                cache.set(cache.enums.cacheItems.USER, currentUser);
                                            }

                                            cache.set(cache.enums.cacheItems.USER, currentUser);
                                            vm.headerLogout('(' + global.dict()[1320] + ')');
                                            vm.headerHiAndName(response.EmployeeHeaderData.Emp_no + ', ' + response.EmployeeHeaderData.Emp_name);
                                            if (global.isMobileApp()) global.callMobileFunction('SetEmployeeId', response.EmployeeHeaderData.Emp_no + ', ' + response.EmployeeHeaderData.Emp_name);
                                            if (global.isMobileApp()) global.callMobileFunction('SetImageSourceSyHarmony', global.getResponseCompanyOfPortalImagePath(0));
                                            if (global.isMobileApp()) global.callMobileFunction('SetImageSourceCompany', global.cache.get(global.enums.cacheItems.LOGO_MAIN));                                            
                                            vm.headerDepartment(global.dict()[1] + ' : ' + response.EmployeeHeaderData.Department + ', ' + response.EmployeeHeaderData.str_Department);
                                            if (global.isMobileApp()) global.callMobileFunction('SetDepartment', global.dict()[1] + ' : ' + response.EmployeeHeaderData.Department + ', ' + response.EmployeeHeaderData.str_Department);
                                            vm.headerUserProfile(global.dict()[3774] + ' : ' + currentUser.Profile.Code + ', ' + currentUser.Profile.Descript);
                                            if (global.isMobileApp()) global.callMobileFunction('SetUserProfile', global.dict()[3774] + ' : ' + currentUser.Profile.Code + ', ' + currentUser.Profile.Descript);

                                            if (currentCompany.name != "") {
                                                var fullPortalClientName = global.dict()[4406] + ' : [' + currentCompany.id + '] ' + currentCompany.name;
                                                vm.headerCompanyName(fullPortalClientName);
                                                if (global.isMobileApp()) global.callMobileFunction('SetCompanyName', fullPortalClientName);
                                                vm.visibleCompany(true);
                                            }

                                            vm.isSupportLinkCheck(cacheManager.getCompanyParamByFieldName('eHarmSupportLinkCheck') == '1');
                                            vm.isContactSupervisorLinkVisible(!global.isNullOrEmpty(cacheManager.getCompanyParamByFieldName('SupervisorEmail')));
                                            if (vm.isSupportLinkCheck() == true) {
                                                vm.supportLinkURL(cacheManager.getCompanyParamByFieldName('eHarmSupportLinkURL'));
                                            }
                                            if (vm.isContactSupervisorLinkVisible() == true) {
                                                vm.contactSupervisorLinkURL("mailto:" + encodeURIComponent(cacheManager.getCompanyParamByFieldName('SupervisorEmail')));
                                            }
                                            vm.helpPath = configurationManager.getConfigParam(global.enums.configParams.HELP_PATH);
                                            if (cacheManager.getCompanyParamByFieldName('webHelpFile') != null && cacheManager.getCompanyParamByFieldName('webHelpFile') != '') {
                                                vm.helpLinkURLCustomized(((global.webApiConfig.port.lastIndexOf('/') == global.webApiConfig.port.length - 1) ? global.webApiConfig.port : global.webApiConfig.port + '/') + vm.helpPath + cacheManager.getCompanyParamByFieldName('webHelpFile'));
                                                vm.isHelpLinkVisible(true);
                                            }
                                            vm.islUrl(configurationManager.getConfigParam(global.enums.configParams.ISL_DOWNLOAD_URL));
                                            if (response.EmployeeHeaderData.StartScreen != null)
                                                defaultPage = response.EmployeeHeaderData.StartScreen;

                                            // should be initialized only after login, requires DOM and resoursec to be initialized
                                            if (vm.isHelpHebrew) 
                                                initHelp();
                                        }
                                        catch (err) {
                                            global.treatError(err);
                                        }
                                    });

                                $.when(lookupsCountPromise, getEmployeeHeaderDataPromise, getReplacementSwitchPromise).done(function setRouterAfterLoadData() {
                                    global.isPerformenceImmedientLogin(false);
                                    return setRouter();
                                });
                            }
                        }
                        else {//2
                            cacheManager.set(global.enums.cacheItems.IsAfterReloadByCode, false)
                            global.logOut(false);
                        }
                    }
                    else {//1, 4
                        cacheManager.set(global.enums.cacheItems.IsAfterReloadByCode, false)
                        initializeSystemData().done(function handleInitilizeSystemDataAndGetLanguagesResponse(initializeSystemDataResponse) {
                            try {
                                //17/02/2019, WI=26761: prevent saving into SessionStorage ElementInformation.Source = [path to web.config]
                                delete initializeSystemDataResponse.GlobalParams.ElementInformation;
                                delete initializeSystemDataResponse.Language.ElementInformation;
                                delete initializeSystemDataResponse.Billing.ElementInformation;

                                cacheManager.set(cacheItems.CUSTOM_CONFIG, {
                                    Language: initializeSystemDataResponse.Language,
                                    GlobalParams: initializeSystemDataResponse.GlobalParams,
                                    ExpiryTime: initializeSystemDataResponse.ExpiryTime,
                                    SaveLayout: initializeSystemDataResponse.SaveLayout,
                                    Billing: initializeSystemDataResponse.Billing,
                                    eHarmonyDocsPath: initializeSystemDataResponse.EHarmonyDocsPath, // save encoded to sessionStorage, for F12
                                    harmonySrvLogPath: initializeSystemDataResponse.SrvLogPath
                                    /* -- DON't DELETE : commented >> 17/02/2019, WI=26761: prevent saving path into SessionStorage
                                    harmonySrvLogPath: decodeURIComponent(escape(atob(initializeSystemDataResponse.SrvLogPath))),
                                    eHarmonyDocsPath: decodeURIComponent(escape(atob(initializeSystemDataResponse.EHarmonyDocsPath)))
                                    */
                                });
                                var responseCompOfPortal = configurationManager.getConfigParam(global.enums.configParams.RESPONSE_COMP_OF_PORTAL);
                                vm.isDT(responseCompOfPortal == enums.responseCompanyOfPortal.DT.id || responseCompOfPortal == enums.responseCompanyOfPortal.DT.name);
                                $(".dynamicIcons").attr("href", (vm.isDT() ? global.imagesManager.favicon : global.imagesManager.harmony));//change icon in Index.cshtml <head> tag by config: DT / Synel
                                cacheManager.set(cacheItems.DATE_FORMAT, initializeSystemDataResponse.DateFormat);
                                cacheManager.set(cacheItems.DATE_FORMAT_YYYYMM, initializeSystemDataResponse.DateFormat_YYYYMM); // 02.01.2018 lyn
                                cacheManager.set(cacheItems.DATE_WITHOUT_YEAR_FORMAT, initializeSystemDataResponse.DateWithoutYearFormat);
                                cacheManager.set(cacheItems.CURRENCY_SYMBOL, initializeSystemDataResponse.CurrencySymbol);
                                global.logOut(true);
                            }
                            catch (err) {
                                err.logOut = true;
                                global.treatError(err);
                            }
                        });

                    }
                    // please note, 
                    // that IE11 now returns undefined again for window.chrome
                    // and new Opera 30 outputs true for window.chrome
                    // but needs to check if window.opr is not undefined
                    // and new IE Edge outputs to true now for window.chrome
                    // and if not iOS Chrome check
                    // so use the below updated condition
                    var isChromium = window.chrome;
                    var winNav = window.navigator;
                    var vendorName = winNav.vendor;
                    var isOpera = typeof window.opr !== "undefined";
                    var isIEedge = winNav.userAgent.indexOf("Edge") > -1;
                    var isIOSChrome = winNav.userAgent.match("CriOS");
                    var languageId = cache.get(cache.cacheItems.LAST_LANGUAGE);
                    if (
                        isChromium !== null &&
                        typeof isChromium !== "undefined" &&
                        vendorName === "Google Inc." &&
                        isOpera === false &&
                        isIEedge === false &&
                        languageId === 3
                    ) {
                        setTimeout(function () {
                            var listItems = $("#harmonyMenu li");
                            listItems.each(function (idx, li) {
                                var listLink = $(li).find('a');
                                if (!global.isNullOrEmpty(listLink.width()) && /chrom(e|ium)/.test(navigator.userAgent.toLowerCase())) {
                                    listLink.css("right", -1 * ($(li).width() - listLink.width()) + "px");
                                }
                            });
                        }, 1000);
                    }
                    
                }
                catch (err) {
                    global.treatError(err);
                    vm.visiblePage(true);
                    global.displaySpin(false);
                }
            });

        }
        catch (err) {
            global.treatError(err);
            vm.visiblePage(true);
            global.displaySpin(false);
        }
        //}
    }
    function initializeSystemData() {
        return global.httpGet(global.enums.httpPath.InitializeSystem);
    }
    function showAbout(s, e) {
        $('#aboutWebSiteShell').show();
        e.stopPropagation();
    }

    function setRouter() {
        setSelectedMenu(window.location.hash);
        //need to keep isLayoutSave property value on reload page
        if (window.location.hash != '') {
            global.changeIsLayoutSaveProp();
        }
        //in the first time 
        if (!isRouterActivated) {
            var routerMap = [];

            if (!global.isNull(global.cache.get(global.cache.enums.cacheItems.SESSION_ID))) {
                routerMap.push({ route: 'login', moduleId: routingPaths['login'].path, nav: true });
                routerMap.push({ route: 'employees(/:parm)', moduleId: routingPaths['employees'].path, nav: true });
                routerMap.push({ route: 'attendance(/:parm)', moduleId: routingPaths['attendance'].path, nav: true, title: 'attendance', hash:"#attendance" });
                routerMap.push({ route: 'home(/:parm)', moduleId: routingPaths['home'].path, nav: true, title: 'home' });
                routerMap.push({ route: 'reports(/:parm)', moduleId: routingPaths['reports'].path, nav: true, title: 'reports' });
                routerMap.push({ route: 'maintenanceOrg', moduleId: routingPaths['maintenanceorg'].path, nav: true });
                routerMap.push({ route: 'iosalaryexport', moduleId: routingPaths['iosalaryexport'].path, nav: true });
                routerMap.push({ route: 'maintenance(/:view)', moduleId: routingPaths['maintenance'].path, nav: true, hash: '#maintenance' });
                routerMap.push({ route: 'workSchedule(/:parm)', moduleId: routingPaths['workschedule'].path, nav: true, title: 'workSchedule' });
                routerMap.push({ route: 'form101/:context1', moduleId: 'views/forms/form101/form101', nav: true, hash: '#form101' });
                routerMap.push({ route: 'form101Main', moduleId: 'pages/forms/form101/form101Main', nav: true });
                routerMap.push({ route: 'empDocs', moduleId: 'views/forms/EmpDocuments/EmpAbsDoc', nav: true, hash: '#empDocs' });
                routerMap.push({ route: 'documents(/:parm)(/:docType)', moduleId: routingPaths['documents'].path, nav: true, hash: '#documents' });
                routerMap.push({ route: 'homeMobile', moduleId: routingPaths['homeMobile'].path, nav: true, hash: '#homeMobile' });
                routerMap.push({ route: 'form101Mobile', moduleId: routingPaths['form101Mobile'].path, nav: true, hash: '#form101Mobile' });
                routerMap.push({ route: 'form106Mobile', moduleId: routingPaths['form106Mobile'].path, nav: true, hash: '#form106Mobile' });
                routerMap.push({ route: 'payrollMobile', moduleId: routingPaths['payrollMobile'].path, nav: true, hash: '#payrollMobile' });
            }

            isRouterActivated = true;
            if (defaultPage.toLowerCase() == 'form101' && global.cache.getCompanyParamByFieldName("isElectronicForm101") != 1)
                defaultPage = 'home';
            if (!global.isNOE(defaultPage))
                defaultPage = defaultPage.toLowerCase()
            else
                defaultPage = 'home';   //default first page

            // Mobile home page
            if (global.isMobileApp())
                defaultPage = 'homeMobile';
            
            if (window.location.hash == '')  //first page after login - need to color menu
                setSelectedMenu('#' + routingPaths[defaultPage].hash);
            router.on('router:navigation:complete', function composfinished(child, parent, context) {
                var path = window.location.pathname + window.location.hash;
                var title = parent.fragment;
                gaTrack(path, title);
            });
            return router.map(routerMap).buildNavigationModel()
               .mapUnknownRoutes(routingPaths[defaultPage].path, routingPaths[defaultPage].hash + (global.isNOE(routingPaths[defaultPage].param) ? '' : ('/' + routingPaths[defaultPage].param))).activate();
        }
    }

    //no use
    function setRoute(item) {
        if (item.HasChilds) {
            $.each(item.ChildMenuItems, function (key, child) {
                setRoute(child)
            });
        }
        else {
            var moduleId = 'pages/' + item.Url + '/' + item.Url;
            routerMap.push({ route: item.Url, title: item.Name, moduleId: moduleId, nav: true });
        }
    }

    function writeMenu(items) {
        var html = '';
        if (items().length > 0) {
            $.each(items._latestValue, function (key, item) {
                //add li item for menuItem
                html = html + formatItem(item);
            });
        }
        return html;
    }

    function formatItem(item) {

        var html = '';
        var href = '#' + item.Url;
        var text = item.Name;
        if (href == '#') {
            text = text;// + 'raquo;';
        }
        if (item.Url == '') //node with childs - the node has no ref to page
            html = html + "<li><a>" + text + "</a>";
        else
            html = html + "<li><a href=" + href + ">" + text + "</a>";
        var childs = item.ChildMenuItems;
        if (childs) {
            html = html + "<ul>";
            $.each(childs, function (key, child) {
                html = html + formatItem(child);
            });
            html = html + "</ul>";
        }
        html = html + "</li>";
        return html;
    }

    function clearTextProcess() {
        if (isTextProcessHasMesssage) {
            vm.textProcess("");
            vm.visibleProcess(false);
            isTextProcessHasMesssage = false;
        }
    }

    function onRouter(sender, e, etc) {
        if (e.currentTarget.hash == '#maintenance') {
            global.app.trigger('maintenanceClicked');
        }
        onRoute(e.currentTarget.hash)
        return true;
    }

    function onRoute(newNav) {
        clearTextProcess();
        global.stopQueuesTimer();
        global.SetQueuesInterval(null);
        if (global.GetInterfaceFlag() == 0) IO_interfaces_ClearStatus();
        //must need the "if"!!
        //checking if clicked on menu of the current page - so reload the page
        //(otherwise , the href is loading the page[and not all the browser page])


        if (newNav == window.location.hash) {
            window.location.reload();
        }

        //remove old-hash background
        if (window.location.hash.indexOf('/') > -1) {
            var slashLocation = window.location.hash.indexOf('/');
            var netoHash = window.location.hash.substring(0, slashLocation);
            $(netoHash).removeClass("backBlack");
        }
        else
            $(window.location.hash).removeClass("backBlack");
        setSelectedMenu(newNav);
    }

    function setSelectedMenu(newNav) {
        if (newNav == '#/') {
            newNav = '';
        }
        /* =====================================================================================
         * NOTE !!! : main help site for diff lang should be added with API key into INDEX.CSHTML
         * <script type="text/javascript" src="http://help.synel.co.il/remote_auth/kxxw20flzks3s0mjw9bv5jbqery9lxe7"></script> 
        ==========================================================================*/
        if (global.isNullOrEmpty(strHelpUrl)) {
            $('#lnkHelpMain').hide();
        }
        var menuItemHelp = '';
        var strHelpUrlDisplay = '';
        //add background to the new hash
        if (newNav.indexOf('/') > -1) {
            var slashLocation = newNav.indexOf('/');
            var netoHash = newNav.substring(0, slashLocation);
            $(netoHash).addClass("backBlack");
            menuItemHelp = netoHash.slice(1, netoHash.length);
        }
        else {
            $(newNav).addClass("backBlack");
            menuItemHelp = newNav.slice(1, newNav.length);
            getHeaderDisplayMode(newNav);
        }
        if (menuItemHelp.length != 0)
            strHelpUrlDisplay = strHelpUrl + menuItemHelp;

        vm.helpLinkURLMain(strHelpUrlDisplay);

    }

    function setHeaderDisplayMode() {
        vm.isHeaderExpanded = !vm.isHeaderExpanded;
        cacheManager.set(cacheManager.cacheItems.HEADER_DISPLAY_MODE, vm.isHeaderExpanded);
        changeHeaderDisplayMode();
    }
    function getHeaderDisplayMode(netoHash) {
        if (netoHash == '#home') {
            $("#hide_expand_header").css('display', 'none');
            vm.isHeaderExpanded = true;
        }
        else if (!cacheManager.isExistKey(cacheItems.HEADER_DISPLAY_MODE)) {
            vm.isHeaderExpanded = false;
            $("#hide_expand_header").css('display', '');
        }
        else {
            vm.isHeaderExpanded = cacheManager.get(cacheItems.HEADER_DISPLAY_MODE);
            $("#hide_expand_header").css('display', '');
        }
        changeHeaderDisplayMode();
    }
    function changeHeaderDisplayMode() {
        if (vm.isHeaderExpanded) { //expand header
            document.getElementById("hide_expand_header").innerHTML = global.res[2929];
            $("#blue_header_1").css('height', '80%').css('display', '');
            $("#blue_header_2").css('height', '20%');
            $(".headerHeight-shell").css('height', '15%');
            $(".contentHeight-shell").css('height', 'calc(85% - 2.2rem)');
            $("#header_2_profileDetails").css('display', 'none');
        }
        else { //hide header
            $("#blue_header_1").css('height', '0%').css('display', 'none');
            $("#blue_header_2").css('height', '100%');
            $(".headerHeight-shell").css('height', '3%');
            $(".contentHeight-shell").css('height', 'calc(97% - 2.2rem)');
            $("#header_2_profileDetails").css('display', '');
            document.getElementById("hide_expand_header").innerHTML = global.res[5330];
        }
    }


    function clearMetadataStore() {
        var dataContext = require('data/datacontext');
        dataContext.clearMetadataStore();
    }

    //method is called on cases:
    //1. button logout is clicked
    //2. event ExpireSession occurs
    function logoutProcess(logoutReason) {
        var info = "logout from system";
        var externalLogoutLink = global.cache.getCompanyPreferenceByName(global.enums.companyPreferencesNames.LogOutExternalLink);
        if (!global.isNullOrEmptyOrSpacesOnly(externalLogoutLink)) {
            return global.helper.removeSession().done(function navigateToExternalLink() {
                global.stopTimer();
                datacontext.clearMetadataStore();
                cacheManager.set(cacheManager.cacheItems.USER, null);
                cacheManager.set(cacheManager.cacheItems.LOOKUPS, {});
                global.cache.set(global.enums.cacheItems.CURCOMP, null);
                window.location.href = externalLogoutLink;
                info += " to: " + externalLogoutLink;
                global.httpPost(global.enums.httpPath.WriteInfoToLog, { Info: info });
            });
        }
        //write to log
        global.httpPost(global.enums.httpPath.WriteInfoToLog, { Info: info });
        router.navigate('', false); //clear navigation url path
        cacheManager.set(global.enums.cacheItems.NEED_RETRIVE_COMPANY_DATA_AGAIN, true);
        global.logoutFromSystem();

        //update LoginsHistory db table
        var data = {
            Session_ID: global.cache.get(global.cache.enums.cacheItems.SESSION_ID),
            Application_Name: "eHarmony",
            Action: global.isNOE(logoutReason) ? "LOGOUT" : "TIMEOUT",
            Action_Status: 0,
            Action_Status_Reason: "",
            Emp_no: cache.get(cache.enums.cacheItems.USER).Id,
            HostName: "",
            LoginBy_Type: "",
            LoginBy_Value: "",         
            LanguageId: cache.get(cache.cacheItems.LAST_LANGUAGE),
            CompanyId: "",
            CompanyDB: ""
        };
        global.httpPost(global.enums.httpPath.UpdateLoginsHistory, data);

    }
    // !!!method is called on cases when CacheManager.GetCurrentSession() had custom exception
    // same as the upper one - without logging since there is no session in server-thread.
    function forcedLogoutProcess() {
        // error might be thrown several times, so we limit with first one only
        if (isFirstForcedLogout) {
            // it is the same as in shell.js without post-logging and all codes that do server-requests
            global.stopTimer();
            datacontext.clearMetadataStore();
            cacheManager.set(cacheManager.cacheItems.USER, null);
            cacheManager.set(cacheManager.cacheItems.LOOKUPS, {});
            global.cache.set(global.enums.cacheItems.CURCOMP, null);
            router.navigate('', false); //clear navigation url path
            cacheManager.set(global.enums.cacheItems.NEED_RETRIVE_COMPANY_DATA_AGAIN, true);
            global.logoutFromSystem();
            isFirstForcedLogout = false;
        }
    }

    function logoutClicked() {
        if (global.isMobile()) global.callMobileFunction('HidePdfBtn');        
        global.cache.set(global.enums.cacheItems.LOGOUT_HAS_OCCURED, '2');
        //in case security cookie by rememberMe checkbox - need to remove cookie in server
        if (cacheManager.getCompanyParamByFieldName('isRememberMe') == '1' && cacheManager.getCompanyParamByFieldName("ADS_Mode") != '2')//not ADS_Mode && has rememberMe checkbox
        {
            global.httpPost(global.enums.httpPath.RemoveSecurityCookie).done(function afterRemovedSecurityCookie() { logoutProcess(""); });
        }
        else
            logoutProcess("");
    }
    //#region init Localization

    function initLocalization() {

        /*
           * Kendo UI Localization Project for v2012.3.1114 
           * Copyright 2012 Telerik AD. All rights reserved.
           * 
           * English US (en-US) Language Pack
           *
           * Project home  : https://github.com/loudenvier/kendo-global
           * Kendo UI home : http://kendoui.com
           * Author        : Felipe Machado (Loudenvier) 
           *                 http://feliperochamachado.com.br/index_en.html
           *
           * This project is released to the public domain, although one must abide to the 
           * licensing terms set forth by Telerik to use Kendo UI, as shown bellow.
           *
           * Telerik's original licensing terms:
           * -----------------------------------
           * Kendo UI Web commercial licenses may be obtained at
           * https://www.kendoui.com/purchase/license-agreement/kendo-ui-web-commercial.aspx
           * If you do not own a commercial license, this file shall be governed by the
           * GNU General Public License (GPL) version 3.
           * For GPL requirements, please review: http://www.gnu.org/copyleft/gpl.html
           */

        //  kendo.ui.Locale = "English US (en-US)";
        kendo.ui.ColumnMenu.prototype.options.messages =
          $.extend(kendo.ui.ColumnMenu.prototype.options.messages, {

              /* COLUMN MENU MESSAGES 
               ****************************************************************************/
              sortAscending: res.getValueByKey('4440'),
              sortDescending: res.getValueByKey('4441'),
              filter: res.getValueByKey('4442'),
              columns: res.getValueByKey('3623')
              /***************************************************************************/
          });

        kendo.ui.Groupable.prototype.options.messages =
          $.extend(kendo.ui.Groupable.prototype.options.messages, {

              /* GRID GROUP PANEL MESSAGES 
               ****************************************************************************/
              empty: res.getValueByKey('4468')
              /***************************************************************************/
          });
        kendo.ui.Grid.prototype.options.messages.commands = $.extend(kendo.ui.Grid.prototype.options.messages.commands, {
            update: res.getValueByKey('294'),
            canceledit: res.getValueByKey('303')
        });
        kendo.ui.FilterMenu.prototype.options.messages =
          $.extend(kendo.ui.FilterMenu.prototype.options.messages, {

              /* FILTER MENU MESSAGES 
               ***************************************************************************/
              info: res.getValueByKey('4445'), // sets the text on top of the filter menu
              isTrue: res.getValueByKey('4472'),                   // sets the text for "isTrue" radio button
              isFalse: res.getValueByKey('4473'),                 // sets the text for "isFalse" radio button
              filter: res.getValueByKey('297'),   // sets the text for the "Filter" button
              clear: res.getValueByKey('2024'),        // sets the text for the "Clear" button
              and: res.getValueByKey('4443'),
              or: res.getValueByKey('4444'),
              selectValue: res.getValueByKey('959')
              /***************************************************************************/
          });

        kendo.ui.FilterMenu.prototype.options.operators =
          $.extend(kendo.ui.FilterMenu.prototype.options.operators, {

              /* FILTER MENU OPERATORS (for each supported data type) 
               ****************************************************************************/
              string: {
                  eq: res.getValueByKey('4447'),
                  neq: res.getValueByKey('4448'),
                  startswith: res.getValueByKey('4446'),
                  contains: res.getValueByKey('4449'),
                  doesnotcontain: res.getValueByKey('4450'),
                  endswith: res.getValueByKey('4451')
              },
              number: {
                  eq: res.getValueByKey('4447'),
                  neq: res.getValueByKey('4448'),
                  gte: res.getValueByKey('4453'),
                  gt: res.getValueByKey('4454'),
                  lte: res.getValueByKey('4455'),
                  lt: res.getValueByKey('4456')
              },
              date: {
                  eq: res.getValueByKey('4447'),
                  neq: res.getValueByKey('4448'),
                  gte: res.getValueByKey('4457'),
                  gt: res.getValueByKey('4458'),
                  lte: res.getValueByKey('4459'),
                  lt: res.getValueByKey('4460'),
              },
              enums: {
                  eq: res.getValueByKey('4447'),
                  neq: res.getValueByKey('4448'),
              }
              /***************************************************************************/
          });

        kendo.ui.Pager.prototype.options.messages =
          $.extend(kendo.ui.Pager.prototype.options.messages, {

              /* PAGER MESSAGES 
               ****************************************************************************/
              display: "{0} - {1} " + res.getValueByKey('1744') + " {2} " + res.getValueByKey('298'),
              empty: res.getValueByKey('4452'),
              page: "", //res.getValueByKey('471'),
              //of: "", //res.getValueByKey('1744') + " {0}",
              of: res.getValueByKey('1744') + " {0} " + res.getValueByKey('1078'), //alexa, 25/11/2014
              itemsPerPage: res.getValueByKey('1391') + ".",//res.getValueByKey('3232'),
              first: res.getValueByKey('1073'),
              previous: res.getValueByKey('1112'),
              next: res.getValueByKey('1075'),
              last: res.getValueByKey('1076'),
              //refresh: "Refresh"
              /***************************************************************************/
          });

        kendo.ui.Validator.prototype.options.messages =
         $.extend(kendo.ui.Validator.prototype.options.messages, {

             /* VALIDATOR MESSAGES 
              ****************************************************************************/
             required: replaceResXXX(res.getMessageByKey('349')),//4461
             pattern: replaceResXXX(res.getMessageByKey('350')),
             min: replaceResXXX(res.getMessageByKey('351')),
             max: replaceResXXX(res.getMessageByKey('352')),
             email: replaceResXXX(res.getMessageByKey('353')),
             url: replaceResXXX(res.getMessageByKey('354')),
             date: replaceResXXX(res.getMessageByKey('404'))
             /***************************************************************************/
         });

        kendo.cultures.current.calendars.standard.days.names[0] = global.dict()[671];
        kendo.cultures.current.calendars.standard.days.names[1] = global.dict()[672];
        kendo.cultures.current.calendars.standard.days.names[2] = global.dict()[673];
        kendo.cultures.current.calendars.standard.days.names[3] = global.dict()[674];
        kendo.cultures.current.calendars.standard.days.names[4] = global.dict()[675];
        kendo.cultures.current.calendars.standard.days.names[5] = global.dict()[676];
        kendo.cultures.current.calendars.standard.days.names[6] = global.dict()[677];

        kendo.cultures.current.calendars.standard.days.namesAbbr[0] = global.dict()[3048];
        kendo.cultures.current.calendars.standard.days.namesAbbr[1] = global.dict()[3049];
        kendo.cultures.current.calendars.standard.days.namesAbbr[2] = global.dict()[3050];
        kendo.cultures.current.calendars.standard.days.namesAbbr[3] = global.dict()[3051];
        kendo.cultures.current.calendars.standard.days.namesAbbr[4] = global.dict()[3052];
        kendo.cultures.current.calendars.standard.days.namesAbbr[5] = global.dict()[3053];
        kendo.cultures.current.calendars.standard.days.namesAbbr[6] = global.dict()[3054];

        kendo.cultures.current.calendars.standard.days.namesShort[0] = global.dict()[3048];
        kendo.cultures.current.calendars.standard.days.namesShort[1] = global.dict()[3049];
        kendo.cultures.current.calendars.standard.days.namesShort[2] = global.dict()[3050];
        kendo.cultures.current.calendars.standard.days.namesShort[3] = global.dict()[3051];
        kendo.cultures.current.calendars.standard.days.namesShort[4] = global.dict()[3052];
        kendo.cultures.current.calendars.standard.days.namesShort[5] = global.dict()[3053];
        kendo.cultures.current.calendars.standard.days.namesShort[6] = global.dict()[3054];

        kendo.cultures.current.calendars.standard.months.names[0] = global.dict()[4478];
        kendo.cultures.current.calendars.standard.months.names[1] = global.dict()[4479];
        kendo.cultures.current.calendars.standard.months.names[2] = global.dict()[4480];
        kendo.cultures.current.calendars.standard.months.names[3] = global.dict()[4481];
        kendo.cultures.current.calendars.standard.months.names[4] = global.dict()[4482];
        kendo.cultures.current.calendars.standard.months.names[5] = global.dict()[4483];
        kendo.cultures.current.calendars.standard.months.names[6] = global.dict()[4484];
        kendo.cultures.current.calendars.standard.months.names[7] = global.dict()[4485];
        kendo.cultures.current.calendars.standard.months.names[8] = global.dict()[4486];
        kendo.cultures.current.calendars.standard.months.names[9] = global.dict()[4487];
        kendo.cultures.current.calendars.standard.months.names[10] = global.dict()[4488];
        kendo.cultures.current.calendars.standard.months.names[11] = global.dict()[4489];

        kendo.cultures.current.calendars.standard.months.namesAbbr[0] = global.dict()[4505];
        kendo.cultures.current.calendars.standard.months.namesAbbr[1] = global.dict()[4506];
        kendo.cultures.current.calendars.standard.months.namesAbbr[2] = global.dict()[4507];
        kendo.cultures.current.calendars.standard.months.namesAbbr[3] = global.dict()[4508];
        kendo.cultures.current.calendars.standard.months.namesAbbr[4] = global.dict()[4509];
        kendo.cultures.current.calendars.standard.months.namesAbbr[5] = global.dict()[4510];
        kendo.cultures.current.calendars.standard.months.namesAbbr[6] = global.dict()[4511];
        kendo.cultures.current.calendars.standard.months.namesAbbr[7] = global.dict()[4512];
        kendo.cultures.current.calendars.standard.months.namesAbbr[8] = global.dict()[4513];
        kendo.cultures.current.calendars.standard.months.namesAbbr[9] = global.dict()[4514];
        kendo.cultures.current.calendars.standard.months.namesAbbr[10] = global.dict()[4515];
        kendo.cultures.current.calendars.standard.months.namesAbbr[11] = global.dict()[4516];
    }

    function replaceResXXX(resOld) {
        if (!global.isNullOrEmpty(resOld)) {
            var resNew = resOld.replace("XXX", "{0}");
            return resNew.replace("XXX", "{1}");
        }
        return '';
    }

    //#endregion

    //#region local Process
    var interval;
    var idNum;
    var processingInterval;
    var processNo;
    var maintenanceInterval;
    var globalUpdateInterval;
    var processingEventName;
    var interfacesInterval;
    var interfaceNameField;
    var interfaceType;
    var InitFlag;

    //#endregion

    //#region Call Processing before
    function processing(params) {
        try {
            //   app.off(global.enums.events.CALL_PROCESSING.name);
            if (!global.isNull(params)) {

                processingEventName = params.EventName;

                switch (params.ProcessType) {
                    case global.enums.processType.MNG_APPR_CHILD:
                        var numerators = params.Numerators;
                        var url = params.Url;
                        return global.httpPost(url, numerators)
                                  .then(InitProcessingLog);

                    case global.enums.processType.MAINTENANCE:
                        //call processing
                        var command = params.Command;
                        var url = params.Url;
                        processNo = params.Command.ProcessNo;
                        return global.httpPost(url, command)
                                  .then(InitMaintenanceProcessingTimer);

                    case global.enums.processType.IO_SALARY_EXPORT:
                        vm.visibleProcess(true);
                        processStatusTag = global.dict()[4242] + " <B>" + params.ExportNo + " " + params.ExportName + "</B> ";
                        vm.srcIOExportFileOnly('');
                        vm.txtIOExportFile('');
                        vm.txtIOPdfFile('');
                        vm.srcIOExportErrorFileOnly('');
                        vm.textProcess(processStatusTag);
                        break;

                    case global.enums.processType.IO_SALARY_EXPORT_FINISH:
                        var resultIO = params.Result;
                        vm.srcIOExportFileOnly('');
                        vm.txtIOExportFile('');
                        vm.txtIOPdfFile('');
                        vm.srcIOExportErrorFileOnly('');
                        maintenanceIOExportFinished(resultIO);
                        break;

                    case global.enums.processType.IO_INTERFACES_FINISH:
                        vm.visibleProcess(true);
                        var resultIO1 = params.Result;
                        IO_interfaces_Finished(resultIO1);
                        break;
                    case global.enums.processType.IO_INPUT_START:
                        InitFlag = 1;
                        IO_interfaces_ClearStatus();
                        var command = params.Command;
                        var url = params.Url;
                        exportNo = params.Command.ExportNo;
                        processNo = params.Command.ProcessID;
                        interfaceNameField = params.Command.InterfaceName;
                        interfaceType = "I";
                        vm.textProcess(params.Command.InterfaceName);
                        vm.visibleProcess(true);
                        return global.httpPost(url, command)
                                  .then(InitInterfacesTimer);
                        break;
                    case global.enums.processType.IO_INPUT_FINISH:
                        InitFlag = 0;
                        clearTimeout(interfacesInterval);
                        IO_interfaces_ClearStatus();
                        var command = params.Command;
                        var url = params.Url;
                        exportNo = params.Command.ExportNo;
                        processNo = params.Command.ProcessID;
                        interfaceNameField = params.Command.InterfaceName;
                        interfaceType = "I";
                        vm.textProcess(params.Command.InterfaceName);
                        vm.visibleProcess(true);
                        IO_interfaces_Finished(params);
                        break;
                    case global.enums.processType.IO_OUTPUT_START:
                        InitFlag = 1;
                        IO_interfaces_ClearStatus();
                        var command = params.Command;
                        var url = params.Url;
                        exportNo = params.Command.ExportNo;
                        processNo = params.Command.ProcessID;
                        interfaceNameField = params.Command.InterfaceName;
                        interfaceType = "O";
                        vm.textProcess(params.Command.InterfaceName);
                        vm.visibleProcess(true);
                        return global.httpPost(url, command)
                                  .then(InitInterfacesTimer);
                        break;
                    case global.enums.processType.IO_BACKUP_INTERFACE_START:
                        InitFlag = 1;
                        IO_interfaces_ClearStatus();
                        var command = params.Command;
                        var url = params.Url;
                        exportNo = params.Command.ExportNo;
                        processNo = params.Command.ProcessID;
                        interfaceNameField = params.Command.InterfaceName;
                        interfaceType = "O";
                        vm.textProcess(params.Command.InterfaceName);
                        vm.visibleProcess(true);
                        return global.httpPost(url, command)
                                  .then(InitInterfacesTimer);
                        break;
                    case global.enums.processType.IO_BACKUP_INTERFACE_FINISH:
                        vm.visibleProcess(true);
                        var resultIO1 = params.Result;
                        IO_backup_interfaces_Finished(resultIO1);
                        break;
                    case global.enums.processType.NOTIFIER_RUNNOW_FINISH: // notificetion after finishing Notifier RunNow few events
                        vm.visibleProcess(true);
                        Notifier_runNow_Finished(params.Result);
                        break;
                    case global.enums.processType.PWD_SENTINIT_FINISH: // notificetion after finishing Notifier RunNow few events
                        vm.visibleProcess(true);
                        Pwd_SentInit_Finished(params.Result);
                        break;
                	case global.enums.processType.JOB_AUTOMATION_RUNNOW_FINISH: // notificetion after finishing Notifier RunNow few automation reports
                		vm.visibleProcess(true);
                		JobAutomation_runNow_Finished(params.Result, params.JobDesc); //maybe need to change
                		break;
                    case global.enums.processType.HRPROC_SENTACTIVITYMSG_FINISH: // notification after finishing Notifier sent HR Processing activity mail/sms
                        vm.visibleProcess(true);
                        HRProc_SentActivityMsg_Finished(params.Result);
                        break;
                    case global.enums.processType.PERIOD_BUDGET_UPDATE_PROCESS:
                        var url = params.Url;
                    case global.enums.processType.ATTENDANCE_SEND2QUEUE:
                        var url = params.Url;
                        return global.httpPost(url, params.Command);
                        break;
                    case global.enums.processType.GLOBAL_UPDATE:
                    case global.enums.processType.ATTENDANCE:
                    case global.enums.processType.ATTENDANCE_DELETE:
                    case global.enums.processType.PERIOD_PROCESS: // 05/12/2017, for Update PeriodBudget
                        var url = params.Url;
                        if (!(params.NotDisplaySpin == true)) {
                            global.displaySpin(true);//new request, bug 11173, displaying spin always when process runs
                        }
                        var command = params.Command;
                        return global.httpPost(url, command).then(function CheckGlobalUpdateEnded(result) {
                            command.IdNum = result.IdNum;
                            setCheckProcessEndedInterval(command, params.EndEventParams, params.Text);
                        }).fail(function () {
                            try {
                                if (!global.isNull(params.EndEventParams)) {//response.IsEnded && 
                                    global.app.trigger(params.EndEventParams.Event.name, params.EndEventParams);
                                }
                            }
                            catch (err) {
                                global.treatError(err);
                            }
                        });

                    default:
                        break;
                }
            }
        }
        catch (err) {
            global.treatError(err);
        }

    }
    //#endregion

    //#region MNG_APPR_CHILD

    //#region Call Processing log
    function LogProcessPortal() {
        vm.visibleProcess(true);
        global.httpGet(global.enums.httpPath.GetLogProcess, { idNum: idNum })
              .then(IntervalProcess);
    }
    //#endregion

    //#region Processing result
    function IntervalProcess(result) {
        idNum = result.idNum;
        vm.textProcess(result.remark);
        if (result.remark == vm.remark.OK || result.remark == vm.remark.FAILED) {
            clearTimeout(interval);
            clearTimeout(processingInterval);
            ProcessingFinished(true);
        }
        else {
            if (vm.visibleProcess() == true)
                //settimeout every 200 miliseconds
                processingInterval = setTimeout(function () { LogProcessPortal(); }, 200);

        }
    }
    //#endregion

    function setCheckProcessEndedInterval(command, endEventParams, processText) {
        iteration = 1;
        if (!global.isNull(processText)) {
            vm.processText(processText);
        }
        else {
            vm.processText(global.dict()[1703]);
        }
        vm.visibleProcess(true);
        var processingIntervalHolder = setInterval(function () {
            command.LoopCnt = iteration;
            global.httpPost(global.enums.httpPath.CheckProcessEnded, command).done(function (response) {
                iteration++;
                if (response.IsEnded == true || iteration >= 500) {
                    clearInterval(processingIntervalHolder);
                    vm.visibleProcess(false);
                    if (!global.isNull(processingEventName)) {
                        global.app.trigger(processingEventName);
                    }
                    global.displaySpin(false);
                    if (!global.isNull(endEventParams)) {//response.IsEnded && 
                        global.app.trigger(endEventParams.Event.name, endEventParams);
                    }
                }
            })
        }, 200);
    }

    //#region init Processing timer
    function InitProcessingLog(result) {
        idNum = result.idNum;
        if (result.remark != vm.remark.OK && result.remark != vm.remark.FAILED) {
            processingInterval = setTimeout(function () { LogProcessPortal(); }, 200);
            interval = setTimeout(function finishTimer() { ProcessingFinished(false); }, 100000);
        }
        else
            ProcessingFinished(false);
    }
    //#endregion

    //#region Processing finish
    function ProcessingFinished(result) {
        try {
            vm.visibleProcess(false);
            if (paramsexport == null)
                vm.textProcess("");
            else {
                //+ TO DO - display LINK to file
                vm.textProcess("export SSIS running, export no= " + paramsexport.Command.ExportNo);
            }

            clearTimeout(interval);
            clearTimeout(processingInterval);

            if (result == false) {
                vm.textProcess(res.getValueByKey('4394'));
                isTextProcessHasMesssage = true;
            }
        }
        catch (err) {
            vm.visibleProcess(false);
            vm.textProcess("");
            global.treatError(err);
        }
    }
    //#endregion

    //#endregion

    //#region MAINTENANCE

    function getLogProcessInfoByProcessNo() {
        vm.visibleProcess(true);
        global.httpGet(global.enums.httpPath.GetLogProcessInfoByProcessNo, { processNo: processNo })
              .then(IntervalMaintenanceProcess);
    }

    function getLogInterfacesInfoByRunNo() {
        //vm.visibleProcess(true);
        global.httpGet(global.enums.httpPath.getLogInterfacesInfoByRunNo, { processNo: processNo })
              .then(IntervalInterfacesProcess);
    }

    function displayInfoByRunNo(result) {
        vm.visibleProcess(false);
        vm.textProcess("");
        IO_interfaces_ClearStatus();
        var typ = "";
        var resultIO = result;
        var resCode = result.resultCodeField;
        if (resCode == 1)
            typ = "error";
        else
            typ = "info";
        var title = result.resultDebugField.substring(result.resultDebugField.indexOf('|') + 4, result.resultDebugField.length);
        var MsgFile = "";
        if (result.exportPkgNameField != "")
            MsgFile = global.dict()[584] + ": " + result.resultMessageField + "<br/>";
        else
            MsgFile = "";
        if (result.pkgFileSizeField > 0) {
            IO_interfaces_Finished(resultIO);
            var res = global.dict()[1141] + ":" + result.maxField + " " + global.dict()[1387] + ":" + result.currentGoodField;
            if (result.pkgFileSizeField == 2)
                res = result.resultMessageField;
            var params = {
                Title: title,// result.resultDebugField,
                //Message: "<B>" + global.resMsg[488] + "</B><br/>" + result.resultMessageField + "<br/>" + res + "<br/>" + global.dict()[2060] + global.dict()[319] + "&nbsp;&nbsp;&nbsp;<img id='image1' style='cursor: pointer !important;' onclick=\"openReport\"  src=" + global.imagesManager.actionsStackButtonsPrint + "/>" + "<br/>" + global.resMsg[489],
                Message: "<B>" + global.resMsg[488] + "</B><br/>" + MsgFile + res + "<br/>" + global.resMsg[489] + "&nbsp;&nbsp;<img src='" + global.imagesManager.folderIcon + "' alt=''/>",
                Type: typ
            }
        }
        else {
            var params = {
                Title: title,// result.resultDebugField,
                Message: "<B>" + global.resMsg[488] + "</B><br/>" + global.dict()[1045] + "<br/>" + global.resMsg[489],   //result.resultMessageField +
                Type: typ
            }
        }

        notification.showNotification(params);
        global.SetInterfaceFlag(0);
        interfaceType = "";
    }

    function IntervalInterfacesProcess(result) {
        var d = new Date();
        var n = d.getSeconds();
        if (result.statusField == true) {
            clearTimeout(interfacesInterval);
            //get info from log file
            global.httpGet(global.enums.httpPath.getInfoByRunNo, { processNo: processNo, emp_no: global.cache.get(global.cache.enums.cacheItems.USER).Id, FMT: !global.isNull(global.cache.get(global.enums.cacheItems.REPORT_FMT)) ? global.cache.get(global.enums.cacheItems.REPORT_FMT) : null })
                  .then(displayInfoByRunNo);
        }
        else {
            var txt = global.helper.replaceDelimFromDict("{2}", global.helper.replaceDelimFromDict("{1}", global.helper.replaceDelimFromDict("{0}", global.resMsg[491], result.currentGoodField), result.maxField), result.currentErrField);
            if (interfaceType == "I") {
                vm.textProcess(interfaceNameField + ' - ' + txt);
            }
            interfacesInterval = setTimeout(function setInterfacesTimeout() { getLogInterfacesInfoByRunNo(); }, 1000);
        }
    }

    function IntervalMaintenanceProcess(result) {

        var text = global.dict()[62] + ": #" + processNo + " " + global.dict()[3271] + ": " + result.EmpCount + " " + ((global.isNull(result.CurrEmpNo) || result.CurrEmpNo == 0) ? '' : global.dict()[2] + ": " + result.CurrEmpNo);
        vm.textProcess(text);
        if (!global.isNull(result) && (result.xProcStep == 3115 || result.xProcStep == 1927 || result.xProcStep == 609)) {
            clearTimeout(maintenanceInterval);
            maintenanceProcessingFinished(true, result);
        }
        else {
            if (vm.visibleProcess() == true)
                maintenanceInterval = setTimeout(function () { getLogProcessInfoByProcessNo(); }, 200);
        }
    }

    function InitMaintenanceProcessingTimer(result) {
        maintenanceInterval = setTimeout(function setMaintenanceTimeout() { getLogProcessInfoByProcessNo(); }, 200);
    }

    function InitInterfacesTimer(result) {
        if (InitFlag == 0) return;
        getLogInterfacesInfoByRunNo();
        // interfacesInterval = setTimeout(function setInterfacesTimeout() { getLogInterfacesInfoByRunNo(); }, 1000);
    }


    function maintenanceProcessingFinished(isSucceeded, result) {
        try {
            vm.visibleProcess(false)
            var msg = global.dict()[1505] + " " + global.dict()[897];
            var processStatusTag = "";
            if (global.isNull(result) || result.ProcessStatus == res.getValueByKey('1927')) {
                processStatusTag = "<font color='red'>" + res.getValueByKey('1927') + "</font>";
            }
            else {
                processStatusTag = "<font color='green'>" + result.ProcessStatus + "</font>";
            }
            msg = msg + ": " + processStatusTag + (global.isNull(result) ? "" : " " + global.dict()[205] + ": " + result.EmpCount);
            vm.textProcess("");
            vm.textProcess(msg);
            isTextProcessHasMesssage = true;
            clearTimeout(maintenanceInterval);
            global.app.trigger(global.enums.events.CALL_PROCESSING_HAS_FINISHED.name);
        }
        catch (err) {
            vm.visibleProcess(false);
            vm.textProcess("");
            global.treatError(err);
        }
    }

    function maintenanceIOExportFinished(result) {
        try {
            vm.visibleProcess(false)

            var msg = global.dict()[4243] + " <B>" + result.ExportNo + " " + result.ExportPkgName + "</B> " + global.dict()[897];
            var processStatusTag = "";
            var txtFileCaption = "";

            var fileName2show = result.FileNameOnly;
            var fileErrName2show = result.FileErrNameOnly;
            /*
            var relatDir = "IOExport";
            var fileOnly = "alex.txt"; // TEST ONLY !!!really it's dynamik FILE NAME, extract from FileNameOnly
            */
            if (global.isNull(result) || result.intResultSalaryIOExport2File != 0) {
                processStatusTag = "<font color='red'>" + global.dict()[3442] + "</font>"; //failed
            }
            else {
                processStatusTag = "<font color='green'>" + global.dict()[3755] + "</font>"; //process succesfful
            }

            // var subExportDirHttp = global.webApiConfig.getHostPath() + global.webApiConfig.port + "/" + relatDir + "/";

            var delimChars = ' *** ';
            if (!global.isNullOrEmpty(fileName2show)) {
                /********************** Definition for DOWNLOAD file from Server *****************************
                window.location = global.webApiConfig.getHostPath() + global.webApiConfig.getApiPath('Export/GetFileDownload' + '?fileName=' + fileName2show + '&relativeDir=' + relatDir + '&contentType=' + contentType);
                ********************************************/
                //   processStatusTag = processStatusTag + "  <a href='" + subExportDirHttp + fileName2show + "' target='_blank'>" + fileName2show + "</a>";

                // by full path, even C:/Interface/HA_38xxx_SynelQa - change fileOnly to result.PkgFileName ???
                vm.srcIOExportFile(fileName2show);
                vm.srcIOExportFileOnly(fileName2show);
                vm.srcIOExportFileSize(result.PkgFileSize);
                txtFileCaption = delimChars + global.dict()[4572] + ': ' + vm.srcIOExportFileOnly();
                if (result.PkgFileSize == 0) txtFileCaption = delimChars + vm.srcIOExportFileOnly() + ',' + global.dict()[28] + '=0 (' + global.dict()[833] + ')'; //xxx , size=0(missing data)
                vm.txtIOExportFile(txtFileCaption);
            }

            if (!global.isNullOrEmpty(fileErrName2show)) {
                //   processStatusTag = processStatusTag + " <font color='red'>" + global.dict()[4244] + "</font>: <a href='" + subExportDirHttp + fileErrName2show + "' target='_blank'>" + fileErrName2show + "</a>"
                vm.srcIOExportErrorFile(result.PkgErrorFileName); // TO DO with PATH !!!
                vm.srcIOExportErrorFileOnly(fileErrName2show);
                vm.srcIOExportErrorFileSize(result.PkgFileErrSize);
                txtFileCaption = delimChars + global.dict()[4572] + ': ' + vm.srcIOExportErrorFileOnly();
                if (result.PkgFileSize == 0) txtFileCaption = delimChars + vm.srcIOExportErrorFileOnly() + ',' + global.dict()[28] + '=0 (' + global.dict()[833] + ')'; //xxx , size=0(missing data)
                vm.txtIOExportErrorFile(txtFileCaption)

            }
            msg = msg + ": " + processStatusTag + "; ";
            vm.textProcess("");
            vm.textProcess(msg);
            isTextProcessHasMesssage = true; //??? what is it ??
        }
        catch (err) {
            vm.visibleProcess(false);
            vm.textProcess("");
            global.treatError(err);
        }
    }

    // downloadExportFile called from shell.html, by click on file name
    function downloadExportFile(pFileName) {
        try {
            var vFile = pFileName(); // good=srcIOExportFile OR bad=srcIOExportErrorFile
            if (vFile == "" || vFile == undefined) return;
            var vContentType = vm.fileContentType();
            if (vContentType == "") vContentType = "text/plain";

            global.downloadFile(vFile, "InterfacesFolder", enums.copyFileToDestinationType.compParam, vContentType);
        }
        catch (err) {
            global.treatError(err);
        }
    }

    function downloadPdfFile(pFileName) {
        try {
            var vFile = pFileName(); // good=srcIOExportFile OR bad=srcIOExportErrorFile
            if (vFile == "" || vFile == undefined) return;
            var vContentType = vm.pdfContentType();
            if (vContentType == "") vContentType = "text/html";

            global.downloadFile(vFile, "InterfacesFolder", enums.copyFileToDestinationType.compParam, vContentType);
        }
        catch (err) {
            global.treatError(err);
        }
    }

    function IO_interfaces_Finished(result) {
        clearTimeout(interfacesInterval);
        //var delimChars = ' *** ';
        var delimChars = ' ';
        var msg = global.dict()[4243] + " <B>" + result.exportNoField + " " + result.exportPkgNameField + "</B> " + global.dict()[897];
        var processStatusTag = "";
        var txtFileCaption = "";
        var txtPdfCaption = "";

        var fileName2show = result.fileNameOnlyField;
        var fileErrName2show = result.fileErrNameOnlyField;
        vm.textProcess("<B><font color='red'>" + global.dict()[897] + "</font></B>"); // result.resultDebugField
        vm.textPdf("&nbsp;&nbsp;" + global.dict()[1069] + "&nbsp;<img src='" + global.imagesManager.actionsStackButtonsPrint + "'/>&nbsp;");
        vm.srcIOExportFile(result.pkgFileNameField);
        if (result.pkgFileNameField != "") {
            if(global.cache.get(global.cache.enums.cacheItems.REPORT_FMT) == "pdf")
                vm.srcIOPdfFile("Report_" + global.cache.get(global.cache.enums.cacheItems.USER).Id + ".pdf")
            else
                if(global.cache.get(global.cache.enums.cacheItems.REPORT_FMT) == "html")
                    vm.srcIOPdfFile("Report_" + global.cache.get(global.cache.enums.cacheItems.USER).Id + ".html")
                else
                    if (global.cache.get(global.cache.enums.cacheItems.REPORT_FMT) == "xls")
                        vm.srcIOPdfFile("Report_" + global.cache.get(global.cache.enums.cacheItems.USER).Id + ".xlsx")
        }
        vm.srcIOExportFileOnly(fileName2show);
        vm.srcIOExportFileSize(result.pkgFileSizeField);
        if (result.Command != null && result.Command.errDesc != '') {
            txtFileCaption = delimChars + result.Command.errDesc;
            //
            var params = {
                Title: result.Command.InterfaceName,// result.resultDebugField,
                Message: "<B>" + result.Command.errDesc,   //result.resultMessageField +
                Type: "error"
            }
            notification.showNotification(params);
            //
            if (result.Command.errDesc.indexOf('upload.png') > 0)
                txtFileCaption = "";
        }
        else {
            txtFileCaption = delimChars + global.dict()[4572] + ': ' + vm.srcIOExportFileOnly();
            txtPdfCaption =  global.dict()[1069] + ': ' + vm.srcIOPdfFile();
            vm.txtIOPdfFile(txtPdfCaption);
        }

        if (result.PkgFileSize == 0) txtFileCaption = delimChars + vm.srcIOExportFileOnly() + ',' + global.dict()[28] + '=0 (' + global.dict()[833] + ')'; //xxx , size=0(missing data)
        vm.txtIOExportFile(txtFileCaption);
        vm.visibleProcess(false);
        global.SetInterfaceFlag(0);

    }

    function IO_interfaces_ClearStatus() {
        var delimChars = ' *** ';
        var msg = "";
        var processStatusTag = "";
        var txtFileCaption = "";

        var fileName2show = "";
        var fileErrName2show = "";
        vm.textProcess("");
        vm.srcIOExportFile("");
        vm.srcIOPdfFile("");
        vm.srcIOExportFileOnly("");
        vm.srcIOExportFileSize("");
        txtFileCaption = "";
        vm.txtIOExportFile("");
        vm.visibleProcess(false);
    }
    function IO_backup_interfaces_Finished(result) {
        clearTimeout(interfacesInterval);
        //var delimChars = ' *** ';
        var delimChars = ' ';
        var msg = global.dict()[4243] + " <B>" + result.exportNoField + " " + result.exportPkgNameField + "</B> " + global.dict()[897];
        var processStatusTag = "";
        var txtFileCaption = "";
        var txtPdfCaption = "";

        var fileName2show = result.fileNameOnlyField + ".csv";
        var fileErrName2show = result.fileErrNameOnlyField;
        vm.textProcess("<B><font color='red'>" + global.dict()[897] + "</font></B>"); // result.resultDebugField
        vm.textPdf("&nbsp;&nbsp;" + global.dict()[1069] + "&nbsp;<img src='" + global.imagesManager.actionsStackButtonsPrint + "'/>&nbsp;");
        vm.srcIOExportFile(fileName2show);
        //if (result.pkgFileNameField != "") {
        //    vm.srcIOPdfFile(result.pkgFileNameField)
        //   }
        vm.srcIOExportFileOnly(fileName2show);
        vm.srcIOExportFileSize(result.pkgFileSizeField);
        if (result.Command != null && result.Command.errDesc != '') {
            txtFileCaption = delimChars + result.Command.errDesc;
            //
            var params = {
                Title: result.Command.InterfaceName,// result.resultDebugField,
                Message: "<B>" + result.Command.errDesc,   //result.resultMessageField +
                Type: "error"
            }
            notification.showNotification(params);
            //
            if (result.Command.errDesc.indexOf('upload.png') > 0)
                txtFileCaption = "";
        }
        else {
            txtFileCaption = delimChars + global.dict()[4572] + ': ' + vm.srcIOExportFileOnly();
            //txtPdfCaption = global.dict()[1069] + ': ' + vm.srcIOPdfFile();
            //vm.txtIOPdfFile(txtPdfCaption);
        }

        if (result.PkgFileSize == 0) txtFileCaption = delimChars + vm.srcIOExportFileOnly() + ',' + global.dict()[28] + '=0 (' + global.dict()[833] + ')'; //xxx , size=0(missing data)
        vm.txtIOExportFile(txtFileCaption);
        vm.visibleProcess(false);
        global.SetInterfaceFlag(0);

    }

    // ================== NOTIFIER =========================
    function Notifier_runNow_Finished(runResult) {
        vm.visibleProcess(false);
        vm.textProcess("");
        try {
            var typ = "";
            var title = global.res[4793] + ' : ' + global.res[2504];  // Send E-mail :result
            var msgRes = "";

            if (!global.isNull(runResult)) {
                if (runResult.FailedCount > 0) {
                    msgRes = global.res[3442] + " " + runResult.FailedCount
                    typ = "error";
                }
                if (runResult.SucceededCount >= 0) {
                    typ = "info";
                    if (msgRes != "") {
                        msgRes += "<br/>" + global.res[4793] + " " + runResult.SucceededCount
                    }
                    else
                        msgRes = global.res[4793] + " " + runResult.SucceededCount
                    /*
                    vm.eventsGrid.selectedRowIndex = 0;
                    vm.eventsGrid.rebind(); // just if inside screen!
                    */
                }
                var params = {
                    Title: title,// result.resultDebugField,
                    Message: "<B>" + global.res[1912] + " # " + runResult.Status[0] + "</B><br/>" + msgRes,
                    Type: typ
                }
                notification.showNotification(params);
                global.displaySpin(false);
            }
        }
        catch (err) {
            global.treatError(err);
            global.displaySpin(false);
        }
    }

    function Pwd_SentInit_Finished(runResult) {
        vm.visibleProcess(false);
        vm.textProcess("");
        try {
            var typ = "info";
            var title = global.res[4300] + ' : ' + global.res[2504];  // Send E-mail :result
            var msgRes = "";

            if (!global.isNull(runResult)) {
                msgRes = global.res[4298] + " : " + runResult.IssuedPwdCount2Emp // issue
                
                msgRes = msgRes + "<br><span style='color:navy'><b>" + global.res[4921] + "</b></span>"; // lastly sent
                msgRes = msgRes + "<br>"+ global.res[205] + " : " + runResult.SentCount2Emp; // employees
                msgRes = msgRes + "<br>" + global.res[320] + " : "+runResult.SentCount2Supervisor; // System Manager

                /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                ====================================================
                closed 09/11/2017 due using IssueFirstPasswordMailSmsResult
                if (runResult.SucceededCount >= 0) {
                    msgRes = global.res[4921] + "<span style='color:navy'><b>" + runResult.SentCount2Emp + " " + global.res[4298]// lastly sent XX Issuing of password
                }

                if (runResult.FailedCount > 0) {
                    if (runResult.SucceededCount == 0) typ = "error";
                    var errMsg = "<span style='color:red'><b>"+global.res[3442] + ":</b></span>" + runResult.FailedCount + " " + global.res[4298]// Failed
                   
                    if (runResult.ErrorMessage.length > 0) {
                        errMsg = errMsg + "<br>" + runResult.ErrorMessage
                    }
                    msgRes = msgRes + "<br>" + errMsg;
                }
                ===========================================================*/
                if (msgRes != "") {
                    var params = {
                        Title: title,// result.resultDebugField,
                        Message: msgRes,
                        Type: typ
                    }
                    notification.showNotification(params);
                }
                global.displaySpin(false);
            }
        }
        catch (err) {
            global.treatError(err);
            global.displaySpin(false);
        }
    }

    function JobAutomation_runNow_Finished(runResult, jobDescList) {
    	vm.visibleProcess(true);
    	vm.textProcess("");
    	try {
    		var typ = "other";
    		var title = !global.isNull(global.resMsg[622]) ? global.resMsg[622] : '';// + ' : ' + global.res[2504];  // Send auto job :result
    		var imgStatus = "";
        	var tdStyle = "padding: 3px; text-align: center";
    		//var msgRes = "";
        	if (!global.isNull(runResult) && runResult.length > 0) {
        		var msgRes = "<style> div.scroll { overflow-y:scroll; height: 80px; } </style>" + 
					          "<div class='scroll'><table style = 'font-size: 13px'>" +
					          "<col style='width:10%'><col style='width:15%'><col style='width:35%'><col style='width:40%'>" +
							  "<thead><tr><th style = '" + tdStyle + "'>" + global.res[15] +
							  "</th><th style = '" + tdStyle + "'>" + global.res[5252] +
                              "</th><th style = '" + tdStyle + "'>" + global.res[168] +
                              "</th><th style = '" + tdStyle + "'>" + global.res[3539] + "</th></tr></thead><tbody>";
    			for (var i = 0; i < runResult.length; i++) {
    				if (runResult[i].WasSuccessfull)
    					imgStatus = global.imagesManager.tagTypeActiveGreen;
    				else
    					imgStatus = global.imagesManager.error;

    				msgRes += "<tr>";
    				msgRes += "<td style = '" + tdStyle + "'><img src='" + imgStatus + "'/></td>";
    				msgRes += "<td style = '" + tdStyle + "'>" + runResult[i].JobId + "</td>";
					msgRes += "<td style = '" + tdStyle + "'>" + jobDescList[i].JobDesc + "</td>";
    				msgRes += "<td style = '" + tdStyle + "'>" + runResult[i].ErrorMessage + "</td>";
    				msgRes += "</tr>";
    			}
    			msgRes += "</tbody></table></div>";

    			var params = {
    				Title: title,
    				Message: msgRes,
    				Type: typ
    			}
    			notification.showNotification(params);
    			vm.visibleProcess(false);
        	}        	
    	}
    	catch (err) {
    		global.treatError(err);
    		vm.visibleProcess(false);
    	}
    }

    function HRProc_SentActivityMsg_Finished(sentResult) {
        vm.visibleProcess(false);
        vm.textProcess("");
        try {
            var typ = "info";
            var title = global.res[5397] +' : '+ global.res[4923]  + ' : ' + global.res[2504];  // Processes + events :result
            var msgRes = "";

            if (!global.isNull(sentResult)) {
                if (sentResult.Receipients2Mail != 0)
                    msgRes = global.res[39] + " " + global.res[4935] + " >> eMail : " + sentResult.Receipients2Mail; //Quont + Recipient address
                     
                if (sentResult.Receipients2Mail != 0)
                     msgRes = msgRes + "<br> " + global.res[39] + " " + global.res[4935] + " >> SMS : " + sentResult.Receipients2SMS;

                 msgRes = msgRes + "<br><span style='color:navy'><b>" + global.res[762] + " " + global.res[39] + global.res[4921] + ": </b></span>"; // total quantity
                 msgRes = msgRes + "<br>" + global.res[3443] + " : " + sentResult.SentSucceededCount; // successful
                 msgRes = msgRes + "<br>" + global.res[3442] + " : " + sentResult.SentFailedCount; // failedr

                if (msgRes != "") {
                    var params = {
                        Title: title,// result.resultDebugField,
                        Message: msgRes,
                        Type: typ
                    }
                    notification.showNotification(params);
                }
                global.displaySpin(false);
            }
        }
        catch (err) {
            global.treatError(err);
            global.displaySpin(false);
        }
    }
    //#endregion
});
