﻿define(function helperModule(require) {
    var system = require('durandal/system');
    var http = require('plugins/http');
    var enums = require('common/enums/enums');
    var cacheManager = require('common/cache/cacheManager');
    var webApiConfig = require('common/webApiConfig');
    var dialogManager = require('common/dialogManager');
    var imagesManager = require('common/imagesManager');

    function createInputViewInsteadCombo(code, descript, isOnlyCode) {
        if (!isNull(code)) {
            if (!isNull(descript) && !isOnlyCode)
                return code + ' | ' + descript;
            else
                return code;
        }
        else
            return "";
    }

    function isNull(value) {
        if (value == null || value == 'undefined')
            return true;
        else
            return false;
    }

    function isNullOrEmpty(value) {
        if (value == null || value == 'undefined' || value == '')
            return true;
        else
            return false;
    }

    function isNOE(value) {
        if (value == null || value == 'undefined' || value === '' || value === "")
            return true;
        else
            return false;
    }

    function buildPdfUrl(url) {
        url += "?" + new Date().getTime() + "#wmode=transparent&toolbar=0&navpanes=0&page=1&scrollbar=0&statusbar=0&messages=0&view=fit 1FP";
        if (explorerType() == enums.explorerType.IE)
            url += "&zoom=100";
        return url;
    }

    function replaceDelimFromDict(delim, msg, param) {
        var languageId = cacheManager.get(cacheManager.cacheItems.LAST_LANGUAGE);
        var dir = cacheManager.getLanguageDir(languageId);
        var a, b = msg;

        if (dir.toLowerCase() == 'rtl') {
            a = msg.substring(0, msg.indexOf(delim) - 1);
            b = msg.substring(msg.indexOf(delim) + 3) + ' ' + param + ' ' + a;
        }
        else {
            b = msg.replace(delim, param);
        }
        return b;
    }


    function removeSession() {
        var deferred = system.defer(function (dfd) {
            $(function () {
                http.post(webApiConfig.getApiPath(enums.httpPath.RemoveSessionBySessionId.path), { SessionId: cacheManager.get(cacheManager.cacheItems.SESSION_ID) }).done(
                      function () {
                          dfd.resolve();
                      }
             )
            });
        });
        return deferred.promise();
    }

    function observableObjectAsRegular(observableObject) {
        var newObject = {};
        $.each(observableObject, function (k, v) {
            newObject[k] = v();
        });
        return newObject;
    }

    function timeAsFloat(time) {
        if (!isNullOrEmpty(time)) {
            var timeAsArray = time.split(':');
            if (timeAsArray.length > 1) {
                return timeAsArray[0] + '.' + timeAsArray[1];
            }
            else
                return timeAsArray[0];
        }
        else
            return time;
    }

    function getLastDayOfCurrentMonth() {
        return new Date(new Date().getFullYear(), new Date().getMonth() + 1, 0);
        //NOTE: using getMonthe()+1, becouse of function getMonth
        //begin number the month from 0! (January=0)
    }

    function closeWindow(e, sender) {
        try {
            dialogManager.closeDialog(this, null);
        }
        catch (ex) {
            var e = ex;
        }
    }
    function deepCopy(value) {
        if ($.isArray(value))
            return deepCopyArray(value);
        if (/*!$.isPlainObject(value)*/(isNullOrEmpty(value) || isNullOrEmpty(value.__proto__) || isNullOrEmpty(value.__proto__.fields)) && !$.isPlainObject(value)) {
            return value;
        }
        else {
            if (!$.isPlainObject(value)) {
                var a = 1;
            }
            var object = {};
            $.each(value, function copyProp(name, val) {
                object[name] = deepCopy(val);
            });
            return object;
        }
    }
    function deepCopyArray(sourceArray) {
        var newArray = [];
        $.each(sourceArray, function copyItem(i, item) {
            newArray.push(deepCopy(item));
        });
        return newArray;
    }

    function add24Hours(orginalTime) {
        if (!isNullOrEmpty(orginalTime)) {
            var orginalTimeAsArray = orginalTime.split(':');
            orginalTimeAsArray[1] = parseInt(orginalTimeAsArray[1]) + 24;
            return orginalTimeAsArray[1] + ':' + orginalTimeAsArray[0];
        }
        return '24:00';
    }


    function compareTimes(first, second) {
        if (isNullOrEmpty(first))
            first = '00:00';
        if (isNullOrEmpty(second))
            second = '00:00';

        if (first == second) {
            return 0;
        }
        var firstTimeAsArray = first.split(':');
        var secondTimeAsArray = second.split(':');
        firstTimeAsArray[0] = parseInt(firstTimeAsArray[0]);
        firstTimeAsArray[1] = parseInt(firstTimeAsArray[1]);
        secondTimeAsArray[0] = parseInt(secondTimeAsArray[0]);
        secondTimeAsArray[1] = parseInt(secondTimeAsArray[1]);

        //condition summery: if (second < first)
        if (secondTimeAsArray[0] < firstTimeAsArray[0] || secondTimeAsArray[0] == firstTimeAsArray[0] && secondTimeAsArray[1] < firstTimeAsArray[1]) {
            return -1;
        }
        else {
            return 1;
        }
    }

    function compareObjectsValue(val1, val2) {
        /* comparation in this function is slight, 
        for example- 
        when val1 = 5 and val2="5" 
        the function returns true (5 == "5")!
        */
        if (val1 == null && val2 || val2 == null && val1)
            return false;//one of the object is null while the other is not
        if (val1 == val2)
            return true;
        if (typeof (val1) == "object" && typeof (val2) == "object") {
            if (Object.keys(val1).length != Object.keys(val2).length) {
                return false;
            }
            for (var property in val1) {
                if (val1.hasOwnProperty(property) && val2.hasOwnProperty(property)) {//this question is nessesary according to http://stackoverflow.com/questions/8312459/iterate-through-object-properties#answer-16735184
                    if (compareObjectsValue(val1[property], val2[property]) == false)
                        return false;
                }
            }
        }
        else {
            //val1 and val2 are not objects and not equal
            return false;
        }
        return true;
    }

    function compareByCodeField(obj1, obj2) {
        if (obj1.Code < obj2.Code)
            return -1;
        if (obj1.Code > obj2.Code)
            return 1;
        return 0;
    }
    //helper method convertStringToURLEncodeByAscii
    //in cases need encoding and standard method "encodeURIComponent" is not correct, we use this method
    //for example: when calling method of delphi in reports 
    //relevant for ISO (not US )languages - such as hebrew
    function convertStringToURLEncodeByAscii(inStr) {
        var outStr = '', asciiCode;

        for (var i = 0; i < inStr.length; i++) {
            asciiCode = (inStr[i]).charCodeAt(0);
            //made next calculation only for hebrew letters (ascci is from 1488 till 1514 and need to reduces to 224 till 250) 
            //for ex. letter "ע" is 1506 asciiCode and we need it to be 242 such as table below(link), so reduced the difference
            //according to ascii table in link : http://lab.artlung.com/urlencode/ & http://www.addressmunger.com/special_ascii_characters/
            //this link shows the encoding Delphi waiting for: http://stackoverflow.com/questions/776302/standard-url-encode-function
            asciiCode = (asciiCode > 1487 && asciiCode < 1515) ? asciiCode - 1264 : asciiCode;
            outStr += escape(String.fromCharCode(asciiCode));
        }

        return outStr;
    }

    function setDictionaryObject(list, keyColumn, valueColumn) {
        try {
            var dictionaryObject = {};
            var i;
            if (!isNull(keyColumn)) {
                for (i = 0; i < list.length; i++)
                    dictionaryObject[list[i][keyColumn]] = list[i][valueColumn];
            }
            else {
                for (i = 0; i < list.length; i++)
                    dictionaryObject[list[i].Code] = list[i].Descript;
            }
            return dictionaryObject;
        }
        catch (err) {
            alert(err);
        }
    }

    function emptyIfReadonly(widgets) {
        $.each(widgets, function (index, widget) {
            if (widget.isReadOnly() == true) {
                switch (widget.controlType) {
                    case enums.controlType.combo:
                    case enums.controlType.autoComplete:
                        widget.changeSelectedItem(null);
                        break;
                    case enums.controlType.datePicker:
                    case enums.controlType.timeInput:
                    case enums.controlType.numricTextBox:
                        widget.value(null);
                        break;
                    case enums.controlType.colorPickerSlider://טרם מומש
                        break;
                    case enums.controlType.selectFile://טרם מומש
                        widget.path(null);
                    default: break;
                };
            }
        });

    }

    function arrayFirstIndexOf(array, predicate, predicateOwner) {
        for (var i = 0, j = array.length; i < j; i++) {
            if (predicate.call(predicateOwner, array[i])) {
                return i;
            }
        }
        return -1;
    }

    function checkGeneralSavingResult(customMessageWindowModel, result) {
        if (result.Status != 0) {
            customMessageWindowModel.buildMessage({ mode: enums.messageType.error, messageText: result.Message });
            dialogManager.showDialog(customMessageWindowModel);
            return false;
        }
        else {
            return true;
        }
    }

    function emptyPromiseWithFalseResult() {
        return system.defer(function (dfd) {
            dfd.resolve(false);
        }).promise();
    }

    function toggleMinusPlus(id, event) {
        try {
            if (!isNOE(event)) {//in case screen appears twice, we search for specific div in its parent and not in whole document
                parentElement = $($(event.currentTarget)[0].offsetParent.offsetParent.offsetParent);
                parentElement.find('#' + id + "Div").slideToggle();
                parentElement.find('#' + id + "Minus").toggle();
                parentElement.find('#' + id).toggle();
            }
            else {
                $("#" + id + "Div").slideToggle();
                $("#" + id + "Minus").toggle();
                $("#" + id).toggle();
            }
        }
        catch (err) {
            treatError(err);
        }
    }
    //num of day between 0-6
    function getWeekByFirstDayOfWeek(value, numDay) {
        if (!(value instanceof Date))    //in case date param is in format yyyy-MM-ddTHH:mm:ss
            value = Date.parse(value);
        var week = value.getWeek(numDay);

        if (value.getDay() < numDay) {
            week.startDate.addWeeks(-1);
            week.endDate.addWeeks(-1);
        }
        return week;
    }


    function getUpdateStatusTooltip(date, dateFormat) {
        var isAmPm = cacheManager.getCompanyParamByFieldName("isAmPm") == 1 ? true : false;
        var dateOnly = "";
        var time = "";
        if (!isNullOrEmpty(date)) {
            var datetime = date.substring(0, 19);
            dateOnly = (Date.parse(datetime)).clearTime().toString(dateFormat);
            time = datetime.substring(datetime.indexOf('T') + 1);
            if (isAmPm)
                time = get_ampm_oclock_text(time);
        }
        return dateOnly + " " + time;
    }

    function getDateByNumOfDaysBackFromDate(nomOfDaysBack, date) {
        //if date=null, go back from today
        if (isNullOrEmpty(date))
            var date = new Date();
        date.setDate(date.getDate() - nomOfDaysBack);
        return date.toString("yyyy-MM-ddT00:00:00");
    }

    function returnTimeHoursIn2Digits(time) {    //such as "7:00" to "07:00"
        var timeHour = time.split(':');
        if (timeHour[0].length < 2) {
            return "0" + time;
        }
        else
            return time;
    }

    function isValidEmail(value) {
        if (value == null || value === '') return true;
        if (typeof (value) !== 'string') return false;

        var re = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
        return re.test(value);
    }

    var helper = {
        createInputViewInsteadCombo: createInputViewInsteadCombo,
        buildPdfUrl: buildPdfUrl,
        isNull: isNull,
        isNullOrEmpty: isNullOrEmpty,
        isNOE: isNOE,
        removeSession: removeSession,
        replaceDelimFromDict: replaceDelimFromDict,
        observableObjectAsRegular: observableObjectAsRegular,
        timeAsFloat: timeAsFloat,
        getLastDayOfCurrentMonth: getLastDayOfCurrentMonth,
        closeWindow: closeWindow,
        deepCopy: deepCopy,
        add24Hours: add24Hours,
        compareTimes: compareTimes,
        compareObjectsValue: compareObjectsValue,
        compareByCodeField: compareByCodeField,
        convertStringToURLEncodeByAscii: convertStringToURLEncodeByAscii,
        setDictionaryObject: setDictionaryObject,
        emptyIfReadonly: emptyIfReadonly,
        arrayFirstIndexOf: arrayFirstIndexOf,
        checkGeneralSavingResult: checkGeneralSavingResult,
        emptyPromiseWithFalseResult: emptyPromiseWithFalseResult,
        toggleMinusPlus: toggleMinusPlus,
        getWeekByFirstDayOfWeek: getWeekByFirstDayOfWeek,
        dummy: function dummyFunc() { },
        getHashCode: getHashCode,
        getUpdateStatusTooltip: getUpdateStatusTooltip,
        getDateByNumOfDaysBackFromDate: getDateByNumOfDaysBackFromDate,
        dict: ko.observable([]),
        dictMsg: ko.observable([]),
        returnTimeHoursIn2Digits: returnTimeHoursIn2Digits,
        hideAndDisableElementsByCompanyUsed: hideAndDisableElementsByCompanyUsed,
        get_ampm_oclock: get_ampm_oclock,
        get_ampm_oclock_text: get_ampm_oclock_text,
        startHandleDataTooltip: startHandleDataTooltip,
        getResponseCompanyOfPortalName: getResponseCompanyOfPortalName,
        uploadFiles: uploadFiles,
        codingSpecificComapnyParamsFromServer: codingSpecificComapnyParamsFromServer,
        isValidEmail: isValidEmail,
        changeXMLParamValue: changeXMLParamValue,
        escapeHtml: escapeHtml,
        getDayOrMonthNameByDate: getDayOrMonthNameByDate,
        explorerType: explorerType
    };
    return helper;

    function treatError(err) {
        //need require it only before use, for prevent cycle-referance
        require(['common/errorManager'], function treatError(errorManager) {
            errorManager.treatError(err);
        })
    }

    function showMessage(mode, messageText) {
        //need require it only before use, for prevent cycle-referance
        require(['views/combinedControls/customMessageWindow/customMessageWindow'], function showMessageAfterRequire(customMessageWindow) {
            customMessageWindow.buildMessage({ mode: mode, messageText: messageText });
            dialogManager.showDialog(customMessageWindow);
        });
    }

    function escapeHtml(str, maxLength, fieldName) {
        //fieldName maybe used foe special allow/restrict chars, ex. for UserComment
        var antiXSSstr = "";
        antiXSSstr = String(str)
            .replace('<script', "")
            .replace('</script>', "")
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;")
            .replace(/\//g, "&#x2F;")
            .replace(':', '-')
            .replace('|', '-')
        if (maxLength)
            antiXSSstr = antiXSSstr.substring(0, maxLength);
        return antiXSSstr;
    }

    function changeDisplaySpin(isDisaply) {
        //need require it only before use, for prevent cycle-referance
        require(['common/global'], function changeDisplaySpinAfterRequire(globalModule) {
            globalModule.displaySpin(isDisaply);
        });
    }

    function getHashCode(str) {
        var hash = 5381;
        if (str.length == 0) return hash;
        for (var i = 0; i < str.length; i++) {
            var character = str.charCodeAt(i);
            hash = ((hash << 5) + hash) + character;
            hash = hash & hash; // Convert to 32bit integer
        }
        return hash;
    };

    function hideAndDisableElementsByCompanyUsed(masterName) {
        var showType = enums.showType;
        var unUsedElements;
        var elementsToHandleArray = cacheManager.get(enums.cacheItems.FORMS_ELEMENT_SHOW_TYPE);
        if (!elementsToHandleArray) {
            return;
        }
        elementsToHandle = elementsToHandleArray[masterName];
        if (elementsToHandle) {
            unUsedElements = $('[data-form-id=' + masterName + '] [data-map-id]');
            $.each(elementsToHandle, function (i, item) {
                if (item.ShowType == showType.hide) {
                    unUsedElements.filter('[data-map-id = ' + item.ElementMapping_ID + ']').hide();
                }
                else {//showType.disable
                    unUsedElements.filter('[data-map-id = ' + item.ElementMapping_ID + ']').attr('disabled', 'disabled');
                    var caseAllowElement = unUsedElements.filter('[data-map-id = ' + item.ElementMapping_ID + ']').find('.caseAllow');
                    if (caseAllowElement.length > 0) {
                        removeVisibilityBindingOfElement(caseAllowElement, true);
                    }

                    var caseNotAllowElement = unUsedElements.filter('[data-map-id = ' + item.ElementMapping_ID + ']').find('.caseNotAllow');
                    if (caseNotAllowElement.length > 0) {
                        removeVisibilityBindingOfElement(caseNotAllowElement);
                    }

                    unUsedElements.filter('[data-map-id = ' + item.ElementMapping_ID + ']').find('.disableOnNotAllow').attr('disabled', 'disabled');;
                }
            });
        }
    }

    function get_ampm_oclock(oclock) {
        var timeHour = parseInt(oclock.split(':')[0]);
        var timeToDisplay;
        if (timeHour == 0 || timeHour == 12)
            timeToDisplay = '12:' + oclock.split(':')[1];
        else {
            timeToDisplay = timeHour % 12;
            if (timeToDisplay.toString().length == 1)
                timeToDisplay = '0' + (timeHour % 12);
            timeToDisplay = timeToDisplay + ':' + oclock.split(':')[1];
        }
        return timeToDisplay + "<span " + (timeHour > 12 ? "" : "class='dailyAM'") + " style='font-size:9px'>" + (timeHour > 12 ? "P" : "A") + "</span>";
    }

    function get_ampm_oclock_text(oclock) {
        var timeHour = parseInt(oclock.split(':')[0]);
        var timeToDisplay;
        if (timeHour == 0 || timeHour == 12)
            timeToDisplay = '00:' + oclock.split(':')[1];
        else {
            timeToDisplay = timeHour % 12;
            if (timeToDisplay.toString().length == 1)
                timeToDisplay = '0' + (timeHour % 12);
            timeToDisplay = timeToDisplay + ':' + oclock.split(':')[1];
        }
        return timeToDisplay + " " + (parseInt(timeHour / 12) == 0 ? "AM" : "PM");
    }

    function startHandleDataTooltip(tooltips) {
        if (tooltips != null) {
            $('[data-tooltip]').livequery(function () {
                var dataTooltip = $(this).attr('data-tooltip');
                var tooltip = tooltips[dataTooltip];
                var tooltipElement = document.createElement("a");
                if (this.localName != 'span')
                    tooltipElement.className = "dictTooltip col-md-1";
                else
                    tooltipElement.className = "dictTooltip";
                tooltipElement.innerHTML = '<img  src="' + imagesManager.questionMark + '" /><span class="showTooltip">' + tooltip + '</span>';
                $(tooltipElement).insertAfter(this);
                //set  the left position
                $(tooltipElement).children()[0].onmouseover = function () {
                    var tooltip = tooltipElement.children[1];
                    //if ($(tooltip).width() > 700) {//when tooltip is too much big, limit its width
                    //    $(tooltip).width("700px");
                    //    $(tooltip).css("white-space", "pre-wrap");//prevent overflow-long-rows from being cut, and cause them to move to new line.
                    //}
                    var isRtl = (cacheManager.getLanguageDir(cacheManager.get(cacheManager.cacheItems.LAST_LANGUAGE))).toLowerCase() == 'rtl';
                    var tooltipTop = $(tooltipElement).offset().top;

                    $(tooltip).css('top', tooltipTop + 'px');

                    if (isRtl) {
                        var tooltipRight = ($(window).width() - ($(tooltipElement).offset().left + $(tooltipElement).outerWidth())) + 15;//calc right position of element.
                        $(tooltip).css('right', tooltipRight + 'px');//on rtl lang, position calc is by right.
                    }
                    else {
                        var tooltipLeft = $(tooltipElement).offset().left + 15;//on ltr lang, position calc is by right.
                        $(tooltip).css('left', tooltipLeft + 'px');
                    }
                    if ($(tooltip).css("margin-top") != '0px') {
                        $(tooltip).css({ "margin-top": "0px" });
                    }
                    var left = $(tooltip).offset().left;
                    var height = $(tooltip).height();
                    var top = $(tooltip).offset().top;
                    var parentDiv = $($(tooltipElement).closest('[data-view]')[0]);
                    var margin = $(tooltip).width();
                    var bodyWidth = $('body').innerWidth();



                    if (isRtl) {//when language is rtl - handle cases tooltip overflow from left side of screen.
                        if (left < 0 && $(tooltip).css("margin-right") == '0px')
                            $(tooltip).css({ "margin-right": +(left - 30) + "px" });//give minus margin-right for take element to right. add 30px for nice looking.
                    }
                    else {//when language is rtl - handle cases tooltip overflow from right side of screen.
                        if (left + $(tooltip).width() > bodyWidth && $(tooltip).css("margin-left") == '0px') {
                            $(tooltip).css({ "margin-left": "-" + (left + $(tooltip).width() - bodyWidth + 30) + "px" });//give minus margin-left for take element to left. add 30px for nice looking.
                        }
                    }

                    if (top + height > $(document).height()) {
                        $(tooltip).css({ "margin-top": "-" + (top + height - $(document).height() + 30) + "px" });
                    }

                };
            });
        }
    }

    function removeVisibilityBindingOfElement(element, isHide) {
        element = $(element);
        var bindingString = element.attr('data-bind');
        if (bindingString) {
            var newBindingString = '';
            if (bindingString.indexOf('visible') > -1) {
                var bindingArray = bindingString.split('visible');
                if (bindingArray[1].indexOf(',') > -1) {
                    bindingArray[1] = bindingArray[1].substring(bindingArray[1].indexOf(',') + 1);
                    newBindingString = bindingArray[1];
                }
                var bindingString = element.attr('data-bind', newBindingString);

                if (isHide || element.hasClass('hideOnNotAllow')) {
                    element.hide();
                }
                else {
                    element.show();
                }
            }
        }
        if (!element.hasClass('hideOnNotAllow')) {
            $.each(element.children(), function callReqursive(i, item) {
                removeVisibilityBindingOfElement(item, isHide);
            });
        }
    }

    function getResponseCompanyOfPortalName(configuredParam) {
        switch (configuredParam) {
            case enums.responseCompanyOfPortal.DT.id:
                return enums.responseCompanyOfPortal.DT.name;
            case enums.responseCompanyOfPortal.Synel.id:
                return enums.responseCompanyOfPortal.Synel.name;
            default:
                return configuredParam;
        }
    }

    function uploadFiles(path, data) {
        var response = $.ajax({
            url: path,
            data: data,
            type: 'POST',
            cache: false,
            contentType: false,
            processData: false,
            enctype: 'multipart/form-data',
            async: false,
        });
        return response;
    }

    function codingSpecificComapnyParamsFromServer(decodeOrEncode, companyParams) {
        //implemented by explanation in url http://www.url-encode-decode.com/base64-encode-decode/
        var resultList = Enumerable.From(companyParams)
                .Select(function (lu) {
                    var luToReturn = lu;
                    if (lu.FieldName == "ServerHost" ||
                    lu.FieldName == "CommIP" || lu.FieldName == "FTPpath" ||
                    lu.FieldName == "FTPServer" || lu.FieldName == "NotifierIP" ||
                    lu.FieldName == "SynergyCommServer" ||
                    lu.FieldName == "TranFileDir" ||
                    lu.FieldName == "BackUpFileDir" ||
                    lu.FieldName == "TemplateFileDir" ||
                    lu.FieldName == "RdyFileDir" ||
                    lu.FieldName == "EmpPicFilesDir") {
                        luToReturn = deepCopy(lu);
                        if (decodeOrEncode == 1)    /*decode*/
                            luToReturn.fieldvalue = decodeURIComponent(escape(atob(luToReturn.fieldvalue)));
                        else    /*encode*/
                            luToReturn.fieldvalue = btoa(unescape(encodeURIComponent(luToReturn.fieldvalue)));
                    }
                    return luToReturn;
                }).ToArray();
        return resultList;
    }

    //helper method for changing field value in XNL string
    function changeXMLParamValue(xmlString, fieldName, fieldValue) {
        if (!isNullOrEmpty(xmlString)) {
            var params = ''
            if (xmlString.indexOf(fieldName) > -1)//exists in string - change its value
                params = xmlString.substring(0, xmlString.indexOf(fieldName) - 1) + '<' + fieldName + '>' + fieldValue + '</' + fieldName + '>' + xmlString.substring(xmlString.indexOf('</' + fieldName) + fieldName.length + 3);
            else//not exist in paramsXML - so add it
                params = xmlString.substring(0, xmlString.indexOf("</Root>")) + '<' + fieldName + '>' + fieldValue + '</' + fieldName + '></Root>';
            return params;
        }
    }

    function getDayOrMonthNameByDate(type, dateParam) {
        switch (type) {
            case 1://day
                return kendo.cultures.current.calendars.standard.days.namesAbbr[dateParam.getDay()];
                break;
            case 2://month
                return kendo.cultures.current.calendars.standard.months.namesAbbr[dateParam.getMonth()];
                break;
        }
    }

    //get explorer type 
    function explorerType() {
        var trident = !!navigator.userAgent.match(/Trident\/7.0/);
        var net = !!navigator.userAgent.match(/.NET4.0E/);
        var IE11 = trident && net
        var IEold = (navigator.userAgent.match(/MSIE/i) ? true : false);
        if (IE11 || IEold) {
            return "IE";
        } else {
            return "notIE";
        }
    }

});

