﻿define(function serverWrapper(require) {
    var http = require('plugins/http');
    var webApiConfig = require('common/webApiConfig');
    var errorManager = require('common/errorManager');

    var getSync = function getSync(path, data) {
        try {
            var response = $.ajax({
                url: path,
                data: data,
                async: false
            });
            return JSON.parse(response.responseText);
        } catch (err) {
            errorManager.treatError(err);

        }
    }

    var postSync = function postSync(path, data) {
        try {
            var response = $.ajax({
                url: path,
                data: ko.toJSON(data),
                type: 'POST',
                contentType: 'application/json',
                dataType: 'json',
                async: false,
            });
            return JSON.parse(response.responseText);
        } catch (err) {
            errorManager.treatError(err);

        }

    }

    var post = function httpPost(enumPath, data) {
        try {
            return http.post(webApiConfig.getApiPath(enumPath.path), data);
        } catch (err) {
            errorManager.treatError(err);
        }

    }

    var get = function httpGet(enumPath, data) {
        try {
            return http.get(webApiConfig.getApiPath(enumPath.path), data);
        } catch (err) {
            errorManager.treatError(err);

        }

    }

    var serverWrapper = {
        getSync: getSync,
        postSync: postSync,
        post: post,
        get: get
    };

    return serverWrapper;
});