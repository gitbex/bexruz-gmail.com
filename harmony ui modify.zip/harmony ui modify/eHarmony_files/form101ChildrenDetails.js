﻿define(function form101ChildrenDetails(require) {
    var validator = require('common/customValidator');
    var global = require('common/global');
    var resources = require('common/resourcesManager');
    var datePicker = require('views/controls/datePicker/datePicker');
    var form101Helper = require('views/forms/form101/form101Helper');   
    var dateFormat = global.cache.get(global.enums.cacheItems.DATE_FORMAT);
    var maskDate = dateFormat.replace(/[a-zA-Z]/g, "9")
    var globalDataObject = null;
    var customIsModified = false;
    var kidGridWasModified = false;
    var sourceData;
    var counter;
    var rejectCounter;
    var acceptCounter;
    var kidGridElement = null;
    var rejectCreditsGridElement = null;
    var acceptCreditsGridElement = null;
    var years19AgoFirstDate = new Date(new Date().getFullYear() - 19, 11, 31); // in march 2018 - returns 31/12/1999
    //var years19AgoFirstDate = new Date(new Date().getFullYear() - 19, 12, 31);// in march 2018 - returns 31/01/2000
    var form101params;
    function compositionComplete() {
        $(document).ready(function () {
            kidGridElement = $("#kid");
            counter = globalDataObject.gridsData.childrenData.length;
            var ds = new kendo.data.DataSource({
                data: globalDataObject.gridsData.childrenData,
                transport: {
                    read: function (o) { o.success(globalDataObject.gridsData.childrenData); },
                    create: function (o) {
                        var item = o.data;
                        item.id = counter++;
                        o.success(item);
                    },
                    update: function (o) {
                        o.success();
                    },
                    destroy: function (o) { o.success(); }
                },
                //batch: true,
                schema: {
                    model: {
                        id: 'id',
                        fields: {
                            check_row: { editable: false },
                            ChildState1: { type: "boolean", editable: true },
                            ChildState2: { type: "boolean", editable: true },
                            ChildName: {
                                type: "string", editable: true
                            },
                            Child_ID: {
                                type: "string", editable: true
                            },
                            ChildBirthDate: {
                                type: "string", editable: true,
                                validation: {
                                    requireAndNotEmpty: validator.requireAndNotEmpty
                                }
                            }
                        }
                    }
                },
                change: function (e) {
                    $("#infos").text(JSON.stringify(e.sender._data));
                },

            });
            kidGridElement.kendoGrid({
                dataSource: ds,
                pageable: false,
                editable: {
                    confirmation: false,
                },
                dataBound: function (e) {
                    try {
                        addEventAfterBind(e);
                    }
                    catch (err) {
                        global.treatError(err);
                    }
                },
                edit:
                    function (e) {
                        if (e.container.closest("tr").hasClass("customNotEditable")) {
                            e.sender.closeCell();
                            e.container.addClass("k-state-focused");
                            e.container.focus();
                            return;
                        }
                        var control = $("[name='Child_ID']", e.container);
                        control.attr('maxlength', '9');
                        control.attr('data-minLength', '5');
                        control.blur(function () {
                            var input = $(this);
                            if (input[0].value.length >= 5) {
                                while (input[0].value.length < 9) {
                                    input[0].value = '0' + input[0].value;
                                }
                            }
                            e.model.Child_ID = input[0].value;
                        });
                        control.keypress(function (e) {
                            var key = window.event ? event.keyCode : event.which;
                            if (event.keyCode == 8 || event.keyCode == 46
                                || event.keyCode == 37 || event.keyCode == 39) {
                                return true;
                            }
                            else if (key < 48 || key > 57) {
                                return false;
                            }
                            else return true;
                        });
                        var control1 = $("[name='Child_Name']", e.container);
                        control1.blur(function () {
                            var input = $(this);
                            e.model.Child_Name = input[0].value;
                        });
                        //var dateMask = global.cache.get(global.enums.cacheItems.DATE_FORMAT).replace(/[a-zA-Z]/g, "9")
                        //$('[name = ChildBirthDate]').mask(dateMask);
                    }
                ,
                navigatable: true,
                columns: [
                  { field: "check_row", width: '3%', title: "<input id='checkAll', type='checkbox', class='check_row headerbox' />", template: "<input type='checkbox' class='check_row checkbox' />" },
                  {
                      field: "ChildName", width: '20%', title: "שם", editor: function childNameEditor(container) {
                          $('<input name="ChildName" class="k-input k-textbox" type="text" data-bind="value:ChildName" maxlength="50"/>').appendTo(container);
                      }, template: function childNameTemplate(dataItem) {
                          var result = "<span>" + dataItem.ChildName + "</span>";
                          return result += "<input data-text='" + dataItem.ChildName + "' value='" + dataItem.ChildName + "' valid='requireAndNotEmpty' type='hidden' name='" + dataItem.id + "ChildName'/>";
                      }
                  },
                  {
                      field: "Child_ID", width: '8%', title: "מספר זהות", editable: true, template: function childIdTemplate(dataItem) {
                          var result = "<span>" + normalId(dataItem) + "</span>";
                          if (global.isNOE(dataItem.ChildBirthDate) || Date.parse(dataItem.ChildBirthDate) > years19AgoFirstDate || dataItem.isNewData) {
                              result += "<input data-text='" + dataItem.Child_ID + "' value='" + dataItem.Child_ID + "' valid='requireAndNotEmpty;isDigit;isValidID;firstCustom' type='hidden' name='" + dataItem.id + "Child_ID' />";
                          }
                          else {
                              result += "<input data-text='" + dataItem.Child_ID + "' value='" + dataItem.Child_ID + "' type='hidden' name='" + dataItem.id + "Child_ID' />";
                          }
                          return result;
                      }
                  },
                  {
                      field: "ChildBirthDate", width: '8%', title: "תאריך לידה", editable: true,
                      template: function ChildBirthDateTemplate(container) { return datePickerTemplate(container, "ChildBirthDate") },
                      editor: function ChildBirthDateEditor(container, options) { return datePickerEditor(container, options, true); }
                  },
                  {
                      field: "ChildState1", width: '10%', title: "האם הילד נמצא בחזקתך?", editable: true, template: function readonlyCheckBoxChildState1(dataItem) {
                          return readonlyCheckBoxChildStateFunc(dataItem, "ChildState1");
                      }
                  },
                  {
                      field: "ChildState2", width: '20%', title: 'האם את/ה מקבל/ת בגינו קצבת ילדים מביטוח לאומי?', editable: true, template: function readonlyCheckBoxChildState2(dataItem) {
                          return readonlyCheckBoxChildStateFunc(dataItem, "ChildState2");
                      }
                  }

                ]
            });

            function readonlyCheckBoxChildStateFunc(dataItem, fieldName) {
                var blnChildState = dataItem[fieldName];
                var doDisabled = "";

                if (global.isNOE(dataItem.ChildBirthDate) && Date.parse(dataItem.ChildBirthDate) < years19AgoFirstDate) {
                    blnChildState = false; // case child 19 years old in TaxYear
                    dataItem[fieldName] = blnChildState;
                }
                if (global.isNOE(dataItem.ChildBirthDate) || global.isNullOrEmpty(dataItem.ChildName) || global.isNullOrEmpty(dataItem.Child_ID))
                    doDisabled = "disabled";
                if (fieldName == "ChildState2" && doDisabled=="" && !dataItem.ChildState1)
                    doDisabled = "disabled";
                return '<input ' + doDisabled + ' class="' + fieldName + '" name="' + fieldName + '" type="checkbox"' + (blnChildState == true ? 'checked="checked"' : '') + '/>';
            }

            //#region settings for credits grids
            rejectCreditsGridElement = $("#rejectCredits");
            rejectCounter = globalDataObject.gridsData.rejectCreditsData.length;
            var dsRejects = new kendo.data.DataSource({
                data: globalDataObject.gridsData.rejectCreditsData,
                transport: {
                    read: function (o) { o.success(globalDataObject.gridsData.rejectCreditsData); },
                    create: function (o) {
                        var item = o.data;
                        item.id = rejectCounter++;
                        o.success(item);
                    },
                    update: function (o) {
                        o.success();
                    },
                    destroy: function (o) { o.success(); }
                },
                //batch: true,
                schema: {
                    model: {
                        id: 'id',
                        fields: {
                            check_row: { editable: false },
                            ChildName: {
                                type: "string", editable: true
                            },
                            Child_ID: {
                                type: "string", editable: true
                            },
                            ChildBirthDate: {
                                type: "string", editable: true, validation: {
                                    requireAndNotEmpty: validator.requireAndNotEmpty
                                }
                            }
                        }
                    }
                },

            });
            rejectCreditsGridElement.kendoGrid({
                dataSource: dsRejects,
                pageable: false,
                editable: {
                    confirmation: false,
                },
                dataBound: function (e) {
                    try {
                        addEventAfterBindRejectCredits(e);
                    }
                    catch (err) {
                        global.treatError(err);
                    }
                },
                edit:
                    function (e) {
                        if (e.container.closest("tr").hasClass("customNotEditable")) {
                            e.sender.closeCell();
                            e.container.addClass("k-state-focused");
                            e.container.focus();
                            return;
                        }
                        var control = $("[name='Child_ID']", e.container);
                        control.attr('maxlength', '9');
                        control.attr('data-minLength', '5');
                        control.blur(function () {
                            var input = $(this);
                            if (input[0].value.length >= 5) {
                                while (input[0].value.length < 9) {
                                    input[0].value = '0' + input[0].value;
                                }
                            }
                            e.model.Child_ID = input[0].value;
                        });
                        control.keypress(function (e) {
                            var key = window.event ? event.keyCode : event.which;
                            if (event.keyCode == 8 || event.keyCode == 46
                                || event.keyCode == 37 || event.keyCode == 39) {
                                return true;
                            }
                            else if (key < 48 || key > 57) {
                                return false;
                            }
                            else return true;
                        });
                        var control1 = $("[name='Child_Name']", e.container);
                        control1.blur(function () {
                            var input = $(this);
                            e.model.Child_Name = input[0].value;
                        });
                        //var dateMask = global.cache.get(global.enums.cacheItems.DATE_FORMAT).replace(/[a-zA-Z]/g, "9")
                        //$('[name = ChildBirthDate]').mask(dateMask);
                    }
                ,
                navigatable: true,
                columns: [
                  { field: "check_row", width: '40px', title: "<input id='rejectCheckAll', type='checkbox', class='check_row headerbox' />", template: "<input type='checkbox' class='check_row checkbox' />" },
                  {
                      field: "ChildName", title: "שם", editor: function childNameEditor(container) {
                          $('<input name="ChildName" class="k-input k-textbox" type="text" data-bind="value:ChildName" maxlength="50"/>').appendTo(container);
                      }, template: function childNameTemplate(dataItem) {
                          var result = "<span>" + dataItem.ChildName + "</span>";
                          return result += "<input data-text='" + dataItem.ChildName + "' value='" + dataItem.ChildName + "' valid='requireAndNotEmpty' type='hidden' name='" + dataItem.id + "ChildName'/>";
                      }
                  },
                  {
                      field: "Child_ID", width: '8em', title: "מספר זהות", editable: true, template: function childIdTemplate(dataItem) {
                          var result = "<span>" + normalId(dataItem) + "</span>";
                          if (global.isNOE(dataItem.ChildBirthDate) || Date.parse(dataItem.ChildBirthDate) > years19AgoFirstDate || dataItem.isNewData) {
                              result += "<input data-text='" + dataItem.Child_ID + "' value='" + dataItem.Child_ID + "' valid='requireAndNotEmpty;isDigit;isValidID;firstCustom' type='hidden' name='" + dataItem.id + "Child_ID' />";
                          }
                          else {
                              result += "<input data-text='" + dataItem.Child_ID + "' value='" + dataItem.Child_ID + "' type='hidden' name='" + dataItem.id + "Child_ID' />";
                          }
                          return result;
                      }
                  },
                  {
                      field: "ChildBirthDate", title: "תאריך לידה", editable: true,
                      template: function ChildBirthDateTemplate(container) { return datePickerTemplate(container, "ChildBirthDate") },
                      editor: function ChildBirthDateEditor(container, options) { return datePickerEditor(container, options, true); }
                  },
                ]
            });


            acceptCreditsGridElement = $("#acceptCredits");
            acceptCounter = globalDataObject.gridsData.acceptCreditsData.length;
            var dsAccepts = new kendo.data.DataSource({
                data: globalDataObject.gridsData.acceptCreditsData,
                transport: {
                    read: function (o) { o.success(globalDataObject.gridsData.acceptCreditsData); },
                    create: function (o) {
                        var item = o.data;
                        item.id = acceptCounter++;
                        o.success(item);
                    },
                    update: function (o) {
                        o.success();
                    },
                    destroy: function (o) { o.success(); }
                },
                schema: {
                    model: {
                        id: 'id',
                        fields: {
                            check_row: { editable: false },
                            ChildName: {
                                type: "string", editable: true
                            },
                            Child_ID: {
                                type: "string", editable: true
                            },
                            ChildBirthDate: {
                                type: "string", editable: true, validation: {
                                    requireAndNotEmpty: validator.requireAndNotEmpty
                                }

                            }
                        }
                    }
                },

            });
            acceptCreditsGridElement.kendoGrid({
                dataSource: dsAccepts,
                pageable: false,
                editable: {
                    confirmation: false,
                },
                dataBound: function (e) {
                    try {
                        addEventAfterBindAcceptCredits(e);
                    }
                    catch (err) {
                        global.treatError(err);
                    }
                },
                edit:
                    function (e) {
                        if (e.container.closest("tr").hasClass("customNotEditable")) {
                            e.sender.closeCell();
                            e.container.addClass("k-state-focused");
                            e.container.focus();
                            return;
                        }
                        var control = $("[name='Child_ID']", e.container);
                        control.attr('maxlength', '9');
                        control.attr('data-minLength', '5');
                        control.blur(function () {
                            var input = $(this);
                            if (input[0].value.length >= 5) {
                                while (input[0].value.length < 9) {
                                    input[0].value = '0' + input[0].value;
                                }
                            }
                            e.model.Child_ID = input[0].value;
                        });
                        control.keypress(function (e) {
                            var key = window.event ? event.keyCode : event.which;
                            if (event.keyCode == 8 || event.keyCode == 46
                                || event.keyCode == 37 || event.keyCode == 39) {
                                return true;
                            }
                            else if (key < 48 || key > 57) {
                                return false;
                            }
                            else return true;
                        });
                        var control1 = $("[name='Child_Name']", e.container);
                        control1.blur(function () {
                            var input = $(this);
                            e.model.Child_Name = input[0].value;
                        });
                        //var dateMask = global.cache.get(global.enums.cacheItems.DATE_FORMAT).replace(/[a-zA-Z]/g, "9")
                        //$('[name = ChildBirthDate]').mask(dateMask);
                    }
                ,
                navigatable: true,
                columns: [
                  { field: "check_row", width: '40px', title: "<input id='acceptCheckAll', type='checkbox', class='check_row headerbox' />", template: "<input type='checkbox' class='check_row checkbox' />" },
                  {
                      field: "ChildName", title: "שם", editor: function childNameEditor(container) {
                          $('<input name="ChildName" class="k-input k-textbox" type="text" data-bind="value:ChildName" maxlength="50"/>').appendTo(container);
                      }, template: function childNameTemplate(dataItem) {
                          var result = "<span>" + dataItem.ChildName + "</span>";
                          return result += "<input data-text='" + dataItem.ChildName + "' value='" + dataItem.ChildName + "' valid='requireAndNotEmpty' type='hidden' name='" + dataItem.id + "ChildName'/>";
                      }
                  },
                  {
                      field: "Child_ID", width: '8em', title: "מספר זהות", editable: true, template: function childIdTemplate(dataItem) {
                          var result = "<span>" + normalId(dataItem) + "</span>";
                          if (global.isNOE(dataItem.ChildBirthDate) || Date.parse(dataItem.ChildBirthDate) > years19AgoFirstDate || dataItem.isNewData) {
                              result += "<input data-text='" + dataItem.Child_ID + "' value='" + dataItem.Child_ID + "' valid='requireAndNotEmpty;isDigit;isValidID;firstCustom' type='hidden' name='" + dataItem.id + "Child_ID' />";
                          }
                          else {
                              result += "<input data-text='" + dataItem.Child_ID + "' value='" + dataItem.Child_ID + "' type='hidden' name='" + dataItem.id + "Child_ID' />";
                          }
                          return result;
                      }
                  },
                  {
                      field: "ChildBirthDate", title: "תאריך לידה", editable: true,
                      template: function ChildBirthDateTemplate(container) { return datePickerTemplate(container, "ChildBirthDate") },
                      editor: function ChildBirthDateEditor(container, options) { return datePickerEditor(container, options, true); }
                  },
                ]
            });
            //#endregion
            global.displaySpin(false);
        });

    }

    function normalId(dataItem) {
        value = dataItem["Child_ID"] + "";
        if (value.length >= 1 && value.length < 9) {
            while (value.length < 9) {
                value = '0' + value;
            }
        }
        dataItem["Child_ID"] = value;
        return value;
    }

    function datePickerTemplate(dataItem, fieldName, newDateFormat, className) {
        className = global.isNOE(className) ? '' : className;
        var value = ParseDateFormat(dataItem, fieldName, newDateFormat);
        var displayedValue = value != "" ? value : "&nbsp";
        return '<div class ="editable-cell"> <span class="' + className + '">' + displayedValue + '</span>' + '<img class="editable-cell-img floutR" src="' + global.imagesManager.sm_calandar + '"/>' + '</div>';
    }

    function datePickerEditor(container, options, isRequired) {

        var required = isRequired == true ? 'required' : '';

        $('<input ' + required + ' name="' + options.field + '" value="' + new Date(options.model[options.field]) + '"/>')
        .appendTo(container).kendoDatePickerWidget({
            change: function (e) {
                if (!global.isNOE(e.sender._value)) {
                    var returnedVal = e.sender._value.clearTime();
                    options.model[options.field] = returnedVal.toString("yyyy-MM-ddTHH:mm:ss");
                }
                else {
                    e.sender.element[0].value = "";
                }
            }, minDate: ko.observable(),
            maxDate: ko.observable(),
            disableDates: ko.observableArray([]),
            format: dateFormat
        })
         .kendoMaskedTextBox({
             mask: maskDate
         });
        $('<span data-for="' + options.field + '" class="k-invalid-msg"></span>').appendTo(container);
    }

    function ParseDateFormat(container, nameField, newDateFormat) {

        var dateFormatVM = dateFormat
        if (newDateFormat)
            dateFormatVM = newDateFormat;
        if (!nameField || !container[nameField])
            return "";
        if (container[nameField] instanceof Date)
            return kendo.toString(container[nameField], dateFormatVM);
        return kendo.toString(Date.parse(container[nameField].substring(0, 19)/*removing from string timezone like -7:00*/), dateFormatVM);
    }

    function keydownSelectRow(gridId) {

        $("#" + gridId + " > .k-grid-content > table").on("keydown", function selectRowKeyDown(ke) {
            try {
                var kGrid, curRow, newRow, curGrid;
                kGrid = $(this).closest('.k-grid').data("kendoGrid");

                curGrid = $("#kid").data("kendoGrid");
                newRow = $(".k-state-focused").closest("tr");
                if (!newRow.length)
                    return;

                //get newRow up or down.
                if (ke.which == 38) {
                    curRow = newRow.next();
                } else if (ke.which == 40) {
                    curRow = newRow.prev();
                } else if (ke.which == 9) {
                    var currentCell = $("#" + gridId + " _active_cell");
                    var cellfirst = currentCell.prev();
                    if (cellfirst && cellfirst.length > 0) {
                        curGrid.closeCell();
                        curGrid.editCell($(cellfirst));
                        cellfirst.focus();
                        curGrid.current(cellfirst);
                    }
                    return true;
                }
                else {
                    return;
                }
                return;
            }
            catch (err) {
                global.treatError(err);
            }
        });
    }

    function addEventAfterBind(e) {
        addFeaturesAfterGridBound();
        setChildrenOver19YearsReadonly();
        checkIfContainChildrenForCredits();
    }

    function addFeaturesAfterGridBound(gridId) {
        var objGridElement = null;
        switch (gridId) {
            case "rejectCredits":
                objGridElement = rejectCreditsGridElement;
                break;
            case "acceptCredits":
                objGridElement = acceptCreditsGridElement;
                break;
            default://kid
                objGridElement = kidGridElement;
                globalDataObject.composeComplete(true);
                var grid = kidGridElement.data("kendoGrid")
                // grid.tbody.on("change", ".ChildState1", function (e) {
                grid.tbody.on("change", "input", function (e) {
                    var row = $(e.target).closest("tr");
                    var item = grid.dataItem(row);
                    if ($(e.target).attr('type') == 'text') {
                        if (global.isNullOrEmpty($(e.target).val())) {
                            row.find("input.ChildState1").attr('disabled', 'disabled');
                            row.find("input.ChildState2").attr('disabled', 'disabled');
                        }
                        else {
                            if (row.find("input.ChildState1").attr('disabled') == 'disabled') {
                                if (!global.isNullOrEmpty(row.find("input[name=ChildName]").val()) &&
                                     !global.isNullOrEmpty(row.find("input[name=Child_ID]").val()) &&
                                          !global.isNOE(row.find("input[name=ChildBirthDate]").val()))
                                    row.find(".ChildState1").removeAttr('disabled')
                            }
                        }
                    }
                    else if ($(e.target).attr('name') == 'ChildState1') {
                        item.ChildState1 = $(e.target).is(":checked") ? 1 : 0;
                        if (!item.ChildState1)
                            row.find(".ChildState2").attr('disabled', 'disabled')
                        else
                            row.find(".ChildState2").removeAttr('disabled')
                    }
                    else if ($(e.target).attr('name') == 'ChildState2') {
                        item.ChildState2 = $(e.target).is(":checked") ? 1 : 0;
                    }
                });
                break;
        }
        //adding event for all grids
        objGridElement.on("change", ".check_row", function selectRow(e) {
            try {
                var element = $(e.target);

                if (element.hasClass("headerbox")) {

                    if (this.checked) {
                        $("#" + e.delegateTarget.attributes["id"].value).find("tr").addClass("k-state-selected");
                        $("#" + e.delegateTarget.attributes["id"].value).find(".checkbox").prop("checked", true);
                    }
                    else {
                        $("#" + e.delegateTarget.attributes["id"].value).find("tr").removeClass("k-state-selected");
                        $("#" + e.delegateTarget.attributes["id"].value).find(".checkbox").prop("checked", false);
                    }
                }
            }
            catch (err) {
                global.treatError(err);
            }
        });
        addTooltip();
        objGridElement.data("kendoGrid").thead.kendoTooltip({
            filter: "th:not(:empty):not(:has(input))",
            content: function headerTooltipContent(e) {
                try {
                    var target = e.target; // element for which the tooltip is shown
                    if (target.find("img").length > 0) {
                        if (!global.isNullOrEmpty(target.find("img").attr("alt")))
                            return target.find("img").attr("alt");
                    }
                    return $(target).text();
                }
                catch (err) {
                    global.treatError(err);
                }
            }
        });
        keydownSelectRow(gridId);
    }

    function setChildrenOver19YearsReadonly() {
        //this solution makes all rows editable / not editable initially
        var grid = kidGridElement.data("kendoGrid");
        var data = grid.dataSource.view();
        var $grid = grid.tbody;
        for (var i = 0; i < data.length; i++) {
            if ((!global.isNOE(data[i].ChildBirthDate)) && Date.parse(data[i].ChildBirthDate) < years19AgoFirstDate && !data[i].isNewData) {
                data[i].isReadonly = true;
                var classToAdd = 'customNotEditable RORow'
                $grid.find("tr[data-uid='" + data[i].uid + "']").addClass(classToAdd);
            }
        }
    }

    //#region addEventAfterBind for credits grids
    function addEventAfterBindRejectCredits(e) {
        addFeaturesAfterGridBound("rejectCredits");
    }

    function addEventAfterBindAcceptCredits(e) {
        addFeaturesAfterGridBound("acceptCredits");
    }
    //#endregion
    function add(e, obj) {
        var grid = $("#" + $(obj.currentTarget)[0].attributes["data-gridID"].value).data("kendoGrid");
        if (!global.isNOE(grid)) {
            if (grid.dataSource.hasChanges()) {
                grid.one("dataBound", function (e) {
                    setTimeout(function () { grid.addRow(); });
                });
                grid.saveChanges();
            } else {
            	grid.addRow();            	
            }
            var childrenCount = kidGridElement.data().kendoGrid._data.length;
            vm.data().Unit_C().ChildrenCount(childrenCount);
        }
    }

    function deleteRows(e, obj) {
        var gridId = $(obj.currentTarget)[0].attributes["data-gridID"].value;
        var checked = $('#' + gridId + ' :checkbox:checked');

        if (gridId != "kid") {
            $.each(checked.closest('tr'), function (index, value) {
                if (checked[index].className.indexOf("check_row checkbox")!=-1) {
                    var objDataInCurGrid = $.grep($('#' + gridId).data().kendoGrid.dataSource.view(), function (e) { return e.uid == $.grep(value.attributes, function(l){return l.name == "data-uid"})[0].value; })[0];
                    if (!global.isNOE(objDataInCurGrid) && !global.isNOE(kidGridElement.data("kendoGrid")._data[objDataInCurGrid.ChildIndex]))
                        kidGridElement.data("kendoGrid")._data[objDataInCurGrid.ChildIndex].CreditRequsetStatus = global.enums.requestStatus.None;//clear CreditRequsetStatus value to None, in kidsgrid
                }
            });
        }
        $.each(checked.closest('tr'), function (index, value) {
            if (checked[index].className.indexOf("check_row checkbox")!=-1) {
                $('#' + gridId).data().kendoGrid.removeRow($(this));
            }
        });
        if ($("#" + gridId).find(".headerbox").is(":checked")) {
            $("#" + gridId).find(".headerbox").prop("checked", false);
        }
        var childrenCount = kidGridElement.data().kendoGrid._data.length;
        vm.data().Unit_C().ChildrenCount(childrenCount);
    }

    function init(context, dataObject) {
        var uploadSupportType = new Array("*.pdf", "*.jpg");
        customIsModified = false;
        kidGridWasModified = false;
        dataObject.composeComplete(false);
        vm.data(dataObject.data);
        globalDataObject = dataObject;
        sourceData = [];
        for (var i = 0; i < globalDataObject.gridsData.childrenData.length; i++) {
            var object = {};
            $.each(globalDataObject.gridsData.childrenData[i], function copyProp(name, value) {
                object[name] = value;
            });
            sourceData[i] = object;
        }

        form101params = {
            TaxYear: context.xTaxYear,
            Emp_no: context.xEmpNo,
            Version: context.xVerNo
        };

    }


    function setDataForSaving() {
        vm.rejectIsValid(true);
        vm.acceptIsValid(true);
        if (global.isNull(kidGridElement)) {
            return;
        }
        var kidGrid = kidGridElement.data("kendoGrid");
        kidGrid.saveChanges();
        var data = kidGrid._data;

        if (sourceData.length != data.length) {
            customIsModified = true;
            kidGridWasModified = true;
        }
        else {
            for (var i = 0; i < sourceData.length; i++) {
                if (sourceData[i].Child_ID.length >= 5 && sourceData[i].Child_ID.length < 9) {
                    while (sourceData[i].Child_ID.length < 9) {
                        sourceData[i].Child_ID = '0' + sourceData[i].Child_ID;
                    }
                }
                if (data[i].Child_ID != sourceData[i].Child_ID ||
                    data[i].ChildState1 != sourceData[i].ChildState1 ||
                    data[i].ChildState2 != sourceData[i].ChildState2 ||
                    data[i].ChildName != sourceData[i].ChildName ||
                    data[i].ChildBirthDate != sourceData[i].ChildBirthDate) {
                    customIsModified = true;
                    kidGridWasModified = true;
                    break;
                }
            }
        }

        //check validation of credts grid and set data field CreditRequsetStatus in kidGrid
        var validStatus = false;
        $.each(rejectCreditsGridElement.data('kendoGrid')._data, function loopOverRejectGrid(index, row) {
            validStatus = false;
            $.each(kidGridElement.data('kendoGrid')._data, function loopOverChildGrid(index2, row2) {
            	if (row.Child_ID == row2.Child_ID && row.ChildName == row2.ChildName && row.ChildBirthDate == row2.ChildBirthDate && (Date.parse(row.ChildBirthDate).getFullYear() >= 2017)) {
                    data[index2].CreditRequsetStatus = global.enums.requestStatus.Reject;
                    row.ChildIndex = index2;
                    validStatus = true;
                    return;
                }
            });
            if (!validStatus) {
                vm.creditsInvalidMsg(global.resMsg['568']);
                vm.rejectIsValid(false);
            }
        });

        $.each(acceptCreditsGridElement.data('kendoGrid')._data, function loopOverAcceptGrid(index, row) {
            validStatus = false;
            $.each(kidGridElement.data('kendoGrid')._data, function loopOverChildGrid2(index2, row2) {
                if (row.Child_ID == row2.Child_ID && row.ChildName == row2.ChildName && row.ChildBirthDate == row2.ChildBirthDate && (Date.parse(row.ChildBirthDate).getFullYear() >= 2017)) {
                    data[index2].CreditRequsetStatus = global.enums.requestStatus.Accept;
                    row.ChildIndex = index2;
                    validStatus = true;
                    return;
                }
            });
            if (!validStatus)
                vm.acceptIsValid(false);
        });

        if (vm.needShowCreditsContent() && rejectCreditsGridElement.data('kendoGrid')._data.length == 0 && acceptCreditsGridElement.data('kendoGrid')._data.length == 0)
            vm.data().Unit_C().ApproveCredits(false);

        if (!vm.needShowCreditsContent()) {
            rejectCreditsGridElement.data('kendoGrid')._data = [];
            acceptCreditsGridElement.data('kendoGrid')._data = [];
            vm.data().Unit_C().ApproveCredits(false);
            vm.acceptIsValid(true);
            vm.rejectIsValid(true);
        }

        var childrenNotInHold = 0;
        var childrenInHoldAndAcceptPension = 0;
        var childrenInHold = 0;
        var childrenCount = kidGridElement.data().kendoGrid._data.length;
        vm.data().Unit_C().ChildrenCount(childrenCount);
        if (childrenCount > 0) {

            $.each(data, function (index, row) {
                if (row.ChildState1 == false) {
                	childrenNotInHold++;
                	if (row.ChildState2 == true) {
                		childrenInHoldAndAcceptPension++;
                	}
                }
                if (row.ChildState1 == true) {
                    childrenInHold++;
                    if (row.ChildState2 == true) {
                        childrenInHoldAndAcceptPension++;
                    }
                }
            });
        }

        vm.data().Unit_C().ChildrenNotInHold(childrenNotInHold);
        vm.data().Unit_C().ChildrenInHold(childrenInHold);
        vm.data().Unit_C().ChildrenInHoldAndAcceptPension(childrenInHoldAndAcceptPension);
        globalDataObject.gridsData.childrenData = data;
        globalDataObject.gridsData.rejectCreditsData = rejectCreditsGridElement.data('kendoGrid')._data;
        globalDataObject.gridsData.acceptCreditsData = acceptCreditsGridElement.data('kendoGrid')._data;
        globalDataObject.gridsData.isChildenGridChanged = customIsModified;

        if (kidGridWasModified) {   //incase children have been changed - delete employeeId attachment
            if(!global.isNOE(vm.data().Unit_B().Employee_ID_Attachment().Id()))
                form101Helper.removeSpecFileFromDbByID({ attachedId: vm.data().Unit_B().Employee_ID_Attachment().Id(), TaxYear: form101params.TaxYear, Emp_no: form101params.Emp_no, Version: form101params.Version });
            vm.data().Unit_B().Employee_ID_Attachment().Id(null);
            vm.data().Unit_B().Employee_ID_Attachment().Name(null);
        }       
    }

    function forceDependenceRules() {
        if ((vm.data().Unit_B().Sex() == 0)) {//Male

            if (vm.data().Unit_C().ChildrenInHoldAndAcceptPension() > 0) {
                //check if need to uncheck unit_h, part 8
                if (vm.data().Unit_B().MaritalStatus() != 2 &&//not married
                    vm.data().Unit_H().Unit_H_7() == true) {
                    vm.data().Unit_H().Unit_H_8(false);
                }
            }

            else {//need to uncheck unit_h, part 7

                vm.data().Unit_H().Unit_H_7(false);
            }
        }
        if (vm.data().Unit_C().ChildrenInHoldAndAcceptPension() == 0) {
            //need to uncheck unit_h, part 6
            vm.data().Unit_H().Unit_H_6(false);
        }

        if (vm.data().Unit_C().ChildrenInHold() == 0) {
            vm.data().Unit_H().Unit_H_7(false);
            vm.data().Unit_H().Unit_H_9(false);
        }
        if (vm.data().Unit_C().ChildrenCount() == 0) {
            vm.data().Unit_H().Unit_H_8(false);
            vm.data().Unit_H().Unit_H_30(false);
        }
        if (vm.data().Unit_C().ChildrenNotInHold() == 0) {
            vm.data().Unit_H().Unit_H_10(false);
        }

        //if ((vm.data().Unit_H().Unit_H_7() || vm.data().Unit_B().Sex() == 1)
        //    && (vm.data().Unit_B().Sex() == 0 || vm.data().Unit_B().MaritalStatus() == 2 || !vm.data().Unit_C().HasChildrenNotInHold())
        //    && !vm.data().Unit_H().Unit_H_9()) {
        //    vm.data().Unit_H().Unit_H_8(false);
        //}


    }

    function isValid() {
        if (global.isNull(kidGridElement)) {
            return true;
        }
        //check validation of children grid
        if (!validator.onSetValidate("kid", { requireMessage: global.res['4556'], isDigitMessage: global.resMsg['361'], validFormatMessage: global.resMsg['404'], minLengthMeassage: global.resMsg['361'], greaterThenOtherDateMessage: global.res['4586'], firstCustomMessage: global.resMsg['369'] }, [isDuplicateId], ['data-isduplicateid-msg'])) {
            return false;
        }

        //in case reject&accepts are not visible - no valid errors
        if (!vm.needShowCreditsContent())
            return true;
        //otherwise - need to check validation on reject&accept grids
        if (!vm.rejectIsValid() || !vm.acceptIsValid()) {
            return false;
        }

        if ((rejectCreditsGridElement.data('kendoGrid')._data.length > 0 || acceptCreditsGridElement.data('kendoGrid')._data.length > 0) && !vm.data().Unit_C().ApproveCredits()) {
            vm.approveCredits(false);
            return false;
        }
        else
            vm.approveCredits(true);

        //check if exists same child in both reject&accept grids - that invalid
        var isDuplicate = false;
        if ((rejectCreditsGridElement.data('kendoGrid')._data.length > 0 && acceptCreditsGridElement.data('kendoGrid')._data.length == 0)
            || (rejectCreditsGridElement.data('kendoGrid')._data.length == 0 && acceptCreditsGridElement.data('kendoGrid')._data.length > 0))
            return true;
        $.each(rejectCreditsGridElement.data('kendoGrid')._data, function loopOverRejectGrid(index, row) {
            var result = Enumerable.From(acceptCreditsGridElement.data('kendoGrid')._data).Where(function (el) {
                return el.ChildBirthDate == row.ChildBirthDate && el.ChildName == row.ChildName && el.Child_ID == row.Child_ID
                }).Select(function (el) { return el }).FirstOrDefault();
            
            if (!global.isNOE(result)) {
                isDuplicate = true;
                return;
            }
        });
        if (isDuplicate) {
            vm.creditsInvalidMsg(global.resMsg['569']);
            vm.rejectIsValid(false);
            return false;
        }
        return true;
    }

    function addTooltip(name) {
        if (!global.isNull(name))
            name = "td[" + name + "]:not(:empty)";
        else
            name = "td:not(:empty):not(:has(input)):not(:has(img[src='" + global.imagesManager.addNote + "'])):not(:has(p))";
        var tooltip = $("#kid").kendoTooltip({
            filter: name,
            width: 120,
            position: "top",
            content: function contentContent(e) {
                try {
                    var elem = $(e.target);
                    if (elem.text() != "" && elem.text() != ' \xa0' && elem.text() != '\xa0'
                        && elem.text().replace(/\s/g, '').length > 0 && elem[0].offsetWidth < elem[0].scrollWidth)
                        return elem.text();

                    if (elem.find("img:not(.editable-cell-img)").length > 0) {
                        if (!global.isNullOrEmpty(elem.find("img").attr("alt")))
                            return elem.find("img").attr("alt");
                    }
                    // replace the popup that was created with a stub so _show doesn't break
                    tooltip.popup = {
                        open: function () { },
                        one: function () { },
                        close: function () { },
                        options: {}
                    };

                    // delete the popup stub
                    setTimeout(function () {
                        tooltip.popup = null;
                    }, 5);
                }
                // }
                catch (err) {
                    global.treatError(err);
                }
            }
        }).data("kendoTooltip");
    }

    function isDuplicateId(input) {
        input.attr('data-isduplicateid-msg', global.resMsg['369']);
        var isValid = true;
        if (!global.isNullOrEmpty(input[0].value)) {
            var currentRow = validator.getCurrentRowByField(input);
            $.each(kidGridElement.data('kendoGrid')._data, function checkIsDuplicate(index, row) {
                if (row.Child_ID == input[0].value && row.uid != currentRow.uid) {
                    isValid = false;
                    return false;//break loop
                }
            });
        }
        return isValid;
    }

    //#region credits
    function checkIfContainChildrenForCredits() {
        vm.needShowCreditsContent(false);
        $.each(kidGridElement.data('kendoGrid')._data, function checkIsChildInSpecificYears(index, row) {
            if (!global.isNOE(row.ChildBirthDate) && !global.isNOE(Date.parse(row.ChildBirthDate)) && (Date.parse(row.ChildBirthDate).getFullYear() >= 2017)) {
                vm.needShowCreditsContent(true);
                return;
            }
        });
    }

    function needShowUserCreditsContentBeforeNextOccurs() {
        if (vm.creditsContentAndNextOccursFlag()) {
            vm.creditsContentAndNextOccursFlag(false);
            return false;
        }
        checkIfContainChildrenForCredits();
        if (globalDataObject.gridsData.rejectCreditsData.length == 0 && globalDataObject.gridsData.acceptCreditsData.length == 0 && vm.needShowCreditsContent() == true) {
            //this 101 has shown credits content for first time
            vm.creditsContentAndNextOccursFlag(true);
            return true;
        }
        else
            return false;
    }
    //#endregion

    var vm = {
        compositionComplete: compositionComplete,
        add: add,
        init: init,
        isValid: isValid,
        deleteRows: deleteRows,
        global: global,
        setDataForSaving: setDataForSaving,
        data: ko.observable(null),
        forceDependenceRules: forceDependenceRules,
        addTooltip: addTooltip,
        needShowCreditsContent: ko.observable(false),
        needShowUserCreditsContentBeforeNextOccurs: needShowUserCreditsContentBeforeNextOccurs,
        creditsContentAndNextOccursFlag: ko.observable(false),
        rejectIsValid: ko.observable(true),
        acceptIsValid: ko.observable(true),
        approveCredits: ko.observable(true),
        creditsInvalidMsg: ko.observable('')
    };
    return vm;
});

