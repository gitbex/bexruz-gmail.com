﻿$.widget("custom.kendoDatePickerWidget", {

    _setOption: function (key, value) {
        this.options[key] = value;
    },
    _create: function () {
        this.element.kendoDatePicker({
            format: this.options["format"],
            min: this.options["minDate"](),
            max: this.options["maxDate"](),
            dates: this.options["disableDates"](),
            close: this.options["close"],
            change: this.options["change"],
            month: {
                content: this.options["content"]
            },
        }).kendoTooltip({ content: this.options["format"] });
        ;
    }
});

$.widget("custom.kendoTimePickerWidget", {
    _setOption: function (key, value) {
        this.options[key] = value;
    },
    _create: function () {

        var maskOptions = {
            onComplete: this.options["onComplete"],
            onKeyPress: this.options["onKeyPress"],
            onInvalid: this.options["onInvalid"],
            'translation': {
                H: { pattern: /[0-2]/, optional: true },
                M: { pattern: /[0-9]/, optional: true },
                S: { pattern: /[0-5]/, optional: true },
                D: { pattern: /[0-9]/ },
            },
            placeholder: this.options["formatTime"]().placeHolder
        };
       
        var element;
        if (this.element[0].nodeName == "DIV")
        {
            element = this.element.find('input')[0];
        }
        else {
            element = this.element[0];
        }
        $(element).attr("type", "text").addClass("timeInput widgetTimeInput").mask(this.options["formatTime"]().maskFormat, maskOptions);
        $(element).bind("focusout.timeInput", this.options["exit"]).bind("keypress.timeInput", this.options["onEnter"]);
        return this;
    }
});

$.widget("custom.kendoSimpleComboWidget", {

    _setOption: function (key, value) {
        this.options[key] = value;
    },
    _create: function () {
        this.element.kendoDropDownList({
            dataSource: this.options["data"],
            dataValueField: this.options["itemValue"],
            optionLabel: this.options["optionLabel"](),
            dataTextField: this.options["isComboInETableGrid"] == true ?
                this.options["itemText"] : this.options["itemSimpleText"],
            template: this.options["template"],
            change: this.options["onChange"],
            dataBound: this.options["dataBound"],
        });
    }
});


$.widget("custom.kendoAutoCompleteWidget", {

    _setOption: function (key, value) {
        this.options[key] = value;
    },
    _create: function () {
        this.element.kendoComboBox({
            dataSource: this.options["data"](),
            dataValueField: this.options["itemValue"],
            dataTextField: this.options["itemText"],
            filter: 'contains',
            suggest: true,
            minLength: 1,
            template: this.options["template"],
            dataBound: this.options["dataBound"],
            change: this.options["onChange"]
        });
        //display button for lookup screen, and add its functionality
        if (this.options["needOpenLookupScreen"]() == true) {
            (this.element).after('<input id="btn' + this.options["comboId"]() + '"  class="btnMore height21" type="button" value="..."  />');
            $("#btn" + this.options["comboId"]())[0].onclick = this.options["openLookupScreen"];
        }
    }
});

$.widget("custom.kendoAutoCompleteETableWidget", {

    _setOption: function (key, value) {
        this.options[key] = value;
    },
    _create: function () {
        this.element.kendoComboBox({
            dataSource: this.options["data"](),
            dataValueField: this.options["itemValue"],
            dataTextField: this.options["itemText"],
            filter: 'contains',
            suggest: true,
            minLength: 1,
            template: this.options["template"],
            change: this.options["onChange"],
            dataBound: this.options["dataBound"]
        });
        if (this.options["needEtableButton"]() == true) {
            (this.element).parent().parent().append('<input id="btn' + this.options["comboId"]() + '"  class="btnMore height0_9em marginBottom0" type="button" value="..."  />');
            $("#btn" + this.options["comboId"]())[0].onclick = this.options["openETableScreen"];
        }
    }
});

$.widget("custom.kendoSimpleComboETableWidget", {

    _setOption: function (key, value) {
        this.options[key] = value;
    },
    _create: function () {

        this.element.kendoDropDownList({
            dataSource: this.options["data"],
            dataValueField: this.options["itemValue"],
            optionLabel: this.options["optionLabel"](),
            dataTextField: this.options["isComboInETableGrid"] == true ?
                this.options["itemText"] : this.options["itemSimpleText"],
            template: this.options["template"],
            change: this.options["onChange"],
            dataBound: this.options["dataBound"],
        });

        (this.element).after('<input id="btn' + this.options["comboId"]() + '"  class="btnMore height21" type="button" value="..."  />');
        $("#btn" + this.options["comboId"]())[0].onclick = this.options["openETableScreen"];
    }
});

$.widget("custom.multySelect", {

    _setOption: function (key, value) {
        this.options[key] = value;
    },
    _create: function () {

        this.element.multySelect({
            selectedCodes: this.options["selectedCodes"],
            dataValueField: this.options["itemValue"],
            optionLabel: this.options["optionLabel"](),
            dataTextField: this.options["isComboInETableGrid"] == true ?
                this.options["itemText"] : this.options["itemSimpleText"],
            template: this.options["template"],
            change: this.options["onChange"],
            dataBound: this.options["dataBound"],
        });

        (this.element).after('<input id="btn' + this.options["comboId"]() + '"  class="btnMore height21" type="button" value="..."  />');
        $("#btn" + this.options["comboId"]())[0].onclick = this.options["openETableScreen"];
    }
});