﻿define(function webApiConfigModule() {
    var port = window.location.pathname;
    var href = window.location.href;
    var prefixPath = (port.lastIndexOf('/') == port.length - 1) ? "api/" : "/api/";

    function getApiPath(httpPathParameter) {
        /*port :can be changed to other site in IIS of server*/
        return port + prefixPath + httpPathParameter;
    }

    function getHostPath() {
        return window.location.protocol + '//' + window.location.host;
    }

    return {
        getApiPath: getApiPath,
        getHostPath: getHostPath,
        port: port,
        href: href
    };
});