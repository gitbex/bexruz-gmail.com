﻿define(function errorManagerModule(require) {
    var http = require('plugins/http');
    var webApiConfig = require('common/webApiConfig');
    var enums = require('common/enums/enums');
    var helper = require('common/helper');
    var dialogManager = require('common/dialogManager');
    var messageWindow = true;
    var app = require('durandal/app');

    var module = {
        displaySpin: null,//get value by global
        clientErrorWithnoClientPropt: function (err) {
            http.post(webApiConfig.getApiPath(enums.httpPath.TreatClientError.path), { Msg: err });
        },
        //Extroverted just for initiate client-side errors
        errorOccured: function (message) {
            alert(message);
            http.post(webApiConfig.getApiPath(enums.httpPath.TreatClientError.path), { Msg: error })
        },
        treatError: treatError

    };
    function treatError(err, errorSender) {
        var shortMessage = "";
        try {
            module.displaySpin(false);
            shortMessage = err.message;
            message = err.stack;
            exType = enums.exceptionTypes.Regular;
            if (helper.isNull(message)) {//error not have stack
                message = err.message;//DOMerror, etc.
                if (helper.isNull(message)) {
                    try{
                        var errorInJson = JSON.parse(err);
                        exType = errorInJson.ExType;
                        shortMessage = errorInJson.ErrorMessage || errorInJson.Message;
                        message = errorInJson.InnerException || errorInJson.MessageDetail;
                    } catch (ex1) //err is simple string
                    {
                        shortMessage = err;
                    }
                    
                }
            }
        }
        catch (e) {
            message = err;
        }
        if (!helper.isNOE(err) && !helper.isNull(err.entityErrors) && !helper.isNull(err.entityErrors[0])) {//if it is breeze-saving error, need retrive error-message correctly
            message = err.entityErrors[0].errorMessage;
            errorSender = enums.errorSender.SERVER;
        }
        if (errorSender != enums.errorSender.SERVER) {//if error is from server- not need to write it to log again
            try {
                http.post(webApiConfig.getApiPath(enums.httpPath.TreatClientError.path), { Msg: message })
                .fail(function (e) { });
            }
            catch (e) { }
        }
        //don't change it must stay connected to custom exception in CacheManager.cs
        var sessionIdNull = "the sessionId is null in cache manager";
        if (shortMessage != null)
            if (shortMessage.indexOf(sessionIdNull) > -1) {
                app.trigger(enums.events.FORCED_SESSION_LOGOUT.name);
            }

        require(
                 ['views/combinedControls/customMessageWindow/customMessageWindow'],
                 function showPopupAfterRequirePopupModule(customMessageWindow) {
                     if (messageWindow == true) {
                         customMessageWindow.buildMessage({ mode: enums.messageType.error, messageText: shortMessage, btnsMode: !helper.isNOE(err) && err.logOut ? enums.btnsMode.logOutOk : null, detailsArray: message, exceptionType: exType });
                         var dialogPromise = dialogManager.showDialog(customMessageWindow);
                         messageWindow = false;
                         dialogPromise.then(function customMessageCloseResult(resp) {
                             messageWindow = true;
                         });
                     }
                 });



    }
    //client error
    window.onerror = function (message, file, line, colno, error) {
        var errMsg;
        var err2User='';
        if (error) {
            // be care, stack it's different for each browser!
            errMsg = error.stack;
            
            var browser = navigator.userAgent.toLowerCase();
            var UrlFirst = '';
            var re = new RegExp(/^.*\//);

            // get 1st URL string from stack like http://127.0.0.1/eHarmonyDev/App/views/maintenance/communication/communicationParams/popupTabs/generalTab.js?v=1.0.8.70:48:17)
            if (browser.indexOf('firefox') > -1)
                UrlFirst = errMsg.slice(errMsg.indexOf('@http'));
            else
                UrlFirst = errMsg.slice(errMsg.indexOf('(http'));

            // build url without version data (?v=1.0.xx.yy...)
            UrlFirst = UrlFirst.slice(0, UrlFirst.indexOf(')')).slice(0, UrlFirst.indexOf('?'));
            // extract file name only
            var fileName = UrlFirst.replace(/^.*(\\|\/|\:)/, ''); 

            // build final: message + "compressed" path[http://127.0.0.1/eHarmonyDev/#maintenance/.../generalTab.js]
            err2User = message + '\n' + '(' + re.exec(window.location.href) + '.../' + fileName + ')'; 
        }
        else {
            errMsg = file + ':' + line + '\n\n' + message;
        }

        try {
            http.post(webApiConfig.getApiPath(enums.httpPath.TreatClientError.path), { Msg: errMsg })
                .fail(function (e) { });
        }
        catch (e) { }
        if (err2User != null && err2User.length > 0) errMsg = err2User;
        if (error != undefined && error != null && error.stack != undefined && error.stack != "Unspecified error") 
            alert(errMsg);
        return true;
    };

    //server ajax calling error - is catched in global.js

    return module;
});