﻿define("common/global", function globalModule(require) {
    var permissions = require('common/permission');
    var enums = require('common/enums/enums');
    var cache = require('common/cache/cacheManager');
    var app = require('durandal/app');
    var http = require('plugins/http');
    var system = require('durandal/system');
    var webApiConfig = require('common/webApiConfig');
    var serverWrapper = require('common/serverWrapper');
    var imagesManager = require('common/imagesManager');
    var helper = require('common/helper');
    var consts = require('common/consts');
    var errorManager = require('common/errorManager');
    var customMessageWindow = require('views/combinedControls/customMessageWindow/customMessageWindow');
    var dialog = require('plugins/dialog');
    var dialogManager = require('common/dialogManager');
    var configurationManager = require('common/configurationManager');
    var router = require('plugins/router');
    var tempData = require('common/tempData');
    var binder = require('durandal/binder');
    var sessionTimer;
    var IsInterfaceRun;
    var GlobalQueuesInterval;

    //#region Date prototype functions

    Date.prototype.addDays = function addDays(days) {
        var dat = new Date(this.valueOf());
        dat.setDate(dat.getDate() + days);
        return dat;
    }

    Date.prototype.getWeek = function getWeek(start) {
        //Calcing the starting point
        start = start || 0;
        var currentDate = new Date(this.setHours(0, 0, 0, 0));
        var day = currentDate.getDay() - start;
        var date = currentDate.getDate() - day;

        // Grabbing Start/End Dates
        var startDate = new Date(currentDate.setDate(date));
        var endDate = startDate.addDays(6);
        return { startDate: startDate, endDate: endDate };
    }

    Date.prototype.getWeekNumber = function getWeekNumber(start) {
        start = start || 0;
        var onejan = new Date(this.getFullYear(), 0, 1);
        return Math.ceil((((this - onejan) / 86400000) + onejan.getDay() + 1 - start) / 7);
    }


    //#endregion 

    //#region string prototypes
    if (!String.prototype.repeat) {
        String.prototype.repeat = function (count) {
            'use strict';
            if (this == null) {
                throw new TypeError('can\'t convert ' + this + ' to object');
            }
            var str = '' + this;
            count = +count;
            if (count != count) {
                count = 0;
            }
            if (count < 0) {
                throw new RangeError('repeat count must be non-negative');
            }
            if (count == Infinity) {
                throw new RangeError('repeat count must be less than infinity');
            }
            count = Math.floor(count);
            if (str.length == 0 || count == 0) {
                return '';
            }
            // Ensuring count is a 31-bit integer allows us to heavily optimize the
            // main part. But anyway, most current (August 2014) browsers can't handle
            // strings 1 << 28 chars or longer, so:
            if (str.length * count >= 1 << 28) {
                throw new RangeError('repeat count must not overflow maximum string size');
            }
            var rpt = '';
            for (; ;) {
                if ((count & 1) == 1) {
                    rpt += str;
                }
                count >>>= 1;
                if (count == 0) {
                    break;
                }
                str += str;
            }
            // Could we try:
            // return Array(count + 1).join(this);
            return rpt;
        }
    }
    //#endregion

    //#region binding hendlers

    //set unique Id to the grids
    ko.bindingHandlers.uniqueId = {
        init: function (element, valueAccessor) {
            var value = valueAccessor();
            element.id = value();
        },
    };
    ko.bindingHandlers.draggable = {
        init: function (element, valueAccessor) {
            var options = valueAccessor();
            options.handle = ".modal-header, .modal-footer";
            $(element).draggable(options);
        }
    };
    ko.bindingHandlers.resizable = {
        init: function (element, valueAccessor) {
            var options = valueAccessor();
            options.stop = function (event, ui) {
                if ($("#scrollDiv").length)
                    $("#scrollDiv").height(ui.element.height() * 80 / 100);
                if ($("#CMWmodal-content").length)
                    $("#CMWmodal-content").height(ui.element.height());
            };
            $(element).resizable(options);
        }
    };
    ko.bindingHandlers.slideVisible = {
        init: function (element, valueAccessor) {
            // Initially set the element to be instantly visible/hidden depending on the value
            var value = valueAccessor();
            ko.unwrap(value) ? $(element).slideDown() : $(element).slideUp(); // Use "unwrapObservable" so we can handle values that may or may not be observable
        },
        update: function (element, valueAccessor) {
            // Whenever the value subsequently changes, slowly fade the element in or out
            var value = valueAccessor();
            ko.unwrap(value) ? $(element).slideDown() : $(element).slideUp();
        }
    };

    //#endregion

    ko.observable.fn.beforeAndAfterSubscribe = function (callback, target) {
        var _oldValue;
        this.subscribe(function (oldValue) {
            _oldValue = oldValue;
        }, null, 'beforeChange');

        this.subscribe(function (newValue) {
            callback.call(target, _oldValue, newValue);
        });
    };


    //#region ajax events

    $(document).ajaxSend(function (e, xhr, opt) {
        // convert [ <script>alert('XXX')</script> ] TO [ >alert('XXX') ]
        if (!isNOE(opt.data) && !(opt.data instanceof FormData))
            opt.data = opt.data.split("<script").join("").split("</script>").join("");
        if (!isNOE(opt.url))
            opt.url = opt.url.split("<script").join("").split("</script>").join("");
        module.isInAjax(true);
        xhr.setRequestHeader(cache.cacheItems.SESSION_ID.name, cache.get(cache.enums.cacheItems.SESSION_ID));
    });
    $(document).ajaxComplete(function ajaxComplete(e, xhr, opt) {
        if (!isNullOrEmpty(cache.get(enums.cacheItems.SESSION_ID))) {
            increaseTimer();
        }
    });

    $.xhrPool = []; // array of uncompleted requests
    //build array of request methods which are behaving as background process - should not be aborted when navigating between pages
    var httpPathProcesses = ["GetProcessNo", "GetQtyEmpByParam", "insertLogProcessInfo", "GetLogProcessInfoByProcessNo",
        "ExecuteReProcess", "PeriodProcessingWithoutIndicator",
        "AttendanceProcess", "AttendanceProcessSend2Queue", "CheckProcessEnded",
        "GlobalUpdateProcess", "GetLogProcess"];

    $.xhrPool.abortAll = function () { // our abort function
        $.each($.xhrPool, function (idx, val) {
            if (val != null && val.isProcess == 0) {  //if http method is not a background process - abort it
                val.xhr.responseText = module.initiatedError;
                val.xhr.abort();
            }
        });
    };

    $.ajaxSetup({
        // before jQuery send the request we will push it to our array
        //adding the jqXHR request with parameter osProcess - indicates whether it is a background process or not
        beforeSend: function (jqXHR, settings) {
            if (settings.url != null) {
                var url = (settings.url.lastIndexOf('?') == -1) ? settings.url.substring(settings.url.lastIndexOf('/') + 1) : settings.url.substring(settings.url.lastIndexOf('/') + 1, settings.url.lastIndexOf('?'));
                if ($.inArray(url, httpPathProcesses) != -1)    //this jqXHR is a background process
                    $.xhrPool.push({ xhr: jqXHR, isProcess: 1 });
                else
                    $.xhrPool.push({ xhr: jqXHR, isProcess: 0 });
            }
        },
        // when some of the requests completed it will splice from the array
        complete: function (jqXHR) {
            $.each($.xhrPool, function (key, val) {
                if (val != null && val.xhr == jqXHR) {
                    $.xhrPool.splice(key, 1);
                    return false;
                }
            });
        }
    });

    $(document).ajaxStop(function onAjaxStop(e, xhr, opt) {
        module.isInAjax(false);
    });
    $(document).ajaxError(function onAjaxError(e, xhr, opt) {
        var isSessionError = isSessionNullError(xhr);
        if (xhr.status == 401) {
            cache.set(enums.cacheItems.NEED_RETRIVE_COMPANY_DATA_AGAIN, true);
            //app.trigger(enums.events.LOGOUT_SHELL.name);
            window.location.reload();
        }
        else if (xhr.status == 500 && isSessionError) {
            app.trigger(enums.events.FORCED_SESSION_LOGOUT.name);
            return true;
        }
        else
            if (xhr.responseText == module.initiatedError) {
                return true;
            }
            else {
                module.treatError(xhr.responseText, enums.errorSender.SERVER);
                return true;
            }
    });
    function isSessionNullError(xhr) {
        if (xhr.responseText != null) {
            // string of error to search. identical to CacheManager.GetCurrentSession() c#
            var errorinMethod = "the sessionId is null in cache manager";
            if (xhr.responseText.indexOf(errorinMethod) > -1) {
                return true;
            }
        }
        return false;
    }

    //#endregion    

    //#region helpers functions

    function getJsonToGridHtml(arr, names) {
        if (!names.length && !arr.length)
            return "";
        var height = $(window).height() * 35 / 100;
        var str = '<div id="scrollDiv" style="overflow:auto;height:' + height + 'px"><table class="k-grid"><thead class="k-grid-header-wrap k-grid-header"><tr>';
        for (var name in names)
            str += '<th class="k-header">' + (module.dict()[names[name].Field_Dict]) + '</th>';
        str += '</tr></thead>';
        for (var p in arr) {
            str += '<tr>';
            var obj = arr[p];
            for (var name in names) {
                var nameField = names[name].Field_Name;
                if (obj.hasOwnProperty(nameField))
                    str += '<td>' + obj[nameField] + '</td>';
            }
            str += '</tr>';
        }
        str += '</table></div>';
        return str;
    }

    function calcIsChrome() {
        return navigator.userAgent.toLowerCase().indexOf('chrome') > 0;
    }
    function calcIsFireFox() {
        return navigator.userAgent.toLowerCase().indexOf('firefox') > 0;
    }
    function isRTL() {
        var language = cache.get(enums.cacheItems.LAST_LANGUAGE);
        var dir = cache.getLanguageDir(language);
        return dir.toLowerCase() == 'rtl'
    }

    //permissions
    function checkVisiblePermission(permissionCode) {
        var accessDeniedInfo = "tried to access page with " + permissionCode + " permissionCode and rejected";
        http.post(webApiConfig.getApiPath(enums.httpPath.WriteInfoToLog.path), { Info: accessDeniedInfo });
        if (permissions.isVisible(permissionCode) == false) {
            customMessageWindow.buildMessage({ mode: enums.messageType.error, messageText: module.dict()[1774] });
            dialogManager.showDialog(customMessageWindow);
            router.navigate("#home");
            return false;
        }
        return true;
    }

    //move in array  
    function arrayMove(arr, fromIndex, toIndex) {
        var element = arr[toIndex]
        arr.splice(toIndex, 1);
        arr.splice(fromIndex, 0, element);
    }

    function breezeSavingFail(mess) {
        try {
            if (!isNullOrEmpty(mess.entityErrors) && mess.entityErrors.length > 0 && !isNullOrEmpty(mess.entityErrors[0]) && !isNullOrEmpty(mess.entityErrors[0].errorMessage) && mess.entityErrors[0].errorMessage != '') {
                var error = mess.entityErrors[0].errorMessage;
                if ((!module.isNull(mess.description)) && mess.description.indexOf("Client side validation errors encountered") < 0) {
                    if (error.indexOf("errorInSaving") > 0) // 13.06.2016 show all message
                        error = error.substring(consts.breezeSavingErrorIdentify.length, error.length);
                }
                module.treatError(error, enums.errorSender.SERVER);
            }
            else {
                module.treatError(mess, enums.errorSender.SERVER);
            }
        }
        catch (err) {
            module.treatError(err);
        }
    }

    function getItemByCodeDescript(code, descript) {
        if (!isNull(code)) {
            return { Code: code, Descript: descript };
        }
        else
            return null;
    }



    function stopEvent(evt) {
        evt || window.event;
        if (evt.stopPropagation) {
            evt.stopPropagation();
            evt.preventDefault();
        } else if (typeof evt.cancelBubble != "undefined") {
            evt.cancelBubble = true;
            evt.returnValue = false;
        }
        return false;
    }

    function process(params) {
        app.trigger(enums.events.CALL_PROCESSING.name, params);
    }

    function synchronousHttpCalling(type, url, data) {

        return $.ajax({
            type: type,
            url: url,
            data: data,
            async: false
        });
    }


    function getEmptyPromise() {
        return system.defer(
            function resolvePromise(dfd) {
                dfd.resolve();
            }
        ).promise();

    }

    function getEmptyUnreslovedPromise() {
        return system.defer(
            function resolvePromise(dfd) {

            }
        ).promise();

    }


    function dateWithoutTime(date) {
        return new Date(date.getFullYear(), date.getMonth(), date.getDate(), 0, 0, 0, 0);
    }

    function isPortal() {
        return configurationManager.getConfigParam(enums.configParams.IS_PORTAL);
    }

    function getCurrentDir() {
        return cache.getLanguageDir(cache.get(enums.cacheItems.LAST_LANGUAGE)).toLowerCase();
    }

    function getCurrentLangHelpUrl() {
        return cache.getLanguageHelp(cache.get(enums.cacheItems.LAST_LANGUAGE));
    }
    function UrlExists(url) {
        var http = new XMLHttpRequest();
        http.open('HEAD', url, false);
        http.send();
        return http.status != 404;
    }
    //#endregion

    //#region isNullOrEmpty methods
    function isNull(value) {
        if (value == null || value == 'undefined')
            return true;
        else
            return false;
    }

    function isNullOrEmpty(value) {
        if (value == null || value == 'undefined' || value == '')
            return true;
        else
            return false;
    }

    function isNOE(value) {
        if (value == null || value == 'undefined' || value === '' || value === "")
            return true;
        else
            return false;
    }

    function isNullOrEmptyOrSpacesOnly(value) {
        if (value == null || value == 'undefined' || value == '')
            return true;
        else {
            var valueString = value.toString();
            for (var i = 0; i < valueString.length; i++) {
                if (valueString.substring(i, i + 1) != ' ')
                    return false;
            }
        }
        return true;
    }
    //#endregion

    //#region logout/ session expired

    logoutFromSystem.enable = false;

    function logoutFromSystem() {
        if (sessionTimer) {
            clearTimeout(sessionTimer);
            sessionTimer = null;
        }
        cache.set(enums.cacheItems.IsAfterReloadByCode, true);
        if (window.location.href.indexOf('HTTP_TXTUSERID') > -1) {
            //login is from back-office, params are at href.
            //reload is by change href, becose must remove the params for prevent re-auto-login.
            var location = window.location.href;
            location = location.substring(0, location.indexOf('?'));
            window.location = location;
        }
        else {
            window.location.reload();
        }

    }

    function checkSessionExpiryTimeOver() {
        var expiryTime = cache.get(enums.cacheItems.SessionExpiryTime);
        if (expiryTime != null) {
            if (expiryTime > new Date(new Date().getTime() + new Date().getTimezoneOffset() * 60000)) {
                return false;
            }
            else
                return true;
        }
        else
            throw exception("there is not session-expiry-time declaretion yet; You cannot check it");
    }

    function expireSession() {

        if (logoutFromSystem.enable == true) {
            cache.set(enums.cacheItems.NEED_RETRIVE_COMPANY_DATA_AGAIN, true);
            var autoLogoutInfo = "Session Was Expired, User Logout Automatically";
            http.post(webApiConfig.getApiPath(enums.httpPath.WriteInfoToLog.path), { Info: autoLogoutInfo });
            app.trigger(enums.events.EXPIRE_SESSION.name, { logoutReason: "Session Was Expired" });
        }
    }


    function logOut(sessionRemoved) {
        try {
            stopTimer();
            require(['data/dataContext'], function clearMetadataStore(datacontext) {
                datacontext.clearMetadataStore();
            });
            $("#logout").attr('disabled', 'disabled');
            app.setRoot('pages/login/login', 'entrance');
            if (sessionRemoved != true) {
                helper.removeSession();
            }
        }
        catch (err) {
            module.treatError(err);
        }
    }

    function startTimer() {
        logoutFromSystem.enable = true;
        increaseTimer();
    }
    function increaseTimer() {
        if (sessionTimer) {
            clearTimeout(sessionTimer);
            sessionTimer = null;
        }
        var timeOut = configurationManager.getConfigParam(enums.configParams.EXPIRE_SESSION_TIME);
        if (timeOut > 2) {
            timeOut = (((timeOut - 2) * 60) - 30) * 1000;
        }
        else {
            timeOut = ((timeOut * 60) - 30) * 1000;
        }
        sessionTimer = setTimeout(function () {
            expireSession()
        }, timeOut);
    }
    function stopTimer() {
        if (sessionTimer) {
            clearTimeout(sessionTimer);
            sessionTimer = null;
        }
        logoutFromSystem.enable = false;
    }
    function stopQueuesTimer() {
        if (module.GlobalQueuesInterval) {
            clearTimeout(module.GlobalQueuesInterval);
            module.GlobalQueuesInterval = null;
        }
    }
    //#endregion

    //#region mobile function
    function isDevelopment() {
        var host = window.location.hostname;
        return host == "localhost";
    }

    function callMobileFunction(func, param) {
        try {
            if (window.CSharp != null && window.CSharp[func] != null) {
                if (param != null) window.CSharp[func](param);
                else window.CSharp[func]();
            } else {
                console.log('callMobileFunction(' + func + ') cannot be invoked');
            }
        } catch (err) {
            console.log(err);
        }
    }

    function isMobile() {
        return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
    }

    function isImageUrl(url) {
        return /\/App.*\.(png|jpg|jpeg|gif)(\?v=.*)?$/.test(url);
    }

    function isMobileAndIsNotImageUrl(url) {
        return isMobile() && !isImageUrl(url);
    }

    function isMobileBrowser() {
        if (isDevelopment()) {
            return false;
        } else {
            var isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
            return isMobile && !isMobileApp();
        }
    }

    function isMobileApp() {
        if (!isMobile()) return false;

        if (isDevelopment()) {
            return isMobile();
        } else {
            var clientId = getClientId();
            if (clientId != null && clientId != '') {
                return true;
            } else {
                return false;
            }
        }
    }

    function isiOS() {
        if (isDevelopment()) {
            return isMobile();
        } else {
            var ios = /iPhone|iPad|iPod/i.test(navigator.userAgent);
            return ios;
        }
    }

    function getClientId() {
        var result = null,
            tmp = [];
        location.search
            .substr(1)
            .split("&")
            .forEach(function (item) {
                tmp = item.split("=");
                if (tmp[0] === "clientid") result = decodeURIComponent(tmp[1]);
            });
        return result;
    }

    function getOnlyNumbers(txt) {
        if (!isNOE(txt))
            return txt.replace(/^\D+/g, '');
        else
            return "";
    }
    //#endregion

    function startUpdateControllerStatusTimer(listViewDataPointer) {
        startUpdateControllerStatusTimer.prototype.updateStatusTimer = null;
        startUpdateControllerStatusTimer.prototype.isMaintenanceActivate = true;
        var updateStatus_timeOut;
        updateStatus();
        function updateStatus() {
            clearTimeout(startUpdateControllerStatusTimer.prototype.updateStatusTimer);
            var controllerCodes = $.map(listViewDataPointer.dataSource.data(), function (item) { return item.Code; });
            var is_status = true
            if (controllerCodes.length == 0)    //first time
            {
                is_status = null;
                module.httpGet(enums.httpPath.GetMaxStatusTimeOutSysController).done(StatusTimeOutDone);
            }
            else
                module.httpGet(enums.httpPath.GetMaxStatusTimeOutSysControllerByControllerCodes, { controllerCodes: controllerCodes.toString() }).done(StatusTimeOutDone);

            function StatusTimeOutDone(result) {
                try {
                    if (!isNull(result) && !isNull(result.ReturnVal)) {
                        if (result.ReturnVal == "")
                            updateStatus_timeOut = 180;
                        else
                            updateStatus_timeOut = parseInt(result.ReturnVal);
                        if (updateStatus_timeOut < 180) //in case first time max returned <180 
                            updateStatus_timeOut = 180;
                        if (startUpdateControllerStatusTimer.prototype.isMaintenanceActivate)
                            startUpdateControllerStatusTimer.prototype.updateStatusTimer = setTimeout(function () {
                                app.trigger(enums.events.UPDATE_CONTROLLER_STATUS.name, { isStatus: is_status, timeOutMAin: updateStatus_timeOut / 60 });
                                updateStatus();
                            }
                                , updateStatus_timeOut * 1000);
                    }
                }
                catch (err) {
                    module.treatError(err);
                }
            }
        }
    }


    function stopUpdateControllerStatusTimer() {
        clearTimeout(startUpdateControllerStatusTimer.prototype.updateStatusTimer);
        startUpdateControllerStatusTimer.prototype.isMaintenanceActivate = false;
    }

    function checkSaveNeededFuncWrapper(options) {

        var resultObj = { status: null };

        if (!options.funcArguments)
            options.funcArguments = [];
        if (!options.cancelFuncArgs)
            options.cancelFuncArgs = [];
        if (!options.anyContinueFuncArgs)
            options.anyContinueFuncArgs = [];
        options.funcArguments.push(resultObj);
        options.cancelFuncArgs.push(resultObj);
        options.anyContinueFuncArgs.push(resultObj);

        var resultEnum = enums.checkSaveNeededResult;
        if (options.needSaving) {
            customMessageWindow.buildMessage({ mode: enums.messageType.question, messageText: module.dict()[1360], btnsMode: enums.btnsMode.yesNoCancel });
            return module.showDialog(customMessageWindow).then(function handleSaveChangesDialogResult(dialogResult) {
                try {
                    switch (dialogResult) {
                        case enums.customMsgWindowResult.yes:
                            options.saveFunc().done(function doFuncAfterSave(saveResult) {
                                try {

                                    if (saveResult == true || saveResult != null && saveResult.status == 0 || saveResult != null && saveResult.Status == 0) {
                                        if (!isNull(options.anyContinueFunc)) {
                                            options.anyContinueFunc();
                                        }
                                        resultObj.status = resultEnum.saveDone;
                                        options.func.apply(this, options.funcArguments);
                                    }
                                    else if (saveResult != null && saveResult.status !== undefined && saveResult.status != 0) {
                                        customMessageWindow.buildMessage({ mode: enums.messageType.error, messageText: result.message });
                                        module.showDialog(customMessageWindow)
                                    }
                                } catch (err) {
                                    module.treatError(err);
                                }
                            });
                            break;
                        case enums.customMsgWindowResult.cancel:
                            resultObj.status = resultEnum.cancel;
                            if (!isNull(options.cancelFunc)) {
                                options.cancelFunc(options.cancelFuncArgs);
                            }
                            break;
                        default:// case customMsgWindowResult.no
                            resultObj.status = resultEnum.noSave;
                            if (!isNull(options.noSavingFunc)) {
                                options.noSavingFunc(options.noSavingFuncArgs);
                            }
                            if (!isNull(options.anyContinueFunc)) {
                                options.anyContinueFunc();
                            }
                            options.func.apply(this, options.funcArguments);
                            break;
                    }

                }
                catch (err) {
                    module.treatError(err);
                }
            });
        }
        else {
            resultObj.status = resultEnum.notModified;
            if (!isNull(options.anyContinueFunc)) {
                options.anyContinueFunc();
            }
            options.func.apply(this, options.funcArguments);
            return getEmptyPromise();
        }
    }

    function confitmDeleteRowFuncWrapper(deleteFunc, deleteArgs) {
        customMessageWindow.buildMessage({ mode: enums.messageType.question, messageText: module.res[768], btnsMode: enums.btnsMode.yesNo });
        module.showDialog(customMessageWindow).then(function (dialogResult) {
            if (dialogResult == enums.customMsgWindowResult.yes) {
                deleteFunc.apply(this, deleteArgs);
            }
        });
    }

    function getResponseCompanyOfPortalImagePath(isIframe) {
        var responseCompOfPortal;
        try {
            responseCompOfPortal = configurationManager.getConfigParam(enums.configParams.RESPONSE_COMP_OF_PORTAL);
        }
        catch (err) {
            responseCompOfPortal = enums.responseCompanyOfPortal.Synel.name;
        }
        switch (responseCompOfPortal) {
            case enums.responseCompanyOfPortal.DT.id:
            case enums.responseCompanyOfPortal.DT.name:
                return imagesManager.dayTrackWhiteModule;
            case enums.responseCompanyOfPortal.Synel.id:
            case enums.responseCompanyOfPortal.Synel.name:
                if (isIframe)
                    return imagesManager.iframeLoginDefaultLogo;
                else
                    return imagesManager.loginRightLogo;
        }
    }

    function getOrgTreeOptions() {
        var orgTreeList;
        orgTreeList = [
            { text: module.res[4], value: "0", lookupName: enums.lookupName.Dep },
            { text: module.res[1], value: "1", lookupName: enums.lookupName.Station },
            { text: module.res[1305], value: "2", lookupName: enums.lookupName.Section },
            { text: module.res[1297], value: "3", lookupName: enums.lookupName.Factory },
            { text: module.res[1296], value: "4", lookupName: enums.lookupName.Region },
        ];
        return orgTreeList;
    }

    function SetQueuesInterval(value) {
        module.GlobalQueuesInterval = value;
    }

    function SetGlobalInputTableName(value) {
        module.GlobalInputTableName = value;
    }

    function GetGlobalInputTableName() {
        return module.GlobalInputTableName;
    }

    function SetGlobalInterfaceType(value) {
        module.GlobalInterfaceType = value;
    }

    function GetGlobalInterfaceType() {
        return module.GlobalInterfaceType;
    }

    function SetInterfaceFlag(value) {
        IsInterfaceRun = value;
    }

    function GetInterfaceFlag() {
        return IsInterfaceRun;
    }

    //method for export data of grid to file
    function generateExcel(data) {
        try {
            http.post(webApiConfig.getApiPath(enums.httpPath.ExportGridToExcel.path), {
                Data: JSON.stringify(data), Type: enums.exportFileType.EXL.id
            })
                .done(function (data, code, jqXHR) {
                    if (isNullOrEmpty(data)) {
                        customMessageWindow.buildMessage({ mode: enums.messageType.error, messageText: module.dictMsg()[581] });
                        dialogManager.showDialog(customMessageWindow);
                        module.displaySpin(false);

                    } else {
                        downloadFile(data, "", enums.copyFileToDestinationType.general, "text/csv");
                        module.displaySpin(false);
                    }
                });
        }
        catch (err) {
            module.treatError(err);
        }
    };

    function viewFileInNewWindow(fileName, prePath, targetType, isDeleteSrcFile) {

        if (isiOS()) {
            var url = makeURL(fileName, prePath, targetType, isDeleteSrcFile, enums.httpPath.ExportFileMobile.path);
            var clearUrl = makeURL(fileName, prePath, targetType, isDeleteSrcFile, enums.httpPath.ClearFile.path);

            showPdfPopup({ url: url, clearUrl: clearUrl });
        }
        else if (isMobileApp()) {
            var url = makeURL(fileName, prePath, targetType, isDeleteSrcFile, enums.httpPath.ExportFileMobile.path);
            window.open(url, "_blank");
        }
        else {
            var url = makeURL(fileName, prePath, targetType, isDeleteSrcFile, enums.httpPath.ExportFile.path);
            window.open(url, "_blank");
        }
    }

    function makeURL(fileName, prePath, targetType, isDeleteSrcFile, path) {
        var url = webApiConfig.getHostPath();
        var port = (webApiConfig.port != "") ? webApiConfig.port : "/";
        var port = (port.slice(-1) != "/") ? port + "/" : port;
        url += port;
        url += path + "?xGuid=" + fileName;
        return url;
    }

    function showPdfPopup(params) {
        require(
            ["views/forms/pdfViewerMobile/pdfViewer"],
            function showPopupAfterRequirePopupModule(popupVm) {
                try {
                    pdfPopup = new popupVm(params);
                    dialogManager.showDialog(pdfPopup)
                }
                catch (err) {
                    module.treatError(err);
                }
            }
        );
    }

    function downloadFile(fileName, prePath, targetType, contentType) {
        //window.location
        var url = webApiConfig.getHostPath() + webApiConfig.getApiPath('Export/FileDownload2');
        var data = {
            FileName: fileName,
            PrePath: prePath,
            TargetType: targetType,
            ContentType: contentType,
            Sid: cache.get(cache.enums.cacheItems.SESSION_ID)
        };
        http.get(url, {query: JSON.stringify(data)}).done(function GetFileDownload(response) {
            try {
                window.location = webApiConfig.getHostPath() + webApiConfig.getApiPath('Export/DownloadMessage' + '?xGuid=' + response);
            } catch (err) {
                global.treatError(err);
            }
        });
    }
    function downloadFileFromGuid(guid) {
        window.location = webApiConfig.getHostPath() + webApiConfig.getApiPath('Export/DownloadMessage' + '?xGuid=' + guid);
    }
    function isDTResponse() {
        var responseCompOfPortal = configurationManager.getConfigParam(enums.configParams.RESPONSE_COMP_OF_PORTAL);
        return responseCompOfPortal == enums.responseCompanyOfPortal.DT.id || responseCompOfPortal == enums.responseCompanyOfPortal.DT.name;
    }

    function getReportsCodesForWS() {
        var compReports = cache.getCompanyParamByFieldName(enums.companyParamNames.ReportsCodesForWS.name);
        if (!isNOE(compReports))
            return compReports;
        return configurationManager.getConfigParam(enums.configParams.REPORT_CODES_WS);
    }

    var module = {
        dateWithoutTime: dateWithoutTime,
        logoutFromSystem: logoutFromSystem,
        logOut: logOut,
        errorManager: errorManager,
        treatError: errorManager.treatError,
        permissions: permissions,
        enums: enums,
        cache: cache,
        app: app,
        dialog: dialog,
        system: system,
        webApiConfig: webApiConfig,
        binder: binder,
        tempData: tempData,
        isNull: isNull,
        isNOE: isNOE,
        isNullOrEmpty: isNullOrEmpty,
        isNullOrEmptyOrSpacesOnly: isNullOrEmptyOrSpacesOnly,
        http: http,
        synchronousHttpCalling: synchronousHttpCalling,
        serverWrapper: serverWrapper,
        dict: helper.dict,
        dictMsg: helper.dictMsg,
        isInAjax: ko.observable(false),
        isInProcess: ko.observable(false),
        displaySpin: ko.observable(false),
        imagesManager: imagesManager,
        consts: consts,
        helper: helper,
        stopEvent: stopEvent,
        arrayMove: arrayMove,
        getItemByCodeDescript: getItemByCodeDescript,
        checkSessionExpiryTimeOver: checkSessionExpiryTimeOver,
        startTimer: startTimer,
        breezeSavingFail: breezeSavingFail,
        customMessageWindow: customMessageWindow,
        getJsonToGridHtml: getJsonToGridHtml,
        getCurrentDir: getCurrentDir,
        getCurrentLangHelpUrl:getCurrentLangHelpUrl,
        UrlExists: UrlExists,
        explorerType: helper.explorerType,
        showDialog: dialogManager.showDialog,
        process: process,
        closeDialog: dialogManager.closeDialog,
        stopTimer: stopTimer,
        stopQueuesTimer: stopQueuesTimer,
        checkVisiblePermission: checkVisiblePermission,
        getEmptyPromise: getEmptyPromise,
        getEmptyUnreslovedPromise: getEmptyUnreslovedPromise,
        gridsLayouts: {},
        isLayoutsSave: ko.observable(false),
        changeIsLayoutSaveProp: function changeIsLayoutSaveProp() { if (module.permissions.isSuperVisor() && configurationManager.getConfigParam(module.enums.configParams.SAVE_LAYOUT)) module.isLayoutsSave(true); },
        abortAllAjax: function () {
            // $.xhrPool.abortAll();
            $.xhrPool = []; // array of uncompleted requests
            $.xhrPool.abortAll = function () { // our abort function
                $(this).each(function (idx, jqXHR) {
                    jqXHR.abort();
                });
                $.xhrPool.length = 0
            };

            $.ajaxSetup({
                beforeSend: function (jqXHR) { // before jQuery send the request we will push it to our array
                    $.xhrPool.push(jqXHR);
                },
                complete: function (jqXHR) { // when some of the requests completed it will splice from the array
                    var index = $.xhrPool.indexOf(jqXHR);
                    if (index > -1) {
                        $.xhrPool.splice(index, 1);
                    }
                }
            });
        },
        initiatedError: "initiatedError",
        isPerformenceImmedientLogin: ko.observable(true),
        isPortal: isPortal,
        startUpdateControllerStatusTimer: startUpdateControllerStatusTimer,
        stopUpdateControllerStatusTimer: stopUpdateControllerStatusTimer,
        checkSaveNeededFuncWrapper: checkSaveNeededFuncWrapper,
        confitmDeleteRowFuncWrapper: confitmDeleteRowFuncWrapper,
        httpGet: serverWrapper.get,
        httpPost: serverWrapper.post,
        res: null,
        resMsg: null,
        GlobalQueuesInterval:null,
        isChrome: calcIsChrome(),
        isFireFox: calcIsFireFox(),
        isRTL: isRTL,
        getResponseCompanyOfPortalImagePath: getResponseCompanyOfPortalImagePath,
        getOrgTreeOptions: getOrgTreeOptions,
        SetInterfaceFlag: SetInterfaceFlag,
        GetInterfaceFlag: GetInterfaceFlag,
        SetQueuesInterval: SetQueuesInterval,
        configurationManager: configurationManager,
        generateExcel: generateExcel,
        viewFileInNewWindow: viewFileInNewWindow,
        makeURL: makeURL,
        isDTResponse: isDTResponse,
        downloadFile: downloadFile,
        downloadFileFromGuid: downloadFileFromGuid,
        getReportsCodesForWS: getReportsCodesForWS,
        GlobalInputTableName: null,
        GlobalInterfaceType:null,
        SetGlobalInputTableName: SetGlobalInputTableName,
        GetGlobalInputTableName: GetGlobalInputTableName,
        SetGlobalInterfaceType: SetGlobalInterfaceType,
        GetGlobalInterfaceType: GetGlobalInterfaceType,
        callMobileFunction: callMobileFunction,
        isMobile: isMobile,
        isImageUrl: isImageUrl,
        isMobileAndIsNotImageUrl: isMobileAndIsNotImageUrl,
        isMobileApp: isMobileApp,
        isMobileBrowser: isMobileBrowser,
        isiOS: isiOS,
        showPdfPopup: showPdfPopup,
        rtl: function (element, data) {
            var hebrewCode = 3;
            var currentLanguageCode = cache.get(enums.cacheItems.LAST_LANGUAGE);
            if (hebrewCode == currentLanguageCode && this.global.isiOS()) {
                element.setSelectionRange(element.value.length, element.value.length);
            }
        },
        getClientId: getClientId,
        getOnlyNumbers: getOnlyNumbers,
    };
    //error manager need to stop display spin before view error msg.
    //there are some modules that load error manager by them self, not by global, becose - 
    //global require them and it is cycle- referance.
    //so error manager need to have access to display-spin param by itself.
    errorManager.displaySpin = module.displaySpin;
    return module;
});



