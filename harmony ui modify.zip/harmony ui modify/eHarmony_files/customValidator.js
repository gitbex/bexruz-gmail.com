﻿define(function customValidatorModule() {

    var errorManager = require('common/errorManager');
    var cache = require('common/cache/cacheManager');
    var dict = ko.computed(function () { return cache.get(cache.cacheItems.DICT) });
    var dictMsg = ko.computed(function () { return cache.get(cache.cacheItems.DICTMSG) });
    var global = require('common/global');

    var validationAttributes = {
        GreaterThanFirstDate: "data-GreaterThanFirstDate-msg",
        lessThenOrEqualToToday: "data-lessThenOrEqualToToday-msg",
        betweenNumber: "data - betweenNumber - msg",
        validFormat: "data-validFormat-msg",
        lessThanSecondDate: "data-lessThanSecondDate-msg",
        requireAndNotEmpty: "data-requireAndNotEmpty-msg",
        notEmpty: "data-notEmpty-msg",
        isDigit: "data-isDigit-msg",
        isValidID: "data-isValidID-msg",
        minLength: "data-minLength-msg",
        maxLength: "data-maxLength-msg",
        greaterThenOtherDate: "data-greaterthenotherdate-msg",
        isValidEmail: "data-isValidEmail-msg",
        regularExpress: "data-regularExpression-msg"
    };
    function lessThenOrEqualToToday(input) {
        input.attr(validationAttributes.lessThenOrEqualToToday, dictMsg()['373']);
        if (isNull(input))
            throw new Error("can't check validation of undefine or null referance");
        if (isNull(input.val()) || input.val() == '')
            return true;

        try {
            try {
                var value = input[0].value;
                var format = global.cache.get(global.enums.cacheItems.DATE_FORMAT);
                if (Date.parseExact(value, format) >= new Date())
                    return false;
                return true;
            }
            catch (ex) {
                throw new Error("can't convert first-date-field value to date-type.");
            }
        }
        catch (ex) {
            throw new Error("can't convert second-date-field value to date-type.");
        }
    }

    function greaterThenOtherDate(input, otherDate, message) {
        input.attr(validationAttributes.greaterThenOtherDate, message);
        if (isNull(input))
            throw new Error("can't check validation of undefine or null referance");
        if (isNullOrEmpty(input.val()) || isNullOrEmpty(otherDate))
            return true;
        try {
            try {
                var value = input[0].value;
                var format = global.cache.get(global.enums.cacheItems.DATE_FORMAT);
                if (Date.parseExact(value, format) >= otherDate)
                    return true;
                return false;
            }
            catch (ex) {
                throw new Error("can't convert first-date-field value to date-type.");
            }
        }
        catch (ex) {
            throw new Error("can't convert second-date-field value to date-type.");
        }
    }

    function validFormat(input, message) {
        input.attr(validationAttributes.validFormat, message);
        if (isNull(input))
            throw new Error("can't check validation of undefine or null referance");
        if (isNullOrEmpty(input.val()))
            return true;
        try {
            try {
                var value = input[0].value;
                var format = global.cache.get(global.enums.cacheItems.DATE_FORMAT);
                if (Date.parseExact(value, format))
                    return true;
                return false;
            }
            catch (ex) {
                throw new Error("can't convert first-date-field value to date-type.");
            }
        }
        catch (ex) {
            throw new Error("can't convert second-date-field value to date-type.");
        }
    }

    function greaterThanFirstDate(secondDateField, firstDateFieldName, invalidMessage) {
        secondDateField.attr(validationAttributes.GreaterThanFirstDate, invalidMessage);
        if (isNull(secondDateField))
            throw new Error("can't check validation of undefine or null referance");
        if (isNull(secondDateField.val()) || secondDateField.val() == '')
            return true;
        var fieldRow = getCurrentRowByField(secondDateField);
        var firstDateField = fieldRow[firstDateFieldName];
        if (isNull(firstDateField))
            //   throw new Error("validator can't find field of first-date in current row");
            return true;
        try {
            var firstDate = Date.parse(firstDateField);
            try {
                var endDate = new Date($(secondDateField).data("kendoDatePicker").value());
                if (endDate < firstDate)
                    return false;
                return true;
            }
            catch (ex) {
                throw new Error("can't convert first-date-field value to date-type.");
            }
        }
        catch (ex) {
            throw new Error("can't convert second-date-field value to date-type.");
        }
    }

    function betweenNumber(field, one, two, invalidMessage1, invalidMessage2) {
        if (isNull(field))
            throw "can't check validation of undefine or null referance";
        if (isNull(field.val()) || field.val() == '')
            return true;
        if (field.val() < one) {
            field.attr(validationAttributes.betweenNumber, invalidMessage1);
            field.val(one);
            return false;
        }
        if (field.val() > two) {
            field.attr(validationAttributes.betweenNumber, invalidMessage2);
            field.val(two);
            return false;
        }
        return true;
    }

    function lessThanSecondDate(firstDateField, secondDateFieldName, invalidMessage) {
        firstDateField.attr(validationAttributes.lessThanSecondDate, invalidMessage);
        if (isNull(firstDateField))
            throw "can't check validation of undefine or null referance";
        if (isNull(firstDateField.val()) || firstDateField.val() == '')
            return true;
        var fieldRow = getCurrentRowByField(firstDateField);
        var secondDateField = fieldRow[secondDateFieldName];
        if (isNull(secondDateField))
            return true;
        //  throw "validator can't find field of second-date in current row";
        try {
            var secondDate = Date.parse(secondDateField);
            try {
                var endDate = new Date($(firstDateField).data("kendoDatePicker").value());;
                if (endDate > secondDate)
                    return false;
                return true;
            }
            catch (ex) {
                throw "can't convert second-date-field value to date-type."
            }
        }
        catch (ex) {
            throw "can't convert second-date-field value to date-type."
        }
    }

    function requireAndNotEmpty(field, message) {
        if (isNull(message))
            field.attr(validationAttributes.requireAndNotEmpty, dict()[4556]);
        else
            field.attr(validationAttributes.requireAndNotEmpty, message);
        if (isNull(field))
            throw "can't check validation of undefine or null referance";
        else {
            if (isNullOrEmpty(field.val()))
                return false;
            else
                return true;
        }
    }

    function getCurrentRowByField(field) {
        var row;
        var parentGrid = $(field).parents("[data-role=grid]");
        if (parentGrid.length > 0) {
            row = parentGrid.data('kendoGrid').dataItem(field.closest("tr"));
        }
        else {//may be edit-mode= popup
            row = $(field).closest(".k-popup-edit-form, .k-grid-edit-row").data("kendoEditable").options.model
        }
        if (isNull(row))
            throw new Error("can't find row by grid field. field name: " + field.name);
        else
            return row;
    }

    function isNull(value) {
        if (value == null || value == 'undefined')
            return true;
        else
            return false;
    }

    function isNullOrEmpty(value) {
        if (value == null || value == 'undefined' || value == "")
            return true;
        else
            return false;
    }

    function onSetValidate(id, messages, customValidators, customValidatorsMessagesAttributes, isIdDomElement/*for e.x: true is sent in weekly grid*/) {
        var globalIsValid = true;
        var element = (!global.isNOE(isIdDomElement) && isIdDomElement) ? id : $("#" + id);
        var val = element.kendoValidator({
            messages: {
                notEmpty: messages.requireMessage,
                requireAndNotEmpty: messages.requireMessage,
                isDigit: messages.isDigitMessage,
                minLength: messages.minLengthMeassage,
                maxLength: messages.maxLengthMeassage,
                isValidID: messages.isValidIDMessage,
                validFormat: messages.validFormatMessage,
                greaterThenOtherDate: messages.greaterThenOtherDateMessage,
                firstCustom: messages.firstCustomMessage,
                secondCustom: messages.secondCustomMessage
            },
            rules: {
                notEmpty: function (input) {
                    if (input.is("[valid=notEmpty]") && input.closest("tr").hasClass("k-grid-itemchange")) {
                        var isValid = notEmpty(input, isNull($(input[0]).data('notemptymsg')) ? messages.requireMessage : $(input[0]).data('notemptymsg'));
                        globalIsValid = globalIsValid && isValid;
                        return isValid;
                    }
                    return true;
                },
                requireAndNotEmpty: function (input) {
                    if (input.is("[valid*='requireAndNotEmpty']") || !global.isNull(input[0].getAttribute(validationAttributes.requireAndNotEmpty))) {
                        if (isNullOrEmpty($(input).val()) || $(input).val() == "null") {
                            globalIsValid = false;
                            return false;
                        }
                    }
                    return true;
                },
                isDigit: function (input) {
                    if (input.is("[valid*='isDigit']") || !global.isNull(input[0].getAttribute(validationAttributes.isDigit))) {
                        var isValid = isDigit(input, input[0].name);
                        globalIsValid = isValid && globalIsValid;
                        return isValid;
                    }
                    return true;
                },
                minLength: function (input) {
                    if (input.is("[valid*='minLength']") || !global.isNull(input[0].getAttribute(validationAttributes.minLength))) {
                        var isValid = minLength(input, input[0].name, $(input[0]).data('minlength'), messages.minLengthMeassage);
                        globalIsValid = isValid && globalIsValid;
                        return isValid;
                    }
                    return true;

                },

                maxLength: function (input) {
                    if (input.is("[valid*='maxLength']") || !global.isNull(input[0].getAttribute(validationAttributes.maxLength))) {
                        var isValid = maxLength(input, input[0].name, $(input[0]).data('maxLength'), messages.maxLengthMeassage);
                        globalIsValid = isValid && globalIsValid;
                        return isValid;
                    }
                    return true;

                },
                isValidID: function (input) {
                    if (input.is("[valid*='isValidID']") || !global.isNull(input[0].getAttribute(validationAttributes.isValidID))) {
                        var isValid = isValidID(input, input[0].name);
                        globalIsValid = isValid && globalIsValid;
                        return isValid;
                    }
                    return true;
                },
                validFormat: function (input) {
                    if (input.is("[valid*='validFormat']") || !global.isNull(input[0].getAttribute(validationAttributes.validFormat))) {
                        var isValid = validFormat(input, $(input[0]).data('validFormatmsg'));
                        globalIsValid = isValid && globalIsValid;
                        return isValid;
                    }
                    return true;
                },
                lessThenOrEqualToToday: function (input) {
                    if (input.is("[valid*='lessThenOrEqualToToday']") || !global.isNull(input[0].getAttribute(validationAttributes.lessThenOrEqualToToday))) {
                        var isValid = lessThenOrEqualToToday(input);
                        globalIsValid = isValid && globalIsValid;
                        return isValid;
                    }
                    return true;
                },
                greaterThenOtherDate: function (input) {
                    if (input.is("[valid*='greaterThenOtherDate']") || !global.isNull(input[0].getAttribute(validationAttributes.greaterThenOtherDate))) {
                        var isValid = greaterThenOtherDate(input, new Date($(input[0]).data('otherdate')), $(input[0]).data('otherdatemsg'));
                        globalIsValid = isValid && globalIsValid;
                        return isValid;
                    }
                    return true;
                },
                firstCustom: function (input) {
                    if (input.is("[valid*='firstCustom']") || !isNull(customValidatorsMessagesAttributes) && !global.isNull(input[0].getAttribute(customValidatorsMessagesAttributes[0]))) {
                        var isValid = customValidators[0](input);
                        globalIsValid = isValid && globalIsValid;
                        return isValid;
                    }
                    return true;
                },
                secondCustom: function (input) {
                    if (input.is("[valid*='secondCustom']") || !isNull(customValidatorsMessagesAttributes) && !global.isNull(input[0].getAttribute(customValidatorsMessagesAttributes[1]))) {
                        var isValid = customValidators[1](input);
                        globalIsValid = isValid && globalIsValid;
                        return isValid;
                    }
                    return true;
                }
            }
        }).data("kendoValidator");
        val.validate();
        $("[role=alert]").css({ margin: "0.5em", display: "block", position: "absolute" }).append('<div class="k-callout k-callout-n"></div>');
        return globalIsValid;
    }

    function notEmpty(input, customMessage) {
        input.attr(validationAttributes.notEmpty, isNull(customMessage) ? dict()[517] : customMessage);
        if (isNullOrEmpty($(input).val()) && (!isNullOrEmpty(input.data("text")) && input.data("text") != '00:00')) {
            return false;
        }
        return true;
    }

    function isDigit(field, fieldName, message) {
        if (!field.is("[name=" + fieldName + "]")) {
            return true;
        }
        if (isNull(message)) {
            field.attr(validationAttributes.isDigit, dict()[638]);
        }
        else {
            field.attr(validationAttributes.isDigit, message);
        }
        var value = field[0].value.toString();
        for (var i = 0; i < value.length; i++) {
            if (value[i] < '0' || value[i] > '9') {
                return false;
            }
        }
        return true;
    }

    function isValidID(field, fieldName) {
        if (!field.is("[name=" + fieldName + "]")) {
            return true;
        }

        field.attr(validationAttributes.isValidID, dictMsg()[362]);
        var IDnum = field[0].value.toString();
        if (global.isNullOrEmpty(IDnum)) {
            return true;
        }
        while (IDnum.length < 9) {
            IDnum = '0' + IDnum;
        }
        var counter = 0, incNum;
        for (var i = 0; i < 9; i++) {
            incNum = Number(IDnum.charAt(i));
            incNum *= (i % 2) + 1;
            if (incNum > 9)
                incNum -= 9;
            counter += incNum;
        }
        if (counter % 10 == 0)
            return true;
        else
            return false;
        return true;
    }

    function isValidID2(value) {
        //if (!field.is("[name=" + fieldName + "]")) {
        //    return true;
        //}

        //field.attr(validationAttributes.isValidID, dictMsg()[362]);
        //var IDnum = field[0].value.toString();
        var IDnum = value;

        if (global.isNullOrEmpty(IDnum)) {
            return true;
        }
        while (IDnum.length < 9) {
            IDnum = '0' + IDnum;
        }
        var counter = 0, incNum;
        for (var i = 0; i < 9; i++) {
            incNum = Number(IDnum.charAt(i));
            incNum *= (i % 2) + 1;
            if (incNum > 9)
                incNum -= 9;
            counter += incNum;
        }
        if (counter % 10 == 0)
            return true;
        else
            return false;
        return true;
    }

    function isValidEmail(field, fieldName) {
        if (!field.is("[name=" + fieldName + "]")) {
            return true;
        }
        field.attr(validationAttributes.isValidEmail, "כתובת מייל אינה חוקית");
        var emailAddress = field[0].value.toString();

        return global.helper.isValidEmail(emailAddress);
    }

    function minLength(field, fieldName, minLength, message, minLengthForTitle) {
        if (!field.is("[name=" + fieldName + "]")) {
            return true;
        }

        field.attr(validationAttributes.minLength, dictMsg()['361'].replace('{0}', !global.isNOE(minLengthForTitle) ? minLengthForTitle : minLength));
        var value = field[0].value.toString();
        if (value.toString().length < minLength)
            return false;
        return true;
    }
    function maxLength(field, fieldName, maxLength) {
        if (!field.is("[name=" + fieldName + "]")) {
            return true;
        }

        field.attr(validationAttributes.maxLength, dict()['1960'] + ': ' + maxLength);
        var value = field[0].value.toString();
        if (value.toString().length > maxLength)
            return false;
        return true;
    }

    function regularExpression(field, fieldName, expression, message) {
        if (!field.is("[name=" + fieldName + "]")) {
            return true;
        }
        field.attr(validationAttributes.regularExpress, message);
        var pattern = new RegExp(expression);
        return pattern.test(field[0].value.toString());
    }

    try {
        var validators = {
            greaterThanFirstDate: greaterThanFirstDate,
            requireAndNotEmpty: requireAndNotEmpty,
            validFormat: validFormat,
            lessThanSecondDate: lessThanSecondDate,
            onSetValidate: onSetValidate,
            betweenNumber: betweenNumber,
            isDigit: isDigit,
            isValidID: isValidID,
            isValidID2: isValidID2,
            isValidEmail: isValidEmail,
            minLength: minLength,
            maxLength:maxLength,
            getCurrentRowByField: getCurrentRowByField,
            lessThenOrEqualToToday: lessThenOrEqualToToday,
            greaterThenOtherDate: greaterThenOtherDate,
            regularExpression: regularExpression
        };
        return validators;
    }
    catch (err) {
        errorManager.treatError(err);
    }
});