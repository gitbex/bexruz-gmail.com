﻿define(function loginPage(require) {
    var resourcesManager = require('common/resourcesManager');
    var cacheManager = require('common/cache/cacheManager');
    var errorManager = require('common/errorManager');
    var configurationManager = require('common/configurationManager');
    var router = require('plugins/router');
    var shell = require('pages/shell/shell');
    var global = require('common/global');
    var dataContext = require('data/datacontext');
    var webApiConfig = require('common/webApiConfig');
    var simpleCombo = require('views/controls/combo/combo');
    var selectLanguage = require('views/combinedControls/selectLanguage/selectLanguage');
    var lookupManager = require('common/lookupManager');
    var enums = require('common/enums/enums');
    var customMessageWindow = require('views/combinedControls/customMessageWindow/customMessageWindow');
    var validationHelper = require('data/validationHelper');

    //match to LoginQuery.cs.
    //object to save current user at cache
    var userModel = function () {
        var uiObject = {
            Id: null,
            Profile: null,
            Permissions: null,
            sessionId: null,
            tagNo: null
        };
        return uiObject;
    }

    //those variables used for captcha
    var firstLoginTime = null;
    var loginClickCounter = 0;

    try {
        //global variables and shortcut-referances
        var user = new userModel();
        responseCompOfPortal = configurationManager.getConfigParam(enums.configParams.RESPONSE_COMP_OF_PORTAL);
        var isDT = responseCompOfPortal == enums.responseCompanyOfPortal.DT.id || responseCompOfPortal == enums.responseCompanyOfPortal.DT.name;
        var isNull = global.isNull;
        loginError = global.enums.loginError;
        var lastOrDefaultLanguage;
        var loginError;
        var existUserSecureCookie = false;
        //#region local enums
        var shownScreen = {
            Company: { name: "company", step: 1 },
            LoginHarmonyDB: { name: "loginHarmonyDB", step: 2 },
            LoginActiveDirectory: { name: "loginActiveDirectory", step: 2 },
            Profiles: { name: "profiles", step: 4 },
            ChangePass: { name: "changePassword", step: 2 },
            ResetPass: { name: "resetPassword", step: 3 },
            PassForNew: { name: "pwdForNew", step: 3 },
            ForgotPassword: { name: "forgotPassword", step: 2 },
            ProfilesActiveDirectory: { name: "profilesActiveDirectory", step: 4 },
        };

        var ADS_Mode = {
            name: "ADS_Mode",
            modes: {
                HarmonyDB: { name: "0" },
                ActiveDirectoryByUser: { name: "1" },
                ActiveDirectoryAuto: { name: "2" }
            }
        };
        ko.bindingHandlers.numeric = {
            init: function (element, valueAccessor) {
                $(element).on("keydown", function (event) {
                    if (vm.chkPwdByMail() == 1) {
                        return;
                    }
                    // Allow: backspace, delete, tab, escape, and enter
                    else if (event.keyCode == 46 || event.keyCode == 8 || event.keyCode == 9 || event.keyCode == 27 || event.keyCode == 13 ||
                        // Allow: Ctrl+A
                        (event.keyCode == 65 && event.ctrlKey === true) ||
                        // Allow: . ,
                        (event.keyCode == 188 || event.keyCode == 190 || event.keyCode == 110) ||
                        // Allow: home, end, left, right
                        (event.keyCode >= 35 && event.keyCode <= 39)) {
                        return;
                    }
                    else {
                        if (event.shiftKey || (event.keyCode < 48 || event.keyCode > 57) && (event.keyCode < 96 || event.keyCode > 105)) {
                            event.preventDefault();
                        }
                    }
                });
            }
        };
        var PwdModuleActive =
            {
                name: "PwdModuleActive",
                modes: {
                    regularModule: { name: "0" },
                    passwordModule: { name: "1" }
                }
            }
        //#endregion local enums end

        //variables and consts that there is no need to externalize them
        var statusId;
        var Search_By_ID_Radio_Button_Name = "byNo";
        var companyId_Case_InHouse = "0";
        var notLicenseeErrorCode = "199";
        var loginModel = dataContext.createClientEntity("Login");//view model entity
        var needToShowLastUser = true;
        var imageLoginBtnUrl = global.imagesManager.loginBtn;
        var initVMDfd;
        var initVMPromise;       
        var empPhoneNum = '';

        var initializeDefinitionsDefer = null;

        var vm = {
            global: global,
            profilesCombo: new simpleCombo(),
            currentScreen: loginModel.state,
            login: login,
            loginModel: loginModel,
            loginMode: null,
            helpPath: '',
            logoPath: '',
            isPortal: ko.observable(false),
            isSupportLinkCheck: ko.observable(false),
            isHelpLinkVisible: ko.observable(false),
            isContactSupervisorLinkVisible: ko.observable(false),
            supportLinkURL: ko.observable(''),
            helpLinkURL: ko.observable(''),
            contactSupervisorLinkURL: ko.observable(''),
            isActiveDirectory: ko.observable(false),
            isPasswordModule: ko.observable(true),
            isEnablePasswordChangeVisible: ko.observable(true),
            passwordMaxLength: ko.observable(20),
            searchBy: loginModel.searchBy,// ko.observable("byno"),
            bgImageLoginBtnUrl: ko.computed(bgImageLoginBtnUrlCompute),
            radioClicked: radioClick,
            compositionComplete: compositionComplete,
            activate: activate,
            isPrismLogin: ko.observable(false),
            PrismResult: ko.observable(null),
            visibleSnake: ko.computed(visibleSnakeCompute),
            message: ko.observable(),
            msgIPrange: ko.observable(),
            fromPortalToCompany: fromPortalToCompany,
            startLoginUser: startLoginUser,
            login: login,
            logOut: logOut,
            loginUserWithProfile: loginUserWithProfile,
            loginWithNewPassword: loginWithNewPassword,
            goToChangePassword: goToChangePassword,
            goToForgotPassword: goToForgotPassword,
            remindPassword: remindPassword,
            chkPwdByMail: loginModel.sendByMailOrSMS, //ko.observable("1") // to pwd module, forget pwd
            oldPassVisible: ko.observable(true),
            oldPassRequired: ko.observable(false),
            reconnectAnotherClient: reconnectAnotherClient,
            selectLanguage1: new selectLanguage(),
            loginWith: null,
            backToLogin: backToLogin,
            isNotCompanyScreen: isNotCompanyScreen,
            loginCompanyLogo: ko.observable(''),
            disableLogin: ko.observable(false),
            visiblePage: ko.observable(false),
            visibleCaptcha: ko.observable(false),
            captchaError: ko.observable(''),
            isExistMadan: ko.observable(false),
            showAbout: showAbout,
            enums: enums,
            configurationManager: configurationManager,
            isDT: isDT,
            showAboutText: ko.observable(''),
            islUrl: ko.observable(''),
            expireTitle: ko.observable(''),
            errorMessageInLogin: ko.observable(''),
            rememberMeChecked: ko.observable(false),
            visibleRememberMe: ko.observable(false),
            id: id,
            isVisibleOTP: ko.observable(false),
            isPasswordToggleCreated: false,
            isForgotPasswordVisible: ko.observable(false),
            isOtpMode: ko.observable(false),
            isForgotPasswordEnable: false,
            lastValueEmpIdOrName: ""
        };
        return vm;
    }
    catch (err) {
        global.treatError(err);
        throw err;
    }

    function id() {
        //currentScreen
        switch (loginModel.state) {
            case 'changePassword':
                return 'changePassword';
            case 'resetPassword':
                return 'changePassword';
            case 'profiles':
                return 'profiles';
        }

        if (loginModel.state != shownScreen.Company.name) {
            return 'loginHarmonyDB';
        }
    }

    function checkIfExplorerVersionIsSupport() {

        var ua = window.navigator.userAgent;
        var msie = ua.indexOf("MSIE ");

        if (msie <= 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./))    //not IE or IE11
            return true;
        var version = parseInt(ua.substring(msie + 5, ua.indexOf(".", msie)));
        if (version > 9)
            return true;

        return false;
    }

    function activate() {
        try {

            initVMPromise = global.system.defer(function (dfd) {
                initVMDfd = dfd;
            }).promise();

            global.displaySpin(true);
            vm.visiblePage(false);

            var lastLang = cacheManager.get(cacheManager.cacheItems.LAST_LANGUAGE);
            if (!isNull(lastLang)) {
                lastOrDefaultLanguage = lastLang;
            }
            else {
                lastOrDefaultLanguage = configurationManager.getConfigParam(global.enums.configParams.LANGUAGE);
            }

            var loginCookie = global.cache.get(global.enums.cacheItems.LOGIN_DETAILS_COOKIE);
            if (loginCookie && loginCookie.ClientId) {
                //auto login by external data case portal.
                //for example: external login from backOffice
                vm.loginModel.companyId(loginCookie.ClientId)
                lastOrDefaultLanguage = loginCookie.LanguageId;
                return getLangugesTbl().done(function getLangugesTblSucceed(response) {//need load language list for case user will click logout.
                    //cannot do it after logout becouse need userId for it.
                    try {
                        cacheManager.set(cacheItems.LANGUAGES_LIST, response);
                        return fromPortalToCompany(true);
                    }
                    catch (err) {
                        global.treatError(err);
                    }
                });
            }
            var currentCompany = global.cache.get(global.enums.cacheItems.CURCOMP);
            if (global.cache.get(global.enums.cacheItems.CURCOMP)) {//logOut events: 6, 7, 1b, 2
                if (global.cache.get(global.enums.cacheItems.NEED_RETRIVE_COMPANY_DATA_AGAIN) == true) {//logOut events: 6, 7
                    global.cache.set(global.enums.cacheItems.NEED_RETRIVE_COMPANY_DATA_AGAIN, false);
                    global.httpGet(global.enums.httpPath.RepeatedRetrivalCompanyData, {
                        query: JSON.stringify(
                        {
                            LanguageId: lastOrDefaultLanguage,
                            CompanyId: global.cache.get(global.enums.cacheItems.CURCOMP).id
                        })
                    }).done(function RepeatedRetrivalCompanyDataSucceed(result) {
                        /* decode special company parmas which were encoded in server*/
                        // WI26761, 18/02/2019, closed decoding on ClientSide
                        // result.CompanyParams = global.helper.codingSpecificComapnyParamsFromServer(1/*decode*/, result.CompanyParams);
                        
                        currentCompany.companyParams = result.CompanyParams;
                        currentCompany.companyPermissions = result.CompanyPermissions;
                        currentCompany.companyPreferencesPermissions = result.CompanyPreferencesPermissions;
                        currentCompany.companyPreferences = result.CompanyPreferences;
                        currentCompany.isExistsHelpFile = result.IsExistsHelpFile;
                        currentCompany.encryptedDbName = result.EncryptedDbName;
                        formsElementsShowType: result.FormsElementsShowTypeData;
                        global.cache.set(global.enums.cacheItems.CURCOMP, currentCompany)
                        if (!global.isNOE(result.DateFormat))
                            cacheManager.set(cacheItems.DATE_FORMAT, result.DateFormat);
                        initVM(global.cache.get(global.enums.cacheItems.LAST_LANGUAGE));
                        resourcesManager.initialLanguage(result.Resources, lastOrDefaultLanguage, true);

                        if (result.ExistSecureCookieOfUser)
                            existUserSecureCookie = true;
                        else
                            existUserSecureCookie = false;
                        global.cache.set(global.enums.cacheItems.EXIST_USER_SECURE_COOKIE, existUserSecureCookie);

                        logOut();
                    });
                }
                else {//logOut events: 1b, 2
                    initVM(global.cache.get(global.enums.cacheItems.LAST_LANGUAGE));
                    loadResources().done(logOut);
                }
            }
            else {//logOut events: 1a, 4
                if (global.isNull(global.cache.get(cacheItems.CUSTOM_CONFIG))) {
                    if (global.isNull(global.cache.get(cacheItems.LANGUAGES_LIST))) {
                        $.when(getLangugesTbl()).done(function handleInitilizeSystemDataAndGetLanguagesResponse(getLangugesTblResponse) {
                            try {
                                cacheManager.set(cacheItems.LANGUAGES_LIST, getLangugesTblResponse[0]);
                                initializeDefinitionsCompleted();
                            }
                            catch (err) {
                                err.logOut = true;
                                global.treatError(err);
                            }
                        });
                    }
                    else
                        //initializeSystemData().done(function initializeSystemDataSucceed(response) {
                        //    try {
                        //        cacheManager.set(cacheItems.CUSTOM_CONFIG, { Language: response.Language, GlobalParams: response.GlobalParams, ExpiryTime: response.ExpiryTime });
                        //        cacheManager.set(cacheItems.DATE_FORMAT, response.DateFormat);
                        initializeDefinitionsCompleted()
                    //    }
                    //    catch (err) {
                    //        err.logOut = true;
                    //        global.treatError(err);
                    //    }
                    //});
                }
                else {
                    if (global.isNull(global.cache.get(cacheItems.LANGUAGES_LIST)))
                        getLangugesTbl().done(function getLangugesTblSucceed(response) {
                            try {
                                cacheManager.set(cacheItems.LANGUAGES_LIST, response);
                                initializeDefinitionsCompleted();
                            }
                            catch (err) {
                                err.logOut = true;
                                global.treatError(err);
                            }
                        });
                    else
                        initializeDefinitionsCompleted();
                }
            }

            var href = window.location.href;
            if (href.indexOf('peo_id') !== -1) {
                loginBySSO();
            }
            global.callMobileFunction('HideLogout');
        }
        catch (err) {
            err.logOut = true;
            global.treatError(err);
        }

    }

    function initControlsEvents() {
        var radios = $("input[name = radSearchBy]");
        for (var i = [0]; i < radios.length; i++)
            radios[i].onclick = vm.radioClicked;

        //there are some elements that use in the same model of selectLanguage control,
        //so we must do it in this way (because in other way - changeLanguage occured many times)
        $("#langCompany .languageRecord").click(changeLanguage);
        $("#langLoginHarmonyDB .languageRecord").click(changeLanguage);
        $("#langLoginActiveDirectory .languageRecord").click(changeLanguage);
        $("#langForgotPassword .languageRecord").click(changeLanguage);
        $("#langChangeResetPassword .languageRecord").click(changeLanguage);
        $("#langProfiles .languageRecord").click(changeLanguage);
        $("#langProfilesActiveDirectory .languageRecord").click(changeLanguage);
        if (!global.isPerformenceImmedientLogin()) {
            shell.visiblePage(true);
            global.displaySpin(false);
            vm.visiblePage(true);
        }     
    }

    function compositionComplete() {
        try {
            $(document).ready(function documentReadyFunction() {

                initVMPromise.done(function initControlsAfterInitSelectLanguageList() {
                    initControlsEvents();                  
                });
                $(document).click(function (e, h) {
                    $("#aboutWebSiteLogin").hide();
                });

                // change placeholder for mail/sms on Forget Pwd
                $("input[type=radio][name=sendByMailSms]").change(function () {
                    var tip = "";
                    switch ($(this).val()) {
                    case '1':
                        $("#SMSToolTip").hide();
                        tip = global.dict()[2010]; //mail
                        break;
                    case '0':
                        $("#SMSToolTip").show();
                        tip = global.dict()[2804]; //sms
                        break;
                    }
                    $("#contactNumber").val('');
                    $("#contactNumber").attr("placeholder", tip);
                });
                             
                if (vm.isPasswordToggleCreated == false) {
                    loadOTPcontrol();
                    vm.isPasswordToggleCreated = true;
                }
            });

            if (global.isMobile()) {                
                setTimeout(
                    function () {
                        $("#mobileSplash").css('display', 'none');
                        if (global.isMobileApp()) {
                            autoLoginForMobile();
                        }
                    }, 3000);
            }
        }
        catch (err) {
            global.treatError(err);
        }
    }

    function loadOTPcontrol() {
        //switch button otp/password  
        var passText = '';
        if (global.isNull(global.dict()[267])) {
            if (lastOrDefaultLanguage == '3')
                passText = "סיסמא";
            else
                passText = "Password";
        }
        else
            passText = global.dict()[267];
        $("#passwordToggle").kendoToolBar({
            items: [
              {
                  type: "buttonGroup", buttons: [
                  { type: "button", togglable: true, id: "passType", text: passText, group: "group1", toggle: switchPasswordType },
                  { type: "button", togglable: true, id: "otpType", text: "OTP", group: "group1", toggle: switchPasswordType }
                  ]
              }
            ]
        });

        var toolbar = $("#passwordToggle").data("kendoToolBar");
        if (toolbar != null && toolbar.toggle != null) {
            toolbar.toggle("#otpType", true);
            toolbar.toggle("#passType", true); //default select button with id: "passType"
        }
    }

    function autoLoginForMobile() {
        try {
            var clientIdContainer = window.getComputedStyle($('#clientIdContainer')[0]);
            if (clientIdContainer.display === 'block') {
                var clientId = global.getClientId();
                if (clientId != null && clientId != '') {
                    vm.loginModel.companyId(clientId);
                    $("#loginPageClientIdSectionLoginBtn").click();
                }
            }
        } catch (err) {
            global.treatError(err);
        }
    }

    function isNotCompanyScreen() {
        try {
            if ((!global.isNull(vm.currentScreen) && vm.currentScreen() != null) && vm.currentScreen() != shownScreen.Company.name)
                return true;
            else
                return false;
        }
        catch (err) {
            global.treatError(err);
        }
    };

    function getLangugesTbl() {
        return global.httpGet(global.enums.httpPath.GetLanguagesList, { languageId: 1 });


    }

    function changeLanguage(e) {
        try {
            lastOrDefaultLanguage = $(e.currentTarget).data("code");
            global.cache.set(global.enums.cacheItems.LAST_LANGUAGE, lastOrDefaultLanguage);
            vm.selectLanguage1.changeLanguageByCode(lastOrDefaultLanguage);           
            loadResources(lastOrDefaultLanguage).done(function loadResourcesSucceed() {
                try {
                    if (vm.loginModel.hasValidationErrorsOnSave() == true)
                        vm.loginModel.validateBeforeSubmit(); //for change the language of validation messages.

                    if (vm.isPasswordToggleCreated == true) {
                        var tb = $("#passwordToggle a.k-toggle-button");
                        if (tb != null && tb.length > 0) {
                            tb[0].innerText = global.dict()[267]; //update text of password button
                            tb[0].text = global.dict()[267];
                        }
                        $("#passwordToggle").data("kendoToolBar").toggle("#passType", true);
                    }                              
                }
                catch (err) {
                    global.treatError(err);
                }
            });
          
        }
        catch (err) {
            global.treatError(err);
        }
    }

    function loadResources() {
        if (global.isNull(cacheManager.get(global.enums.cacheItems.CURCOMP)))
            return resourcesManager.loadResources(lastOrDefaultLanguage, false);
        else
            return resourcesManager.loadResources(lastOrDefaultLanguage, true);
    }

    function fromPortalToCompany(isAutomaticLogin/*when getting from external link(such as BO)*/) {
        try {
            vm.expireTitle('');
            vm.disableLogin(true);
            loginModel.validateBeforeSubmit();

            vm.message(null);
            var checkComp = true;
            if (isAutomaticLogin == true)//no need to check company validations , such as active/demo etc
                checkComp = false;
            global.httpPost(global.enums.httpPath.ConnectToCompanyFromPortal, {
                CompanyId: vm.loginModel.companyId(), languageId: lastOrDefaultLanguage, CheckComp: checkComp
            })
                .done(function handleConnectToCompanyFromPortalResult(response) {
                    try {
                        //vm.message(response.ErrorMsgId);
                        // zion 5/7/2018
                        if(!global.isNullOrEmpty(response.ErrorMsgId))
                        {
                         customMessageWindow.buildMessage({ mode: global.enums.messageType.warning, messageText: response.ErrorMsgId, btnsMode: global.enums.btnsMode.ok });
                         global.showDialog(customMessageWindow).then(function handleDialogResult(dialogResult) {

                            try {

                            }
                            catch (err) {
                                global.treatError(err);
                            }
                         });
                        }
                        if (response.ErrorMsgType == 0) {
                            if (cacheManager.get(cacheManager.cacheItems.LASTCOMP) != vm.loginModel.companyId())
                                needToShowLastUser = false;
                            resourcesManager.initialLanguage(response.Resources, lastOrDefaultLanguage, true);

                            /* ==== DO NOT DECODE !!! save in cache ENCODED params, then in getCompanyParamByFieldName do DECODE*/ 
                            //decode special company parmas which were encoded in server
                            // WI26761, 18/02/2019, closed decoding on ClientSide
                            // response.CompanyParams = global.helper.codingSpecificComapnyParamsFromServer(1/*decode*/, response.CompanyParams);
                            cacheManager.set(cacheManager.cacheItems.LASTCOMP, vm.loginModel.companyId());
                            cacheManager.set(cacheManager.cacheItems.CURCOMP, {
                                id: vm.loginModel.companyId(),
                                name: response.CompName,
                                dbName: response.CompDbName,
                                encryptedDbName: response.EncryptedDbName,
                                companyParams: response.CompanyParams,
                                companyPermissions: response.CompanyPermissions,
                                companyPreferencesPermissions: response.CompanyPreferencesPermissions,
                                companyPreferences: response.CompanyPreferences,
                                isExistsHelpFile: response.IsExistsHelpFile,
                                formsElementsShowType: response.FormsElementsShowTypeData,
                                errorMsgType: 0,
                                errorMsgId: response.ErrorMsgId
                            });
                            if (!global.isNOE(response.DateFormat))
                                cacheManager.set(cacheItems.DATE_FORMAT, response.DateFormat);
                            if (response.ExistSecureCookieOfUser)
                                existUserSecureCookie = true;
                            else
                                existUserSecureCookie = false;
                            global.cache.set(global.enums.cacheItems.EXIST_USER_SECURE_COOKIE, existUserSecureCookie);

                            vm.loginModel.companyName(response.CompName);

                            if (vm.isPrismLogin()) {
                                vm.disableLogin(false);
                                login();
                            }
                            else {
                                startLoginUser();
                            }
                        }
                    }
                    catch (err) {
                        global.treatError(err);
                    }
                })
        }
        catch (err) {
            global.treatError(err);
        }
    }

    function startLoginUser() {

        try {
           
            //check if current ip is allowed
            var fromIP = cacheManager.getCompanyParamByFieldName('FromIP');
            var toIP = cacheManager.getCompanyParamByFieldName('ToIP');
            vm.isExistMadan(cacheManager.getCompanyParamByFieldName('isExistMadanModule_INIT') == 1);

            if (global.isNOE(fromIP) || global.isNOE(toIP)) {
                return continueStartLoginUser();
            }

            var query = {
                FromIP: fromIP,
                ToIP: toIP
            };
            return global.httpGet(global.enums.httpPath.CheckLoginIP, { query: JSON.stringify(query) }).done(function ReturnedFromCheckLoginIP(response) {
                try {
                    if (!global.isNOE(response)) {
                        if( cacheManager.getCompanyParamByFieldName('BlockEntranceByIP') != '1' ){
                                vm.msgIPrange(global.dictMsg()[731]);
                            }
                            else {
                                vm.errorMessageInLogin(global.dictMsg()[526].replace("{0}", response));
                                vm.currentScreen(null);
                                return;
                            }
                    }

                    return continueStartLoginUser();
                }
                catch (err) {
                    global.treatError(err);
                }
            });


        }
        catch (err) {
            global.treatError(err);
        }
    }

    function continueStartLoginUser() {
        var loginCookie = global.cache.get(global.enums.cacheItems.LOGIN_DETAILS_COOKIE);
        if (loginCookie) {
            vm.loginModel.empIdOrName(loginCookie.EmpId);
            vm.loginModel.password(decodeURIComponent(escape(atob(loginCookie.Password))));//decode pass
            if (loginCookie.IdMode == true.toString()) {
                vm.searchBy('byNo');
            }
            if (cacheManager.get(global.enums.cacheItems.CURCOMP).isExistsHelpFile && cacheManager.getCompanyParamByFieldName('eHarmLoginInfo') != null && cacheManager.getCompanyParamByFieldName('eHarmLoginInfo') != '') {
                vm.loginModel.companyInfoFileName(((global.webApiConfig.port.lastIndexOf('/') == global.webApiConfig.port.length - 1) ? global.webApiConfig.port : global.webApiConfig.port + '/') + vm.helpPath + cacheManager.getCompanyParamByFieldName('eHarmLoginInfo'));
            }
            else {
                vm.loginModel.companyInfoFileName(global.getResponseCompanyOfPortalImagePath(1));
            }

        }
        else {
            if (needToShowLastUser)
                //the next condition designed only for safety.
                //(if the previous condition return true- the condition below should return true, too.)
                var lastUser = cacheManager.get(cacheManager.cacheItems.LAST_USER);
            if (!isNull(lastUser)) {
                if (lastUser.isId) {
                    vm.searchBy("byNo");
                }
                else {
                    vm.searchBy("byName");
                }
                vm.loginModel.empIdOrName(lastUser.idOrName);
            }
            else
                vm.searchBy("byNo");
        }

        vm.loginMode = cacheManager.getCompanyParamByFieldName(ADS_Mode.name);
        vm.isSupportLinkCheck(cacheManager.getCompanyParamByFieldName('eHarmSupportLinkCheck') == '1');
        //vm.isHelpLinkVisible(!global.isNullOrEmpty(cacheManager.getCompanyParamByFieldName('webHelpFile')));
        vm.isContactSupervisorLinkVisible(!global.isNullOrEmpty(cacheManager.getCompanyParamByFieldName('SupervisorEmail')));
        if (vm.isSupportLinkCheck() == true) {
            vm.supportLinkURL(cacheManager.getCompanyParamByFieldName('eHarmSupportLinkURL'));
        }
        //if (vm.isHelpLinkVisible() == true) {
        //    vm.helpLinkURL(cacheManager.getCompanyParamByFieldName('webHelpFile'));
        //}
        if (vm.isContactSupervisorLinkVisible() == true) {
            vm.contactSupervisorLinkURL("mailto:" + encodeURIComponent(cacheManager.getCompanyParamByFieldName('SupervisorEmail')));
        }
        vm.isPasswordModule(cacheManager.getCompanyParamByFieldName(PwdModuleActive.name) == PwdModuleActive.modes.passwordModule.name ? true : false);
        vm.isForgotPasswordEnable = cacheManager.getCompanyPreferenceByName("isForgotPasswordEnable", 1) == '1' ? true : false;
        
        if ((vm.loginMode == ADS_Mode.modes.HarmonyDB.name && vm.isPasswordModule()) ||
                (vm.loginMode == ADS_Mode.modes.HarmonyDB.name && !vm.isPasswordModule() && vm.isForgotPasswordEnable))
            vm.isForgotPasswordVisible(true);
        else
            vm.isForgotPasswordVisible(false);
       
        if (vm.isPasswordModule() == true) {
            vm.passwordMaxLength(20);
        }
        else {
            vm.passwordMaxLength(14);
        }

        var enablePasswordChange = cacheManager.getCompanyPreferenceByName("EnableChangePwdOnLogin", 1);
        if (!global.isNullOrEmpty(enablePasswordChange))
            vm.isEnablePasswordChangeVisible(enablePasswordChange == "1");

        if (cacheManager.getCompanyParamByFieldName('webHelpFile') != null && cacheManager.getCompanyParamByFieldName('webHelpFile') != '') {
            vm.helpLinkURL(((global.webApiConfig.port.lastIndexOf('/') == global.webApiConfig.port.length - 1) ? global.webApiConfig.port : global.webApiConfig.port + '/') + vm.helpPath + cacheManager.getCompanyParamByFieldName('webHelpFile'));
            vm.isHelpLinkVisible(true);
        }
        if (cacheManager.get(global.enums.cacheItems.CURCOMP).isExistsHelpFile && cacheManager.getCompanyParamByFieldName('eHarmLoginInfo') != null && cacheManager.getCompanyParamByFieldName('eHarmLoginInfo') != '') {
            vm.loginModel.companyInfoFileName(((global.webApiConfig.port.lastIndexOf('/') == global.webApiConfig.port.length - 1) ? global.webApiConfig.port : global.webApiConfig.port + '/') + vm.helpPath + cacheManager.getCompanyParamByFieldName('eHarmLoginInfo'));
        }
        else {
            vm.loginModel.companyInfoFileName(global.getResponseCompanyOfPortalImagePath(1));
        }

        var enableOTP = cacheManager.getCompanyPreferenceByName("isOTPloginEnable", 1);
        if (vm.loginMode == ADS_Mode.modes.HarmonyDB.name && !vm.isPasswordModule() && !global.isNullOrEmpty(enableOTP) && enableOTP == "1") //vm.loginMode -> Active directory
            vm.isVisibleOTP(true);
        else
            vm.isVisibleOTP(false);

        var eHarmLogoMain = cacheManager.getCompanyParamByFieldName('eHarmLogoMain');
        var logoName = '';


        if (eHarmLogoMain != null && eHarmLogoMain != '' && eHarmLogoMain != '.jpg') {
            logoName = eHarmLogoMain;
            //vm.isExistsLogo(true);
            if (global.webApiConfig.port.lastIndexOf('/') == global.webApiConfig.port.length - 1) {
                vm.loginModel.companyLogo(global.webApiConfig.port + vm.logoPath + logoName);
            }
            else {
                vm.loginModel.companyLogo(global.webApiConfig.port + '/' + vm.logoPath + logoName);
            }
        }
        else {
            if (isDT) {
                vm.loginModel.companyLogo(null);
            }
            else {
                logoName = 'CompLogo.jpg';
                if (global.webApiConfig.port.lastIndexOf('/') == global.webApiConfig.port.length - 1) {
                    vm.loginModel.companyLogo(global.webApiConfig.port + vm.logoPath + logoName);
                }
                else {
                    vm.loginModel.companyLogo(global.webApiConfig.port + '/' + vm.logoPath + logoName);
                }
            }
        }
        global.cache.set(global.enums.cacheItems.LOGO_MAIN, vm.loginModel.companyLogo());

        vm.isPortal(configurationManager.getConfigParam(global.enums.configParams.IS_PORTAL));
        /* set showAbout text with values from companyParam */
        vm.showAboutText(global.dict()[4861] + ': ' + cacheManager.getCompanyParamByFieldName('Version') + "<br/>" +
            cacheManager.getCompanyParamByFieldName('VersionNo') + "<br/>" +
            global.dict()[4862] + ': ' + window.VersionCookie);       

        if (!vm.isPortal()) {
        	$("#aboutWebSiteLogin").addClass("aboutWebSiteNotPortal");
            vm.showAboutText(vm.showAboutText() + "<br/>" +
            "<span class = 'loginAboutSpan'>" + global.dictMsg()[565] + "</span>");
        }
        else {
        	$("#aboutWebSiteLogin").addClass("aboutWebSitePortal");
        }

        if (global.cache.isExistKey(global.enums.cacheItems.LOGIN_DETAILS_COOKIE)) {
            vm.disableLogin(false);
            return login();
        }
       
        //var dateExpire = cacheManager.get(global.enums.cacheItems.CURCOMP).dateExpire;
        //if (!global.isNOE(dateExpire))
        //    vm.expireTitle(global.isNOE(global.dictMsg()[501]) ? "License will expire in " + dateExpire + "days!" : global.dictMsg()[501].replace("{0}", dateExpire));
        //check if company has error with type 0 - show the message
        if (cacheManager.get(global.enums.cacheItems.CURCOMP).errorMsgType == 0)
            vm.message(cacheManager.get(global.enums.cacheItems.CURCOMP).errorMsgId);

        if (vm.loginMode != ADS_Mode.modes.ActiveDirectoryAuto.name && cacheManager.getCompanyParamByFieldName('isRememberMe') == '1')
            vm.visibleRememberMe(true);

        switch (vm.loginMode) {
            case ADS_Mode.modes.HarmonyDB.name:
                if (existUserSecureCookie && global.cache.get(global.enums.cacheItems.LOGOUT_HAS_OCCURED) != '2') {//login automatically
                    vm.disableLogin(false);
                    vm.loginModel.password('*************');
                    login();
                }
                else {
                    vm.isActiveDirectory(false);
                    vm.passwordMaxLength(14);
                    vm.currentScreen(shownScreen.LoginHarmonyDB.name);
                    vm.disableLogin(false);
                }
                break;
            case ADS_Mode.modes.ActiveDirectoryByUser.name:
                if (existUserSecureCookie && global.cache.get(global.enums.cacheItems.LOGOUT_HAS_OCCURED) != '2') {//login automatically
                    vm.disableLogin(false);
                    vm.loginModel.password('*************');
                    login();
                }
                else {
                    vm.searchBy("byName");  //prevent validation of "byId"
                    vm.isActiveDirectory(true);
                    vm.passwordMaxLength(20);
                    vm.loginModel.empIdOrName(global.cache.get(cacheItems.ADS_USER));
                    vm.currentScreen(shownScreen.LoginActiveDirectory.name);
                    vm.disableLogin(false);
                }
                break;
            default:    //case ActiveDirectoryAuto
                vm.searchBy("byName");  ////prevent validation of "byId"
                vm.isActiveDirectory(true);
                vm.passwordMaxLength(20);
                vm.loginModel.empIdOrName(global.cache.get(cacheItems.ADS_USER));
                if (existUserSecureCookie && global.cache.get(global.enums.cacheItems.LOGOUT_HAS_OCCURED) == '2') {//in case user clicked logout && this is adsmode=2 - need to show only user&password input is disabled and let user click on login - process will automatic login with pass&profile
                    vm.loginModel.password('*************');
                    vm.currentScreen(shownScreen.LoginActiveDirectory.name);
                    $("input[name*='password']").prop('disabled', true);
                    $("input[name*='empName']").prop('disabled', true);
                    vm.disableLogin(false);
                    if (!global.isNOE(cacheManager.get(cacheManager.cacheItems.USER_HAS_PROFILE)) && cacheManager.get(cacheManager.cacheItems.USER_HAS_PROFILE).exists)
                        login();
                }
                else if (existUserSecureCookie && global.cache.get(global.enums.cacheItems.LOGOUT_HAS_OCCURED) != '2')//user browse to app in adsmode and has cookie - login automatically
                {
                    vm.disableLogin(false);
                    vm.loginModel.password('*************');
                    login();
                }
                else {//other cases - such as user has no cookie
                    vm.currentScreen(shownScreen.LoginActiveDirectory.name);
                    $("input[name*='password']").prop('disabled', false);
                    $("input[name*='empName']").prop('disabled', false);
                    vm.disableLogin(false);
                }
                break;
        }
    }

    function isId() {
        return vm.searchBy() == "byNo" ? true : false;
    }

    function login() {
        try {
            vm.expireTitle('');
            if (vm.disableLogin() == false) {
                vm.disableLogin(true);
                if (vm.visibleCaptcha()) {
                    vm.captchaError('');
                    var inputHashCode = global.helper.getHashCode($('#captcha').val());
                    if (inputHashCode != $('#captcha').data().realperson.hash) {
                        vm.captchaError(global.dict()[3896]);
                        setCaptcha();
                        $('#captcha').val('');
                        vm.disableLogin(false);
                        return;
                    }
                    else {
                        vm.visibleCaptcha(false);
                        loginClickCounter = 0;
                        firstLoginTime = null;
                        $('#captcha').val('');
                    }
                }
                considerNewEmp().done(function (result) {
                    if (result == true) {
                        vm.loginModel.password(null);
                        //TODO: ask bati about the follow line:
                        if (vm.isPasswordModule()) {
                            vm.oldPassVisible(true);
                            vm.currentScreen(shownScreen.ChangePass.name);
                        }
                        else {
                            vm.oldPassVisible(false);
                            vm.currentScreen(shownScreen.ResetPass.name);
                        }
                        $("[name=newPassword]").focus();
                        vm.disableLogin(false);
                        vm.message(global.dictMsg()[504]);
                        clearPasswordsFields();
                        firstLoginTime = null;
                    }
                    else {
                        if (vm.isPrismLogin()) {
                            vm.loginModel.empIdOrName(vm.PrismResult().employee);
                            vm.loginModel.password(vm.PrismResult().password);
                        }
                        else {
                            loginModel.validateBeforeSubmit();
                            if (vm.loginModel.entityAspect.hasValidationErrors) {
                                vm.disableLogin(false);
                                return false;
                            }
                        }
                        vm.message(null);
                        var currentCompany = global.cache.get(global.enums.cacheItems.CURCOMP);

                        //17/02/2019 - CLOSED encode special company parmas before sending to server, becouse it's saved ENCODED in currentCompany.companyParams
                        //var companyParamsToSend = global.helper.codingSpecificComapnyParamsFromServer(0/*encode*/, currentCompany.companyParams);
                        lastValueEmpIdOrName = vm.loginModel.empIdOrName();
                        var companyParamsToSend = currentCompany.companyParams;
                        global.httpPost(global.enums.httpPath.Login, {
                            EmpIdOrName: vm.loginModel.empIdOrName(), IsId: isId(), Password: vm.isOtpMode() ? '' : btoa(unescape(encodeURIComponent(vm.loginModel.password()))),
                            OtpCode: vm.isOtpMode() ? vm.loginModel.password() : '', OtpPhone: vm.isOtpMode() ? empPhoneNum : '',
                            LanguageId: cacheManager.get(cacheManager.cacheItems.LAST_LANGUAGE), CompanyId: vm.loginModel.companyId(),
                            CompanyPermissions: currentCompany.companyPermissions, CompanyParams: companyParamsToSend,
                            CompanyPreferencesPermissions: currentCompany.companyPreferencesPermissions, CompanyPreferences: currentCompany.companyPreferences,
                            LoginByExistedRememberMe: existUserSecureCookie, RememberMe: vm.loginMode == ADS_Mode.modes.ActiveDirectoryAuto.name || vm.rememberMeChecked(),
                            LogoutHasOccuredByUser: global.cache.get(global.enums.cacheItems.LOGOUT_HAS_OCCURED) == '2'
                        })
                            .done(function handleLoginResult(response) {
                                try {
                                    if (response != null && response.Error != loginError.None.id && global.cache.isExistKey(global.enums.cacheItems.LOGIN_DETAILS_COOKIE)) {
                                        //in case login failed from external link (such as BO) - clean cookie and get in regular login screen
                                        global.cache.deleteCookie(global.enums.cacheItems.LOGIN_DETAILS_COOKIE);
                                        global.isPerformenceImmedientLogin(false);
                                        //reload to login screen
                                        logOut();
                                        //display message for user about failure
                                        vm.message(response.ErrorMessage);
                                    }
                                    else {
                                        checkLoginResult(response);
                                        if (response.Error == loginError.Error.id)
                                            updateErrorLoginsHistory(response, false);
                                    }
                                }
                                catch (err) {
                                    global.treatError(err);
                                }
                            }
                            ).fail(function () {
                                try {
                                    vm.disableLogin(false);
                                }
                                catch (err) {
                                    global.treatError(err);
                                }
                            });
                    }
                });
            }
        }
        catch (err) {
            global.treatError(err);
        }
    }

    function considerNewEmp() {
        if (!global.isNullOrEmpty(loginModel.empIdOrName()) && global.isNOE(loginModel.password())) {
            var query = {
                LanguageId: lastOrDefaultLanguage,
                CompanyId: loginModel.companyId(),
                EmpIdOrName: loginModel.empIdOrName()
            };
            return global.httpGet(global.enums.httpPath.IsNewEmp, { query: JSON.stringify(query) });
        }
        else
            return global.getEmptyPromise();
    }

    function checkLoginResult(response) {
        if (response != null) {
            if (response.Error != loginError.None.id && response.Error != loginError.ChooseProfile.id)//in case returned with error - clear flag of existing cookie cause server already removed it
                existUserSecureCookie = false;
            switch (response.Error) {
                case loginError.Error.id:
                    //in case tried to login by security cookie auto -  need to show screen of login against mode
                    switch (vm.loginMode) {
                        case ADS_Mode.modes.HarmonyDB.name:
                            vm.isActiveDirectory(false);
                            vm.passwordMaxLength(14);
                            vm.currentScreen(shownScreen.LoginHarmonyDB.name);
                            vm.disableLogin(false);
                            break;
                        default:    //case ActiveDirectory 1 or 2
                            vm.searchBy("byName");  //prevent validation of "byId"
                            vm.isActiveDirectory(true);
                            vm.passwordMaxLength(20);
                            vm.loginModel.empIdOrName(global.cache.get(cacheItems.ADS_USER));
                            vm.currentScreen(shownScreen.LoginActiveDirectory.name);
                            vm.disableLogin(false);
                            break;
                    }

                    if (!global.isNull(response.ErrorMessageId) && response.ErrorMessageId != -1 && response.ErrorMessageId != 0) {
                        if (response.ErrorMessageId > 1000 || response.ErrorMessageId == 834)
                            vm.message(global.dict()[response.ErrorMessageId]);
                        else
                            vm.message(global.dictMsg()[response.ErrorMessageId]);
                    }
                    else {
                        vm.message(response.ErrorMessage);
                    }
                    clearPasswordsFields();
                    if (firstLoginTime != null && new Date() < firstLoginTime.setSeconds(firstLoginTime.getSeconds() + 30)) {
                        firstLoginTime.setSeconds(firstLoginTime.getSeconds() - 30);
                        loginClickCounter++;
                        if (loginClickCounter == 5) {
                            vm.visibleCaptcha(true);
                            setCaptcha();
                        }
                    }
                    else {
                        loginClickCounter = 1;
                        firstLoginTime = new Date();
                    }
                    lastLoginTime = new Date();
                    break;
                case loginError.ResetPassword.id:
                    vm.loginModel.password(null);
                    //TODO: ask bati about the follow line:
                    if (vm.isPasswordModule()) {
                        vm.oldPassVisible(true);
                        vm.currentScreen(shownScreen.ChangePass.name);
                    }
                    else {
                        vm.oldPassVisible(false);
                        vm.currentScreen(shownScreen.ResetPass.name);
                    }
                    vm.disableLogin(false);
                    //vm.message(response.ErrorMessage);
                    clearPasswordsFields();
                    showCustomMessage(global.dictMsg()[317]);
                    firstLoginTime = null;
                    break;
                case loginError.BackToPortal.id:
                    if (vm.isPortal()) {
                        reconnectAnotherClient();
                    }
                    vm.message(response.ErrorMessage);
                    firstLoginTime = null;
                    break;
                default:    //case ChooseProfile or None 
                    loginUser(response);
                    firstLoginTime = null;
                    break;
            }
        }

    }

    function clearPasswordsFields() {
        vm.loginModel.password(null);
        vm.loginModel.newPassword(null);
        vm.loginModel.confirmNewPassword(null);
        vm.loginModel.oldPassword(null);
        $("input[name*='password']").prop('disabled', false);
        $("input[name*='empName']").prop('disabled', false);
    }

    function showCustomMessage(msg) {
    	customMessageWindow.buildMessage({ mode: global.enums.messageType.info, messageText: msg, btnsMode: global.enums.btnsMode.ok });
    	customMessageWindow.popupWidth($(window).width() * 0.2 + 'px');
    	global.showDialog(customMessageWindow);
    }

    function setGridLayouts(layouts) {
        $(layouts).each(function (k, v) {
            global.cache.setPropOfLocalStorageItem(global.enums.cacheItems.GRID_LAYOUT, v.GridName, v.Layout);
        });
    }


    function loginUser(response) {
        cacheManager.set(global.enums.cacheItems.LAST_USER, { idOrName: vm.loginModel.empIdOrName(), isId: isId() });
        user.Id = response.EmpId;
        user.sessionId = response.SessionId;

        if (vm.loginMode != ADS_Mode.modes.HarmonyDB.name)  //save ads user in cache for nex time
            global.cache.set(cacheItems.ADS_USER, vm.loginModel.empIdOrName());
        global.startTimer();
        if (configurationManager.getConfigParam(global.enums.configParams.SAVE_LAYOUT)) {
            setGridLayouts(response.GridsLayouts);
        }
        //set current tax year in cache
        cacheManager.set(cacheManager.cacheItems.CURRENT_TAX_YEAR, response.CurrentTaxYear);

        if (response.Error == loginError.None.id) {
            global.cache.set(global.enums.cacheItems.LOGOUT_HAS_OCCURED, '1');
            enterToEHarmony(response.ChosenProfile, response.Permissions, response.MngDashboardsPremissions, response.EmpDashboardsPremissions);
        }
        else {
            cacheManager.set(cacheManager.cacheItems.USER, user);
            var lookups = cacheManager.get(global.enums.cacheItems.LOOKUPS);
            lookups[global.enums.lookupName.UserEmpProfiles.name] = response.Profiles;
            cacheManager.set(global.enums.cacheItems.LOOKUPS, lookups);
            vm.profilesCombo.initialize({ comboId: "profilesCombo", lookupName: global.enums.lookupName.UserEmpProfiles, cancelOptionLabel: true, width: '12.7em' });
            if (!global.isNOE(cacheManager.get(cacheManager.cacheItems.USER_HAS_PROFILE)) && cacheManager.get(cacheManager.cacheItems.USER_HAS_PROFILE).exists && !global.isNOE(cacheManager.get(cacheManager.cacheItems.USER_HAS_PROFILE).profile))
                vm.profilesCombo.changeSelectedItem({
                    Code: cacheManager.get(cacheManager.cacheItems.USER_HAS_PROFILE).profile.Code, Descript: cacheManager.get(cacheManager.cacheItems.USER_HAS_PROFILE).profile.Descript
                });
            else
                vm.profilesCombo.changeSelectedItem({ Code: response.Profiles[0].Code, Descript: response.Profiles[0].Descript });
            //check if company has error with type 0 - show the message
            if (cacheManager.get(global.enums.cacheItems.CURCOMP).errorMsgType == 0)
                vm.message(cacheManager.get(global.enums.cacheItems.CURCOMP).errorMsgId);
            else
                vm.message(null);
            global.isPerformenceImmedientLogin(false);
            if (global.isNOE(cacheManager.get(cacheManager.cacheItems.USER_HAS_PROFILE)))
                cacheManager.set(cacheManager.cacheItems.USER_HAS_PROFILE, { exists: true });
            if (vm.loginMode == ADS_Mode.modes.HarmonyDB.name)
                vm.currentScreen(shownScreen.Profiles.name);
            else
                vm.currentScreen(shownScreen.ProfilesActiveDirectory.name);
            vm.disableLogin(false);
        }
    }

    function loginUserWithProfile() {
        try {
            vm.disableLogin(true);
            global.httpPost(global.enums.httpPath.LoginByProfile, {
                Profile: { Code: vm.profilesCombo.selectedId(), Descript: vm.profilesCombo.selectedItem().Descript }, RememberMe: vm.loginMode == ADS_Mode.modes.ActiveDirectoryAuto.name || vm.rememberMeChecked()
            }).then(function checkLoginByProfileResult(response) {
                try {
                    if (response.ErrorMessage == null) {
                        global.cache.set(global.enums.cacheItems.LOGOUT_HAS_OCCURED, '1');
                        if (!global.isNOE(cacheManager.get(cacheManager.cacheItems.USER_HAS_PROFILE)) && cacheManager.get(cacheManager.cacheItems.USER_HAS_PROFILE).exists) {
                            var objProfile = cacheManager.get(cacheManager.cacheItems.USER_HAS_PROFILE);
                            objProfile.profile = { Code: vm.profilesCombo.selectedId(), Descript: vm.profilesCombo.selectedItem().Descript };
                            cacheManager.set(cacheManager.cacheItems.USER_HAS_PROFILE, objProfile);
                        }
                        enterToEHarmony({ Code: vm.profilesCombo.selectedId(), Descript: vm.profilesCombo.selectedItem().Descript }, response.Permissions, response.MngDashboardsPremissions, response.EmpDashboardsPremissions);
                    }
                }
                catch (err) {
                    global.treatError(err);
                }
            })
        }
        catch (err) {
            global.treatError(err);
        }
    }

    function goToChangePassword() {
        try {
            vm.expireTitle('');
            vm.currentScreen(shownScreen.ChangePass.name);
            vm.disableLogin(false);
        }
        catch (err) {
            global.treatError(err);
        }
    }


    function goToForgotPassword() {
        try {
            vm.chkPwdByMail("1"); //for mail
            $("#contactNumber").attr("placeholder", global.dict()[2010]);
            $("#SMSToolTip").hide();
            vm.currentScreen(shownScreen.ForgotPassword.name);
            vm.disableLogin(false);
        }
        catch (err) {
            global.treatError(err);
        }
    }

    function loginWithNewPassword() {
        try {
            vm.oldPassRequired(false);
            if (vm.oldPassVisible() && global.isNullOrEmpty(vm.loginModel.oldPassword()))
                vm.oldPassRequired(true);
            loginModel.validateBeforeSubmit();
            if (vm.loginModel.entityAspect.hasValidationErrors || vm.oldPassRequired()) {
                return false;
            }
            vm.loginModel.password(vm.loginModel.newPassword());
            var currentCompany = global.cache.get(global.enums.cacheItems.CURCOMP);

            //encode special company parmas before sending to server
            // currentCompany.companyParams = global.helper.codingSpecificComapnyParamsFromServer(0/*encode*/, currentCompany.companyParams);
            lastValueEmpIdOrName = vm.loginModel.empIdOrName();
            if (vm.isOtpMode()) { //if user select to get OTP code but click on change password need to return pass mode in passwordToggle
                vm.isOtpMode(false);
                $("#passwordToggle").data("kendoToolBar").toggle("#passType", true);
                $("#togglePassword").attr("placeholder", global.dict()[267]);
            }

            global.httpPost(global.enums.httpPath.ChangePassword, {
                StatusId: 106,
                EmpIdOrName: vm.loginModel.empIdOrName(),
                IsId: isId(), Password: btoa(unescape(encodeURIComponent(vm.loginModel.oldPassword()))),
                NewPassword: btoa(unescape(encodeURIComponent(vm.loginModel.newPassword()))),
                LanguageId: cacheManager.get(cacheManager.cacheItems.LAST_LANGUAGE),
                CompanyId: vm.loginModel.companyId(),
                CompanyPermissions: currentCompany.companyPermissions, CompanyParams: currentCompany.companyParams,
                CompanyPreferencesPermissions: currentCompany.companyPreferencesPermissions, CompanyPreferences: currentCompany.companyPreferences
            })
                .then(function handleChangePasswordResult(response) {
                    try {
                        checkLoginResult(response);
                        if (response.Error == loginError.Error.id) {
                            updateErrorLoginsHistory(response, true);
                        }
                        else
                            updateLoginsHistory(true);
                    }
                    catch (err) {
                        global.treatError(err);
                    }
                });
        }
        catch (err) {
            global.treatError(err);
        }
    }

    function enterToEHarmony(profile, permissions, mngDashboardsPremissions, empDashboardsPremissions) {

        if (global.cache.isExistKey(global.enums.cacheItems.LOGIN_DETAILS_COOKIE)) {
            //destroy login cookie, for security
            global.cache.deleteCookie(global.enums.cacheItems.LOGIN_DETAILS_COOKIE);
        }

        vm.message(null);
        user.Profile = profile;
        user.Permissions = permissions;

        cacheManager.set(cacheManager.cacheItems.USER, user);
        cacheManager.set(cacheManager.cacheItems.MNG_DASHBOARD_PERMITIONS, mngDashboardsPremissions);
        cacheManager.set(cacheManager.cacheItems.EMP_DASHBOARD_PERMITIONS, empDashboardsPremissions);
        //TODO:handle when the history deleted because the timeout expired
        // router.navigateBack();
        global.changeIsLayoutSaveProp();

        global.res = global.dict();
        global.resMsg = global.dictMsg();
        global.app.setRoot('pages/shell/shell', 'entrance');
        var url = window.location.href;
        if (vm.isPrismLogin() && url.indexOf('?peo_id') !== -1) {
            window.location.href = url.split('?')[0];
            vm.isPrismLogin(false);
        }

        updateLoginsHistory(false);
    }

    function updateLoginsHistory(isChangePassword) {
        var loginByType = isId() ? "EMP_NO" : "EMP_NAME";
        if (vm.isOtpMode()) {
            loginByType = "OTP_" + loginByType;
        }
        if (vm.loginMode != ADS_Mode.modes.HarmonyDB.name) {
            loginByType = "ADS";
        }
        var actionStr = "LOGIN";
        if (isChangePassword)
            actionStr = "CHANGE_PWD";
        var data = {
            Session_ID: global.cache.get(global.cache.enums.cacheItems.SESSION_ID),
            Application_Name: "eHarmony",
            Action: actionStr,
            Action_Status: 0,
            Action_Status_Reason: "",
            Emp_no: global.cache.get(global.cache.enums.cacheItems.USER).Id,
            HostName: "",
            LoginBy_Type: loginByType,
            LoginBy_Value: vm.loginModel.empIdOrName(),
            LanguageId: lastOrDefaultLanguage,
            CompanyId: "",
            CompanyDB: ""
        };
        global.httpPost(global.enums.httpPath.UpdateLoginsHistory, data);
    }

    function loginBySSO() {
        var prismCmd = {
            languageId: global.isNullOrEmpty(cacheManager.get(cacheManager.cacheItems.LAST_LANGUAGE)) ? 1 : cacheManager.get(cacheManager.cacheItems.LAST_LANGUAGE),
            peo_id: getParameterByName('peo_id'),
            key: getParameterByName('key')
        };
        global.httpPost(global.enums.httpPath.PrismSSO, prismCmd)
            .then(function handleChangePasswordResult(response) {
                if (response != null && response.Status == 0) {
                    vm.isPrismLogin(true);
                    var result = {
                        clientId: response.ClientId,
                        employee: response.Employee,
                        password: response.Password
                    };
                    vm.PrismResult(result);
                    vm.loginModel.companyId(result.clientId);
                    vm.loginModel.empIdOrName(vm.PrismResult().employee);
                    vm.loginModel.password(vm.PrismResult().password);
                    fromPortalToCompany(true);
                }
            });
    }

    function getParameterByName(name) {
        var url = window.location.href;
        name = name.replace(/[\[\]]/g, '\\$&');
        var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
            results = regex.exec(url);
        if (!results) return null;
        if (!results[2]) return '';
        return decodeURIComponent(results[2].replace(/\+/g, ' '));
    }

    function updateErrorLoginsHistory(response, isChangePassword) {
        var loginByType = isId() ? "EMP_NO" : "EMP_NAME";
        var loginByValue = lastValueEmpIdOrName;
        if (vm.isOtpMode()) {
            loginByType = "OTP_" + loginByType;
        }
        if (vm.loginMode != ADS_Mode.modes.HarmonyDB.name) {
            loginByType = "ADS";
            loginByValue = global.cache.get(cacheItems.ADS_USER) == null ? loginByValue : global.cache.get(cacheItems.ADS_USER);
        }
        var actionStr = "LOGIN";
        var actionStatusReason = vm.message(); //response.ErrorMessage
        if (isChangePassword) {
            actionStr = "CHANGE_PWD";
        }
        var data = {
            Session_ID: "",
            Application_Name: "eHarmony",
            Action: actionStr,
            Action_Status: 1,
            Action_Status_Reason: actionStatusReason,
            Emp_no: -1, //default value, because of response error emp_no not created 
            HostName: "",
            LoginBy_Type: loginByType,
            LoginBy_Value: loginByValue,
            LanguageId: lastOrDefaultLanguage,
            CompanyId: vm.isPortal() ? vm.loginModel.companyId() : "0",
            CompanyDB: global.cache.get(global.enums.cacheItems.CURCOMP).dbName
        };
        global.httpPost(global.enums.httpPath.UpdateLoginsHistory, data);
    }

    function backToLogin() {
        try {
            global.cache.set(global.enums.cacheItems.LOGOUT_HAS_OCCURED, '1');
            existUserSecureCookie = false;
            global.helper.removeSession().done(function backToLoginRemoveSessionSucceed() {
                try {
                    logOut({ existUserSecureCookie: false })
                }
                catch (err) {
                    global.treatError(err);
                }
            });
        }
        catch (err) {
            global.treatError(err);
        }
    }




    function logOut(params) {
        try {
            if (!global.isNull(global.cache.get(global.enums.cacheItems.CURCOMP))) {//if it not arived from first-login
                global.stopTimer();
                clearData(false);
                cacheManager.set(cacheManager.cacheItems.USER, null);
                cacheManager.set(cacheManager.cacheItems.LOOKUPS, {});
                if (global.isNOE(params) || (!global.isNOE(params) && global.isNOE(params.existUserSecureCookie)))
                    existUserSecureCookie = global.cache.get(global.enums.cacheItems.EXIST_USER_SECURE_COOKIE);
                getLangugesTbl().done(function getLangugesTblSucceed(response) {
                    try {
                        lookupManager.saveLookupAtCache(global.enums.lookupName.LanguagesList, response)
                        needToShowLastUser = true;
                        startLoginUser();
                    }
                    catch (err) {
                        global.treatError(err);
                    }
                });
            }
        }
        catch (err) {
            global.treatError(err);
        }
    }

    function reconnectAnotherClient() {
        try {
            firstLoginTime = null;
            global.helper.removeSession();
            clearData(true);
             vm.isOtpMode(false);
            cacheManager.set(cacheManager.cacheItems.USER, null);
            cacheManager.set(cacheManager.cacheItems.LAST_USER, null);
            cacheManager.set(cacheManager.cacheItems.CURCOMP, null);
            cacheManager.set(cacheManager.cacheItems.LASTCOMP, null);
            initializeDefinitionsCompleted();
            initControlsEvents();//must call this function after calling to initializeDefinitionsCompleted becouse initializeSelectLanguages can cancel it's click-event-binding
            vm.currentScreen(shownScreen.Company.name)
            vm.disableLogin(false);
            //call method reconnect in server
            global.httpPost(global.enums.httpPath.ReconnectAnotherClient);
        }
        catch (err) {
            global.treatError(err);
        }
    }

    function initVM() {

        vm.logoPath = configurationManager.getConfigParam(global.enums.configParams.LOGO_PATH);
        vm.searchBy("byNo");
        vm.selectLanguage1.initializeLanguageList(global.enums.lookupName.LanguagesList);
        vm.selectLanguage1.changeLanguageByCode(lastOrDefaultLanguage);
        vm.helpPath = configurationManager.getConfigParam(global.enums.configParams.HELP_PATH);
        vm.isPortal(configurationManager.getConfigParam(global.enums.configParams.IS_PORTAL));
        if (!global.isNull(global.cache.get(global.enums.cacheItems.CURCOMP))) {
            vm.loginModel.companyId(global.cache.get(global.enums.cacheItems.CURCOMP).id);
            vm.loginModel.companyName(global.cache.get(global.enums.cacheItems.CURCOMP).name);
        }
        /* set ISL url value */
        vm.islUrl(configurationManager.getConfigParam(global.enums.configParams.ISL_DOWNLOAD_URL));
        initVMDfd.resolve();
    }

    function initializeDefinitionsCompleted() {
        initVM();
        if (vm.isPortal()) {
            loadResources(lastOrDefaultLanguage).done(continueAlgoritm);           
        }
        else {
            vm.loginModel.companyId(companyId_Case_InHouse);
            ConnectToCompanyCaseInHouse().done(startLoginUser);
        }       
    }

    function continueAlgoritm() {
        try {
            if (!isNull(cacheManager.get(cacheManager.cacheItems.LASTCOMP)))
                vm.loginModel.companyId(cacheManager.get(cacheManager.cacheItems.LASTCOMP));
            vm.currentScreen(shownScreen.Company.name);           
            vm.disableLogin(false);
        }
        catch (err) {
            global.treatError(err);
        }
    }

    function ConnectToCompanyCaseInHouse() {
        return global.httpPost(global.enums.httpPath.ConnectToCompanyCaseInHouse, {
            LanguageId: lastOrDefaultLanguage
        }).done(function handleConnectToCompanyCaseInHouseResult(response) {
            try {
                resourcesManager.initialLanguage(response.Resources, lastOrDefaultLanguage, true);

                /* ==== DO NOT DECODE !!! save in cache ENCODED params, then in getCompanyParamByFieldName do DECODE*/
                //decode special company parmas which were encoded in server
                // WI26761, 18/02/2019, closed decoding on ClientSide
               // response.CompanyParams = global.helper.codingSpecificComapnyParamsFromServer(1/*decode*/, response.CompanyParams);

                cacheManager.set(cacheManager.cacheItems.CURCOMP, {
                    id: companyId_Case_InHouse,
                    name: response.CompName,
                    dbName: '',
                    companyParams: response.CompanyParams,
                    companyPermissions: response.CompanyPermissions,
                    companyPreferencesPermissions: response.CompanyPreferencesPermissions,
                    companyPreferences: response.CompanyPreferences,
                    encryptedDbName: response.EncryptedDbName,
                    isExistsHelpFile: response.IsExistsHelpFile,
                    formsElementsShowType: response.FormsElementsShowTypeDTO,
                    dateExpire: response.DateExpire
                });
                if (!global.isNOE(response.DateFormat))
                    cacheManager.set(cacheItems.DATE_FORMAT, response.DateFormat);
                if (response.ExistSecureCookieOfUser)
                    existUserSecureCookie = true;
                else
                    existUserSecureCookie = false;
                global.cache.set(global.enums.cacheItems.EXIST_USER_SECURE_COOKIE, existUserSecureCookie);                
            }
            catch (err) {
                global.treatError(err);
            }
        })
    };


    function clearData(needToClearCompanyData) {
        if (needToClearCompanyData) {
            loginModel.companyId(null);
            loginModel.companyName(null);
            loginModel.companyInfoFileName(null);
            loginModel.companyLogo(null);
        }

        //TODO: check how to clear breeze object
        // loginModel.id(null);
        vm.message(null);
        loginModel.empIdOrName(null);
        loginModel.password(null);
        loginModel.newPassword(null);
        loginModel.confirmNewPassword(null);
        loginModel.oldPassword(null);
        loginModel.empProfiles(null);
       // loginModel.emailAddress(null);
        loginModel.contactNumber(null);
        vm.captchaError('');
        user = new userModel();
        //vm.selectedProfile(null);

    }



    function deactivate() {
        try {
            clearData(false);
        }
        catch (err) {
            global.treatError(err);
        }
    }
    
    function remindPassword() {
        try {
            vm.message('');
            var dictMsgStr = "";

            if (vm.loginMode == ADS_Mode.modes.HarmonyDB.name && !vm.isPasswordModule() && vm.isForgotPasswordEnable) { //if not password module
                if (isId()) {
                    loginModel.validateBeforeSubmit();
                    if (vm.loginModel.entityAspect.hasValidationErrors && vm.loginModel.getFirstValErrMsg('empIdOrName') != '')
                        return;
                }
                global.httpPost(global.enums.httpPath.RemindPasswordRegularModule, {
                    IsId: isId(),
                    EmpIdOrName: vm.loginModel.empIdOrName(),
                    CompanyId: vm.loginModel.companyId(),
                    CompanyDB: global.cache.get(global.enums.cacheItems.CURCOMP).dbName,
                    EmailAddress: '',
                    PwdStr: "",
                    IsSendByMail: vm.chkPwdByMail(), // 1-by mail, 0 by sms
                    LanguageId: lastOrDefaultLanguage
                }).then(function checkRemindPasswordRegularResult(response) {
                    try {
                        if (response != null) {
                            switch (response.StatusId) {
                                case 0:
                                    vm.backToLogin(); // back to login screen + msg
                                    customMessageWindow.buildMessage({ mode: global.enums.messageType.info, messageText: global.dictMsg()[755], btnsMode: global.enums.btnsMode.ok });
                                    global.showDialog(customMessageWindow);
                                    break;
                                case 3:
                                    vm.message(global.dict()[4317] + ": " + response.Message)
                                    break;
                                case 4:
                                    vm.message(global.dictMsg()[756])
                                    break;
                                case 5:
                                    vm.message(global.dictMsg()[757]);
                                    break;
                                case 6:
                                    vm.message(global.dict()[4312]);
                                    break;
                                default:
                                    vm.message(response.Message);
                                    break;
                            }
                        }
                    }
                    catch (err) {
                        global.treatError(err);
                    }
                });
            }
            else {
                loginModel.validateBeforeSubmit();
                if (vm.loginModel.entityAspect.hasValidationErrors) {
                    var isErr = 1
                    return false; //-- TO RETURN!!!
                }
                /*
                var contactNumber = vm.loginModel.emailAddress();
                if (vm.chkPwdByMail() == 0) contactNumber = vm.loginModel.mobileNumber();
                */
                var contactNumber = '';
                if (vm.chkPwdByMail() == 0) {
                    contactNumber = vm.loginModel.contactNumber().replace(/[<>^a-zA-Z ]/g, '');
                }
                else {
                    contactNumber = vm.loginModel.contactNumber();
                }

                global.httpPost(global.enums.httpPath.RemindPassword, {
                    IsId: isId(),
                    EmpIdOrName: vm.loginModel.empIdOrName(),
                    CompanyId: vm.loginModel.companyId(),
                    CompanyDB: global.cache.get(global.enums.cacheItems.CURCOMP).dbName,
                    EmailAddress: contactNumber,
                    PwdStr: "",
                    IsSendByMail: vm.chkPwdByMail(), // 1-by mail, 0 by sms
                    LanguageId: lastOrDefaultLanguage
                }).then(function checkRemindPasswordResult(response) {
                    try {
                        if (response.ErrorMessageId != "") {
                            var dictMsgId = parseInt(response.ErrorMessageId);


                            if (dictMsgId > 1000) {
                                dictMsgStr = global.dict()[dictMsgId]
                                if (dictMsgId == 1643)
                                    dictMsgStr += " " + vm.loginModel.empIdOrName();
                            }
                            else
                                dictMsgStr = global.dictMsg()[dictMsgId];

                            vm.message(dictMsgStr);
                        }
                        else if (response.StatusId != 0 && !global.isNullOrEmpty(response.Message))
                            vm.message(response.Message)
                        else {
                            dictMsgStr = global.dictMsg()[587].replace("{0}", contactNumber) + ' ' + vm.loginModel.empIdOrName();
                            vm.expireTitle(dictMsgStr);
                            vm.backToLogin(); // with message on login screen
                        }
                    }
                    catch (err) {
                        global.treatError(err);
                    }
                });
            }
        }
        catch (err) {
            global.treatError(err);
        }
    }

    function bgImageLoginBtnUrlCompute() {
        try {
            if (webApiConfig.href.lastIndexOf('/') == webApiConfig.href.length - 1)
                return "url(" + webApiConfig.href + imageLoginBtnUrl + ")";
            else
                return "url(" + webApiConfig.href + '/' + imageLoginBtnUrl + ")";
        }
        catch (err) {
            global.treatError(err);
        }
    }

    function radioClick() {
        try { loginModel.empIdOrName(""); } catch (err) { global.treatError(err); }
    }


    function visibleSnakeCompute() {
        try {
            return global.isInAjax;
        }
        catch (err) {
            global.treatError(err);
        }
    }

    function setCaptcha() {
        $('#captcha').realperson('destroy')
        $('#captcha').realperson();
    }

    function showAbout(s, e) {
        $('#aboutWebSiteLogin').show(); 
        e.stopPropagation();
    }


    function switchPasswordType(sender, e) {
        if (sender.id == "otpType"){
            $("#togglePassword").attr("placeholder", global.dict()[4726]);
            generateOTP();
            vm.isOtpMode(true);
        }           
        else {
            $("#togglePassword").attr("placeholder", global.dict()[267]);
            vm.isOtpMode(false);
        }      
    }

    function generateOTP() {
        if (!global.isNOE(vm.loginModel.empIdOrName())) {
            if (isId()) {               
                loginModel.validateBeforeSubmit();
                if (vm.loginModel.entityAspect.hasValidationErrors && vm.loginModel.getFirstValErrMsg('empIdOrName') != '')
                    return;
            }          

            var guid = global.cache.getCompanyParamByFieldName("GUID");
            global.httpGet(global.enums.httpPath.LoginGenerateOTP, {
                query: JSON.stringify({
                    GUID: guid,
                    MobileNumber: '',
                    EmpNo: isId() ? vm.loginModel.empIdOrName() : '',
                    EmpName: isId() ? '' : vm.loginModel.empIdOrName(),
                    ClientId: vm.isPortal() ? vm.loginModel.companyId() : "0",
                    LanguageId: lastOrDefaultLanguage
                })
            }).done(function getOtpFinish(result) {
                if (!global.isNull(result)) {
                    if (result.Status == -2) {
                        customMessageWindow.buildMessage({ mode: global.enums.messageType.error, messageText: global.dictMsg()[747], btnsMode: global.enums.btnsMode.ok });
                        global.showDialog(customMessageWindow);
                    }
                    else if (result.Status == -1) {
                        customMessageWindow.buildMessage({ mode: global.enums.messageType.error, messageText: global.dict()[3002], btnsMode: global.enums.btnsMode.ok });
                        global.showDialog(customMessageWindow);
                    }
                    else if (result.Status == 0) {
                        empPhoneNum = result.Description;
                        customMessageWindow.buildMessage({ mode: global.enums.messageType.info, messageText: global.dictMsg()[750], btnsMode: global.enums.btnsMode.ok });
                        global.showDialog(customMessageWindow);
                    }
                    else {
                        customMessageWindow.buildMessage({ mode: global.enums.messageType.error, messageText: global.dictMsg()[751], btnsMode: global.enums.btnsMode.ok });
                        global.showDialog(customMessageWindow);
                    }
                }
            });
        }
        else {
            customMessageWindow.buildMessage({ mode: global.enums.messageType.info, messageText: global.dictMsg()[753], btnsMode: global.enums.btnsMode.ok });
            global.showDialog(customMessageWindow);
        }
    }

});
