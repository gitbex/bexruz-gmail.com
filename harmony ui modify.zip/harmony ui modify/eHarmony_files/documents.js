﻿define(function docsView(require) {

    //#region require modules
    var global = require('common/global');
    var router = require('plugins/router');
    //#endregion require modules

    var noPermission = global.enums.permissionCodes.NO_PERMISSION.code;
    var notVisiblePermission = global.enums.permissionCodes.ALWAYS_NOT_VISIBLE.code;

    var allPermissions = {
        payRoll: !global.permissions.isVisibleCompanyParam(global.enums.companyParamNames.SalaryPortalSupport.name) ? notVisiblePermission : global.enums.permissionCodes.DOCS_PAYROLL.code,
        form101: !global.permissions.isVisibleCompanyParam(global.enums.companyParamNames.IsElectronicForm101.name) ? notVisiblePermission : global.enums.permissionCodes.FORM_101_PERMISSION.code,
        form106: !global.permissions.isVisibleCompanyParam(global.enums.companyParamNames.IsForm106.name) ? notVisiblePermission : global.enums.permissionCodes.DOCS_FORM106.code,
        empDocs: global.enums.permissionCodes.EMP_DOCUMENTS.code,
        templateSetting: global.enums.permissionCodes.FORMS_DIGITAL_DOCUMENTS_DEF.code 
    };
    //local enum
    var frames = {
        payRoll: { path: 'views/forms/payRoll/payRoll', permission: allPermissions.payRoll, docType: global.enums.documentType.paycheck },
        form101: { path: 'pages/forms/form101/form101Main', permission: allPermissions.form101, docType: global.enums.documentType.form101 },
        form106: { path: 'views/forms/form106/form106', permission: allPermissions.form106, docType: global.enums.documentType.form106 },
        empAbsDocs: { path: 'views/forms/EmpDocuments/EmpAbsDoc', permission: allPermissions.empDocs, docType: global.enums.documentType.employee },
        templatesDocs: { path: 'views/forms/formsTemplate/templatesSetting', permission: allPermissions.templateSetting, docType: global.enums.documentType.template } //to change 
    }


    //#region vm (public fields)
    var vm = {
        global: global,
        changeFrame: changeFrame,
        linkedDocType: ko.observable(0),
        startDocType: 0,
        docPayRollPermissionCode: allPermissions.payRoll,
        docForm101PermissionCode: allPermissions.form101,
        docForm106PermissionCode: allPermissions.form106,
        docEmpDocsPermissionCode: allPermissions.empDocs,
        docTemplatePermissionCode: allPermissions.templateSetting,
        documentsMenuPermission: global.enums.permissionCodes.MENU_DOCUMENTS.code,
        isIsraelCustomerCountry: ko.observable(false),
        //isPermitPayRoll: function () {
        //    var salaryCompanyPermission = global.permissions.isVisibleCompanyParam(global.enums.companyParamNames.SalaryPortalSupport.name);
        //    return global.permissions.isVisible(frames.payRoll.permission) && salaryCompanyPermission;
        //},
        homeClick: homeClick,
        currentFrame: ko.observable(),
        frames: frames,
        activate: activate,
        canActivate: canActivate,
        changeFrameClick: changeFrameClick
    };
    //#endregion vm (public fields)

    //#region events  
    function activate(parm, docType) {
        try {
            global.httpGet(global.enums.httpPath.CheckIsraelFormsEnabled).done(function setParam(result) {
                if (result.ReturnVal == 1) { vm.isIsraelCustomerCountry(true); }
            });
            if (docType) {
                var requiredTab = getTabByDoctype(docType);
                changeFrame(requiredTab);
            }
            else if (window.location.hash.lastIndexOf('/') > 0 && window.location.hash.lastIndexOf('/') == window.location.hash.length - 2) {
                //in case get from shell - where url is from param StartScreen in companyPrefernces
                var requiredTab = getTabByDoctype(parseInt(window.location.hash.substring(window.location.hash.lastIndexOf('/') + 1)));
                changeFrame(requiredTab);
            }
            else { //no specific docType - default docType in documents
                var startDoc;
                $.each(frames, function findFirstTab(i, tab) {
                    if (global.permissions.isVisible(tab.permission) && tab.permission != notVisiblePermission) {
                        if (tab.docType == frames.form101.docType && global.configurationManager.getConfigParam(global.enums.configParams.WEB_CONTAINS_101) == false)
                            return;
                        else{
                            startDoc = tab;
                            return false;//break loop
                        }
                    }
                });
                if(startDoc!=null) changeFrame(startDoc);
            }
        }
        catch (err) {
            global.treatError(err);
        }
    }

    function canActivate() {
        var permit = global.checkVisiblePermission(global.enums.permissionCodes.MENU_DOCUMENTS.code);
        if (permit) {
            return true;
        }
        else return false;
    }
    /*
    // see http://stackoverflow.com/questions/19179490/navigate-using-router-and-pass-an-object-as-a-query-string
    function activate(docType) { // see shell.js ->setRouter
        //var myrouteconfig = router.activeInstruction().config;
        //var mycallobject = myrouteconfig.params; //your object params
        //var valdocType = mycallobject.docType; // your param2 last value
        if (docType == global.enums.documentType.form101) {
            alert("33")
        }
    }
    */   

    function homeClick() {
        try {
            if (window.location.hash.indexOf('/') > -1) {
                var slashLocation = window.location.hash.indexOf('/');
                var netoHash = window.location.hash.substring(0, slashLocation);
                $(netoHash).removeClass("backBlack");
            }
            else
                $(window.location.hash).removeClass("backBlack");
            $("#home").addClass("backBlack");
            router.navigate("#home");
        } catch (err) {
            global.treatError(err);
        }
    }

    function changeFrameClick(e, s) {
        try {
            changeFrame(frames[s.currentTarget.id]);
        } catch (err) {
            global.treatError(err);
        }
    }
    //#endregion

    //#region methods
    function changeFrame(tab) {
        require([tab.path], function (tabModule) {
            var composeParameters = {
                model: tabModule,
                view: tab.path + '.html'
            };
            vm.currentFrame(composeParameters);
        });
        vm.linkedDocType(tab.docType);
    }

    function getTabByDoctype(docType) {
        var requiredTab;
        $.each(frames, function findMatchTab(i, tab) {
            if (tab.docType == docType) {
                requiredTab = tab;
                return false;//break loop
            }
        });
        if (global.isNull(requiredTab)) {
            throw new Error('unknown doc type required');
        }
        return requiredTab;
    }
    //#endregion methods

    return vm;
});