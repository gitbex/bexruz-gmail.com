﻿define(function constsModule (require) {

    var errorManager = require('common/errorManager');

    try {
        var timeOutArgs = { one: { val: 1000 }, two: { val: 2000 }, three: { val: 3000 } };
        var defaultLanguage = { Code: 1, Descript: "English" };
        var getAbsencesListForGroupUpdateTypeParam = 40;
        var getAbsencesListForGroupUpdateUserNoParam = 0;
        var getAbsencesListForManualEditTypeParam = 39;
        var breezeSavingErrorIdentify = "errorInSaving:";
        var zeroTime = '00:00';
        var maxTime = '23:59';
     
        var tempTableForProcessGlobalUpdateName = "TmpSerWebEmp_";
        var dboSchema = 'dbo';
        var monthFirstDateFormat = 'MM/dd/yyyy';
        var dayFirstDateFormat = 'dd/MM/yyyy';
        var yearFirstDateFormat = 'yyyy-MM-dd';
        var dateTimeFormatYMDTHMS = 'yyyy-MM-ddTHH:mm:ss';
        var dateTimeFormatYYYYMM = 'yyyy/MM'; // 02.01.2018 lyn 
        var webUserProfile = 9999;
        var supervisiorProfile = 0;
        var empOrgTree = 6;
        var profile = 'profile';
        var user = 'user';
        var report = 'rep';
        var firstDay1900 = '01/01/1900';
        var hebrewLanguage = "he-IL";
        var hebrewExplorerMessage = "האפליקציה אינה תומכת בדפדפן זה, יש לעדכן את הדפדפן לגירסה 10.";
        var EnglishExplorerMessage ="This application does not support this browser, please update your browser to version 10.";
        var defaultColor = "ffffff";
        var defaultTypeForNewController = 19;
        var defaultMediaPath = 'files';
        var enterAscii = 13;
        var backSpaceAscii = 8;
        var deleteAscii = 46;
        var tempFilesPath = "Exports/";

        var constsSets = {
            timeOutArgs: timeOutArgs,
            defaultLanguage: defaultLanguage,
            getAbsencesListForGroupUpdateTypeParam: getAbsencesListForGroupUpdateTypeParam,
            getAbsencesListForGroupUpdateUserNoParam: getAbsencesListForGroupUpdateUserNoParam,
            getAbsencesListForManualEditTypeParam: getAbsencesListForManualEditTypeParam,
            breezeSavingErrorIdentify: breezeSavingErrorIdentify,
            zeroTime: zeroTime,
           
            tempTableForProcessGlobalUpdateName: tempTableForProcessGlobalUpdateName,
            dboSchema: dboSchema,
            monthFirstDateFormat: monthFirstDateFormat,
            dayFirstDateFormat: dayFirstDateFormat,
            yearFirstDateFormat: yearFirstDateFormat,
            webUserProfile: webUserProfile,
            empOrgTree: empOrgTree,
            maxTime: maxTime,
            profile: profile,
            report: report,
            firstDay1900: firstDay1900,
            hebrewLanguage: hebrewLanguage,
            hebrewExplorerMessage: hebrewExplorerMessage,
            EnglishExplorerMessage: EnglishExplorerMessage,
            defaultColor: defaultColor,
            defaultTypeForNewController: defaultTypeForNewController,
            defaultMediaPath: defaultMediaPath,
            supervisiorProfile: supervisiorProfile,
            enterAscii: enterAscii,
            backSpaceAscii: backSpaceAscii,
            deleteAscii: deleteAscii,
            dateTimeFormatYMDTHMS: dateTimeFormatYMDTHMS,
            dateTimeFormatYYYYMM : dateTimeFormatYYYYMM,
            user: user,
            tempFilesPath: tempFilesPath

        };
        return constsSets;
    }
    catch (err) {
        errorManager.treatError(err);
    }
});