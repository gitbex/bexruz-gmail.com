﻿define(function lookupManagermodule(require) {

    var global = require('common/global');
    var cacheManager = require('common/cache/cacheManager');
    var http = require('plugins/http');
    var cacheItems = global.enums.cacheItems;
    var Enumerable = require('Enumerable');
    var configurationManager = require('common/configurationManager');

    var nonSortOrderArr = ["AvailableDays","NotifierDaysOfWeek"]; //for multiselect elems -> prevent additional sorting, display according sp LookUp returns
    function getLookupWithDefaultQuery(lookupnameObj, xmlData, sortByDescript) {
        //lookupName is enum-obj, not string
        var query =
             {
                 EmpNo: global.cache.get(global.enums.cacheItems.USER).Id,
                 UserNo: global.cache.get(global.enums.cacheItems.USER).Profile.Code,
                 ElemName: lookupnameObj.name,
                 PageNo: 0,
                 PageSize: 200,
                 PagingBy: global.isNull(sortByDescript) ? false : sortByDescript,
                 PagingOrder: false,
                 SearchBy: 0,
                 SearchVal: "",
                 SearchExact: true,
                 OtherParamsXML: global.isNull(xmlData) ? '' : xmlData
             };
        return getLookupData(query, lookupnameObj).done(function saveAtCache(result) {
            if (lookupnameObj.mode == global.enums.cacheOrDb.cacheMode) {
                saveLookupAtCache(lookupnameObj, result);
            }
        });
    }

    function getLookup(dfdSource, lookupList, query, lookupnameObj, goToServerAnyCase) {

        //from db
        if (lookupnameObj.mode == global.enums.cacheOrDb.dbMode || goToServerAnyCase == true ||
            query.OtherParamsXML != '' && query.OtherParamsXML != lookupnameObj.xmlData) {
            if (lookupnameObj.xmlData != 'undifined') {
                lookupnameObj.xmlData = query.OtherParamsXML;
            }
            return getLookupData(query, lookupnameObj).done(function finish(response) {
                try {
                    if (lookupnameObj.mode.id == global.enums.cacheOrDb.cacheMode.id) {
                        //case goToServerAnyCase == true || query.OtherParamsXML != '' && query.OtherParamsXML != lookupnameObj.xmlData
                        var lookups = cacheManager.get(cacheItems.LOOKUPS);
                        saveLookupAtCache(lookupnameObj, response);
                    }
                    lookupList(response);
                    dfdSource.resolve();
                }
                catch (err) {
                    global.treatError(err);
                }
            })
        }
            //from cache
        else {

            var lookups = cacheManager.get(cacheItems.LOOKUPS);
            if (lookups[lookupnameObj.cacheName]) {
                lookupList(lookups[lookupnameObj.cacheName]);
                doFilter(lookupList, query, lookupnameObj);
                doOrder(dfdSource, lookupList, query, lookupnameObj);
            }
                //lookup doesn't exist in memoryCache - get it from db (or create it- if it special lookup)
            else {
                if (lookupnameObj.localCreate == true) {
                    switch (lookupnameObj.cacheName){
                        case global.enums.lookupName.FirstHundred.cacheName:
                            var firstHundredLookup = [];
                            for (var i = 1; i < 100; i++) {
                                firstHundredLookup.push({ Code: i });
                            }
                            saveLookupAtCache(lookupnameObj, firstHundredLookup);
                            lookupList(firstHundredLookup);
                            dfdSource.resolve();
                            break;
                        case global.enums.lookupName.NoData.cacheName:
                            lookupList([]);
                            dfdSource.resolve();
                            break;
                        default:throw Error('this lookpup is not local create');
                    }
                }
                else {
                    getLookupData(query, lookupnameObj).done(function getLookupSucceed(response) {
                        try {
                            lookupList(response);
                            saveLookupAtCache(lookupnameObj, response);
                            doFilter(lookupList, query, lookupnameObj);
                            doOrder(dfdSource, lookupList, query, lookupnameObj)
                        }
                        catch (err) {
                            global.treatError(err);
                        }
                    });
                }
            }
        }
    }


    function doFilter(lookupList, query, lookupnameObj) {
        try {
            var lookups = global.cache.get(global.enums.cacheItems.LOOKUPS);
            if (query.SearchVal == '') {

                /*return*/ lookupList(lookups[lookupnameObj.cacheName]);
            }
                //there is value for filter
            else {

                var filterArray = lookups[lookupnameObj.cacheName];
                //Gil code for implemeting the code below
                //var filterFunction = getFilterFunction(query);
                //var queryResult = Enumerable.From(filterArray)
                //                                       .Where(filterFunction)
                //                                       .Select(function (lu) { return lu })
                //                                       .ToArray();
                //lookupList(queryResult);

                //function getFilterFunction(query) {
                //    switch (query.SearchBy) {
                //        case 0:
                //            if (query.SearchExact) {
                //                return function (lu) { return lu.Code.toLowerCase().indexOf(query.SearchVal) >= 0 };
                //            }
                //            else {
                //                function (lu) { return lu.Code == query.SearchVal }
                //            }
                //            break;

                //        /// TODO: implement the rest
                //    }
                //}

                switch (query.SearchBy) {

                    //by code
                    case 0:
                        //like
                        if (query.SearchExact) {
                            var queryResult = Enumerable.From(filterArray)
                                                       .Where(function whereOnFilterArrayExactByCode(lu) { return lu.Code.toLowerCase().indexOf(query.SearchVal) >= 0 })
                                                       .Select(function selectOnFilterArrayExactByCode(lu) { return lu })
                                                       .ToArray();
                            lookupList(queryResult);
                            //return queryResult;
                        }
                            //exact
                        else {
                            var queryResult = Enumerable.From(filterArray)
                                                       .Where(function whereOnFilterArrayLikeByCode(lu) { return lu.Code == query.SearchVal })
                                                       .Select(function selectOnFilterArrayLikeByCode(lu) { return lu })
                                                       .ToArray();
                            lookupList(queryResult);
                            //return queryResult;
                        }
                        break;

                        //by description
                    case 1:
                        //like
                        if (query.SearchExact) {
                            var queryResult = Enumerable.From(filterArray)
                                                       .Where(function whereOnFilterArrayExactByDesc(lu) { return lu.Descript.toLowerCase().indexOf(query.SearchVal) >= 0 })
                                                       .Select(function selectOnFilterArrayExactByDesc(lu) { return lu })
                                                       .ToArray();
                            lookupList(queryResult);
                            //return queryResult;
                        }
                            //exact
                        else {
                            var queryResult = Enumerable.From(filterArray)
                                                       .Where(function whereOnFilterArrayLikeByDesc(lu) { return lu.Descript == query.SearchVal })
                                                       .Select(function selectOnFilterArrayLikeByDesc(lu) { return lu })
                                                       .ToArray();
                            lookupList(queryResult);
                            //return queryResult;
                        }
                        break;

                        //by both
                    case 2:
                        //like
                        if (query.SearchExact) {
                            var queryResult = Enumerable.From(filterArray)
                                                       .Where(function whereOnFilterArrayExactByBoth(lu) {
                                                           return lu.Descript.toLowerCase().indexOf(query.SearchVal) >= 0
                                                          || lu.Code.toLowerCase().indexOf(query.SearchVal) >= 0
                                                       })
                                                       .Select(function selectOnFilterArrayExactByBoth(lu) { return lu })
                                                       .ToArray();
                            lookupList(queryResult);
                            //return queryResult;
                        }
                            //exact
                        else {
                            var queryResult = Enumerable.From(filterArray)
                                                       .Where(function whereOnFilterArrayLikeByBoth(lu) {
                                                           return lu.Descript == query.SearchVal
                                                       || lu.Code == query.SearchVal
                                                       })
                                                       .Select(function selectOnFilterArrayLikeByBoth(lu) { return lu })
                                                       .ToArray();
                            lookupList(queryResult);
                            //return queryResult;
                        }
                        break;

                    default: break;

                }
            }
        }
        catch (err) {
            err.message = "lookupname: " + lookupnameObj.cacheName + "," + err.message;
            err.description = "lookupname: " + lookupnameObj.cacheName + "," + err.description;
            throw err;
        }
    }

    function doOrder(dfdSource, lookupList, query, lookupnameObj) {
        var dataAsArray = [];
        $.each(lookupList(), function (k, v) {
            dataAsArray.push(v);
        });
        //don't sort Notifier AvailableDays non by Code, Non By Descr- leave as from LookUp table
        if (nonSortOrderArr.indexOf(query.ElemName) == -1) {
            if (query.PagingBy == global.enums.sortMode.code.value) {
                if (query.PagingOrder == global.enums.sortDirection.down.value) {
                    dataAsArray.sort(function (a, b) {
                        if (a['Code'].length != b['Code'].length) {
                            return a['Code'].length < b['Code'].length ? 1 : -1;
                        }
                        else {
                            return a['Code'] < b['Code'] ? 1 : -1;
                        }
                    });
                }
                else {//PagingOrder == global.enums.sortDirection.up
                    dataAsArray.sort(function (a, b) {
                        if (a['Code'].length != b['Code'].length) {
                            return a['Code'].length > b['Code'].length ? 1 : -1;
                        }
                        else {
                            return a['Code'] > b['Code'] ? 1 : -1;
                        }
                    });
                }
            }
            else {//PagingBy==global.enums.sortMode.descript
                if (query.PagingOrder == global.enums.sortDirection.down.value) {
                    dataAsArray.sort(function (a, b) {
                        return a['Descript'] < b['Descript'] ? 1 : -1;
                    });
                }
                else {//PagingOrder == global.enums.sortDirection.up
                    dataAsArray.sort(function (a, b) {
                        return a['Descript'] > b['Descript'] ? 1 : -1;
                    });
                }
            }
        }
        lookupList(dataAsArray);
        dfdSource.resolve();
    }

    function getLookupData(lookupQuery, lookupnameObj) {//private function
        //add responseCompanyOfPortal to pOtherXmlData
        if (lookupnameObj.isSpecificCreating) {
            switch (lookupnameObj.name) {
                case global.enums.lookupName.TimeZoneList.name:
                    return global.httpGet(global.enums.httpPath.GetTimeZoneLookup);
                default: throw new Error("specific creating is not implemented");
            }
        }
        if (global.isNOE(lookupQuery.OtherParamsXML))
            lookupQuery.OtherParamsXML = "<Root><" + global.enums.configParams.RESPONSE_COMP_OF_PORTAL.name + ">" + global.helper.getResponseCompanyOfPortalName(configurationManager.getConfigParam(global.enums.configParams.RESPONSE_COMP_OF_PORTAL)) + "</" + global.enums.configParams.RESPONSE_COMP_OF_PORTAL.name + "></Root>";
        else
            lookupQuery.OtherParamsXML = lookupQuery.OtherParamsXML.replace("</Root>", "") + "<" + global.enums.configParams.RESPONSE_COMP_OF_PORTAL.name + ">" + global.helper.getResponseCompanyOfPortalName(configurationManager.getConfigParam(global.enums.configParams.RESPONSE_COMP_OF_PORTAL)) + "</" + global.enums.configParams.RESPONSE_COMP_OF_PORTAL.name + "></Root>";

        var params = { GetLookupDataQuery: lookupQuery };
        if (!global.isNull(lookupnameObj.extraField))
            params.LookupExtraField = lookupnameObj.extraField.code;
        if (!global.isNull(lookupQuery.EmpNo)) {
            return http.get(global.webApiConfig.getApiPath(global.enums.httpPath.Lookup.path), { query: JSON.stringify(params) });
        }
        else throw new Error("cannot retrive lookup from server when query.EmpNo is null.");
    }

    function getCompatibleModeForLookup(dfdSource, query, obj, lookupNameObj) {
        var lookupsRecordsCount = cacheManager.get(cacheItems.LOOKUPS_RECORDS_COUNT);
        var recordsCount = lookupsRecordsCount[lookupNameObj.cacheName];
        recordsCount = lookupsRecordsCount[lookupNameObj.cacheName];
        lookupManager.updateChacheMode(lookupNameObj, dfdSource, recordsCount);
    }

    //update the cache mode according to the lookup records count and WebMaxComboCount parameter
    function updateChacheMode(obj, dfdSource, recordsCount) {
        var maxCount = 0;
        var companyParams = cacheManager.get(cacheManager.enums.cacheItems.COMPANY_PARAMS);
        if (companyParams != null) {
            $.each(companyParams, function loopOverComapnyParams(key, val) {
                if (val.FieldName == "WebMaxComboCount") {
                    maxCount = parseInt(val.fieldvalue);
                    return false;
                }
            });
        }
        //changes the obj lookup enum mode value
        if (recordsCount > maxCount) {
            obj.mode = cacheOrDb.dbMode;
        }
        else {
            obj.mode = cacheOrDb.cacheMode;
        }
        dfdSource.resolve();
    }

    function saveLookupAtCache(lookupNameObj, lookupList) {
        //the following row mustn't be deleted!!!! read comment inside
        lookups = cacheManager.get(cacheItems.LOOKUPS);//need to retrive again, becouse may be new lookup joined over time when it run to db
        lookups[lookupNameObj.cacheName] = lookupList;
        global.cache.set(global.enums.cacheItems.LOOKUPS, lookups);
    }

    function getLookupDefaultSelection(lookupnameObj) {

        var defaultItem = null;
        if (global.isNull(lookupnameObj.extraField) || lookupnameObj.extraField.code != global.enums.lookupExtraField.defaultValue.code) {
            return null;
        }
        var lookups = cacheManager.get(cacheItems.LOOKUPS);
        if (lookups[lookupnameObj.cacheName]) {
            var lookups = lookups[lookupnameObj.cacheName];
            $.each(lookups, function loopFindDefaultItem(key, value) {
                if (value.DefaultAct == 1) {
                    defaultItem = { Code: value.Code, Descript: value.Descript };
                    return false;//for break loop
                }
            });
        }
        return defaultItem;

    }

    function getLookupFromCache(lookupNameObj) {
        var lookups = global.cache.get(global.enums.cacheItems.LOOKUPS);
        if (checkExistLookup(lookupNameObj)) {
            return lookups[lookupNameObj.cacheName];
        }
        else
            return null;
    }

    function checkExistLookup(lookupNameObj) {
        var lookups = global.cache.get(global.enums.cacheItems.LOOKUPS);
        if (!global.isNull(lookups) && !global.isNull(lookups[lookupNameObj.cacheName])) {
            return true;
        }
        else {
            return false;
        }
    }

    function loadByChoiceLookups() {
        if (checkExistLookup(global.enums.lookupName.compParTagType)) {
            return global.getEmptyPromise();
        }
        else {
            return global.httpGet(global.enums.httpPath.CompParamsByChoice).done(function getTagComboLists(result) {
                if (result != null) {
                    /* -- must be available if directly to Tags, not after Default params --*/
                    saveLookupAtCache(global.enums.lookupName.compParTagType, result.TagTypeList);
                    saveLookupAtCache(global.enums.lookupName.compParTagBarCode, result.TagBarCodeList);
                    saveLookupAtCache(global.enums.lookupName.compParTagBurnType, result.TagBurnTypeList);
                    saveLookupAtCache(global.enums.lookupName.compParTagConnIssue, result.TagConnIssueList);
                    saveLookupAtCache(global.enums.lookupName.compParTagPicFileName, result.TagPicFileNameList);
                    saveLookupAtCache(global.enums.lookupName.compParSrchField, result.SrchByFieldList);
                    saveLookupAtCache(global.enums.lookupName.compParWebPeriodType, result.WebPeriodTypeList);
                }
            });
        }
    }

    function loadConstOrgLevelLookup() {
        var deferred = global.system.defer(function returnLookup(dfd) {
            var lookups = global.cache.get(global.enums.cacheItems.LOOKUPS);
            //1 - Region, 2 - Factory, 3 - Section, 4 - Dep, 5 - WC, 6 - Emp
            if (!global.isNull(lookups[global.enums.lookupName.OrganizationLevelConstList.name])) {
                dfd.resolve(lookups[global.enums.lookupName.OrganizationLevelConstList.name]);
            }
            else {
                if (global.cache.get(cacheItems.IS_REGION_EXIST) == null) {
                    global.httpGet(global.enums.httpPath.OrganizationLevelsExist).then(function (response) {
                        if (response.Region > 0) {
                            global.cache.set(cacheItems.IS_REGION_EXIST, true);
                        }
                        else {
                            global.cache.set(cacheItems.IS_REGION_EXIST, false);
                        }

                        if (response.Factory > 0) {
                            global.cache.set(cacheItems.IS_FACTORY_EXIST, true);
                        }
                        else {
                            global.cache.set(cacheItems.IS_FACTORY_EXIST, false);
                        }

                        if (response.Section > 0) {
                            global.cache.set(cacheItems.IS_SECTION_EXIST, true);
                        }
                        else {
                            global.cache.set(cacheItems.IS_SECTION_EXIST, false);
                        }
                        createOrgLookupAccordingCompanyLevels();
                    });
                }
                else {
                    createOrgLookupAccordingCompanyLevels();
                }
                function createOrgLookupAccordingCompanyLevels() {
                    var orgLevelsLookup;
                    if (global.cache.get(global.enums.cacheItems.IS_SECTION_EXIST) == false) {
                        orgLevelsLookup = [{ Code: 4, ParentCol: 'Section', Descript: global.dict()['1'], cacheMode: global.enums.cacheOrDb.byCountMode, lookupName: global.enums.lookupName.Dep, tableCode: global.enums.tableCode.department },/*Dep*/
                                       { Code: 5, ParentCol: 'dep', Descript: global.dict()['4'], cacheMode: global.enums.cacheOrDb.byCountMode, lookupName: global.enums.lookupName.Station, tableCode: global.enums.tableCode.work_center },/*WC*/
                                       { Code: 6, ParentCol: 'Station', Descript: global.dict()['2'], cacheMode: global.enums.cacheOrDb.byCountMode, lookupName: global.enums.lookupName.Emp, tableCode: global.enums.tableCode.emp }];/*Emp*/
                    }
                    else if (global.cache.get(global.enums.cacheItems.IS_FACTORY_EXIST) == false) {
                        orgLevelsLookup = [
                                       { Code: 3, ParentCol: 'Factory', Descript: global.dict()['1305'], cacheMode: global.enums.cacheOrDb.byCountMode, lookupName: global.enums.lookupName.Section, tableCode: global.enums.tableCode.section },/*Sect*/
                            { Code: 4, ParentCol: 'Section', Descript: global.dict()['1'], cacheMode: global.enums.cacheOrDb.byCountMode, lookupName: global.enums.lookupName.Dep, tableCode: global.enums.tableCode.department },/*Dep*/
                                       { Code: 5, ParentCol: 'dep', Descript: global.dict()['4'], cacheMode: global.enums.cacheOrDb.byCountMode, lookupName: global.enums.lookupName.Station, tableCode: global.enums.tableCode.work_center },/*WC*/
                                       { Code: 6, ParentCol: 'Station', Descript: global.dict()['2'], cacheMode: global.enums.cacheOrDb.byCountMode, lookupName: global.enums.lookupName.Emp, tableCode: global.enums.tableCode.emp }];/*Emp*/
                    }
                    else if (global.cache.get(global.enums.cacheItems.IS_REGION_EXIST) == false) {
                        orgLevelsLookup = [
                                       { Code: 2, ParentCol: 'region', Descript: global.dict()['1297'], cacheMode: global.enums.cacheOrDb.byCountMode, lookupName: global.enums.lookupName.Factory, tableCode: global.enums.tableCode.factory },/*Fact*/
                                       { Code: 3, ParentCol: 'Factory', Descript: global.dict()['1305'], cacheMode: global.enums.cacheOrDb.byCountMode, lookupName: global.enums.lookupName.Section, tableCode: global.enums.tableCode.section },/*Sect*/
                            { Code: 4, ParentCol: 'Section', Descript: global.dict()['1'], cacheMode: global.enums.cacheOrDb.byCountMode, lookupName: global.enums.lookupName.Dep, tableCode: global.enums.tableCode.department },/*Dep*/
                                       { Code: 5, ParentCol: 'dep', Descript: global.dict()['4'], cacheMode: global.enums.cacheOrDb.byCountMode, lookupName: global.enums.lookupName.Station, tableCode: global.enums.tableCode.work_center },/*WC*/
                                       { Code: 6, ParentCol: 'Station', Descript: global.dict()['2'], cacheMode: global.enums.cacheOrDb.byCountMode, lookupName: global.enums.lookupName.Emp, tableCode: global.enums.tableCode.emp }];/*Emp*/
                    }
                    else {
                        orgLevelsLookup = [
                            { Code: 1, Descript: global.dict()['1296'], cacheMode: global.enums.cacheOrDb.byCountMode, lookupName: global.enums.lookupName.Region, tableCode: global.enums.tableCode.region },/*Reg*/
                                       { Code: 2, ParentCol: 'region', Descript: global.dict()['1297'], cacheMode: global.enums.cacheOrDb.byCountMode, lookupName: global.enums.lookupName.Factory, tableCode: global.enums.tableCode.factory },/*Fact*/
                                       { Code: 3, ParentCol: 'Factory', Descript: global.dict()['1305'], cacheMode: global.enums.cacheOrDb.byCountMode, lookupName: global.enums.lookupName.Section, tableCode: global.enums.tableCode.section },/*Sect*/
                            { Code: 4, ParentCol: 'Section', Descript: global.dict()['1'], cacheMode: global.enums.cacheOrDb.byCountMode, lookupName: global.enums.lookupName.Dep, tableCode: global.enums.tableCode.department },/*Dep*/
                                       { Code: 5, ParentCol: 'dep', Descript: global.dict()['4'], cacheMode: global.enums.cacheOrDb.byCountMode, lookupName: global.enums.lookupName.Station, tableCode: global.enums.tableCode.work_center },/*WC*/
                                       { Code: 6, ParentCol: 'Station', Descript: global.dict()['2'], cacheMode: global.enums.cacheOrDb.byCountMode, lookupName: global.enums.lookupName.Emp, tableCode: global.enums.tableCode.emp }];/*Emp*/
                    }

                    orgLevelsLookup.push({ Code: 7, ParentCol: '', Descript: global.dict()['702'], cacheMode: global.enums.cacheOrDb.byCountMode, lookupName: global.enums.lookupName.EmpGroup, tableCode: global.enums.tableCode.empGroup })
                    saveLookupAtCache(global.enums.lookupName.OrganizationLevelConstList, orgLevelsLookup);
                    dfd.resolve(orgLevelsLookup);
                }
            }
        });
        return deferred.promise();

    }


    var lookupManager = {
        getLookup: getLookup,
        getLookupWithDefaultQuery: getLookupWithDefaultQuery,
        getCompatibleModeForLookup: getCompatibleModeForLookup,
        updateChacheMode: updateChacheMode,
        saveLookupAtCache: saveLookupAtCache,
        getLookupDefaultSelection: getLookupDefaultSelection,
        getLookupFromCache: getLookupFromCache,
        checkExistLookup: checkExistLookup,
        loadByChoiceLookups: loadByChoiceLookups,
        loadConstOrgLevelLookup: loadConstOrgLevelLookup
    };

    return lookupManager;
});