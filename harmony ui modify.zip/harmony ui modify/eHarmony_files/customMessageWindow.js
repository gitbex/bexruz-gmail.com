﻿define(function customMessageWindowControl(require) {

    var enums = require('common/enums/enums');
    var imagesManager = require('common/imagesManager');
    var resourcesManager = require('common/resourcesManager');
    var cacheManager = require('common/cache/cacheManager');
    var dialogManager = require('common/dialogManager');
    var configurationManager = require('common/configurationManager');
    var isExistDict;
    var dialog = require('plugins/dialog');
    var layoutName;
    var global;

    function buildMessage(options) {
        if (options.pHeight) {
            $(".popupHeight").height(options.pHeight);
        }
        if (options.layoutName && options.global) {
            global = options.global;
            layoutName = options.layoutName;
        }
        //build buttons
        isExistDict = cacheManager.isExistKey(enums.cacheItems.DICT);
        if (isExistDict) {

            vm.yesText(resourcesManager.getValueByKey(765));
            vm.noText(resourcesManager.getValueByKey(766));
            vm.cancelText(resourcesManager.getValueByKey(640));
            vm.textCancel(resourcesManager.getValueByKey(303));
            vm.okText(resourcesManager.getValueByKey(302));
            vm.showDetailsLableText(resourcesManager.getValueByKey(998));
            vm.logOutText(resourcesManager.getValueByKey(1320));
            vm.closeText(resourcesManager.getValueByKey(640));
            vm.continueText(resourcesManager.getValueByKey(2855));
            vm.backText(resourcesManager.getValueByKey(5444));
        }
        else {
            vm.yesText("yes");
            vm.noText("no");
            vm.cancelText("cancel");
            vm.textCancel("cancel");
            vm.okText("ok");
            vm.showDetailsLableText("show details");
            vm.logOutText("logut");
            vm.closeText("exit");
            vm.continueText("continue");
            vm.backText("back");
        }
        vm.imgClose(imagesManager.actionsStackButtonsCollapse);

        //building title text
        if (options.title)  //specific title
            vm.title(options.title);
        else {
            if (isExistDict) {
                switch (options.mode) {
                    case enums.messageType.info:
                        vm.title(resourcesManager.getValueByKey(4221));//Information
                        break;
                    case enums.messageType.error:
                        vm.title(resourcesManager.getValueByKey(118));//Error
                        break;
                    case enums.messageType.warning:
                        vm.title(resourcesManager.getValueByKey(4503));//Warning
                        break;
                    case enums.messageType.question:
                        vm.title(resourcesManager.getValueByKey(4502));//Question
                        break;
                    default:
                        break;
                }
            }
            else {  //case failure before Dict have been loaded
                switch (options.mode) {
                    case enums.messageType.info:
                        vm.title("Information");
                        break;
                    case enums.messageType.error:
                        vm.title("Error");
                        break;
                    case enums.messageType.warning:
                        vm.title("Warning");
                        break;
                    case enums.messageType.question:
                        vm.title("Question");
                        break;
                    default:
                        break;
                }
            }
        }

        switch (options.mode) {
            case enums.messageType.info:
                vm.headerImg(imagesManager.info);
                break;
            case enums.messageType.error:
                vm.headerImg(imagesManager.error);
                break;
            case enums.messageType.warning:
                vm.headerImg(imagesManager.notice);
                break;
            case enums.messageType.question:
                vm.headerImg(imagesManager.question);
                break;
            default:
                vm.headerImg(imagesManager.info);
                break;
        }

        //building details text
        if (options.detailsArray) {
            var detailsText = '';
            if (typeof (options.detailsArray) === 'string')
                detailsText = options.detailsArray;
            else if (options.detailsArray instanceof Array) {
                $.each(options.detailsArray, function llopOverDetailsArray(index, error) {
                    detailsText = detailsText + error + '<br/>';
                })
            };
            vm.details(detailsText);
            vm.needShowDetails(true);
            if (options.mode == enums.messageType.error)
                vm.isOpening(true); //WI=12108, Alex,30/11/2014
            else
                vm.isOpening(false);
            vm.popupWidth($(window).width() * 0.4 + 'px');
        }
        else {
            vm.needShowDetails(false);
            vm.details(null);
            vm.isOpening(false);
        }

        //check if error occured & if it is login sql error - show systematic error in message parameter
        if (options.exceptionType && options.exceptionType == enums.exceptionTypes.ConnectSQL) {
            vm.messageColor("Red");
            vm.isOpening(false);
        }
        if (options.messageColor)
            vm.messageColor(options.messageColor);

        vm.message(('' + options.messageText).replace('\r\n', '<br/>').replace('\n', '<br/>'));//replace new line & environment.new_line in c# to tag <br> of html

        //building buttons
        switch (options.btnsMode) {
            case enums.btnsMode.yesNo:
                vm.msgYesNoWindow(true);
                vm.msgYesNoCancelWindow(false);
                vm.msgOkWindow(false);
                vm.msgOkCancelWindow(false);
                vm.msgContinueBackWindow(false);
                break;
            case enums.btnsMode.yesNoCancel:
                vm.msgYesNoCancelWindow(true);
                vm.msgYesNoWindow(false);
                vm.msgOkWindow(false);
                vm.msgOkCancelWindow(false);
                vm.msgContinueBackWindow(false);
                break;
            case enums.btnsMode.logOutOk:
                vm.msgLogOutWindow(true);
                vm.msgOkWindow(true);
                vm.msgYesNoCancelWindow(false);
                vm.msgYesNoWindow(false);
                vm.msgOkCancelWindow(false);
                vm.msgContinueBackWindow(false);
                break;
            case enums.btnsMode.okCancel:
                vm.msgLogOutWindow(false);
                vm.msgOkWindow(false);
                vm.msgYesNoCancelWindow(false);
                vm.msgYesNoWindow(false);
                vm.msgOkCancelWindow(true);
                vm.msgContinueBackWindow(false);
                break;
        	case enums.btnsMode.continueBack:        		
        		vm.msgYesNoWindow(false);
        		vm.msgYesNoCancelWindow(false);
        		vm.msgOkWindow(false);
        		vm.msgOkCancelWindow(false);
        		vm.msgContinueBackWindow(true);
        		break;
            default:
                vm.msgOkWindow(true);
                vm.msgYesNoCancelWindow(false);
                vm.msgYesNoWindow(false);
                vm.msgOkCancelWindow(false);
                vm.msgContinueBackWindow(false);
                break;
        }

        if (options.isCustom) {
            vm.customAction(options.customDelegate);
            vm.msgCustomWindow(true);
            vm.customText(options.customText);
        }
        else {
            vm.msgCustomWindow(false);//clear last time            
        }

        if (options.windowId)
            vm.windowId(options.windowId);

        //showing details by Config param
        var configParam;
        try {
            configParam = configurationManager.getConfigParam(enums.configParams.MODE_OF_RUNNING_APP);
        }
        catch (err) { }
        if (!options.detailsMustDisplay && vm.needShowDetails()) { // added to display attend details per row, e.g. OVERLAP
            if (options.mode == enums.messageType.error && configParam == 2)   //release - not show details error messages
            {
                vm.needShowDetails(false);
                vm.isOpening(false);
            }
        }
    }

    function showDetailsClick() {
        try {
            if (vm.isOpening()) {
                vm.isOpening(false);
            }
            else {
                vm.isOpening(true);
            }
        }
        catch (err) {
        }
    }

    function closeWindow(e, sender) {
        try {

            var btnId = sender.currentTarget.id;
            var userAnswer = null;
            switch (btnId) {
                case "btnOk":
            	case "okBtn":
            	case "continueBtn":
                    userAnswer = enums.customMsgWindowResult.ok;
                    break;
                case "btnYes":
                case "yesBtn":
                    userAnswer = enums.customMsgWindowResult.yes;
                    break;
                case "btnNo":
                case "noBtn":
                    userAnswer = enums.customMsgWindowResult.no;
                    break;
                case "btnclose":
                case "btnCancel":
            	case "cancelBtn":
            	case "backBtn":
                    userAnswer = enums.customMsgWindowResult.cancel;
                    break;
                case "btnLogOut":
                    var logout = $(".linkLogoHarmonyHeader");
                    if (logout.length > 0)
                        logout.click();
                    else
                        window.location.reload();
                    break;
                default:
                    break;
            }
            if (layoutName && global)
                layout({ name: layoutName, set: true });
            dialogManager.closeDialog(vm, userAnswer);
        }
        catch (err) {
            //implement
        }
    }

    function layout(option) {
        var layout = global.enums.cacheItems.MESSAGE_LAYOUT;
        layout.name = option.name;
        var mess = $(".messageBox");
        if (option.get) {
            var getLayout = global.cache.get(layout);
            if (getLayout != null) {
                var oLayout = JSON.parse(getLayout);
                mess.height(oLayout.height);
                mess.width(oLayout.width);
                if (mess.find("#scrollDiv").length)
                    mess.find("#scrollDiv").height(oLayout.height * 80 / 100);
                if (mess.find("#CMWmodal-content").length)
                    mess.find("#CMWmodal-content").height(oLayout.height);
            }
        }
        else if (option.set) {
            var layoutSet = kendo.stringify({ height: mess.height(), width: mess.width() });
            global.cache.set(layout, layoutSet);
        }
    }

    function compositionComplete() {
        try {
            if (layoutName && global)
                layout({ name: layoutName, get: true });
            
            if ($('#formPDFFrame') && $('#formPDFFrame').length > 0)
                $('#outerFrame')[0].style.display = '';

            setTimeout(function () { $(".firstButton:visible").focus(); }, 10);
        }
        catch (err) {
            global.treatError(err);
        }

    }
    var vm = {
        title: ko.observable(),
        msgOkWindow: ko.observable(false),
        msgOkCancelWindow: ko.observable(false),
        msgYesNoCancelWindow: ko.observable(false),
        msgYesNoWindow: ko.observable(false),
        msgLogOutWindow: ko.observable(false),
        msgCustomWindow: ko.observable(false),
    	msgContinueBackWindow: ko.observable(false),
        showDetailsLableText: ko.observable(),
        imgClose: ko.observable(),
        message: ko.observable(),
        details: ko.observable(''),
        showDetailsClick: showDetailsClick,
        closeWindow: closeWindow,
        isOpening: ko.observable(false),
        buildMessage: buildMessage,
        yesText: ko.observable(),
        noText: ko.observable(),
        cancelText: ko.observable(),
        textCancel: ko.observable(),
        okText: ko.observable(),
        logOutText: ko.observable(),
        closeText: ko.observable(),
        continueText: ko.observable(),
        backText: ko.observable(),
        needShowDetails: ko.observable(false),
        compositionComplete: compositionComplete,
        popupWidth: ko.observable(''),
        customAction: ko.observable(function () { }),
        customText: ko.observable(''),
        headerImg: ko.observable(''),
        windowId: ko.observable("defaultId"),
        messageColor: ko.observable('Black')
    };

    return vm;

});