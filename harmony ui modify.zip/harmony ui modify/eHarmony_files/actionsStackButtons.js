﻿define(function actionStackButtonsControl(require) {

    var global = require('common/global');

    var vm = function (options) {

        var obj = {
            global: global,
            actionsStackButtonsId: ko.observable("defaultActionsStackButtons"),
            displayBothSectionFunction: ko.observable(options.displayBothSectionFunc),
            deleteFunction: ko.observable(options.deleteFunc),
            addFunction: ko.observable(options.addFunc),
            processingFunction: ko.observable(options.processingFunc),
            addSelectFunction: ko.observable(options.addSelectFunc),
            undoFunction: ko.observable(options.undoFunc),
            refreshFunction: ko.observable(options.refreshFunc),
            excelFunction: ko.observable(options.excelFunc),
            EmpCardReportFunction: ko.observable(options.EmpCardFunc),
            saveFunction: ko.observable(options.saveFunc),
            displayBothSectionPermissionCode: ko.observable((options.displayBothSectionPermissionCode) ? options.displayBothSectionPermissionCode : options.displayBothSectionFunc ? global.enums.permissionCodes.NO_PERMISSION.code : global.enums.permissionCodes.ALWAYS_NOT_VISIBLE.code),
            deletePermissionCode: ko.observable((options.deletePermissionCode) ? options.deletePermissionCode : options.deleteFunc ? global.enums.permissionCodes.NO_PERMISSION.code : global.enums.permissionCodes.ALWAYS_NOT_VISIBLE.code),
            addPermissionCode: ko.observable((options.addPermissionCode) ? options.addPermissionCode : options.addFunc ? global.enums.permissionCodes.NO_PERMISSION.code : global.enums.permissionCodes.ALWAYS_NOT_VISIBLE.code),
            undoPermissionCode: ko.observable((options.undoPermissionCode) ? options.undoPermissionCode : options.undoFunc ? global.enums.permissionCodes.NO_PERMISSION.code : global.enums.permissionCodes.ALWAYS_NOT_VISIBLE.code),
            refreshPermissionCode: ko.observable((options.refreshPermissionCode) ? options.refreshPermissionCode : options.refreshFunc ? global.enums.permissionCodes.NO_PERMISSION.code : global.enums.permissionCodes.ALWAYS_NOT_VISIBLE.code),
            excelPermissionCode: ko.observable((options.excelPermissionCode) ? options.excelPermissionCode : options.excelFunc ? global.enums.permissionCodes.NO_PERMISSION.code : global.enums.permissionCodes.ALWAYS_NOT_VISIBLE.code),
            EmpCardPermissionCode: ko.observable((options.ProcessPermissionCode) ? options.ProcessPermissionCode : options.EmpCardFunc ? global.enums.permissionCodes.NO_PERMISSION.code : global.enums.permissionCodes.ALWAYS_NOT_VISIBLE.code),
            savePermissionCode: ko.observable((options.savePermissionCode) ? options.savePermissionCode : options.saveFunc ? global.enums.permissionCodes.NO_PERMISSION.code : global.enums.permissionCodes.ALWAYS_NOT_VISIBLE.code),
            addSelectPermissionCode: ko.observable((options.addSelectPermissionCode) ? options.addSelectPermissionCode : options.addSelectFunc ? global.enums.permissionCodes.NO_PERMISSION.code : global.enums.permissionCodes.ALWAYS_NOT_VISIBLE.code),
            progressPermissionCode: ko.observable((options.progressPermissionCode) ? options.progressPermissionCode : options.processingFunc ? global.enums.permissionCodes.NO_PERMISSION.code : global.enums.permissionCodes.ALWAYS_NOT_VISIBLE.code),
            changeBtnsPermissions: changeBtnsPermissions,
            changePartOfBtnsPermission: changePartOfBtnsPermission
        };

        function changeBtnsPermissions(btnsPermissions) {
            if (btnsPermissions.addSelect)
                obj.addSelectPermissionCode(btnsPermissions.addSelect);
            else
                obj.addSelectPermissionCode(global.enums.permissionCodes.ALWAYS_NOT_VISIBLE.code);
            if (btnsPermissions.progress)
                obj.progressPermissionCode(btnsPermissions.progress);
            else
                obj.progressPermissionCode(global.enums.permissionCodes.ALWAYS_NOT_VISIBLE.code);
            obj.displayBothSectionPermissionCode(btnsPermissions.displayBothSection);
            obj.deletePermissionCode(btnsPermissions.delete);
            obj.addPermissionCode(btnsPermissions.add);
            obj.undoPermissionCode(btnsPermissions.undo);
            obj.refreshPermissionCode(btnsPermissions.refresh);
            obj.savePermissionCode(btnsPermissions.save);
            obj.excelPermissionCode(btnsPermissions.excel);
        }

        function changePartOfBtnsPermission(btnsPermissions) {
            if (btnsPermissions.addSelect)
                obj.addSelectPermissionCode(btnsPermissions.addSelect);
            if (btnsPermissions.displayBothSection)
                obj.displayBothSectionPermissionCode(btnsPermissions.displayBothSection);
            if (btnsPermissions.delete)
                obj.deletePermissionCode(btnsPermissions.delete);
            if (btnsPermissions.add)
                obj.addPermissionCode(btnsPermissions.add);
            if (btnsPermissions.undo)
                obj.undoPermissionCode(btnsPermissions.undo);
            if (btnsPermissions.refresh)
                obj.refreshPermissionCode(btnsPermissions.refresh);
            if (btnsPermissions.save)
                obj.savePermissionCode(btnsPermissions.save);
            if (btnsPermissions.excel)
                obj.excelPermissionCode(btnsPermissions.excel);
            if (btnsPermissions.progress)
                obj.progressPermissionCode(btnsPermissions.progress);

        }

        return obj;
    };

    return vm;
});