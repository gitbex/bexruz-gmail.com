﻿define(function dialogManagerModel(require) {
    var dialog = require('plugins/dialog');
    var currentZIndex;
    var differance = [];
    function showDialog(htmlPiece, data) {       
        if (dialog.currentZIndex == Number.NaN) {
            alert('problem with z-index: 1');
        }
        var durandalCurrentIndex = dialog.currentZIndex;
        var telerikCurrentIndex = $('.k-window:last').css('z-index');
        if (telerikCurrentIndex != null && telerikCurrentIndex != 'undefined') {
            if (telerikCurrentIndex > durandalCurrentIndex) {
                if (telerikCurrentIndex - 1 == Number.NaN) {
                    alert('problem with z-index: 2');
                }
                dialog.currentZIndex = telerikCurrentIndex - 1;               
                if (((telerikCurrentIndex - 1) - durandalCurrentIndex) == Number.NaN) {
                    alert('problem with z-index: 5');
                }
                differance.push((telerikCurrentIndex-1) - durandalCurrentIndex);
            }
            else {
                differance.push(0);
            }
        }
        else {
            differance.push(0);
        }       
        if (dialog.currentZIndex == Number.NaN) {
            alert('problem with z-index: 3');
        }
        return dialog.show(htmlPiece, data);
    }

    function closeDialog(htmlPiece, firstResultParam, secondResultParam, thirdResultParam) {
        if (dialog.currentZIndex == Number.NaN) {
            alert('problem with z-index: 4');
        }
        var test6 = dialog.currentZIndex;
        var lastDifferance = differance.pop();
        if (dialog.currentZIndex - lastDifferance == Number.NaN) {
            alert('problem with z-index: 6');
        }
        dialog.currentZIndex = dialog.currentZIndex - lastDifferance;
       
        dialog.close(htmlPiece, firstResultParam, secondResultParam, thirdResultParam);
    }

    function activate() {
        currentZIndex = dialog.currentZIndex;
    }

    var vm = {
        showDialog: showDialog,
        activate: activate,
        closeDialog: closeDialog
    }

    return vm;
});