﻿define(function gridKendoUcControl(require) {

	//#region require modules-----------------------------------------------------------------------

	var global = require('common/global');
	var http = require('plugins/http');
	var app = require('durandal/app');
	var res = require('common/resourcesManager');
	var datePicker = require('views/controls/datePicker/datePicker');
	var customMessageWindow = require('views/combinedControls/customMessageWindow/customMessageWindow');
	var configurationManager = require('common/configurationManager');
    var cacheManager = require('common/cache/cacheManager');

	//#endregion require modules----------------------------------------------------------------------


	//#region consts----------------------------------------------------------------------------------

	var dateFormat = global.cache.get(global.enums.cacheItems.DATE_FORMAT);
	var timeFormat = "{0:HH:mm}";
	var isAmPm = global.cache.getCompanyParamByFieldName("isAmPm") == 1 ? true : false;
	var maskDate = dateFormat.replace(/[a-zA-Z]/g, "9")
	var maskDateTime = maskDate + " 99:99";


	var currentUser = global.cache.get(global.enums.cacheItems.USER);

	var specialKeys = [0, kendo.keys.UP, kendo.keys.DOWN];// keydown in combo edit not close
	var isFromExcel = false;
	var colArrayToRemove = [];
	//#endregion consts------------------------------------------------------------------------------

	function initVM(initOptions) {

		var defaultPageSize = global.cache.getCompanyPreferenceByName(global.enums.companyPreferencesNames.DefaultGridPageSize);
		var dataSourcePrepared = false, isBoundDOM = false;
		var footerParent = initOptions.gridId + 'Pager';
		var gridPageSizes = (initOptions.additionalPageSizes) ? [10, 20, 40, 70, 100].concat(initOptions.additionalPageSizes) : [10, 20, 40, 70, 100];
		if (initOptions.enableAllRecordsOption) {
			gridPageSizes.push('all');
		}
		function detached() {
			try {
				clear();
			}
			catch (err) {
				global.treatError(err);
			}
		}

		function compositionComplete(view) {
			try {
				if (dataSourcePrepared == true && getGrid() == null) {
					bindGridDOM();
				}
			}
			catch (err) {
				global.treatError(err);
			}
		}

		function bindGridDOM() {
			$("#" + vm.gridId()).kendoGrid(vm.gridOptions);
			if (!global.isNull(initOptions.permission)) {
				setPermissions(initOptions.permission);
			}
			afterBindEvents();
			isBoundDOM = true;
			if (initOptions.openPopup) {
				openPopup(initOptions.openPopup);
			}
			//change filter values date when filtering grid by kendo menu
			if (!global.isNOE($("#" + vm.gridId()).data("kendoGrid")) && global.isNOE($("#" + vm.gridId()).data("kendoGrid").dataSource.originalFilter)
                && !global.isNOE(getGrid().dataSource.filter)) {
				$("#" + vm.gridId()).data("kendoGrid").dataSource.originalFilter = getGrid().dataSource.filter;

				// Replace the original filter function.
				$("#" + vm.gridId()).data("kendoGrid").dataSource.filter = function () {
					// If a column is about to be filtered, then raise a new "filtering" event.
					if (arguments.length > 0) {
						this.trigger("filtering", arguments);
					}
					// Call the original filter function.
					var result = getGrid().dataSource.originalFilter.apply(this, arguments);
					return result;
				}

				$("#" + vm.gridId()).data("kendoGrid").dataSource.bind("filtering", function (a, b) {
					var filter = a[0];
					if (!global.isNOE(filter) && !global.isNOE(filter.filters)) {
						$.each(filter.filters, function loopFilter(k, item) {
							if (item.value instanceof Date)
								item.value = item.value.toString('yyyy-MM-dd HH:mm:ss');
						});
					}
				});
			}
		}

		function lastRowValidationTooltip(grid) {
			grid.table.on("focusout", "tr:last .k-invalid", function () {
				grid.content.scrollTop(grid.content.prop('scrollHeight'));
			});
		}

		function selectRowFirst(grid) {
			if (vm.notSetScroll) {
				vm.notSetScroll = false;
				return;
			}
			//select row in grid after bind
			if (!global.isNull(vm.selectedRowIndex)) {
				var rowNo = vm.selectedRowIndex;
				var row = grid.tbody.find("tr[role='row']:eq(" + rowNo + ")");
				grid.select(row);

				var firstCell = grid.tbody.find("tr[role='row']:eq(" + rowNo + ")" + " td:eq(1)");
				firstCell.focus();
				grid.current(firstCell);
				// grid.table.focus();

			    /*
                // not for schedul, see WI=15881
				if (rowNo > 0) 
				    setScroll();
				*/
				vm.mustInit = true;
			}
		}

		function editDropdown(e) {
			var ddl = e.container.find(".k-dropdown");
			ddl.keydown(function (e) {
				if ($.inArray(e.keyCode, specialKeys) > 0) {
					e.stopImmediatePropagation();
				}
			});

		}

		function menuColumn(grid) {
			grid.thead.find(".k-header-column-menu").bind("click", function clickColumnMenu(event) {
				var $grid = grid;
				var e = $(this);
				setTimeout(function () {
					$.each($('[role="menubar"] ul li'), function (k, v) {
						try {
							var $v = $(v);
							if ($v.hasClass("k-state-selected"))
								$v.removeClass("k-state-selected");
							if ($v.find("input").attr("data-field") == e.closest("th").attr("data-field"))
								$v.addClass("k-state-selected");
						}
						catch (err) {
							global.treatError(err);
						}
					});
					//$('[role="menubar"] ul li').sort(function (a, b) {
					//    return $(a).text() > $(b).text() ? 1 : -1; //be carefull, string comparaison
					//}).appendTo('[role="menubar"] ul');
				}, 20);
			});
		}

		function getCellIndex(field) {
			var index = 0;
			$.each(getGrid().thead.find("th"), function cellIndex() {
				if ($(this).data("field") == field)
					return false;
				if ($(this).is(':visible'))
					index++;
			});
			return index;
		}

		function setWidthColumn(grid, width, column) {
			try {

				var index = getCellIndex(column.field);
				column.width = width;

				$("#" + vm.gridId() + " .k-grid-header colgroup col").eq(index).width(width + "px");
				$("#" + vm.gridId() + " .k-grid-content colgroup col").eq(index).width(width + "px");
			}
			catch (err) {
				global.treatError(err);
			}
		}

		function resizeGrid() {
			if (initOptions.setHeight != true) {
				var gridElement = $("#" + vm.gridId()),
                dataArea = gridElement.find(".k-grid-content"),
                    gridHeight = gridElement.innerHeight(),
                    otherElements = gridElement.children().not(".k-grid-content"),
                    otherElementsHeight = 0;
				otherElements.each(function resizeOtherElementsHight() {
					otherElementsHeight += $(this).outerHeight();
				});
				dataArea.height(gridHeight - otherElementsHeight);
			}
			if (vm.setHeight100)//set grid 100%
				$("#" + vm.gridId()).find("div.k-grid-content").css("height", "100%");
		}

		function getGridLayout() {
			if (!global.isNull(initOptions.layoutMode) && initOptions.layoutMode != true) {
				return;
			}
			var gridOptions = vm.gridOptions;
			var layoutName = vm.gridId();
			if (!configurationManager.getConfigParam(global.enums.configParams.SAVE_LAYOUT)) {
				layoutName += "_" + currentUser.Id + "_" + currentUser.Profile.Code;
			}
			var strState = global.cache.getPropOfLocalStorageItem(global.enums.cacheItems.GRID_LAYOUT, layoutName);
			if (strState) {
				var state = JSON.parse(strState);
				vm.page = state.page;
				vm.pageSize = (!vm.gridOptions.pageable) ? 1000 : ((state.pageSize == 1000) ? 40 : state.pageSize);
				vm.sort = state.sort;
				//vm.group = state.group;
				//  vm.filter = state.filter;
				if (state.reorder) {
					var cells = vm.gridOptions.columns;
					for (var i = 0; i < vm.gridOptions.columns.length; i++) {
						var currentColumn = vm.gridOptions.columns[i];
						var isNewColumn = true;
						for (var j = 0; j < state.reorder.length; j++) {
							if (currentColumn.field == state.reorder[j].field) {
								isNewColumn = false;
								break;
							}
						}
						if (isNewColumn) {
							state.reorder.splice(i, 0, currentColumn);
						}
					}
					for (var i = 0; i < state.reorder.length; i++) {
						isRemovedColumn = true;
						for (var j = 0; j < vm.gridOptions.columns.length; j++) {
							if (vm.gridOptions.columns[j] && vm.gridOptions.columns[j].field == state.reorder[i].field) {
								if ((!(vm.gridOptions.columns[j].menu === false)) && state.reorder[i].hidden == true)
									vm.gridOptions.columns[j].hidden = true;
								if (state.reorder[i].hidden == false && vm.gridOptions.columns[j].hidden == true)
									vm.gridOptions.columns[j].hidden = false;
								vm.gridOptions.columns[j].width = state.reorder[i].width;
								global.arrayMove(vm.gridOptions.columns, i, j);
								isRemovedColumn = false;
								break;
							}
						}
						if (isRemovedColumn) {
							state.reorder.splice(i, 1);
							//when you remove column from array, next column get the removed index.
							//so need to sub i, for prevent skipping next column.
							i--;

						}
					}
				}
			}
			//used for when company preferance was changed andparets of last grid layout are not relevant

			vm.gridOptions.columns = $.map(vm.gridOptions.columns, function removeUnexistColumn(colObj) {
				if (!global.isNOE(colObj)) {
					return colObj;
				}
			});

		}

        // save layout in TLA_DefPanels
        function setGridLayout(grid) {
            try {
                if (global.isNull(initOptions.layoutMode) || initOptions.layoutMode == true) {
                    if (cacheManager.getCompanyParamByFieldName('SaveLayout')) {

						var dataSource = grid.dataSource;
						var layoutName = vm.gridId();
						if (!configurationManager.getConfigParam(global.enums.configParams.SAVE_LAYOUT)) {
							layoutName += "_" + currentUser.Id + "_" + currentUser.Profile.Code;
						}
						var state = kendo.stringify({
							page: dataSource.page(),
							pageSize: dataSource.pageSize(),
							sort: dataSource.sort(),
							//group: dataSource.group(),
							//filter: dataSource.filter(),
							reorder: grid.columns
						});
						global.cache.setPropOfLocalStorageItem(global.enums.cacheItems.GRID_LAYOUT, layoutName, state);

					}
				}
			}
			catch (err) {
				global.treatError(err);
			}
		}

		function afterBindEvents() {
			setTimeout(function () {
				keydownSelectRow();
				addTooltip();
				var grid = getGrid();

				if (initOptions.containFooter == true && baseFeatures.pageable) {//in case grid contains footer&paging (such as weekly) need to have spaecial code of kedo-pager
					var gridView = $("#" + vm.gridId()).data("kendoGrid"),
                       pager = $('#div .k-pager-wrap'),
                       id = pager.attr('id') + '_top',
                       $grid = $('#' + vm.gridId());

					if (!global.isNOE(gridView) && gridView.topPager == null) {
						// create top pager div
						topPager = $('<div/>', {
							'id': id,
							'class': 'pagerTop backgroundTransparent k-pager-wrap'
						}).appendTo($('#pager-pane'));

						// copy options for bottom pager to top pager
						gridView.topPager = new kendo.ui.Pager(topPager, $.extend({}, gridView.options.pageable, { dataSource: gridView.dataSource }));

						// cloning the pageable options will use the id from the bottom pager
						gridView.options.pagerId = id;

						// DataSource change event is not fired, so call this manually
						gridView.topPager.refresh()
					}
				}
				else {
					if (!global.isNull(footerParent) && baseFeatures.pageable) {
						var gridPager = $("#" + vm.gridId()).find(".k-grid-pager");
						if (!global.isNull(gridPager[0])) {
							gridPager.detach().appendTo("#" + footerParent);
						}
					}
				}
				// sel check row select

				$("#" + vm.gridId()).on("change", ".check_row", function selectRow(e) {
					try {
						var element = $(e.target);
						if (vm.gridcheckboxStateChanged != null)
							vm.gridcheckboxStateChanged(element)

						if (!element.hasClass("headerbox")) {

							if (element.is(':checked') && vm.rowSelectionHandler != null)
								vm.rowSelectionHandler(e, element.closest("tr"));


							element.closest("tr").toggleClass("k-state-selected");
							if (element.is(':checked') && !element.closest("tr").hasClass("k-state-selected"))
								element.closest("tr").toggleClass("k-state-selected");

							//else
							//    element.prop("checked", false);
							if ($("#" + vm.gridId()).find(".headerbox").is(":checked")) {
								$("#" + vm.gridId()).find(".headerbox").prop("checked", false);
							}
							if (!$(element).is(":checked")) {

								var selectedRows = getGrid().select();
								var first = 0;
								if (selectedRows.length > 0) {
									first = $(getGrid().select()[0]).index();
								}
								else {
									var row = getGrid().tbody.find("tr:eq(0)");
									getGrid().select(row);
								}

								if (vm.clearSelectionHandler != null)
									vm.clearSelectionHandler(first);
							}
						}
						else {
							if (this.checked) {
								$("#" + vm.gridId()).find(":checkbox").closest('tr').addClass("k-state-selected");
								$("#" + vm.gridId()).find(".checkbox").prop("checked", true);
							} else {
								$("#" + vm.gridId()).find("tr").removeClass("k-state-selected");
								$("#" + vm.gridId()).find(".checkbox").prop("checked", false);
								if (vm.clearSelectionHandler != null)
									vm.clearSelectionHandler();
							}
						}
					}
					catch (err) {
						global.treatError(err);
					}
				});

				if (grid != null) {
					menuColumn(grid);
					//cancel menu column
					grid.thead.find("[data-field=check_row]>.k-header-column-menu").remove();
					//cancel resize
					if (grid.thead.find("[data-field=check_row]").length)
						grid.thead.find("[data-field=check_row]").bind("mousemove", cancelEvent);
					if (grid.thead.find(".resizable").length)
						grid.thead.find(".resizable").bind("mousemove", cancelEvent);

					//display tooltip in header
					$("#" + vm.gridId()).kendoTooltip({

						filter: "th:not(:empty):not(:has(input))",
						content: function headerTooltipContent(e) {
							try {
								var target = e.target; // element for which the tooltip is shown
								if (target.find("img").length > 0) {
									if (!global.isNullOrEmpty(target.find("img").attr("alt")))
										return target.find("img").attr("alt");
								}
								return $(target).text();
							}
							catch (err) {
								global.treatError(err);
							}
						}
					});
					$("#" + vm.gridId()).kendoTooltip({
						filter: ".mytooltip",
						content: function (e, s) {
							return "<div>" + $(e.target)[0].getAttribute("data-title") + "</div>";
						}
					});
					vm.customAfterBindEvents(grid);
				}
			}, 10);
		}

		function buildExcelData(e) {
			var schemaFields = e.sender.dataSource.options.schema.model.fields;
			var sheet = e.workbook.sheets[0];
			sheet.freezePane.colSplit = 0;
			sheet.freezePane.rowSplit = 1;
			var columns = {}; //list of column to export         
			sheet.rows = [];
			var headersArray = [];
			var columnsArray = [];
			var fieldsArray = [];
			colArrayToRemove = [];
			if (vm.isCustomExcelExport) {
				UpdateExcelColArrayToRemove();
			}
			$.each(e.sender.columns, function getHiddenColumns(i, col) {
				getColumnExporting(headersArray, columnsArray, col, fieldsArray);
			});
			sheet.rows.push({ cells: headersArray, type: 'header' });
			sheet.columns = columnsArray;
			$.each(e.data, function addRow(i, item) {
				//add rows with shown columns data
				if (vm.isCustomExcelExport && item.IsNotVisible == true) {
					return;
				}
				else {
					cells = [];
					$.each(fieldsArray, function getRowExcelData(i, excelColumn) {
						var value = item[excelColumn.name];
						switch (excelColumn.format) {
							case global.enums.excelFormat.time:
								value = timeStringToFloat(value);
								break;
							case global.enums.excelFormat.date:
								value = value != null ? new Date(value) : '';
							default: break;
						}
						if (excelColumn.exportTemplate) {
							value = excelColumn.exportTemplate(value);
						}

						var colToRemove = Enumerable.From(colArrayToRemove).Where(function (obj) { return obj == excelColumn.name; }).Select(function (obj) { return obj; }).FirstOrDefault();
						if (global.isNOE(colToRemove)) {
							cells.push({ value: value, format: excelColumn.format, autoWidth: true });
						}
					});
					sheet.rows.push({ cells: cells, type: "data" });
				}
			});
		}

		function getColumnExporting(headersArray, columnsArray, column, fieldsArray) {

			if (column.field == 'check_row') {
				return;
			}
			if (column.hidden) {
				return;
			}
			if (column.exportable != false && column.field) {
				fieldsArray.push({ name: column.field, format: column.exportFormat, exportTemplate: column.exportTemplate });

				var columnHeader = {
					background: "#7a7a7a",
					color: "#fff",
					colSpan: 1,
					rowSpan: 1,
					value: getTitleForExcelCol(column),
					hAlign: "center",
					width: column.width
				};

				var colToRemove = Enumerable.From(colArrayToRemove).Where(function (obj) { return obj == column.field; }).Select(function (obj) { return obj; }).FirstOrDefault();
				if (global.isNOE(colToRemove)) {
					headersArray.push(columnHeader);
				}
				columnsArray.push({ autoWidth: true }); //width: 200
			}
			if (column.columns) {//sub columns
				$.each(column.columns, function (i, subColumn) {
					getColumnExporting(headersArray, columnsArray, subColumn, fieldsArray);
				});
			}
			if (column.associatedFields) {
				$.each(column.associatedFields, function (i, associatedField) {
					getColumnExporting(headersArray, columnsArray, associatedField, fieldsArray);
				});
			}
		}

		function UpdateExcelColArrayToRemove() {
			for (var i = 1; i < 8; i++) {
				var colItemAC = $("#" + vm.gridId() + " input[name=AC" + i + "]");
				if (!global.isNOE(colItemAC) && colItemAC.length == 0) {
					colArrayToRemove.push("AN" + i);

					var colItemATM = $("#" + vm.gridId() + " input[name=ATM" + i + "]");
					if (!global.isNOE(colItemATM) && colItemATM.length == 0) {
						colArrayToRemove.push("ATM" + i);
					}
				}
			}
		}

		function getTitleForExcelCol(field) {
			if (field.titleRes) {
				if ($.isArray(field.titleRes)) {
					var title = '';
					$.each(field.titleRes, function getPartOfTitle(i, res) {
						title += global.res[res] + ' ';
					});
					title.substring(0, title.length - 1);
					if (vm.isCustomExcelExport && !global.isNOE(field.headerAttributes) && !global.isNOE(field.headerAttributes.dateDataAtr)) {
						return title = field.headerAttributes.dateDataAtr + ' ' + title;
					}
					else {
						return title;
					}
				}
				else
					return global.res[field.titleRes];
			}
			else
				return field.name ? field.name : field.title;
		}

		function timeStringToFloat(time) {
			if (!global.isNullOrEmpty(time)) {
				var hoursMinutes = time.split(/[.:]/);
				var hours = parseInt(hoursMinutes[0], 10) / 24;
				var minutes = (hoursMinutes[1] ? parseInt(hoursMinutes[1], 10) : 0) / 60 / 24;
				return hours + minutes;
			}
		}

		function cancelEvent(event) {
			event.preventDefault();
			return false;
		}

		function rebind() {
			if ($('#' + vm.gridId()).length > 0) {
				if (initOptions.remote) {
					// grid.dataSource.page(1);
					return getGrid().dataSource.read();
				}
				else {
					return getGrid().dataSource.fetch();
				}
			}
			else {
				console.error("connot rebind grid. grid doesn't exist in dom");
			}
		}

		function getChanges() {
			var entitiesToSave = [];
			var grid = getGrid();
			if (grid) {
				var dataAll = grid._data;
				if (dataAll != null)
					for (var i = 0; i < dataAll.length; i++) {
						if (dataAll[i].dirty == true) {
							entitiesToSave.push(getNormalRowData(dataAll[i]));
						}
					}
			}
			return entitiesToSave;
		}
	  
		function getAllChanges() {
		    var entitiesToSave = [];
		    var grid = getGrid();
		    if (grid) {
		        var dataAll = grid.dataSource.data();
		        if (dataAll != null)
		            for (var i = 0; i < dataAll.length; i++) {
		                if (dataAll[i].dirty == true) {
		                    entitiesToSave.push(getNormalRowData(dataAll[i]));
		                }
		            }
		    }
		    return entitiesToSave;
		}

		function getNormalRowData(rowData) {
			for (var propertyName in rowData) {
				if (propertyName.indexOf('TimeInput') > 0 || propertyName.indexOf('ampmMenuClick') > 0 ||
                    propertyName.indexOf('displayVale') > 0 || propertyName.indexOf('selectAmpm') > 0) {
					delete rowData[propertyName];
				}
			}
			return rowData;
		}

		function setEditable() {
			baseFeatures.editable = {
				confirmation: false
			}
		}

		function changeEditable(isEditable) {
			var grid = getGrid();
			if (!global.isNull(grid)) {
				if (isEditable)
					$(grid.table).removeClass("customNotEditable RORow");
				else
					$(grid.table).addClass("customNotEditable RORow");
			}
		}

		function setGridOptions(option, setoption) {
			if (vm.gridOptions.hasOwnProperty(option))
				vm.gridOptions[option] = setoption;
		}

		function openPopup(func) {
			var grid = getGrid();
			if (grid != null) {

				function onOpenPopup(e) {
					var currentCell = grid.current();
					if (currentCell.hasClass("k-edit-cell")) {
						grid.closeCell();
						e.target = currentCell;
					}
					return func(e, vm);
				}
				grid.element.delegate("tbody>tr", "dblclick", onOpenPopup);
			}
		}

		function setGridOptionsSetting(options) {
			vm.gridOptions = $.extend(vm.gridOptions, options);
		}

		function setPermissions(permission) {

			var grid = getGrid();

			if (!(global.permissions.isReadonly(permission.code)) && (global.permissions.isVisible(permission.code))) {
				setEditable();

				if (!global.isNull(grid)) {
					$(grid.table).removeClass("customNotEditable");
				}
			}
			else {
				if (!global.isNull(grid)) {
					$(grid.table).addClass("customNotEditable");
				}
			}
		}

		function clear() {
			var grid = getGrid();
			if (!global.isNull(grid)) {
				if ($("#" + footerParent + " .k-grid-pager").length > 0) {
					grid.pager.destroy();
					if ($("#" + footerParent + " .k-grid-pager").length > 0) {
						$("#" + footerParent).empty();
					}
				}
				grid.destroy();
			}
		}

		function clearPager() {
			var grid = getGrid();
			if ($("#" + footerParent + " .k-grid-pager").length > 0) {
				if ($("#" + footerParent + " .k-grid-pager").length > 0) {
					$("#" + footerParent).empty();
				}
			}
		}

		function clearData() {
			var emptyData = new kendo.data.ObservableArray([]);
			setData(emptyData);
		}

		function getDataView() {
			var grid = getGrid();
			if (grid != null)
				return grid.dataSource.view();
			return null;
		}

		//#region get selection----------------------------------------------------------------------------------

		function getSelectedRows() {
			var oGrid = getGrid();
			if (oGrid == null)
				return [];
			if (oGrid.thead.find("[data-field=check_row]").length == 0)
				return oGrid.select();
			else {
				var selectedRows = [];
				var dataselectedRows = oGrid.tbody.find(".check_row:checked").closest("tr");
				for (var i = 0; i < dataselectedRows.length; i++)
					selectedRows.push(oGrid.dataItem(dataselectedRows[i]));
				return selectedRows;
			}
		}

		function getSelectedRowsData() {
			var selectedRowsData = [];
			if (getGrid() == null)
				return selectedRowsData;
			var selectedRows = getGrid().select();
			for (var i = 0; i < selectedRows.length; i++) {
				selectedRowsData.push(getGrid().dataItem(selectedRows[i]));
			}
			return selectedRowsData;
		}

		//get the key of selected entities in the current page in remote grid (works on observable entities and observable array data)
		function getSelectedEntitiesKey() {
			var selectedEntitiesKeys = [];
			var grid = getGrid();
			var selectedRows = grid.tbody.find(".check_row:checked").closest("tr");
			for (var i = 0; i < selectedRows.length; i++) {
				selectedEntitiesKeys.push(grid.dataItem(selectedRows[i]).id);
			}
			return selectedEntitiesKeys;
		}

		//get the selected entities in the current page (works on observable entities and observable array data)
		function getSelectedEntities() {
			return getSelectedRows();
		}

		//#endregion get selection--------------------------------------------------------------------------------

		function closeCell(e) {
			getGrid().closeCell();
		}

		//#region editors & templates for grid columns

		//for readonly id columns in combo
		function noEditor(container, options) {
			$(noTemplate(options.model, options.field))
             .appendTo(container)
		}

		function noTemplate(dataItem, fieldName) {
			return dirtyField(dataItem, fieldName) + '<span class=readOnlyColumn>' + (global.isNullOrEmpty(dataItem[fieldName]) ? '' : dataItem[fieldName]) + '</span>';
		}

		function comboEditor(container, options, comboVM, codeField, funcChanged, isETable, descriptField, inputAttributes, codeColumnExistOnly) {
			var prevCodeInCombo = options.model[codeField];
			comboVM.prevCode(prevCodeInCombo);
			comboVM.comboInGridSelectionChanged = function comboInGridSelectionChanged(selectedItem, itemSender, isPrevented) {
				if (itemSender.sender.options.optionLabel == itemSender.sender.text()
                    || comboVM.optionLabel() == itemSender.sender.text()) {
					if (global.isNullOrEmpty(descriptField)) {
						options.model[options.field] = "";
					}
					else {
						options.model[descriptField] = "";
					}
				}
				else {
					if (global.isNullOrEmpty(descriptField)) {
						if (!codeColumnExistOnly) {
							options.model.set(options.field, selectedItem.Descript);
							options.model[options.field] = selectedItem.Descript;
							options.model.set(codeField, selectedItem.Code);
							options.model[codeField] = selectedItem.Code;
						}
					}
					else {
						options.model.set(descriptField, selectedItem.Descript);
						options.model[descriptField] = selectedItem.Descript;
						options.model.set(codeField, selectedItem.Code);
						options.model[codeField] = selectedItem.Code;
					}
				}
				if (funcChanged != null && !isPrevented)
					funcChanged(options.model, descriptField);
			};
			if (comboVM.optionLabel() == "" || options.model.fields[options.field].validation && (options.model.fields[options.field].validation.requireAndNotEmpty || options.model.fields[options.field].validation.require))
				comboVM.optionLabel("");
			else
				comboVM.optionLabel(" ");
			comboVM.widgetId("widgetCombo" + codeField);

			if (global.isNull(inputAttributes)) { inputAttributes = ''; }

			if (isETable != true) {
				$('<input id="widgetCombo"' + codeField + '" name="' + codeField + '" data-bind="value:' + codeField + '"' + inputAttributes + '/>')
                .appendTo(container).kendoSimpleComboWidget(comboVM);
			}
			else {
				$('<input id="widgetCombo' + codeField + '" name="' + codeField + '" data-bind="value:' + codeField + '"/>')
               .appendTo(container).kendoSimpleComboETableWidget(comboVM);
			}

			$('<span data-for="' + codeField + '" class="k-invalid-msg"></span>').appendTo(container);
			//if (comboVM.optionLabel() == "" && global.isNullOrEmpty(options.model[codeField])) {
			//    options.model[codeField] = comboVM.selectedItem().Code;
			//    options.model[descriptField] = comboVM.selectedItem().Descript;
			//}
		}

		function multySelectorEditor(container, options, dataSource, isOptionLabel, isAll_field) {
			var multySelectConfig = {
				dataSource: dataSource,
				dataTextField: "Descript",
				dataValueField: "Code"
			}
			if (isOptionLabel) {
				multySelectConfig.select = function (e) {
					var dataItem = this.dataSource.view()[e.item.index()];
					var values = this.value();

					if (dataItem.Code == -1) {
						this.value([]);
					} else if (values.indexOf(-1) !== -1) {
						values = $.grep(values, function (value) {
							return value != -1;
						});

						this.value(values);
					}
				},
                multySelectConfig.change = function () {
                	removeDeleteOptionFromItemAll();

                }
			}
			msUniqueId = 'msEditor' + vm.gridId();
			$("<select id='" + msUniqueId + "' data-bind='value : " + options.field + "'/>")
            .appendTo(container)
            .kendoMultiSelect(multySelectConfig);
			setTimeout(removeDeleteOptionFromItemAll, 10);

			function removeDeleteOptionFromItemAll() {
				var isAll = $('#' + msUniqueId).data().kendoMultiSelect.value().indexOf(-1) >= 0;
				if (isAll) {
					$('.k-multiselect-wrap .k-select').remove();
				}
				if (isAll_field) {
					options.model.set(isAll_field, isAll);
				}
			}
		}

		function autoCompleteEditor(container, options, autoCompleteVM, codeField, funcChanged, textField, isETable, execCustomSelectionChangeOnFirstTime) {
			autoCompleteVM.getLookupAgain();
			var currentCodeField = codeField ? codeField : options.field;
			var lastId = options.model[currentCodeField];
			var decriptField = textField ? textField : options.field;
			var lastDescript = options.model[decriptField];
			var isAlreadyDirty = false;
			if (options.model.dirty && options.model.dirtyFields && (options.model.dirtyFields.hasOwnProperty(codeField) || options.model.dirtyFields.hasOwnProperty(textField))) {
				isAlreadyDirty = true;
			}
			if (!global.isNullOrEmpty(options.model[codeField]) && !global.isNull(textField)) {
				autoCompleteVM.changeSelectedItem({ Code: options.model[codeField], Descript: options.model[textField] }, null, null, null, !execCustomSelectionChangeOnFirstTime);
			}
			autoCompleteVM.comboInGridSelectionChanged = function autoCompleteInGridSelectionChanged(selectedItem, itemSender, isPrevented, currentCell) {
				if (global.isNull(selectedItem)) {
					options.model[decriptField] = "";
				}
				else {
					options.model.set(currentCodeField, selectedItem.Code);
					options.model[currentCodeField] = selectedItem.Code;
					options.model.set(decriptField, selectedItem.Descript);
					options.model[decriptField] = selectedItem.Descript;
				}
				if (isPrevented) {
					options.model.set(currentCodeField, lastId);
					options.model.set(decriptField, lastDescript);
					options.model[decriptField] = lastDescript;
					$("#widgetAC" + codeField).data("kendoComboBox").text(autoCompleteVM.template({ Code: lastId, Descript: lastDescript }));

				}//for case when user press un-correct value
				//and autoCompleteVM have changed it to be old value

				//empty depandent combo - code and descript columns
				if (autoCompleteVM.lookupName.dependentWasChanged) {
					options.model["dependentWasChanged"] = true;
				}
				if (funcChanged != null && !isPrevented)
					funcChanged(options.model);

				if (!isAlreadyDirty && isPrevented && currentCell) {
					currentCell.removeClass("k-dirty-cell");
				}
			};
			autoCompleteVM.widgetId("widgetAC" + codeField);
			if (isETable != true) {
				$('<input name="' + codeField + '" id="widgetAC' + codeField + '" data-bind="value:' + codeField + '"/>')
                .appendTo(container).kendoAutoCompleteWidget(autoCompleteVM);
			}
			else {
				$('<input name="' + codeField + '" id="widgetAC' + codeField + '" data-bind="value:' + codeField + '" style="width:80%"/>')
                .appendTo(container).kendoAutoCompleteETableWidget(autoCompleteVM);
			}
			$('<span data-for="' + codeField + '" class="k-invalid-msg"></span>').appendTo(container);

			autoCompleteVM.bindComboEvents();
		}

		function comboTemplate(dataItem, fieldName, attributes) {

			if (global.isNull(attributes)) { attributes = ''; }
			var value = !global.isNullOrEmpty([fieldName]) ? (!global.isNullOrEmpty(dataItem[fieldName]) ? dataItem[fieldName] : "&nbsp") : "&nbsp";
			return '<div class ="editable-cell" ' + attributes + '> <span>' + value + '</span>' + '<img class="editable-cell-img floutR" src="' + global.imagesManager.sm_selectOrange + '"/>' + '</div>';
		}

		function comboTemplateWithFrame(dataItem, fieldName, isRed, attributes ) {

		    if (global.isNull(attributes)) { attributes = ''; }
		    var value = !global.isNullOrEmpty([fieldName]) ? (!global.isNullOrEmpty(dataItem[fieldName]) ? dataItem[fieldName] : "&nbsp") : "&nbsp";
		    var comboSpan = "<span>";
		    if (value == "&nbsp")
		        if (isRed==1)
		            comboSpan = "<span class='attendComboTemplateRed'>";
		        else
		            comboSpan = "<span class='attendComboTemplate'>";


		    return '<div class ="editable-cell" ' + attributes + '>'+comboSpan + value + '</span>' + '<img class="editable-cell-img floutR" src="' + global.imagesManager.sm_selectOrange + '"/>' + '</div>';
		}
		function passwordTemplate() {
			return '<span class="passwordTemplate">.....</span>';
		}

		function passwordEditor(container, options) {
			$('<input type="password" class="k-input k-textbox" name="' + options.field + '" data-bind="value:' + options.field + '">').appendTo(container);
		}

		function datePickerEditor(container, options, isRequired) {

			var required = isRequired == true ? 'required' : '';

			$('<input ' + required + ' name="' + options.field + '" value="' + new Date(options.model[options.field]) + '"/>')
            .appendTo(container).kendoDatePickerWidget({
            	change: function (e) {
            		if (!global.isNOE(e.sender._value)) {
            			var returnedVal = e.sender._value.clearTime();
            			options.model[options.field] = returnedVal.toString("yyyy-MM-ddTHH:mm:ss");
            		}
            	}, minDate: ko.observable(),
            	maxDate: ko.observable(),
            	disableDates: ko.observableArray([]),
            	format: dateFormat
            })
             .kendoMaskedTextBox({
             	mask: maskDate
             });
			$('<span data-for="' + options.field + '" class="k-invalid-msg"></span>').appendTo(container);

		}

		function datePickerTemplate(dataItem, fieldName, newDateFormat, className) {
			className = global.isNOE(className) ? '' : className;
			var value = ParseDateFormat(dataItem, fieldName, newDateFormat);
			var displayedValue = value != "" ? value : "&nbsp";
			return '<div class ="editable-cell"> <span class="' + className + '">' + displayedValue + '</span>' + '<img class="editable-cell-img floutR" src="' + global.imagesManager.sm_calandar + '"/>' + '</div>';
		}

		function timeInputTemplate(dataItem, fieldName, displayNormalTime) {
			if (global.isNOE(dataItem[fieldName]))
				return "";
			if (isAmPm == false || displayNormalTime == true) {
				text = dataItem[fieldName];
				return text;
			}
			else {
				var startTimeHour = parseInt(dataItem[fieldName].split(':')[0]);
				var startTimeDisplay;
				if (startTimeHour == 0 || startTimeHour == 12)
					startTimeDisplay = '12:' + dataItem[fieldName].split(':')[1];
				else {
					startTimeDisplay = startTimeHour % 12;
					if (startTimeDisplay.toString().length == 1)
						startTimeDisplay = '0' + (startTimeHour % 12);
					startTimeDisplay = startTimeDisplay + ':' + dataItem[fieldName].split(':')[1];
				}
				text = "<div class='floutL'><span class='rowGrid-att-bold editable-span-cell'>" + startTimeDisplay + "</span>";

				if (isAmPm == true) {
					if (startTimeHour >= 12) {
						text += "<span class='teAMPMbutton pm globalFloatRight'>P</span></div>";
					}
					else {
						text += "<span class='teAMPMbutton am globalFloatRight'>A</span></div>";
					}
				}
				else {
					text += "</div>";
				}
				return text;
			}
		}

		function showTimeInputMode(event) {//adding row is by popup
			try {
				event.stopPropagation();
				if (prevButtonID == event.target.id) {
					if ($("#ampmMenu").css("display") == "none") {
						openAMPMmenu(event);
					}
					else {
						var li = $("#ampmMenu li");
						$.each(li, function eachLi(index, item) {
							$("#" + event.target.id + "Menu").append($(item));
						});
						$("#ampmMenu").css("display", "none");
					}
				}
				else {
					var li = $("#ampmMenu li");
					$.each(li, function eachLi(index, item) {
						$("#" + prevButtonID + "Menu").append($(item));
					});
					openAMPMmenu(event);
				}
				prevButtonID = event.target.id;
			}
			catch (err) {
				global.treatError(err);
			}
		}

		function openAMPMmenu(event) {
			$("#ampmMenu").empty();
			var li = $("#" + event.target.id + "Menu li");
			$.each(li, function eachLi(index, item) {
				$("#ampmMenu").append($(item));
			});
			if (global.getCurrentDir() == global.enums.directions.RTL)
				$("#ampmMenu").css("right", $(window).width() - $(event.target).offset().left - $(event.target).width());
			else
				$("#ampmMenu").css("left", $("#" + event.target.id).offset().left - $("#ampmMenu").width() + $(event.target).width());
			var top = "";
			if ($("#" + event.target.id).attr("data-ampmValue") == "AM")
				top = "1.8em";
			else
				top = "1.4em";
			var topOffset = $("#" + event.target.id).offset().top;
			if ($("#" + event.target.id).closest('#bottom_pane').length > 0) {
				topOffset -= $('#bottom_pane').offset().top;
			}
			$("#ampmMenu").css("top", "calc(" + topOffset + "px + " + top + ")");
			if (($(window).height() - parseFloat($("#ampmMenu").css("top")) - 20) < $("#ampmMenu").height())//if no place
				$("#ampmMenu").css({ "margin-top": (parseFloat($("#ampmMenu").css("top")) - $(window).height()) + "px" });//open in top
			else
				$("#ampmMenu").css({ "margin-top": "3px" });
			$("#ampmMenu").css("display", "block");
		}

		function hideAMPMMenu(e) {
			try {
				var ul = $(e.currentTarget).closest("ul");
				var button = $(e.currentTarget).closest("button");
				if ((ul.length == 0 || ul.id != "ampmMenu") && (button.length == 0 || button.hasClass("teAMPMbutton"))) {//hide menu
					$("#ampmMenu").css("display", "none");
				}
			}
			catch (err) {
				global.treatError(err);
			}
		}
		var prevButtonID;

		function inputTimeEditor(container, options, timeInputVM, codeField, funcChanged, displayNormalTime) {
			$(document).unbind("click", hideAMPMMenu);
			$(document).bind("click", hideAMPMMenu);

			if (!codeField) codeField = options.field;
			timeInputVM.model = options.model;
			timeInputVM.namefield = codeField;
			timeInputVM.previousValue(options.model[codeField]);
			timeInputVM.closeCell = closeCell;
			timeInputVM.container = container;
			timeInputVM.grid = getGrid();
			timeInputVM.ie = global.explorerType() != global.enums.explorerType.NOTIE ? true : false;
			var func = function funcTimeEditor() { }
			timeInputVM.customValueChanged = funcChanged != null ? funcChanged : func;
			timeInputVM.isAmPm = isAmPm == true && displayNormalTime != true;
			if (isAmPm == true && displayNormalTime != true) {
				timeInputVM.displayValue = ko.computed({
					read: function readValue() {
						if (global.isNull(options.model[codeField]) || options.model[codeField] == '') {
							return "";
						}
						var valueToDisplay = options.model[codeField];
						var timeHour = parseInt(options.model[codeField].split(':')[0]);
						if (timeHour == 0 || timeHour == 12)
							valueToDisplay = '12:' + options.model[codeField].split(':')[1];
						else {
							valueToDisplay = timeHour % 12;
							if (valueToDisplay.toString().length == 1)
								valueToDisplay = '0' + (timeHour % 12);
							valueToDisplay = valueToDisplay + ':' + options.model[codeField].split(':')[1];
						}
						return valueToDisplay;
					},
					write: function writeValue(newValue) {
						if (global.isNOE(newValue))
							options.model.set(codeField, newValue);
						else {
							var fieldValue = options.model[codeField].split(':');
							var timeValue = newValue.split(':');
							var minuteValue = timeValue.length > 1 ? timeValue[1] : '00';
							if (parseInt(fieldValue[0]) >= 12) {//pm
								if (parseInt(timeValue[0]) == 12) {
									hours = parseInt(timeValue[0]);
								}
								else
									hours = parseInt(timeValue[0]) + 12;
								options.model.set(codeField, (hours.length == 1 ? '0' + hours : hours) + ":" + minuteValue);//
							}
							else {//am
								if (timeValue[0] == "12") {
									options.model.set(codeField, "00" + ":" + minuteValue);
								}
								else {
									options.model.set(codeField, newValue);
								}
							}
						}
					}
				});
				timeInputVM.selectedAmpm = ko.computed({
					read: function readValue() {
						if (!global.isNull(options.model[codeField]) && options.model[codeField] != '') {
							var timeValue = options.model[codeField].split(':');
							var hours = parseInt(timeValue[0]);
							if (parseInt(hours / 12) == 0) {
								return "AM";
							}
							else {
								return "PM";
							}
						}
						else
							return "AM";
					},
					write: function writeValue(newValue) {
						if (global.isNOE(options.model[codeField]))
							return;
						var timeValue = options.model[codeField].split(':');
						var hours = parseInt(timeValue[0]);
						if (newValue == "AM") {
							if (hours >= 12) {
								hours -= 12;
							}
							options.model.set(codeField, hours + ":" + timeValue[1]);
						}
						if (newValue == "PM") {
							if (hours < 12) {
								hours += 12;
							}
							options.model.set(codeField, hours + ":" + timeValue[1]);
						}
					}
				});

				timeInputVM.ampmMenuClick = function ampmMenuClick(e) {
					try {
						var ampm = $(e.currentTarget).attr("data-id");
						var rowUid = $(e.currentTarget).find("span").attr("data-rowuid");
						var columnName = $(e.currentTarget).attr("name");
						var td = $(container[0]).closest("td")[0];

						var prevValue = options.model[columnName + "selectedAmpm"]();
						options.model[columnName + "TimeInput"].previousValue(options.model[columnName]);
						if (prevValue != ampm) {
							options.model[columnName + "TimeInput"].exit(null, options.model[columnName], { sender: "ampmMenu", rowUid: rowUid });
						}
						options.model[columnName + "selectedAmpm"](ampm);
						td.focus();
						getGrid().editCell(td);
						getGrid().closeCell();
						$("#ampmMenu").hide();
					}
					catch (err) { global.treatError(err); }
				}
				options.model[codeField + "ampmMenuClick"] = timeInputVM.ampmMenuClick;
				options.model[codeField + "displayValue"] = timeInputVM.displayValue;
				options.model[codeField + "selectedAmpm"] = timeInputVM.selectedAmpm;
				options.model[codeField + "TimeInput"] = timeInputVM;
				options.model["showTimeInputMode"] = showTimeInputMode;

				var pmClass = timeInputVM.selectedAmpm() == "PM" ? "pm" : "";
				prevButtonID = "";
				var x =
            '<button id="' + codeField + '" class="teAMPMbutton globalFloatLeft ' + pmClass + '" data-bind="click:showTimeInputMode" data-ampmValue="' + timeInputVM.selectedAmpm() + '">•</button>' +
                '<ul id="' + codeField + 'Menu" class="dropdown-menu" style="display: none">' +
                    '<li name="' + codeField + '" id="' + codeField + 'AMLi"  data-id="AM"  data-bind="click:' + codeField + 'ampmMenuClick">' +
                           '<span name="' + codeField + '" data-id="AM" data-rowUid="' + options.model.uid + '">AM</span>' +
                    '</li>' +
                    '<li class="divider margin0"></li>' +
                    '<li name="' + codeField + '"  id="' + codeField + 'PMLi"  data-id="PM" data-bind="click:' + codeField + 'ampmMenuClick">' +
                            '<span name="' + codeField + '" data-id="PM" data-rowUid="' + options.model.uid + '">PM</span>' +
                   '</li></ul>';
				$('<div class="widgetTimediv widgetTimeInputDiv floutL"><input name="' + codeField + '" onfocus="this.setSelectionRange(0, this.value.length)"  data-bind="value:' + codeField + 'displayValue" />' + x + '</div>')
                .appendTo(container).kendoTimePickerWidget(timeInputVM);
			}
			else {
				$('<input name="' + codeField + '" onfocus="this.setSelectionRange(0, this.value.length)" data-bind="value:' + codeField + '" />')
                .appendTo(container).kendoTimePickerWidget(timeInputVM);
			}
			$('<span data-for="' + codeField + '" class="k-invalid-msg"></span>').appendTo(container);
		}

		function colorEditor(container, options) {
			var colorOptions = {
				placement: 'bottom',
				hsvpanel: true,
				sliders: false,
				previewformat: 'hex',
				customswatches: false,
				invalidcolorsopacity: 0,
				color: ko.observable(options.model.DayColor),
				swatchesHeader: global.res[4590],
				HSVpanelHeader: global.res[4589],
				displayTextColor: false,
				onchange: function onColorChange(selectedItem, color) {
					options.model[options.field] = color.tiny.toHexString();
					options.model.dirty = true;
				}
			}

			$('<input ' + ' name="' + options.field + '" data-bind="value:' + options.field + '"/>').ColorPickerSliders(colorOptions)
       .appendTo(container);


		}

		function noteEditor(container, options, attr, cls) {
			if (attr == null) attr = "";
			if (cls == null) cls = "";
			/*
            $("<div>" + '<div class="modal-header popupHeader blue_lbl" style="height:5px">' +
             ' <div class="floutR"> <input type="image" id="btncloseNote" style="cursor: pointer;" class="notAllowed " ' + 'src=" ' + global.imagesManager.actionsStackButtonsCollapse + '"/></div>' +
             '</div>' +
               " <textarea class=' " + cls + "' name='" + options.field + "' style='position: absolute; width: " + container.width() + "px;height:" + container.height() + "px' " + attr + "/></div>")
           .appendTo(container);
           */
			//23/12/2014, TFS=12371 ,Alexa - set cols/rows 
			$("<div>" + '<div class="modal-header popupHeader blue_lbl" style="height:5px">' +
             ' <div class="floutR"> <input type="image" id="btncloseNote" style="cursor: pointer;" class="notAllowed " ' + 'src=" ' + global.imagesManager.actionsStackButtonsCollapse + '"/></div>' +
             '</div>' +
               " <textarea class=' " + cls + "' name='" + options.field + "' rows=5 cols=40 style='position: absolute; width: " + container.width() + "px;' " + attr + "/></div>")
            .appendTo(container);
			$("#btncloseNote").click(closeCell);
		}

		function noteTemplate(item, isRW) {
			var template;
			isRW = typeof isRW !== 'undefined' ? isRW : 1;
			if (item == null || item == "") {
				if (isRW == 1)
					template = "<img class='noteImg' src='" + global.imagesManager.addNote + "' />";
				else
					template = "";
			}
			else {
				item = item.replace(/'/g, "&#39;");
				template = "<img class='noteImg' src='" + global.imagesManager.note + "'  alt='" + item + "' />";
			}
			return template;
		}

		function activeNotActiveTemplate(item) {
			var template;
			if (item == true) {
				template = "<span class='editable-cell'><img class='imgCenter' src='" + global.imagesManager.active + "' alt='" + item + "' /></span>";
			}
			else {
				template = "<span class='editable-cell'><img class='imgCenter' src='" + global.imagesManager.notActive + "' alt='" + item + "' /></span>";
			}
			return template;
		}

		function checkboxCellTemplate(item) {
			var template;
			template = '<input type="checkbox" ' + (item == true ? 'checked="checked"' : '') + '/>';
			return template;
		}

		//#endregion editors & templates for grid columns

		function dirtyField(dataItem, fieldName) {

			if (dataItem.dirty && dataItem.dirtyFields != null && dataItem.dirtyFields[fieldName]) {
				return "<span class='k-dirty'></span>"
			}
			else {
				return "";
			}
		}

		function dirtyFields(dataItem, fieldsNames) {
			var result = "";
			if (dataItem.dirty && dataItem.dirtyFields != null) {
				$.each(fieldsNames, function loopdirtyFields(fieldkey, fieldName) {
					if (dataItem.dirtyFields[fieldName])
						result = "<span class='k-dirty'></span>";
				});
			}
			return result;
		}

		function setPageNo(pageNo) {
			getGrid().dataSource.page(pageNo);
		}

		function setCancelChanges() {
			getGrid().cancelChanges();
		}

		function setCancelRow() {
			getGrid().cancelRow();
		}

		function getGrid() {
			return $("#" + vm.gridId()).data("kendoGrid");
		}

		function setDataSource(dataAll, fromInit) {
			if (getGrid() == null) {
				if (initOptions.remote) {
					getGridLayout();
					dataSource = new kendo.data.DataSource({
						transport: {
							read: {
								url: global.webApiConfig.getApiPath(initOptions.dataURL.path),
								dataType: "json",
								type: !global.isNull(initOptions.httpType) ? initOptions.httpType : "GET",
								data: initOptions.httpType == "POST" ? vm.dataQuery : { query: JSON.stringify(vm.dataQuery) },
								cache: false
							},
							update: vm.updateConfig,
							create: vm.createConfig,
							destroy: vm.destroyConfig
						},
						pageSize: baseFeatures.pageable ? (vm.pageSize != null ? vm.pageSize : 20) : 1000,
						error: vm.onError,
						serverPaging: true,
						serverFiltering: true,
						serverSorting: vm.serverSorting,
						schema: vm.schema,
						page: 1,
						sort: vm.sort,
						group: vm.group,
						filter: vm.filter,
						requestStart: function requestStart(e, s) {
							try {

								if (vm.requestStart)
									handleDataDirtyOnRequestStart(e);
								switch (e.type) {
									case global.enums.gridRequestType.read:
										if (vm.dataQuery) {
											if (baseFeatures.pageable && getGrid().dataSource.options.serverPaging && !isFromExcel) {
												vm.dataQuery.PageNo = e.sender.page();
												vm.dataQuery.PageLength = e.sender.pageSize();
												if (vm.dataQuery.PageLength % 10 != 0) {//user select all
													vm.dataQuery.PageNo = 0;
													vm.dataQuery.PageLength = 0;
												}
											}
											if (e.sender.options.transport.read.type == "POST") {
												e.sender.options.transport.read.data = vm.dataQuery;
												if (vm.beforeRequestStart != null) {
													vm.beforeRequestStart(e);
												}
											}
											else {//'GET' 
												//beforeRequestStart usually changes query, so needs to call it before next line. just in "Get" grids .   
												if (vm.beforeRequestStart != null) {
													vm.beforeRequestStart(e);
												}
												if (!global.isNOE(vm.getGrid().dataSource.filter())) {//support telerik filter of grid in HttpGet methods(controller must contai query with relevant fields)
													var filter = vm.getGrid().dataSource.filter();
													var arrFilters = [];
													$.each(filter.filters, function loopFilter(k, item) {
														arrFilters.push({ field: item.field, operator: item.operator, value: item.value });
													});
													if (arrFilters.length > 0)
														vm.dataQuery.Filter = { logic: filter.logic, filters: arrFilters };
													else
														vm.dataQuery.Filter = null;
												}
												else
													vm.dataQuery.Filter = null;
												e.sender.options.transport.read.data.query = JSON.stringify(vm.dataQuery);
											}
										}

										isFromExcel = false;
										break;
									case global.enums.gridRequestType.update:
										if (vm.beforeUpdateStart != null) {
											vm.beforeUpdateStart(e);
										}
										break;
									case global.enums.gridRequestType.create:
										if (vm.beforeCreateStart != null) {
											vm.beforeCreateStart(e);
										}
										break;
								}
							}
							catch (err) {
								global.treatError(err);
							}
						},
						change: function dataSourceChange(e) {
							try {
								handleDirtyFieldsPerRow(e);
								handleDataDirtyOnChange(e);
							}
							catch (err) {
								global.treatError(err);
							}
						},
						requestEnd: function requestEnd(e) {
							try {
								if (vm.clearSelectionHandler != null) {
									vm.clearSelectionHandler();
								}
								switch (e.type) {
									case global.enums.gridRequestType.read:
										vm.afterReadEnd(e);
										break;
									case global.enums.gridRequestType.update:
										vm.afterUpdateEnd(e);
										break;
									case global.enums.gridRequestType.create:
										vm.afterCreateEnd(e);
										break;

								}
							}
							catch (err) {
								global.treatError(err);
							}
						}
					});
				}
				else {
					getGridLayout();
					dataSource = new kendo.data.DataSource({
						pageSize: vm.pageSize != null ? vm.pageSize : 20,
						data: dataAll,
						schema: vm.schema,
						sort: vm.sort,
						//group: vm.group,
						//filter: vm.filter,
						change: function dataSourceChange(e) {
							try {
								handleDirtyFieldsPerRow(e);
							}
							catch (err) {
								global.treatError(err);
							}
						}
					});
				}

				vm.gridOptions.dataSource = dataSource;//on load
			}
			else {
				var grid = getGrid();
				grid.dataSource.data(dataAll);
			}
			dataSourcePrepared = true;
			if (!isBoundDOM) {
				bindGridDOM();
			}
		}

		function setDataSourceWithFocus(dataAll, fromInit) {
			setDataSource(dataAll, fromInit);
			var grid = getGrid();
			var row = grid.tbody.find("tr[role='row']:eq(0)");
			grid.select(row);
			var firstCell = grid.tbody.find("tr[role='row']:eq(0)" + " td:eq(1)");
			grid.current(firstCell);
			firstCell.focus();
		}

		function customizeFilterForLocalGrid(isLocal, filterBy, filterVal) {
			if (!isLocal)
				throw new Error("cannot implement 'customizeFilterForLocalGrid' for remote grid");
			else {
				if (vm.entireData != null) {
					vm.getGrid().dataSource.data(vm.entireData.slice());
				}

				if (global.isNullOrEmpty(filterVal)) // 14.06.2016 lyn
				{
					var dataSource = vm.getGrid().dataSource;
					if (vm.getGrid().dataSource.data().length > 0)
						dataSource.filter([]);
					return;
				}

				vm.entireData = vm.getGrid()._data.slice();

				//if (global.isNullOrEmpty(filterVal) || global.isNullOrEmpty(filterBy)) // 14.06.2016 lyn remove
				//    return;

				var filteredData = [];
				var data = vm.getGrid()._data;
				for (var i = 0; i < data.length; i++) {
					if (data[i][filterBy].toString().indexOf(filterVal) >= 0)
						filteredData.push(data[i]);
				}
				vm.getGrid().dataSource.data(filteredData);
			}
		}

		function handleDirtyFieldsPerRow(e) {
			if (e.action == "itemchange") {
				e.items[0].dirtyFields = e.items[0].dirtyFields || {};
				e.items[0].dirtyFields[e.field] = true;
				e.items[0].dirty = true;
				$('tr[data-uid="' + e.items[0].uid + '"] ').addClass("k-grid-itemchange");
			}
		}

		//#region handle Data Dirty On Sorting in Pageing
		var currentPage;
		var currentPageSize;
		var currentSort;
		var isActionFromUser = true;
		var isEventCanceled = false;

		function handleDataDirtyOnChange(e) {

			if (e.sender._sort) {
				currentSort = e.sender._sort[0];
			}
			currentPage = e.sender._page;
			// currentPageSize = e.sender._pageSize;
			isActionFromUser = true;
		}

		function handleDataDirtyOnRequestStart(e) {

			if (isEventCanceled || (e.sender.editable && !e.sender.editable.validatable.validate())) {
				e.preventDefault();
				return;
			}
			var hasChangesTabs = vm.hasChangesTabs();
			if (!vm.askIfSaveAfterRebind && ((vm.gridOptions.editable && !global.isNull(getGrid()) && !global.isNull(getGrid().dataSource) && getGrid().dataSource.hasChanges()) || hasChangesTabs == true) && vm.saveDataFunction && isActionFromUser) {

				e.preventDefault();

				//app.showMessage(res.getValueByKey('1360'), '', [res.getValueByKey('765'), res.getValueByKey('766'), res.getValueByKey('303')]).then(function handleDataDirtyDialogCloseResult(dialogResult) {
				customMessageWindow.buildMessage({ mode: global.enums.messageType.question, messageText: res.getValueByKey('1360'), btnsMode: global.enums.btnsMode.yesNoCancel });
				global.showDialog(customMessageWindow).then(function handleDataDirtyDialogCloseResult(dialogResult) {
					try {
						var isSortEvent = (e.sender._sort && currentSort != e.sender._sort[0])
						var isPageEvent = (currentPage != e.sender._page)
						//  var isPageSizeEvent = (currentPageSize != e.sender._pageSize);

						if (dialogResult == global.enums.customMsgWindowResult.yes)//yes
							vm.saveDataFunction();
						if (dialogResult == global.enums.customMsgWindowResult.no)//no
							vm.askIfSaveAfterRebind = true;
						rebind().done(function () {
							vm.askIfSaveAfterRebind = false;
						});
						if (dialogResult == global.enums.customMsgWindowResult.cancel) {//cancel

							//לא יתבצע דפדוף או מיון
							//although we prevent the event we must to "play" the previus event
							//if we dont do it the "sender" object saves the canceled event
							isEventCanceled = true;
							if (isSortEvent) {
								getGrid().dataSource.sort(currentSort);
							}
							if (isPageEvent) {
								getGrid().dataSource.page(currentPage);
							}
							//if (isPageSizeEvent) {
							//    //      getGrid().dataSource.pageSize(currentPageSize);
							//}
							isEventCanceled = false;
							return;
						}

						if (isActionFromUser) {

							isActionFromUser = false;
							//  getGrid().dataSource.pageSize(e.sender._pageSize);
						}
						if (isPageEvent && isActionFromUser) {

							isActionFromUser = false;
							getGrid().dataSource.page(e.sender._page);
						}
						if (isSortEvent && isActionFromUser) {

							isActionFromUser = false;
							getGrid().dataSource.sort(e.sender._sort[0]);
						}
					}
					catch (err) {
						global.treatError(err);
					}

				});


			}
			vm.askIfSaveAfterRebind = false;
		}
		//---end--- handle Data Dirty On Sorting in Pagigng

		function setData(data) {
			if (!global.isNull(getGrid())) {
				getGrid().dataSource.data(data);
				getGrid().refresh();
			}
		}

		function setUpdateData(item) {
			vm.notSetScroll = true;
			var grid = getGrid();
			var items = grid._data;
			// var items = grid.dataSource.data();
			if (global.isNull(item.id)) {
				item.id = item[grid.dataSource.options.schema.model.id];
			}
			for (var i = 0; i < items.length; i++) {
				var itemOld = items[i];
				if (itemOld.id == item.id) {
					itemOld.dirtyFields = null;
					for (var key in item) {
						if (item.hasOwnProperty(key)) {
							itemOld.set(key, item[key]);
							if (itemOld.fields.hasOwnProperty(key) && itemOld.fields[key].editable == false) {
								itemOld.fields[key].editable = true;
								itemOld.set(key, item[key]);
								itemOld.fields[key].editable = false;
							}
						}
					}
					itemOld.dirtyFields = null;
					itemOld.dirty = false;
					//remove k-dirty on cell
					grid.tbody.find(">tr[data-uid='" + itemOld.uid + "']").find("td").removeClass("k-dirty-cell");
					var dirty = grid.tbody.find(">tr[data-uid='" + itemOld.uid + "']").find(".k-dirty");
					dirty.removeClass("k-dirty");

					//var firstCell = grid.tbody.find(">tr[data-uid='" + itemOld.uid + "'] td:eq(1)");
					//grid.current(firstCell);
					//firstCell.focus();

					var selected = grid.select();
					if (selected && selected.length) {
						var firstCell = selected.find("td:eq(1)");
						grid.current(firstCell);
						firstCell.focus();
					}
					return;
				}
			}
			vm.notSetScroll = false;
		}

		function setCreateData(item) {
			var grid = getGrid();
			grid.dataSource.add(item);
		}

		function setRemoveData(item) {
			var grid = getGrid();
			grid.dataSource.remove(item);
		}

		function addTooltip(name) {
			if (!global.isNull(name))
				name = "td[" + name + "]:not(:empty)";
			else if (vm.allowTooltips)
				name = "td:not(:empty):not(:has(input)):not(:has(img[src='" + global.imagesManager.addNote + "'])):not(:has(p))";
			else
				return;
			var tooltip = $("#" + vm.gridId()).kendoTooltip({
				filter: name,
				// width: 120,//UserComment by content, 23/12/2014, TFS=12371
				position: "top",
				content: function contentContent(e) {
					try {
						var elem = $(e.target);
						if (elem.text() != "" && elem.text() != ' \xa0' && elem.text() != '\xa0'
                            && elem.text().replace(/\s/g, '').length > 0 && elem[0].offsetWidth < elem[0].scrollWidth)
							return elem.text();

						if (elem.find("img:not(.editable-cell-img)").length > 0) {
							if (!global.isNullOrEmpty(elem.find("img").attr("alt")))
								return elem.find("img").attr("alt");
						}
						// replace the popup that was created with a stub so _show doesn't break
						tooltip.popup = {
							open: function () { },
							one: function () { },
							close: function () { },
							options: {}
						};

						// delete the popup stub
						setTimeout(function () {
							tooltip.popup = null;
						}, 5);
					}
					// }
					catch (err) {
						global.treatError(err);
					}
				}
			}).data("kendoTooltip");
		}

		function dataBound(grid) {
			//  var grid = getGrid();
			var newSelection = [];
			var rowsChanges = getChanges();

			if (rowsChanges.length > 0)
				setDirtyCell(rowsChanges, grid);
			//after update not Succeeded Ids
			for (i in rowsChanges)
				if (!global.isNull(vm.notSucceededIds) && jQuery.inArray(rowsChanges[i].id, vm.notSucceededIds) >= 0)
					newSelection.push(grid.tbody.find(">tr[data-uid='" + rowsChanges[i].uid + "']"));
			grid.select(newSelection);
			if (initOptions.remote)
				$("#" + vm.gridId()).find(".headerbox").prop("checked", false);
			readonlyRow(grid);
			if (rowsChanges.length > 0)
				setDirtyCell(rowsChanges, grid);

			setGridLayout(grid);
			//    hoverEditableCell();
		}

		function setDirtyCell(editedItems, grid) {
			for (var i = 0; i < editedItems.length; i++) {
				var dataItem = editedItems[i];
				if (dataItem.dirty && dataItem.dirtyFields != null) {
					for (var key in dataItem.dirtyFields) {
						var cellIdx = grid.thead.find("th[data-field='" + key + "']").index();
						var row = grid.tbody.find(">tr[data-uid='" + dataItem.uid + "']");
						if (cellIdx >= 0)
							$(row.find("td").get(cellIdx)).prepend("<span class='k-dirty' />");
						if (initOptions.remote) {
							grid.tbody.find("tr:eq(0)").closest("tr").removeClass("k-state-selected");
							grid.select(row);
						}
						else
							row.addClass("k-grid-itemchange");
					}
				}
			}
			setScroll();

		}

		function setScroll() {
			if (vm.notSetScroll) {
				vm.notSetScroll = false;
				return;
			}
			var grid = getGrid();
			var scrollContentOffset = $(grid.element).find("tbody").offset().top;
			var select = grid.select();
			if (select.length > 0) {
				var selectContentOffset = select.offset().top;
				var distance = selectContentOffset - scrollContentOffset;
				$(grid.element).find(".k-grid-content").animate({
					scrollTop: distance
				}, 10);
			}
		}

		function readonlyRow(grid) {
			var tr = grid.tbody.find("tr");
			if (grid.table.hasClass("customNotEditable") || baseFeatures.editable == false)
				tr.addClass("customNotEditable");
			var gridNotEditable = grid.tbody.find(".customNotEditable");
			if (!initOptions.remote)
				gridNotEditable.find("td").not('.notInheritRowRO').addClass("readOnlyColumn");
			if (grid.table.hasClass("enableDeleting").length <= 0) //remove checkbox only if enableDeleting class not exist
				gridNotEditable.find(".checkbox").remove();
			if ($("#" + vm.gridId() + " .check_row").length == 1)//hide the checkbox on the title in case there is no row on the grid(In any case it's not just on the readonly)
				$("#" + vm.gridId() + " .check_row").hide();
			else
				$("#" + vm.gridId() + " .check_row").show();
		}

		function setSelectRow(dataRow) {
			var row = $('tr[data-uid="' + dataRow.uid + '"] ');
			row.addClass("k-state-selected");
			row.find(".checkbox").prop("checked", true);
		}

		function setUnSelectRow(dataRow) {
			var row = $('tr[data-uid="' + dataRow.uid + '"] ');
			row.removeClass("k-state-selected");
			row.find(".checkbox").prop("checked", false);
		}

		//scroll if current selected not visible
		function scrollIfNotVisible(current) {
			if ($(current).position().top < $('#' + vm.gridId() + ' .k-grid-content').scrollTop()) {
				$('#' + vm.gridId() + ' .k-grid-content').animate({
					scrollTop: $(current).position().top
				}, 20);
			}
			else
				if ($(current).position().top + $(current).height() > $('#' + vm.gridId() + ' .k-grid-content').scrollTop() + $('#' + vm.gridId() + ' .k-grid-content').height()) {
					$('#' + vm.gridId() + ' .k-grid-content').animate({
						scrollTop: $(current).position().top - $('#' + vm.gridId() + ' .k-grid-content').height() + $(current).height()
					}, 20);
				}
		}

		function keydownSelectRow() {
			$("#" + vm.gridId() + " > .k-grid-content > table").on("keydown", function selectRowKeyDown(ke) {

				try {
					var kGrid, curRow, newRow, curGrid;
					kGrid = $(this).closest('.k-grid').data("kendoGrid");

					//get currently selected row
					var curRowSelect = kGrid.select();
					curGrid = getGrid();
					newRow = $(".k-state-focused").closest("tr");
					if (!newRow.length)
						newRow = curRowSelect;
					if (!newRow.length)
						return;
				}
				catch (err) {
					global.treatError(err);
				}
				try {
					//get newRow up or down.
					if (ke.which == 38) {
						curRow = newRow.next();
						//support grid with invisible rows - jump to next visible row
						while (curRow[0] && curRow[0].style && curRow[0].style.display == "none") {
							curRow = curRow.next();
						}
						//scrollIfNotVisible(newRow);
					} else if (ke.which == 40) {
						curRow = newRow.prev();
						//support grid with invisible rows- jump to previous visible row
						while (curRow[0] && curRow[0].style && curRow[0].style.display == "none") {
							curRow = curRow.prev();
						}
						//scrollIfNotVisible(newRow);
					}
					else if (ke.which == 9) {
						var currentCell = $("#" + vm.gridId() + "_active_cell");
						if (newRow.hasClass("customNotEditable") && !currentCell.hasClass('notInheritRowRO')) {
							var nextCell = currentCell.next();
							nextCell.focus();
							curGrid.current(nextCell.prev());
							curGrid.table.focus()
							return;
						}
						if (currentCell.hasClass("not-editable-cell") || currentCell.hasClass("imgCenter") || currentCell.find("input[type = 'checkbox']").length > 0) {

							var nextCell = currentCell.next();
							nextCell.focus();
							curGrid.current(nextCell.prev());
							curGrid.table.focus();
						}
						var cell = $("#" + vm.gridId() + "_active_cell");
						var cellfirst = cell.prev();
						if (cellfirst.length == 0) {//if new row get cell last in parent row
							var prev = cell.parent().prev();
							if (cell.parent().prev().hasClass('notVisible'))
								prev = prev.prev();
							cellfirst = prev.find("td:last-child");
						}
						if (cellfirst.hasClass("isTabDown")) {//down under cell next row
							var row = $(cellfirst).closest("tr");
							var rowIdx = $("tr:visible", curGrid.tbody).index(row);
							var colIdx = $("td", row).index(cellfirst);

							var rowunder = curGrid.tbody.find("tr:visible").get(rowIdx + 1);
							var cellunder = $(rowunder).find("td").get(colIdx);
							curGrid.closeCell();
							if (cellunder) {
								cellunder.focus();
								curGrid.editCell($(cellunder));
								curGrid.current(cellunder);
							}
							cellfirst.removeClass("isTabDown");
						}
						if (cellfirst.hasClass("isTabUp")) {//down under cell next row 
							var row = $(cellfirst).closest("tr");
							var rowIdx = $("tr:visible", curGrid.tbody).index(row);
							var colIdx = $("td", row).index(cellfirst);

							var rowup = curGrid.tbody.find("tr:visible").get(rowIdx - row.data("rowNumber"));
							var cellup = $(rowup).find("td").get(colIdx + 1);
							if (cellup) {
								curGrid.closeCell();
								cellup.focus();
								curGrid.editCell($(cellup));
								curGrid.current(cellup);
							}
							cellfirst.removeClass("isTabUp");
						}
						if (cellfirst.hasClass("isTab")) {
							if (cellfirst) {
								curGrid.closeCell();
								curGrid.editCell($(cellfirst));
								cellfirst.focus();
								curGrid.current(cellfirst);
							}
							var input2 = cellfirst.find("input:visible , [data-role=dropdownlist]").get(1);
							if ($(input2).data("role") != "dropdownlist")
								input2.select();
							else {
								var dropdownlist = cellfirst.find('.k-dropdown:last input').data("kendoDropDownList");
								if (dropdownlist) {
									dropdownlist.focus();
									//synel asked to prevent opening combo on focus, so this next row is in comment
									// dropdownlist.open();
								}
							}
							cellfirst.removeClass("isTab");
							if (cellfirst.hasClass("tabDown")) //down under cell next row 
								cellfirst.addClass("isTabDown");
							if (cellfirst.hasClass("tabUp")) //up cell next row 
								cellfirst.addClass("isTabUp");
						} else {

							var dropdownlist1 = cell.find('input:eq(0)').data("kendoDropDownList");
							if (dropdownlist1) {
								dropdownlist1.focus();
								//synel asked to prevent opening combo on focus, so this next row is in comment
								// dropdownlist1.open();
							}
							var combobox = cell.find('input:eq(1)').data("kendoComboBox");//in ComboBox there are two inputs, the combo data in second
							if (combobox) {
								combobox.input.focus();
								//synel asked to prevent opening combo on focus, so this next row is in comment
								//  combobox.open();
							}
							var checkBox = cell.find("[type=checkbox]");
							if (checkBox) {
								checkBox.focus();
							}
						}
						if (cell.find("input:visible , [data-role=dropdownlist]").length > 1)
							cell.addClass("isTab");

						return true;

					}
					else if (ke.which == 27) {
						if (vm.allowEscOnEdit) {
							return;
						}
						curRow = newRow;
						var cell = $(".cellIsRequired");
						if ($(cell).length == 0) {
							return;
						}
						cell.focus();
						curGrid.current(cell);
						curGrid.editCell($(cell));

					}
					else {
						return;
					}
				}
				catch (err) {
					global.treatError(err);
				}
				try {
					if (!newRow.length)
						return;

					if (!curRow.find(".checkbox").length)
						curRow.removeClass("k-state-selected");
					else
						curRow.find(".checkbox:not(:checked)").closest("tr").removeClass("k-state-selected");
					//Select new row
					newRow.addClass("k-state-selected");
					if (vm.rowSelectionHandler != null)
						vm.rowSelectionHandler(ke, newRow);
				}
				catch (err) {
					global.treatError(err);
				}
			});

			$("#" + vm.gridId() + " > .k-grid-content > table").on("keydown", "input", function keyDownTimeInput(evt, ui) {
				var curCell = $(evt.currentTarget).closest("td");
				var grid = getGrid();

				if (evt.keyCode == 38 /*arrow up*/ || evt.keyCode == 40 /*arrow down*/ || evt.keyCode == 13 /*enter*/ || evt.keyCode == 27 /*Esc*/)
					setTimeout(function setCloseCell() {
						if (grid.closeCell && curCell) {
							grid.closeCell();
							if (evt.keyCode == 13 /*enter*/ || evt.keyCode == 27 /*Esc*/) {
								curCell.addClass("k-state-focused");
								curCell.focus();
								grid.table.focus();
							}
							if (evt.keyCode == 38 /*arrow up*/ || evt.keyCode == 40) {
								var cellindex = $(curCell).index()
								var newRow = curCell.closest("tr");
								var curRow = null;
								if (evt.keyCode == 40) {
									curRow = newRow.next();
									while (curRow[0] && curRow[0].style && curRow[0].style.display == "none") {
										curRow = curRow.next();
									}
								} else {
									curRow = newRow.prev();
									while (curRow[0] && curRow[0].style && curRow[0].style.display == "none") {
										curRow = curRow.prev();
									}
								}
								if (curRow) {
									newRow.removeClass("k-state-selected");
									var td = curRow.find("td:eq(" + cellindex + ")");
									td.addClass("k-state-focused");
									td.focus();
									if (!global.explorerType() != global.enums.explorerType.NOTIE ? true : false)
										grid.table.focus()
									curCell.closest("table").trigger($.Event("keydown", { keyCode: evt.keyCode, which: evt.keyCode }));
								}
							}
						}
					}, 1);
			});
		}

		function hoverEditableCell() {

			$("#" + vm.gridId() + " > .k-grid-content > table > tbody").find("td[role='gridcell']:not(:has(> img, div, .readOnlyColumn, .not-editable-cell, input[type='checkbox']))")
                .hover(
                function beginCellHover(ke) {
                	try {

                		if (!vm.allowBorderOnHover || $(this).hasClass("readOnlyColumn") || $(this).closest("table").hasClass("readOnlyColumn") || $(this).closest("tr").hasClass("readOnlyColumn")
                           || $(this).closest("table").hasClass("customNotEditable") || $(this).closest("tr").hasClass("customNotEditable"))
                			return;

                		if (this.id == vm.gridId() + "_active_cell")
                			return;

                		var div = document.createElement("div");
                		div.innerText = $(this).text() != "" ? $(this).text() : " ";
                		div.style.border = "1px";
                		div.style.borderStyle = "solid";
                		div.style.borderColor = "gray";
                		$(this).html(div);

                	}
                	catch (err) {
                		global.treatError(err);
                	}
                },
            function endCellHover(ke) {
            	try {

            		if (!vm.allowBorderOnHover || $(this).hasClass("readOnlyColumn") || $(this).closest("table").hasClass("readOnlyColumn") || $(this).closest("tr").hasClass("readOnlyColumn")
                         || $(this).closest("table").hasClass("customNotEditable") || $(this).closest("tr").hasClass("customNotEditable"))
            			return;
            		if (this.id == vm.gridId() + "_active_cell")
            			return;

            		$(this).html($(this).text() != " " ? $(this).text() : "");
            	}
            	catch (err) {
            		global.treatError(err);
            	}
            });


			$("#" + vm.gridId() + " > .k-grid-content > table > tbody").find(".editable-span-cell")
               .hover(
               function beginSpanCellHover(ke) {
               	try {

               		if (!vm.allowBorderOnHover || $(this).hasClass("readOnlyColumn") || $(this).closest("table").hasClass("readOnlyColumn") || $(this).closest("tr").hasClass("readOnlyColumn"))
               			return;

               		var div = document.createElement("div");
               		div.innerText = $(this).text() != "" ? $(this).text() : " ";
               		div.style.border = "1px";
               		div.style.borderStyle = "solid";
               		div.style.borderColor = "gray";
               		$(this).html(div);

               	}
               	catch (err) {
               		global.treatError(err);
               	}
               },
           function endSpanCellHover(ke) {
           	try {

           		if (!vm.allowBorderOnHover || $(this).hasClass("readOnlyColumn") || $(this).closest("table").hasClass("readOnlyColumn") || $(this).closest("tr").hasClass("readOnlyColumn"))
           			return;

           		$(this).html($(this).text() != " " ? $(this).text() : "");
           	}
           	catch (err) {
           		global.treatError(err);
           	}
           });

		}

		function ParseDateFormat(container, nameField, newDateFormat) {

			var dateFormatVM = dateFormat
			if (newDateFormat)
				dateFormatVM = newDateFormat;
			if (!nameField || !container[nameField])
				return "";
			if (container[nameField] instanceof Date)
				return kendo.toString(container[nameField], dateFormatVM);
			return kendo.toString(Date.parse(container[nameField].substring(0, 19)/*removing from string timezone like -7:00*/), dateFormatVM);
		}

		function setcolumnMode(options) {
			var grid = getGrid();
			if (options) {
				for (var i = 0; i < grid.columns.length; i++) {
					if (grid.columns[i].field == options.name) {
						if (global.isNull(options.showColumn) == false) {
							grid.columns[i].menu = options.showColumn;
							options.showColumn == true ? grid.showColumn(options.name) : grid.hideColumn(options.name);
							if (global.isNull(options.width) == false)
								setWidthColumn(grid, options.width, grid.columns[i]);
						}
						if (global.isNull(options.editable) == false) {
							grid.columns[i].editable = options.editable;
						}
						if (global.isNull(options.hidden) == false) {
							grid.columns[i].hidden = options.hidden;
							options.hidden == true ? grid.hideColumn(options.name) : grid.showColumn(options.name);
						}
						return false;
					}
				}
			}
		}

		function undo() {
			var grid = getGrid();
			var rows = getSelectedRows();
			if (rows != null && rows.length > 0) {
				$.each(rows, function loopOverData(dataviewKey, dataviewValue) {
					grid.dataSource.cancelChanges(dataviewValue);
				});
				grid.refresh();
			}
		}

		function refresh() {
			var grid = getGrid();
			var dataAll = getDataView();
			if (dataAll != null) {
				$.each(dataAll, function SetDataDirty(key, model) {
					model.dirty = false;
				});
				grid.refresh();
			}
		}

		function updateSearchFilters(field, operator, value) {
			if (!global.isNullOrEmpty(value)) {
				var newFilter = { field: field, operator: operator, value: value };
				var dataSource = getGrid().dataSource;
				var filters = null;
				if (dataSource.filter() != null) {
					filters = dataSource.filter().filters;
				}
				if (filters == null) {
					filters = [newFilter];
					dataSource.filter(filters); // 14.06.2016 lyn
				}
				else {
					var isNew = true;
					var index = 0;
					for (index = 0; index < filters.length; index++) {
						if (filters[index].field == field) {
							isNew = false;
							break;
						}
					}
					if (isNew) {
						filters.push(newFilter);
					}
					else {
						filters[index] = newFilter;
					}

					dataSource.filter(filters[index]); // 14.06.2016 lyn
				}
				//dataSource.filter(filters);                 
			}
			else {
				var dataSource = vm.getGrid().dataSource; // lyn
				dataSource.filter([]);
			}

		}

		function dataBoundFilter(e) {
			var filter = e.dataSource.filter();
			e.thead.find(".k-state-active-filter").removeClass("k-state-active-filter");
			if (filter) {
				var filteredMembers = {};
				setFilteredMembers(filter, filteredMembers);
				e.thead.find("th[data-field]").each(function () {
					var cell = $(this);
					var filtered = filteredMembers[cell.data("field")];
					if (filtered) {
						cell.find(".k-header-column-menu  span").addClass("k-state-active-filter");
					}
				});
			}
			$("#checkAll").attr('checked', false);
		}

		function exportToExcel() {
			try {
				var grid = getGrid();
				if (grid.dataSource.total() > grid.dataSource.pageSize() && baseFeatures.pageable) {
					//more than one page in grid.
					//need the two parts of condition: first - for pageable grids with only one page.
					//second - for unpageable grids with total > pagesize, like - weekly at workschedule.
					customMessageWindow.buildMessage({ mode: global.enums.messageType.question, messageText: global.resMsg[469], btnsMode: global.enums.btnsMode.yesNoCancel });
					global.showDialog(customMessageWindow).then(function handleCountRowsExportGrid(dialogResult) {
					    try {
					        if (dialogResult == global.enums.customMsgWindowResult.yes) {
					            grid.options.excel.allPages = true;
					            if (vm.dataQuery != null)
					                vm.dataQuery.PageNo = 0;
					            //vm.dataQuery.PageLength = 0;
					            isFromExcel = true;
					        }
					        else if (dialogResult == global.enums.customMsgWindowResult.cancel) {
					            return;
					        }
					        else if (dialogResult == global.enums.customMsgWindowResult.no) {
					            var pageNo = getGrid().dataSource.page(); //bug 26013						
					            grid.options.excel.allPages = false;
					            if (vm.dataQuery != null)
					                vm.dataQuery.PageNo = pageNo;
					            isFromExcel = true;
					        }
					        grid.saveAsExcel();
					    }
						catch (err) {
							global.treatError(err);
						}
					});
				}
				else
					grid.saveAsExcel();
			}
			catch (err) {
				global.treatError(err);
			}
		}

		function setFilteredMembers(filter, members) {
			if (filter.filters) {
				for (var i = 0; i < filter.filters.length; i++) {
					setFilteredMembers(filter.filters[i], members);
				}
			}
			else {
				members[filter.field] = true;
			}
		}

		function validate() {
			var sender = getGrid();
			if (sender.editable && !sender.editable.validatable.validate())
				return false;
			return true;
		}

		function removeColumnBeforeInit(fieldName) {
			var tempColumns = vm.gridOptions.columns;
			var tempColumn = Enumerable.From(tempColumns).Where(function (col) { return col.field == fieldName }).Select(function (col) { return col }).ToArray()[0];
			var tempColumnIndex = tempColumns.indexOf(tempColumn);
			tempColumns.splice(tempColumnIndex, 1);
		}

		function scrollTop() {
			$("#" + vm.gridId() + " .k-grid-content").scrollTop(0);
		}

		function errorOnPopupMode(e, gridObj, refreshFunc) {
			if (e.errors !== false) {
				//telerik grid can accept only one field for error.
				//you cannot send them errorId and errorMsg both, and it is not enuogh to send onlt errorMsg, becouse may be procedure returns only errorCode.
				//so, this field hold errorId and errorMsg both.               
				var error = e.errors;
				if (!global.isNull(error) && !global.isNull(error.substring))
					error = error.substring(error.indexOf('ErrorMsg') + 'ErrorMsg'.length + 2, error.length);

				if (global.isNullOrEmptyOrSpacesOnly(error)) {
					error = 'undefined';
				}

				global.customMessageWindow.buildMessage({ mode: global.enums.messageType.error, messageText: error });
				global.showDialog(global.customMessageWindow).then(function errorDialogClosed(result) {
					gridObj.cancelChanges();
					refreshFunc();
				});


			}
		}

		function openUserCommentFromListETable() {
			alert('openUserCommentFromListETable grid')
			//require(
			//         ["views/combinedControls/eTable/eTable"],
			//         function showETablePopupAfterRequireModule(eTableVM) {
			//             try {
			//                 global.showDialog(new eTableVM(3)) //test by JobCode
			//                     .then(function handleeTableScreenClosedResult(eTableResponse) {
			//                         // var Code = eTableResponse[eTableParams.eTableCodeColumn], 
			//                         //var Descript = eTableResponse[eTableParams.eTableDescriptColumn] );
			//                         var Code = eTableResponse[0];
			//                         var Descript = eTableResponse[1];
			//                     });
			//             }
			//             catch (err) {
			//                 global.treatError(err);
			//             }
			//         });
		}

		function textAreaEditor(container, options) {
			$('<textarea name="' + options.field + '" data-bind="value:' + options.field + '"style="width:100%;" maxlength="20"/>').appendTo(container);
		}

		var vm = {

			//------------------------------------------------------------------------------------------------------------
			//**********************************   members   ***********************************************************
			//------------------------------------------------------------------------------------------------------------ 
			schema: null,
			selectedRowIndex: initOptions.selectedIndex,
			notSucceededIds: [],//set style for dirty ros
			pageSizes: gridPageSizes,
			sort: null,
			group: [],
			filter: [],
			entireData: null,//for local filter
			dataQuery: null,
			updateConfig: null,
			createConfig: null,
			destroyConfig: null,
			columnsMinWidth: "",
			isBoundDOM: isBoundDOM,

			//------------------------------------------------------------------------------------------------------------
			//**********************************   methods   ***********************************************************
			//------------------------------------------------------------------------------------------------------------            
			compositionComplete: compositionComplete,
			customizeFilterForLocalGrid: customizeFilterForLocalGrid,
			getDataView: getDataView,//get data that exists only in the current page  
			//the default setting of Permission, isnt deppend on permission
			gridPermissionCode: initOptions.permission ? initOptions.permission.code : global.cache.enums.permissionCodes.NO_PERMISSION.code,
			//bint to the <table>.id in the user control 
			gridId: ko.observable(global.isNull(initOptions) || global.isNull(initOptions.gridId) ? "defaultId" : initOptions.gridId),
			gridOptions: null,
			getChanges: getChanges,//get all the changes that have made in the grid      
			getAllChanges: getAllChanges, //for local grid - get all changes from all grid pages
			setGridOptions: setGridOptions,//set property of the the grid gridOptions
			setPageNo: setPageNo,
			pageSize: $.inArray(defaultPageSize, gridPageSizes) == -1 && $.inArray(parseInt(defaultPageSize), gridPageSizes) == -1 ? gridPageSizes[gridPageSizes.length - 1] : defaultPageSize,
			setGridOptionsSetting: setGridOptionsSetting,
			rebind: rebind,
			setCancelChanges: setCancelChanges,
			clear: clear,//clearGrid on deactivate
			clearData: clearData,
			detached: detached,
			getSelectedRows: getSelectedRows,
			getSelectedRowsData: getSelectedRowsData,
			getSelectedEntities: getSelectedEntities,
			getSelectedEntitiesKey: getSelectedEntitiesKey,
			getGrid: getGrid,
			setDataSource: setDataSource,
			setData: setData,
			openPopup: openPopup,
			saveDataFunction: null,//save function delegate when page index changed
			ParseDateFormat: ParseDateFormat,
			dirtyFields: dirtyFields,//set update only row             
			setUpdateData: setUpdateData,
			setCreateData: setCreateData,//create new row 
			setRemoveData: setRemoveData,
			clearSelectionHandler: null,
			setSelectRow: setSelectRow,//set select row by data
			setUnSelectRow: setUnSelectRow,
			gridcheckboxStateChanged: null,
			resizeGrid: resizeGrid,
			setcolumnMode: setcolumnMode,// set cell show/hide /RO
			undo: undo,
			refresh: refresh,
			updateSearchFilters: updateSearchFilters,
			hasChangesTabs: function () { return false; },
			setDataSourceWithFocus: setDataSourceWithFocus,//add after setDataSource in delete or update add Focus
			validate: validate,
			exportToExcel: exportToExcel,
			scrollIfNotVisible: scrollIfNotVisible,
			scrollTop: scrollTop,
			removeColumnBeforeInit: removeColumnBeforeInit,

			//------------------------------------------------------------------------------------------------------------
			//**********************************   flags   ***********************************************************
			//------------------------------------------------------------------------------------------------------------            
			askIfSaveAfterRebind: false,
			askIfSaveBeforePaging: true,
			allowTooltips: true,
			allowBorderOnHover: true,
			allowEscOnEdit: true,
			setHeight100: false,
			mustInit: false, //force ro re-init the detailstabs in specific cases
			requestStart: true,
			allowLocalDataSourcePaging: false || initOptions.allowLocalDataSourcePaging,
			notSetScroll: false,
			serverSorting: true,
			isCustomExcelExport: false,

			//------------------------------------------------------------------------------------------------------------
			//**********************************   custom events   ******************************************************
			//------------------------------------------------------------------------------------------------------------    
			addEventAfterBind: null,
			addEventAfterSave: null,
			addEventAfterBound: null,
			beforeRequestStart: null,
			beforeUpdateStart: null,
			beforeCreateStart: null,
			afterUpdateEnd: function (e) { },
			afterReadEnd: function (e) { },
			afterCreateEnd: function (e) { },
			customOnEdit: function (e) { },
			//occures after composition complete of grid in afterBindEvents function
			customAfterBindEvents: function customAfterBindEvents() { },
			rowSelectionHandler: null,
			setPageSizeChangedFunction: function () { },
			onError: null,
			customColumnHide: function () { },

			//------------------------------------------------------------------------------------------------------------
			//**********************************    editors & templates & formats   ************************************
			//------------------------------------------------------------------------------------------------------------               
			multySelectorEditor: multySelectorEditor,
			passwordTemplate: passwordTemplate,
			passwordEditor: passwordEditor,
			comboEditor: comboEditor,
			autoCompleteEditor: autoCompleteEditor,
			comboTemplate: comboTemplate,
			comboTemplateWithFrame:comboTemplateWithFrame,
			datePickerEditor: datePickerEditor,
			datePickerTemplate: datePickerTemplate,
			inputTimeEditor: inputTimeEditor,
			noEditor: noEditor,
			noteEditor: noteEditor,
			colorEditor: colorEditor,
			noteTemplate: noteTemplate,
			activeNotActiveTemplate: activeNotActiveTemplate,
			checkboxCellTemplate: checkboxCellTemplate,
			noTemplate: noTemplate,
			timeFormat: timeFormat,
			dateFormat: dateFormat,
			timeInputTemplate: timeInputTemplate,
			errorOnPopupMode: errorOnPopupMode,
			openUserCommentFromListETable: openUserCommentFromListETable,
			afterBindEvents: afterBindEvents,
			clearPager: clearPager,
			textAreaEditor: textAreaEditor,
			changeEditable: changeEditable,
			getNormalRowData: getNormalRowData
		};

		//method for bug un telerik grids - when there is only one column checked in menu - telerik donwt allow to uncheck it(and hide it)
		//this method fixes this bug #21630
		function enableCheckbox() {
			this.element.find(".k-columns-item :checkbox").prop("disabled", false);
		}

		//#region grid configuration-----------------------------------------------------------------------
		//do not change the order of the baseFeatures
		var baseFeatures = {

			dataSource: {
				data: null,
				pageSize: (initOptions.remote && initOptions.pageable !== false) || vm.allowLocalDataSourcePaging ? 10 : 1000,
				schema: null
			},
			height: "100%",
			batch: true,
			reorderable: true,
			sortable: !global.isNull(initOptions.sortable) ? initOptions.sortable : true,
			resizable: true,
			filterable: !global.isNull(initOptions.filterable) ? initOptions.filterable : true,
			pageable: (initOptions.remote && initOptions.pageable !== false) || vm.allowLocalDataSourcePaging ? {
				refresh: false,
				pageSizes: vm.pageSizes,
				input: true,
				numeric: false,  //remove buttons for paging
				messages: {
					allPages: global.res[548]
				}
			} : false,
			columnMenu: true,
			columnMenuInit: function columnMenuInit(e) {
				var menu = e.container.children().data("kendoMenu");
				var handler = $.proxy(enableCheckbox, menu);

				menu.bind("open", handler).bind("select", handler);
			},
			navigatable: true,
			groupable: false,
			editable: !global.isNull(initOptions.editable) ? initOptions.editable : { confirmation: false },
			scrollable: true,
			selectable: "multiple row",
			change: function change(e) {
				try {
					var rowSelect = e.sender.content.find("tr.k-state-selected");
					e.sender.content.find(".check_row:checked").closest("tr").addClass("k-state-selected");
					if (vm.rowSelectionHandler != null)
						vm.rowSelectionHandler(e, rowSelect);
				}
				catch (err) {
					global.treatError(err);
				}
			},
			dataBound: function dataBoundFunc(e) {
				try {
					if (vm.addEventAfterBind != null) {
						vm.addEventAfterBind(vm, e);
					}

					selectRowFirst(this);
					dataBoundFilter(this);
					dataBound(this);

					if (vm.addEventAfterBound != null) {
						vm.addEventAfterBound(vm, e);
					}

					lastRowValidationTooltip(this);
				}
				catch (err) {
					global.treatError(err);
				}
			},
			edit: function onEditGrid(e) {
				try {
					editDropdown(e);
					var currentColumn = null;
					var cellIndex = e.container.index();
					var tempIndex = 0;
					var columns = e.sender.columns;
					for (var i = 0; i < columns.length; i++) {
						if (columns[i].columns) {
							for (var z = 0; z < columns[i].columns.length; z++) {
								if (cellIndex == tempIndex) {
									currentColumn = columns[i].columns[z];
								}
								tempIndex++;
							}
						}
						else {
							if (cellIndex == tempIndex) {
								currentColumn = columns[i];
							}
							tempIndex++;
						}
					}
					//check if call need to be closed for edit.
					//cases: RO grid (example- per profile) RO column (example- keys columns at realtion grids, like- security group grid), RO row (like future records at attendance grid)
					if (currentColumn.editable == false || (e.container.closest("tr").hasClass("customNotEditable") && !e.container.closest("td").hasClass("notInheritRowRO"))
                     || e.container.closest("table").hasClass("customNotEditable")) {
						e.sender.closeCell();
						e.container.addClass("k-state-focused");
						e.container.focus();
					}
					if (e.container.find(".readOnlyColumn").length) {
						e.container.focus();
					}
					if (e.container.find("input:visible").length > 1)
						e.container.addClass("isTab");
					vm.customOnEdit(e);
				}
				catch (err) {
					global.treatError(err);
				}
			},
			save: function onSaveGrid(e) {
				try {
					if (vm.addEventAfterSave != null) {
						var ev = e;
						setTimeout(function () { vm.addEventAfterSave(ev, vm) }, 10);
					}
				}
				catch (err) {
					global.treatError(err);
				}
			},
			columnHide: function cellHide(e) {
				setGridLayout(this);
				//hide column menu if the selected column is hidden
				selectedcolumn = $("#" + vm.gridId() + "_active_cell");
				if (selectedcolumn && selectedcolumn[0] && selectedcolumn[0].attributes) {
					selectedcolumnField = selectedcolumn[0].attributes['data-field'].value;
					columnToRemove = e.column.field;
					if (selectedcolumnField == columnToRemove)
						$(".k-animation-container:has('.k-column-menu')").hide();
				}
				vm.customColumnHide();
			},
			columnShow: function cellShow(e) {
				setGridLayout(this);
			},
			columnReorder: function cellReorder(e) {
				var that = this;
				var index = null;
				if (e.column.field == "check_row")
					index = 0;
				else if (e.newIndex == 0 && e.column.field != "check_row" && that.thead.find("[data-field=check_row]").length > 0)
					index = e.oldIndex;
				if (index != null) {
					var ev = e;
					setTimeout(function reorderColumnSto() {
						that.reorderColumn(index, ev.column);
					}, 5);
					e.preventDefault();
					return;
				}
				setTimeout(function () {
					setGridLayout(that);
				}, 5);
			},
			columnResize: function cellResize(e) {
				try {
					if (e.column.field && e.column.field.indexOf(vm.columnsMinWidth) >= 0 && e.column.minwidth > e.newWidth) {
						setWidthColumn(this, e.column.minwidth, e.column);
					}
					setGridLayout(this);
				}
				catch (err) {
					global.treatError(err);
				}
			},
			excel: {
				fileName: initOptions.gridId + '.xlsx',
				filterable: true,
				allPages: false
			},
			excelExport: buildExcelData

		};
		//#endregion grid configuration-----------------------------------------------------------------------

		vm.gridOptions = baseFeatures;

		return vm;
	}

	return initVM;
});



