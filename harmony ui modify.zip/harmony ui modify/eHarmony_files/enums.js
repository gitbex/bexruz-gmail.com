﻿/// <reference path="../views/employees/employeeDataPopup/employeeContactData.html" />
define(function enumsModule(require) {
    var imagesManager = require('common/imagesManager');

    cacheOrDb = {
        byCountMode: { id: 3, name: "byCountMode" },
        cacheMode: { id: 2, name: "cacheMode" },
        dbMode: { id: 1, name: "dbMode" }
    };

    lookupExtraField = {
        defaultValue: { name: 'defaultValue', code: 1 },
        timeFormat: { name: 'timeFormat', code: 2 },
        dayColorAndUsedInAgreem: { name: 'dayColorAndUsedInAgreem', code: 3 },
        length: { name: 'length', code: 4 },
        ChoiceValue: { name: 'ChoiceValue', code: 5 },
        trnTypeAndEnroll: { name: 'typeAndEnroll', code: 6 },
        GroupDescr: { name: 'GroupDescr', code: 7 },
        Address: { name: 'Address', code: 8 },
        LookupElemName: { name: 'LookupElemName', code: 9 },
        ServiceCodeDesc: { name: 'ServiceCodeDesc', code: 10 },
        OrgLevel: { name: "OrgLevel", code: 11 },
    };

    lookupName = {//cacheName param is for lookups with a same name and another xml-data
        //*********************NOTE: defaultExist is NOT require parameter***********************************
        AbsenceForUserUpdate: { id: 35, name: "AbsenceForUserUpdate", cacheName: "AbsenceForUserUpdate", mode: cacheOrDb.cacheMode, dependent: false, titleResId: 1108 },
        AbsenceForGroupUpdate: { id: 36, name: "AbsenceForGroupUpdate", cacheName: "AbsenceForGroupUpdate", mode: cacheOrDb.cacheMode, dependent: false, titleResId: 33 },
        AbsenceDocumentType: { id: 159, name: "AbsenceDocumentType", cacheName: "AbsenceDocumentType", mode: cacheOrDb.cacheMode, dependent: false },
        Action: { id: 20, name: "Action", cacheName: "Action", mode: cacheOrDb.byCountMode, dependent: false, titleResId: 6 },
        AddSub: { id: 85, name: "AddSub", cacheName: "AddSub", mode: cacheOrDb.cacheMode, dependent: false, },
        AddDayType2WorkRule: { id: 143, name: "AddDayType2WorkRule", cacheName: "AddDayType2WorkRule", mode: cacheOrDb.dbMode, dependent: false, },
        Agreem: { id: 14, name: "Agreem", cacheName: "Agreem", mode: cacheOrDb.dbMode, dependent: false, titleResId: 270 },
        ApprovalType: { id: 41, name: "ApprovalType", cacheName: "ApprovalType", mode: cacheOrDb.cacheMode, dependent: false, titleResId: 1124 },
        AssignPoint: { id: 25, name: "AssignPoint", cacheName: "AssignPoint", mode: cacheOrDb.cacheMode, dependent: false, titleResId: 3565 },
        AssignSecGroup: { id: 27, name: "AssignSecGroup", cacheName: "AssignSecGroup", mode: cacheOrDb.cacheMode, dependent: false, titleResId: 2778 },
        AuthorPerm: { id: 22, name: "AuthorPerm", cacheName: "AuthorPerm", mode: cacheOrDb.cacheMode, dependent: false, titleResId: 324 },
        BalancePayment: { id: 73, name: "BalancePayment", cacheName: "BalancePayment", mode: cacheOrDb.cacheMode, dependent: false },
        Budget: { id: 38, name: "Budget", cacheName: "Budget", mode: cacheOrDb.byCountMode, dependent: false, titleResId: 2822 },
        BudgetType: { id: 56, name: "118", cacheName: "BudgetType", mode: cacheOrDb.cacheMode, dependent: false },
        BudgetPayCode: { id: 109, name: "PayCodeByTimeClass", cacheName: "BudgetPayCode", mode: cacheOrDb.cacheMode, dependent: false },
        UsersProfile: { id: 159, name: "PermGroupDescr", cacheName: "PermGroupDescr", mode: cacheOrDb.cacheMode, dependent: false, extraField: lookupExtraField.GroupDescr },
        SubBudget: { id: 39, name: "SubBudget", cacheName: "SubBudget", mode: cacheOrDb.dbMode, dependent: true, titleResId: 2823 },
        CalendarType: { id: 5, name: "CalendarType", cacheName: "CalendarType", mode: cacheOrDb.cacheMode, dependent: false, titleResId: 271 },
        Camera: { id: 5, name: "130", cacheName: "Camera", mode: cacheOrDb.cacheMode },
        CardTemplates: { id: 26, name: "CardTemplates", cacheName: "CardTemplates", mode: cacheOrDb.cacheMode, dependent: false, titleResId: 3588 },
        CarType: { id: 17, name: "CarType", cacheName: "CarType", mode: cacheOrDb.dbMode, dependent: false, titleResId: 2200 },
        ClockID: { id: 55, name: "ClockID", cacheName: "ClockID", mode: cacheOrDb.dbMode, dependent: false, titleResId: 1891 },
        ClockActions: { id: 55, name: "100", cacheName: "ClockActions", mode: cacheOrDb.cacheMode, dependent: false, extraField: lookupExtraField.trnTypeAndEnroll },
        ClndTypeYears: { id: 81, name: "ClndTypeYears", cacheName: "ClndTypeYears", mode: cacheOrDb.dbMode, dependent: false },
        ContactType: { id: 3, name: "ContactType", cacheName: "ContactType", mode: cacheOrDb.dbMode, dependent: false, titleResId: 0 },
        ContactTypeList: { id: 29, name: "ContactTypeList", cacheName: "ContactTypeList", mode: cacheOrDb.dbMode, dependent: false, titleResId: 1108 },
        Computers: { id: 54, name: "Computers", cacheName: "Computers", mode: cacheOrDb.cacheMode, dependent: false },
        CommServer: { id: 55, name: "129", cacheName: "CommServer", mode: cacheOrDb.cacheMode, dependent: false },
        ControllerGrp: { id: 56, name: "ControllerGrp", cacheName: "ControllerGrp", mode: cacheOrDb.dbMode, dependent: false, titleResId: 2778 },
        Controllers: { id: 56, name: "102", cacheName: "Controllers", mode: cacheOrDb.cacheMode, dependent: false },
        ControllerStatus: { id: 109, name: "ControllerStatus", cacheName: "ControllerStatus", mode: cacheOrDb.cacheMode, dependent: false },
        DateFormat: { id: 88, name: "137", cacheName: "137", mode: cacheOrDb.cacheMode, dependent: false },
        DoorType: { id: 153, name: "DoorType", cacheName: "DoorType", mode: cacheOrDb.dbMode, dependent: false },
        DocumentType: { id: 161, name: "DocTypes", cacheName: "DocTypes", mode: cacheOrDb.cacheMode, dependent: false },
        EmpDocTypes: { id: 211, name: "EmpDocTypes", cacheName: "EmpDocTypes", mode: cacheOrDb.cacheMode, dependent: false },
        Map: { id: 152, name: "Map", cacheName: "Map", mode: cacheOrDb.dbMode, dependent: false },
        DSTList: { id: 89, name: "142", cacheName: "142", mode: cacheOrDb.cacheMode, dependent: false },
        Employers: { id: 166, name: 'Tfs101CompaniesList', cacheName: 'Tfs101CompaniesList', mode: cacheOrDb.cacheMode },
        TransactList: { id: 100, name: "D108", cacheName: "D108", mode: cacheOrDb.cacheMode, dependent: false },
        RelayOperationList: { id: 101, name: "D210", cacheName: "D210", mode: cacheOrDb.cacheMode, dependent: false },
        RelayNumberList: { id: 102, name: "D115", cacheName: "D115", mode: cacheOrDb.cacheMode, dependent: false },
        SensorList: { id: 103, name: "D112", cacheName: "D112", mode: cacheOrDb.cacheMode, dependent: false },
        MatchRepList: { id: 104, name: "D122", cacheName: "D122", mode: cacheOrDb.cacheMode, dependent: false },
        FilterByAttndAbs: { id: 172, name: "FilterByAttndAbs", cacheName: "FilterByAttndAbs", mode: cacheOrDb.cacheMode, dependent: false },
        FunctionKeyStatus: { id: 105, name: "141", cacheName: "141", mode: cacheOrDb.cacheMode, dependent: false },
        FlexiPeriod: { id: 107, name: "FlexiPeriod", cacheName: "FlexiPeriod", mode: cacheOrDb.dbMode, dependent: false },
        FlexiPeriodOT: { id: 108, name: "FlexiPeriodOT", cacheName: "FlexiPeriodOT", mode: cacheOrDb.dbMode, dependent: false },
        FPU: { id: 150, name: "FPU", cacheName: "FPU", mode: cacheOrDb.cacheMode, dependent: false },
        ClndTypeList: { id: 81, name: 'ClndTypeList', cacheName: 'ClndTypeList', mode: cacheOrDb.cacheMode, dependent: false, titleResId: 271, extraField: lookupExtraField.length },
        CycleTypeList: { id: 82, name: 'CycleTypeList', cacheName: 'CycleTypeList', mode: cacheOrDb.dbMode, dependent: false },
        DailyReportingAction: { id: 50, name: "Action", cacheName: "DailyReportingAction", mode: cacheOrDb.dbMode, dependent: false, titleResId: 6 },
        DailyReportingOper: { id: 51, name: "Oper", cacheName: "DailyReportingOper", mode: cacheOrDb.dbMode, dependent: false, titleResId: 3 },
        DailyReportingMachine: { id: 166, name: "Machine", cacheName: "DailyReportingMachine", mode: cacheOrDb.dbMode, dependent: false, titleResId: 5 },
        DailyReportingLevel: { id: 167, name: "Level", cacheName: "DailyReportingLevel", mode: cacheOrDb.dbMode, dependent: false, titleResId: 13 },
        DailyReportingBudget: { id: 52, name: "Budget", cacheName: "DailyReportingBudget", mode: cacheOrDb.dbMode, dependent: false, titleResId: 2822 },
        DailyReportingSubBudget: { id: 53, name: "SubBudget", cacheName: "DailyReportingSubBudget", mode: cacheOrDb.dbMode, dependent: false, titleResId: 2823 },
        DailyPatterns: { id: 77, name: "DailyPatterns", cacheName: "DailyPatterns", mode: cacheOrDb.cacheMode, dependent: false },
        DayList: { id: 82, name: "DayList", cacheName: "DayList", mode: cacheOrDb.cacheMode },
        DayType: { id: 49, name: "DayType", cacheName: "DayType", mode: cacheOrDb.dbMode, dependent: true },
        DayTypeColor: { id: 80, name: "DayTypeColor", cacheName: "DayTypeColor", mode: cacheOrDb.cacheMode, dependent: true, titleResId: 680, extraField: lookupExtraField.dayColorAndUsedInAgreem },
        DayTypeColorAgr: { id: 108, name: "DayTypeColorAgr", cacheName: "DayTypeColor", mode: cacheOrDb.cacheMode, dependent: true, titleResId: 680, extraField: lookupExtraField.dayColorAndUsedInAgreem },
        Dep: { id: 9, name: "Dep", cacheName: "Dep", mode: cacheOrDb.byCountMode, dependent: false, titleResId: 1 },
        DeviceType: { id: 99, name: "D102", cacheName: "D102", mode: cacheOrDb.cacheMode, dependent: false },
        DeviceNumber: { id: 93, name: "D114", cacheName: "D114", mode: cacheOrDb.cacheMode, dependent: false },
        DeviceRegion: { id: 94, name: "D118", cacheName: "D118", mode: cacheOrDb.cacheMode, dependent: false },
        DoorList: { id: 95, name: "D103", cacheName: "D103", mode: cacheOrDb.cacheMode, dependent: false },
        DaysOfWeek: { id: 136, name: "DaysOfWeek", cacheName: "DaysOfWeek", mode: cacheOrDb.cacheMode, dependent: false },
        Portal_Otp_Options: { id: 165, name: "Portal_Otp_Options", cacheName: "Portal_Otp_Options", mode: cacheOrDb.cacheMode, dependent: false },
        CameraList: { id: 96, name: "D117", cacheName: "D117", mode: cacheOrDb.cacheMode, dependent: false },
        AutoMode: { id: 97, name: "D107", cacheName: "D107", mode: cacheOrDb.cacheMode, dependent: false },
        ReaderKind: { id: 98, name: "D113", cacheName: "D113", mode: cacheOrDb.cacheMode, dependent: false },
        TerminalType: { id: 57, name: "TerminalType", cacheName: "TerminalType", mode: cacheOrDb.dbMode, dependent: false, titleResId: 483 },
        RestTerminals: { id: 199, name: "RestTerminals", cacheName: "RestTerminals", mode: cacheOrDb.dbMode, dependent: false },
        RestGroups: { id: 200, name: "RestGroups", cacheName: "RestGroups", mode: cacheOrDb.cacheMode, dependent: false },
        DvcDefTransactIn: { id: 46, name: "DvcDefTransact", cacheName: "DvcDefTransactIn", mode: cacheOrDb.cacheMode, dependent: false, extraField: lookupExtraField.timeFormat },
        DvcDefTransactOut: { id: 47, name: "DvcDefTransact", cacheName: "DvcDefTransactOut", mode: cacheOrDb.cacheMode, dependent: false, extraField: lookupExtraField.timeFormat },
        DvcDefTransactTask: { id: 48, name: "DvcDefTransact", cacheName: "DvcDefTransactTask", mode: cacheOrDb.cacheMode, dependent: false, extraField: lookupExtraField.timeFormat },
        DvcDefTransactBudget: { id: 49, name: "DvcDefTransact", cacheName: "DvcDefTransactBudget", mode: cacheOrDb.cacheMode, dependent: false, extraField: lookupExtraField.timeFormat },
        Emp: { id: 34, name: "Emp", cacheName: "Emp", mode: cacheOrDb.dbMode, dependent: false, titleResId: 2 }, //must be db mode because of 11880
        EmpCost: { id: 31, name: "EmpCost", cacheName: "EmpCost", mode: cacheOrDb.dbMode, dependent: false, titleResId: 463 },
        EmpForManager: { id: 29, name: "EmpForManager", cacheName: "EmpForManager", mode: cacheOrDb.dbMode, dependent: false, titleResId: 4960 },
        EmpGroup: { id: 2, name: "EmpGroup", cacheName: "EmpGroup", mode: cacheOrDb.cacheMode, dependent: false, titleResId: 908 },
        EntryCode: { id: 37, name: "ArrAction", cacheName: "EntryCode", mode: cacheOrDb.cacheMode, dependent: false, extraField: lookupExtraField.defaultValue, titleResId: 36 },
        ExitCode: { id: 76, name: "ArrAction", cacheName: "ExitCode", mode: cacheOrDb.cacheMode, dependent: false, extraField: lookupExtraField.defaultValue, titleResId: 37 },
        HourCat: { id: 72, name: "HourCat", cacheName: "HourCat", mode: cacheOrDb.cacheMode, dependent: false },
        Factory: { id: 7, name: "Factory", cacheName: "Factory", mode: cacheOrDb.byCountMode, dependent: false, titleResId: 1297 },
        FirstHundred: { id: 44, cacheName: "FirstHundred", mode: cacheOrDb.cacheMode, dependent: false, titleResId: 1297, localCreate: true },
        Form101AreaCodes: { id: 75, name: 'Form101AreaCodes', cacheName: "Form101AreaCodes", mode: cacheOrDb.cacheMode, dependent: false, titleResId: null },
        Form101HMONames: { id: 62, name: 'Form101HMONames', cacheName: "Form101HMONames", mode: cacheOrDb.cacheMode, dependent: false, titleResId: null },
        GlobalTypeParam: { id: 45, name: "GlobalTypeParam", cacheName: "GlobalTypeParam", mode: cacheOrDb.cacheMode, dependent: false },
        GroupQuotaType: { id: 79, name: "GroupQuotaType", cacheName: "GroupQuotaType", mode: cacheOrDb.cacheMode, dependent: false },
        SicknessGroupType: { id: 148, name: "SicknessGroupType", cacheName: "SicknessGroupType", mode: cacheOrDb.cacheMode, dependent: false },
        JobCode: { id: 15, name: "JobCode", cacheName: "JobCode", mode: cacheOrDb.cacheMode, dependent: false, titleResId: 2579 },
        LanguagesList: { id: 32, name: "LanguagesList", cacheName: "LanguagesList", mode: cacheOrDb.cacheMode, dependent: false, titleResId: 564 },
        Law_EventTypes: { id: 154, name: "Law_EventTypes", cacheName: "Law_EventTypes", mode: cacheOrDb.cacheMode, dependent: false },
        Law_EventGroupTypes: { id: 155, name: "Law_EventGroupTypes", cacheName: "Law_EventGroupTypes", mode: cacheOrDb.cacheMode, dependent: false },
        Law_EventGroups: { id: 158, name: "Law_EventGroups", cacheName: "Law_EventGroups", mode: cacheOrDb.dbMode, dependent: false, titleResId: 983 },
        Law_EventSourceTypes: { id: 156, name: "Law_EventSourceTypes", cacheName: "Law_EventSourceTypes", mode: cacheOrDb.cacheMode, dependent: false },
        Law_CustProcedures: { id: 157, name: "Law_CustProcedures", cacheName: "Law_CustProcedures", mode: cacheOrDb.cacheMode, dependent: false },
        Level: { id: 21, name: "Level", cacheName: "Level", mode: cacheOrDb.byCountMode, dependent: false, titleResId: 13 },
        Machine: { id: 18, name: "Machine", cacheName: "Machine", mode: cacheOrDb.byCountMode, dependent: false, titleResId: 5 },
        ManagerForEmp: { id: 30, name: "ManagerForEmp", cacheName: "ManagerForEmp", mode: cacheOrDb.dbMode, dependent: false, titleResId: 4961 },
        MaritalStatus: { id: 16, name: "MaritalStatus", cacheName: "MaritalStatus", mode: cacheOrDb.cacheMode, dependent: false, titleResId: 2438 },
        MealEntry: { id: 42, name: "ArrAction", cacheName: "MealEntry", mode: cacheOrDb.cacheMode, titleResId: 2735 },
        MealExit: { id: 43, name: "ArrAction", cacheName: "MealExit", mode: cacheOrDb.cacheMode, titleResId: 2735 },
        MealType: { id: 23, name: "MealType", cacheName: "MealType", mode: cacheOrDb.cacheMode, dependent: false, titleResId: 487 },//2736
        MealsAction: { id: 198, name: "MealsAction", cacheName: "MealsAction", mode: cacheOrDb.cacheMode, titleResId: 2735 },
        PatternBreakType: { id: 60, name: "PatternBreakType", cacheName: "PatternBreakType", mode: cacheOrDb.cacheMode, dependent: false, titleResId: 684 },
        Patterns: { id: 4, name: "Patterns", cacheName: "Patterns", mode: cacheOrDb.cacheMode, dependent: false, titleResId: 1108 },
        PatternsAll: { id: 24, name: "PatternsAll", cacheName: "PatternsAll", mode: cacheOrDb.byCountMode, dependent: false, titleResId: 3308 },//3438
        PatternsAllFull: { id: 150, name: "PatternsAll", cacheName: "PatternsAllFull", mode: cacheOrDb.dbMode, dependent: false, titleResId: 3308 },//3438
        PayCode: { id: 74, name: "PayCode", cacheName: "PayCode", mode: cacheOrDb.cacheMode, dependent: false, titleResId: 1245 },
        PayCode2DailyUpd: { id: 175, name: "PayCodeByPerm", cacheName: "PayCode2DailyUpd", mode: cacheOrDb.cacheMode, dependent: false, titleResId: 1245 },
        PayCode2PeriodUpd: { id: 176, name: "PayCodeByPerm", cacheName: "PayCode2PeriodUpd", mode: cacheOrDb.cacheMode, dependent: false, titleResId: 1245 },
        PayCodeExclude: { id: 74, name: "PayCodeExclude", cacheName: "PayCodeExclude", mode: cacheOrDb.cacheMode, dependent: false, titleResId: 1245 },
        HourCatUsedAs: { id: 73, name: "HourCatUsedAs", cacheName: "HourCatUsedAs", mode: cacheOrDb.cacheMode, dependent: false, titleResId: 3387 },
        HourCat2DailyUpd: { id: 177, name: "HourCatByPerm", cacheName: "HourCat2DailyUpd", mode: cacheOrDb.cacheMode, dependent: false, titleResId: 1523 },
        HourCat2PeriodUpd: { id: 178, name: "HourCatByPerm", cacheName: "HourCat2PeriodUpd", mode: cacheOrDb.cacheMode, dependent: false, titleResId: 1523 },
        QuotaCateg: { id: 72, name: "QuotaCateg", cacheName: "QuotaCateg", mode: cacheOrDb.cacheMode, dependent: false, titleResId: 2650 },
        PeriodType: { id: 71, name: "PeriodType", cacheName: "PeriodType", mode: cacheOrDb.cacheMode, dependent: false },
        PermGroup: { id: 71, name: "PermGroup", cacheName: "PermGroup", mode: cacheOrDb.cacheMode, dependent: false, titleResId: 1333 },//276
        PermProfileForNew: { id: 1, name: "PermProfile", cacheName: "PermProfile", mode: cacheOrDb.cacheMode, dependent: false, titleResId: 1333 },//276
        PermGroupForAccessLevelTab: { id: 70, name: "PermGroup", cacheName: "PermGroupForAccessLevelTab", mode: cacheOrDb.cacheMode, dependent: false, titleResId: 1333 },//276
        Product: { id: 40, name: "Product", cacheName: "Product", mode: cacheOrDb.cacheMode, dependent: false, titleResId: 20 },
        Oper: { id: 19, name: "Oper", cacheName: "Oper", mode: cacheOrDb.byCountMode, dependent: false, titleResId: 3 },
        ProjectEndCode: { id: 37, name: "ArrAction", cacheName: "ProjectEndCode", mode: cacheOrDb.cacheMode, dependent: false, extraField: lookupExtraField.defaultValue, titleResId: 1108 },
        ProjectStartCode: { id: 69, name: "ArrAction", cacheName: "ProjectStartCode", mode: cacheOrDb.cacheMode, dependent: false, extraField: lookupExtraField.defaultValue, titleResId: 1108 },
        ReaderKind: { id: 56, name: "113", cacheName: "ReaderKind", mode: cacheOrDb.cacheMode, dependent: false },
        Region: { id: 6, name: "Region", cacheName: "Region", mode: cacheOrDb.byCountMode, dependent: false, titleResId: 1296 },
        RegionIn: { id: 56, name: "132", cacheName: "RegionIn", mode: cacheOrDb.cacheMode, dependent: false },
        RegulationType: { id: 70, name: "RegulationType", cacheName: "RegulationType", mode: cacheOrDb.cacheMode, dependent: false },
        RoundInterval: { id: 106, name: "RoundInterval", cacheName: "RoundInterval", mode: cacheOrDb.cacheMode, dependent: false, codeIsVal: true },
        SecGroupMaster: { id: 28, name: "SecGroupMaster", cacheName: "SecGroupMaster", mode: cacheOrDb.dbMode, dependent: false, titleResId: 31 },//1333
        Section: { id: 8, name: "Section", cacheName: "Section", mode: cacheOrDb.byCountMode, dependent: false, titleResId: 1305, dependentWasChanged: true },
        Station: { id: 10, name: "Station", cacheName: "Station", mode: cacheOrDb.dbMode, dependent: false, titleResId: 4 },
        StubType: { id: 56, name: "138", cacheName: "StubType", mode: cacheOrDb.dbMode, dependent: false },
        SecGroup: { id: 151, name: "SecGroup", cacheName: "SecGroup", mode: cacheOrDb.dbMode, dependent: false, titleResId: 2778 },
        TagReason: { id: 11, name: "TagReason", cacheName: "TagReason", mode: cacheOrDb.cacheMode, dependent: false, titleResId: 3584 },
        TagStatus: { id: 13, name: "TagStatus", cacheName: "TagStatus", mode: cacheOrDb.cacheMode, dependent: false, titleResId: 2990 },
        TagType: { id: 12, name: "TagType", cacheName: "TagType", mode: cacheOrDb.byCountMode, dependent: false, titleResId: 289 },
        TerminalType: { id: 57, name: "TerminalType", cacheName: "TerminalType", mode: cacheOrDb.dbMode, dependent: false, titleResId: 483 },
        Tfs101VerSts: { id: 58, name: "Tfs101VerSts", cacheName: "Tfs101VerSts", mode: cacheOrDb.cacheMode, dependent: false },
        TimeZone: { id: 90, name: "TimeZone", cacheName: "TimeZone", mode: cacheOrDb.cacheMode, dependent: false, },
        UserEmpProfiles: { id: 68, name: "UserEmpProfiles", cacheName: "UserEmpProfiles", mode: cacheOrDb.cacheMode, dependent: false },
        ValueByData: { id: 61, name: 'ValueByData', cacheName: "ValueByData", mode: cacheOrDb.cacheMode, dependent: false },
        ValueByType: { id: 169, name: 'valueByType', cacheName: 'valueByType', mode: cacheOrDb.cacheMode },
        SalaryIcons: { id: 170, name: "SalaryIcons", cacheName: "SalaryIcons", mode: cacheOrDb.dbMode, dependent: false, titleResId: 983 },
        OrganizationLevelConstList: { id: 67, name: "OrganizationLevelConstList", cacheName: "OrganizationLevelConstList", mode: cacheOrDb.cacheMode, dependent: false },
        OrganizationLevelDynamicList: { id: 59, name: "OrganizationLevelDynamicList", cacheName: "OrganizationLevelDynamicList", mode: cacheOrDb.cacheMode, dependent: false },
        Work_c: { id: 33, name: "Work_c", cacheName: "Work_c", mode: cacheOrDb.cacheMode, dependent: false, titleResId: 4 },
        WorkRuleList: { id: 92, name: "WorkRuleList", cacheName: "WorkRuleList", mode: cacheOrDb.dbMode, dependent: false },
        workRulesActions: { id: 147, name: "workRulesActions", cacheName: "workRulesActions", mode: cacheOrDb.cacheMode, dependent: false },
        ReportSort: { id: 65, name: "ReportSort", cacheName: "ReportSort", mode: cacheOrDb.dbMode, dependent: false, titleResId: 1108, xmlData: null },
        Warning_Type: { id: 66, name: "Warning_Type", cacheName: "Warning_Type", mode: cacheOrDb.dbMode, dependent: false, titleResId: 2659, xmlData: null },
        ValuesForChoice: { id: 78, name: "ValuesForChoice", cacheName: "ValuesForChoice", mode: cacheOrDb.cacheMode, dependent: false },
        ValuesForChoice214: { id: 62, name: "ValuesForChoice", cacheName: "ValuesForChoice214", mode: cacheOrDb.cacheMode, dependent: false },
        ValuesForChoice213: { id: 110, name: "ValuesForChoice", cacheName: "ValuesForChoice213", mode: cacheOrDb.cacheMode, dependent: false },
        ValuesForChoice218: { id: 63, name: "ValuesForChoice", cacheName: "ValuesForChoice218", mode: cacheOrDb.cacheMode, dependent: false },
        ValuesForChoice9014: { id: 112, name: "ValuesForChoice", cacheName: "ValuesForChoice9014", mode: cacheOrDb.cacheMode, dependent: false },
        ValuesForChoice9015: { id: 113, name: "ValuesForChoice", cacheName: "ValuesForChoice9015", mode: cacheOrDb.cacheMode, dependent: false },
        ValuesForChoice9927: { id: 114, name: "ValuesForChoice", cacheName: "ValuesForChoice9927", mode: cacheOrDb.cacheMode, dependent: false },
        ValuesForChoice9928: { id: 115, name: "ValuesForChoice", cacheName: "ValuesForChoice9928", mode: cacheOrDb.cacheMode, dependent: false },
        ValuesForChoice9929: { id: 116, name: "ValuesForChoice", cacheName: "ValuesForChoice9929", mode: cacheOrDb.cacheMode, dependent: false },
        ValuesForChoice9934: { id: 117, name: "ValuesForChoice", cacheName: "ValuesForChoice9934", mode: cacheOrDb.cacheMode, dependent: false },
        ValuesForChoice9941: { id: 118, name: "ValuesForChoice", cacheName: "ValuesForChoice9941", mode: cacheOrDb.cacheMode, dependent: false },
        ValuesForChoice9943: { id: 111, name: "ValuesForChoice", cacheName: "ValuesForChoice9943", mode: cacheOrDb.cacheMode, dependent: false },
        ValuesForChoice9950: { id: 119, name: "ValuesForChoice", cacheName: "ValuesForChoice9950", mode: cacheOrDb.cacheMode, dependent: false },
        ValuesForChoice9951: { id: 120, name: "ValuesForChoice", cacheName: "ValuesForChoice9951", mode: cacheOrDb.cacheMode, dependent: false },
        ValuesForChoice9955: { id: 121, name: "ValuesForChoice", cacheName: "ValuesForChoice9955", mode: cacheOrDb.cacheMode, dependent: false },
        ValuesForChoice9956: { id: 122, name: "ValuesForChoice", cacheName: "ValuesForChoice9956", mode: cacheOrDb.cacheMode, dependent: false },
        ValuesForChoice9957: { id: 124, name: "ValuesForChoice", cacheName: "ValuesForChoice9957", mode: cacheOrDb.cacheMode, dependent: false },
        ValuesForChoice9962: { id: 125, name: "ValuesForChoice", cacheName: "ValuesForChoice9962", mode: cacheOrDb.cacheMode, dependent: false },
        ValuesForChoice9963: { id: 126, name: "ValuesForChoice", cacheName: "ValuesForChoice9963", mode: cacheOrDb.cacheMode, dependent: false },
        ValuesForChoice9984: { id: 127, name: "ValuesForChoice", cacheName: "ValuesForChoice9984", mode: cacheOrDb.cacheMode, dependent: false },
        ValuesForChoice200: { id: 129, name: "ValuesForChoice", cacheName: "ValuesForChoice200", mode: cacheOrDb.cacheMode, dependent: false },
        ValuesForChoice217: { id: 130, name: "ValuesForChoice", cacheName: "ValuesForChoice217", mode: cacheOrDb.cacheMode, dependent: false },
        ValuesForChoice202: { id: 132, name: "ValuesForChoice", cacheName: "ValuesForChoice202", mode: cacheOrDb.cacheMode, dependent: false },
        ValuesForChoice9976: { id: 133, name: "ValuesForChoice", cacheName: "ValuesForChoice9976", mode: cacheOrDb.cacheMode, dependent: false },
        ValuesForChoice9975: { id: 134, name: "ValuesForChoice", cacheName: "ValuesForChoice9975", mode: cacheOrDb.cacheMode, dependent: false },
        ValuesForChoice9978: { id: 135, name: "ValuesForChoice", cacheName: "ValuesForChoice9978", mode: cacheOrDb.cacheMode, dependent: false },
        ValuesForChoice9933: { id: 137, name: "ValuesForChoice", cacheName: "ValuesForChoice9933", mode: cacheOrDb.cacheMode, dependent: false },
        ValuesForChoice9971: { id: 138, name: "ValuesForChoice", cacheName: "ValuesForChoice9971", mode: cacheOrDb.cacheMode, dependent: false },
        ValuesForChoice9131: { id: 139, name: "ValuesForChoice", cacheName: "ValuesForChoice9131", mode: cacheOrDb.cacheMode, dependent: false },
        ValuesForChoice9132: { id: 140, name: "ValuesForChoice", cacheName: "ValuesForChoice9132", mode: cacheOrDb.cacheMode, dependent: false },
        ValuesForChoice9982: { id: 145, name: "ValuesForChoice", cacheName: "ValuesForChoice9982", mode: cacheOrDb.cacheMode, dependent: false },
        ValuesForChoice9980: { id: 146, name: "ValuesForChoice", cacheName: "ValuesForChoice9980", mode: cacheOrDb.cacheMode, dependent: false },
        ValuesForChoice9981: { id: 149, name: "ValuesForChoice", cacheName: "ValuesForChoice9981", mode: cacheOrDb.cacheMode, dependent: false },
        BrkType: { id: 141, name: "BrkType", cacheName: "BrkType", mode: cacheOrDb.cacheMode, dependent: false },
        //*********************Company params COMBO : start ***********************************
        compParTagType: { id: 83, name: 'compParTagType', cacheName: "compParTagType", mode: cacheOrDb.cacheMode, dependent: false, titleResId: 289, extraField: lookupExtraField.ChoiceValue },
        compParTagBarCode: { id: 84, name: 'compParTagBarCode', cacheName: "compParTagBarCode", mode: cacheOrDb.cacheMode, dependent: false, titleResId: 3570, extraField: lookupExtraField.ChoiceValue },
        compParTagBurnType: { id: 85, name: 'compParTagBurnType', cacheName: "compParTagBurnType", mode: cacheOrDb.cacheMode, dependent: false, titleResId: 3569, extraField: lookupExtraField.ChoiceValue },
        compParTagPicFileName: { id: 90, name: 'compParTagPicFileName', cacheName: "compParTagPicFileName", mode: cacheOrDb.cacheMode, dependent: false, titleResId: 3590, extraField: lookupExtraField.ChoiceValue },
        compParTagConnIssue: { id: 91, name: 'compParTagConnIssue', cacheName: "compParTagConnIssue", mode: cacheOrDb.cacheMode, dependent: false, titleResId: 3572, extraField: lookupExtraField.ChoiceValue },
        compParSrchField: { id: 86, name: 'compParSrchField', cacheName: "compParSrchField", mode: cacheOrDb.cacheMode, dependent: false, titleResId: 3574, extraField: lookupExtraField.ChoiceValue },
        compParWebPeriodType: { id: 136, name: 'compParWebPeriodType', cacheName: "compParWebPeriodType", mode: cacheOrDb.cacheMode, dependent: false },
        //*********************Company params COMBO : end ***********************************
        permListPayCode: { id: 87, name: 'permListPayCode', cacheName: "permListPayCode", mode: cacheOrDb.cacheMode, dependent: false, titleResId: 3149, disableReload: true },
        gridCntList: { id: 142, name: "gridCntList", cacheName: "gridCntList", mode: cacheOrDb.cacheMode, dependent: false },
        IOExportTypes: { id: 144, name: "SalaryIO_Export", cacheName: "SalaryIO_Export", mode: cacheOrDb.cacheMode, dependent: false },
        AuditGroupKey: { id: 159, name: "AuditGroupKey", cacheName: "AuditGroupKey", mode: cacheOrDb.dbMode, dependent: false, titleResId: 983 },
        AuditEventType: { id: 160, name: "AuditEventType", cacheName: "AuditEventType", mode: cacheOrDb.dbMode, dependent: false, titleResId: 983 },
        NoData: { id: 162, name: "NoData", cacheName: "NoData", mode: cacheOrDb.cacheMode, dependent: false, titleResId: 4452, localCreate: true },
        WebUserProfileTypes: { id: 164, name: "WebUserProfileTypes", cacheName: "WebUserProfileTypes", mode: cacheOrDb.cacheMode, dependent: false },
        searchControlworkMode: { id: 257, name: "searchControlworkMode", cacheName: "searchControlworkMode", mode: cacheOrDb.cacheMode, dependent: false },
        logWrittingSettings: { id: 267, name: "logWrittingSettings", cacheName: "logWrittingSettings", mode: cacheOrDb.cacheMode, dependent: false },
        //*********************IO_interfaces COMBO : start ***********************************
        IO_inputTables: { id: 168, name: 'IO_inputTables', cacheName: "IO_inputTables", mode: cacheOrDb.cacheMode, dependent: false },
        Restaurants: { id: 171, name: 'Restaurants', cacheName: "Restaurants", mode: cacheOrDb.cacheMode, dependent: false },
        Rep_OrgLevelsList: { id: 173, name: 'Rep_OrgLevelsList', cacheName: "Rep_OrgLevelsList", mode: cacheOrDb.cacheMode, dependent: false },
        Client: { id: 174, name: 'ClientsPermList', cacheName: "ClientsPermList", mode: cacheOrDb.dbMode, dependent: false },
        PayrollFactory: { id: 179, name: 'PayrollFactory', cacheName: 'PayrollFactory', mode: cacheOrDb.cacheMode, dependent: false },
        ActivityRecStatus: { id: 180, name: "ActivityRecStatus", cacheName: "ActivityRecStatus", mode: cacheOrDb.cacheMode, dependent: false },
        //*********************CostCenter COMBO : start ***********************************
        ReportingArea: { id: 181, name: "ReportingArea", cacheName: "ReportingArea", mode: cacheOrDb.cacheMode, dependent: false },
        //*********************MngAppr grid COMBO : start ***********************************
        AbsenceForMngGroup: { id: 182, name: "AbsenceForMngGroup", cacheName: "AbsenceForMngGroup", mode: cacheOrDb.cacheMode, dependent: false },
        AttendanceMealProfile: { id: 183, name: "MealsProfile", cacheName: "MealsProfile", mode: cacheOrDb.cacheMode, dependent: false },
        AttendanceMealsRestaurant: { id: 184, name: "MealsRest", cacheName: "MealsRest", mode: cacheOrDb.cacheMode, dependent: false },
        AttendanceMealsStart: { id: 185, name: "MealsStart", cacheName: "MealsStart", mode: cacheOrDb.cacheMode, dependent: false },      
        AttendanceMealsEnd: { id: 186, name: "MealsEnd", cacheName: "MealsEnd", mode: cacheOrDb.cacheMode, dependent: false },
        Tfs101BanksList: { id: 187, name: "Tfs101BanksList", cacheName: "Tfs101BanksList", mode: cacheOrDb.cacheMode, dependent: false },
        Tfs101BankBranchesList: { id: 188, name: "Tfs101BankBranchesList", cacheName: "Tfs101BankBranchesList", mode: cacheOrDb.dbMode, dependent: false, extraField: lookupExtraField.Address },
        IO_types: { id: 189, name: "IO_types", cacheName: "IO_types", mode: cacheOrDb.cacheMode, dependent: false },
        IO_DateFormat: { id: 190, name: "IO_DateFormat", cacheName: "IO_DateFormat", mode: cacheOrDb.cacheMode, dependent: false },
        IO_Outsave: { id: 191, name: "IO_Outsave", cacheName: "IO_Outsave", mode: cacheOrDb.cacheMode, dependent: false },
        IO_OutFormat: { id: 192, name: "IO_OutFormat", cacheName: "IO_OutFormat", mode: cacheOrDb.cacheMode, dependent: false },
        Tfs101CitiesList: { id: 193, name: "Tfs101CitiesList", cacheName: "Tfs101CitiesList", mode: cacheOrDb.cacheMode, dependent: false },
        Tfs101CityStreetsList: { id: 194, name: "Tfs101CityStreetsList", cacheName: "Tfs101CityStreetsList", mode: cacheOrDb.dbMode, dependent: false },
        //********************* NOTIFIER COMBOS : start ***********************************
        ExternalPartnerDigivod: { id: 195, name: "ExternalPartnerDigivod", cacheName: "ExternalPartnerDigivod", mode: cacheOrDb.cacheMode, dependent: false },
        NotifierEventTypes: { id: 202, name: "NotifierEventTypes", cacheName: "NotifierEventTypes", mode: cacheOrDb.cacheMode, dependent: false },
        NotifierDaysOfWeek: { id: 203, name: "NotifierDaysOfWeek", cacheName: "NotifierDaysOfWeek", mode: cacheOrDb.cacheMode, dependent: false },
        NotifierMonthList: { id: 204, name: "NotifierMonthList", cacheName: "NotifierMonthList", mode: cacheOrDb.cacheMode, dependent: false },
        NotifierRecurrenceTypes: { id: 205, name: "NotifierRecurrenceTypes", cacheName: "NotifierRecurrenceTypes", mode: cacheOrDb.cacheMode, dependent: false },
        NotifierEmpFilterBy: { id: 206, name: "NotifierEmpFilterBy", cacheName: "NotifierEmpFilterBy", mode: cacheOrDb.cacheMode, dependent: false },
        NotifierContactTypeList: { id: 207, name: "NotifierContactTypeList", cacheName: "NotifierContactTypeList", mode: cacheOrDb.cacheMode, dependent: false },
        NotifierDailyPeriodCategory: { id: 208, name: "NotifierDailyPeriodCategory", cacheName: "NotifierDailyPeriodCategory", mode: cacheOrDb.cacheMode, dependent: false },
        NotifierWebLinkList: { id: 209, name: "NotifierWebLinkList", cacheName: "NotifierWebLinkList", mode: cacheOrDb.cacheMode, dependent: false },
        NotifierLangList: { id: 210, name: "NotifierLangList", cacheName: "NotifierLangList", mode: cacheOrDb.cacheMode, dependent: false },
        NotifierAvailableDays: { id: 213, name: "AvailableDays", cacheName: "NotifierAvailableDays", mode: cacheOrDb.cacheMode, dependent: false },
        NotifierSentEventStatus: { id: 215, name: "NotifierSentEventStatus", cacheName: "NotifierSentEventStatus", mode: cacheOrDb.cacheMode, dependent: false },
        NotifierCustSPList: { id: 216, name: "NotifierCustSPList", cacheName: "NotifierCustSPList", mode: cacheOrDb.cacheMode, dependent: false, codeIsVal: true },
        NotifierPayCategories: { id: 217, name: "NotifierPayCategories", cacheName: "NotifierPayCategories", mode: cacheOrDb.cacheMode, dependent: false },
        NotifierProvidersList: { id: 229, name: "NotifierProvidersList", cacheName: "NotifierProvidersList", mode: cacheOrDb.cacheMode, dependent: false },
        
        //********************* NOTIFIER COMBOS : end ***********************************
        IO_DataType: { id: 196, name: "IO_DataType", cacheName: "IO_DataType", mode: cacheOrDb.cacheMode, dependent: false },
        IO_TransType: { id: 197, name: "IO_TransType", cacheName: "IO_TransType", mode: cacheOrDb.cacheMode, dependent: false },
        IO_NegativeValues: { id: 198, name: "IO_Negative_Values", cacheName: "IO_Negative_Values", mode: cacheOrDb.cacheMode, dependent: false },
        SchedqualifStatus: { id: 214, name: "schedqualif_status", cacheName: "SchedqualifStatus", mode: cacheOrDb.cacheMode, dependent: false },
        Rep_OrgLevelsListTotals: { id: 218, name: "Rep_OrgLevelsList_Totals", cacheName: "Rep_OrgLevelsList_Totals", mode: cacheOrDb.cacheMode, dependent: false, extraField: lookupExtraField.OrgLevel },
        OrgLevelFilter: { id: 219, name: "OrgLevelFilter", cacheName: "OrgLevelFilter", mode: cacheOrDb.dbMode, dependent: false, extraField: lookupExtraField.LookupElemName },
        SchedQualif_PlanEmpFilter: { id: 220, name: "SchedQualif_PlanEmpFilter", cacheName: "SchedQualif_PlanEmpFilter", mode: cacheOrDb.cacheMode, dependent: false },
        SchedQualif_ServiceFilter: { id: 221, name: "SchedQualif_ServiceFilter", cacheName: "SchedQualif_ServiceFilter", mode: cacheOrDb.dbMode, dependent: false, extraField: lookupExtraField.ServiceCodeDesc },
        SchedQualif_NotifierType: { id: 222, name: "SchedQualif_NotifierType", cacheName: "SchedQualif_NotifierType", mode: cacheOrDb.cacheMode, dependent: false },
        SchedQualif_QualifList: { id: 223, name: "SchedQualif_QualifList", cacheName: "SchedQualif_QualifList", mode: cacheOrDb.byCountMode, dependent: false },
        UserNotesList: { id: 224, name: "UserNotesList", cacheName: "UserNotesList", mode: cacheOrDb.cacheMode, dependent: false },
        DayTypeForAllowedReporting: { id: 225, name: "DayTypeForAllowedReporting", cacheName: "DayTypeForAllowedReporting", mode: cacheOrDb.cacheMode, dependent: false },
        EmpPayrollJobType: { id: 226, name: "EmpPayrollJobType", cacheName: "EmpPayrollJobType", mode: cacheOrDb.cacheMode, dependent: false },
        SubBudgetTravel: { id: 227, name: "SubBudgetTravel", cacheName: "SubBudgetTravel", mode: cacheOrDb.dbMode, dependent: true, titleResId: 2823 },		
        DateFormat_Culture: { id: 228, name: "DateFormat_Culture", cacheName: "DateFormat_Culture", mode: cacheOrDb.cacheMode, dependent: false },
        ReportDateFormat_Culture: { id: 256, name: "ReportDateFormat_Culture", cacheName: "ReportDateFormat_Culture", mode: cacheOrDb.cacheMode, dependent: false },
        ClientsPermList: { id: 229, name: "ClientsPermList", cacheName: "ClientsPermList", mode: cacheOrDb.dbMode, dependent: false, titleResId: 21 },
        SitesPermList: { id: 230, name: "SitesPermList", cacheName: "SitesPermList", mode: cacheOrDb.dbMode, dependent: false, titleResId: 2334 },
        TimeZoneList: { id: 231, name: 'TimeZoneList', cacheName: "TimeZoneList", mode: cacheOrDb.cacheMode, isSpecificCreating: true, extraField: lookupExtraField.defaultValue },
        RecurrenceType: { id: 232, name: 'RecurrenceType', cacheName: "RecurrenceType", mode: cacheOrDb.cacheMode, dependent: false },
        AutomationJobsDayTypes: { id: 233, name: 'AutomationJobsDayTypes', cacheName: "AutomationJobsDayTypes", mode: cacheOrDb.cacheMode, dependent: false },
        AutomationJobsDaysOfWeek: { id: 234, name: 'AutomationJobsDaysOfWeek', cacheName: "AutomationJobsDaysOfWeek", mode: cacheOrDb.cacheMode, dependent: false },
        NotifierMonthList: { id: 235, name: 'NotifierMonthList', cacheName: "NotifierMonthList", mode: cacheOrDb.cacheMode, dependent: false },
        DaysCombinationList: { id: 236, name: 'DaysCombinationList', cacheName: "DaysCombinationList", mode: cacheOrDb.cacheMode, dependent: false },
        QueuePriority: { id: 237, name: "QueuePriority", cacheName: "QueuePriority", mode: cacheOrDb.cacheMode, dependent: false },
        AutomationJobsMenuList: { id: 238, name: "AutomationJobsMenuList", cacheName: "AutomationJobsMenuList", mode: cacheOrDb.cacheMode, dependent: false },
        AutomationJobsStatus: { id: 239, name: "AutomationJobsStatus", cacheName: "AutomationJobsStatus", mode: cacheOrDb.cacheMode, dependent: false },
        AutomationJobsHistoryStatus: { id: 240, name: "AutomationJobsHistoryStatus", cacheName: "AutomationJobsHistoryStatus", mode: cacheOrDb.cacheMode, dependent: false },
        Queues: { id: 241, name: "Queues", cacheName: "Queues", mode: cacheOrDb.cacheMode, dependent: false },
        TimeZoneSG: { id: 242, name: "TimeZoneSG", cacheName: "TimeZoneSG", mode: cacheOrDb.cacheMode, dependent: false },    
        EmpPermProfiles: { id: 243, name: "EmpPermProfiles", cacheName: "EmpPermProfiles", mode: cacheOrDb.cacheMode, dependent: false },
        DepExtension: { id: 244, name: "Dep", cacheName: "DepExtension", mode: cacheOrDb.byCountMode, dependent: false, titleResId: 1 },
        PRMifalList: { id: 245, name: "MifalList", cacheName: "MifalList", mode: cacheOrDb.cacheMode, dependent: false }, // lyn 01.01.2018
        PROrgTreeList: { id: 246, name: "OrgTreeList", cacheName: "OrgTreeList", mode: cacheOrDb.cacheMode, dependent: false },
        PRSemelCityList: { id: 247, name: "SemelCityList", cacheName: "SemelCityList", mode: cacheOrDb.cacheMode, dependent: false },
        PRSugHevraList: { id: 248, name: "SugHevraList", cacheName: "SugHevraList", mode: cacheOrDb.cacheMode, dependent: false },
        PRMiyunTlushList: { id: 249, name: "MiyunTlushList", cacheName: "MiyunTlushList", mode: cacheOrDb.cacheMode, dependent: false },
        PRAcntFileList: { id: 250, name: "AcntFileList", cacheName: "AcntFileList", mode: cacheOrDb.cacheMode, dependent: false },
        PRBLBankList: { id: 251, name: "BLBankList", cacheName: "BLBankList", mode: cacheOrDb.cacheMode, dependent: false },
        PRBLSnifList: { id: 252, name: "BLSnifList", cacheName: "BLSnifList", mode: cacheOrDb.cacheMode, dependent: false },
        BudgetTerminal: { id: 253, name: "BudgetTerminal", cacheName: "BudgetTerminal", mode: cacheOrDb.byCountMode, dependent: false, titleResId: 2822 },		
        SubManagersList: { id: 254, name: "SubManagers_List", cacheName: "SubManagersList", mode: cacheOrDb.cacheMode, dependent: false },
        SubManagersListByActualOT: { id: 260, name: "SubManagers_List", cacheName: "SubManagersListByActualOT", mode: cacheOrDb.cacheMode, dependent: false },
        ReportsList: { id: 255, name: "ReportsList", cacheName: "ReportsList", mode: cacheOrDb.cacheMode, dependent: false, titleResId: 564 },
        IO_InputTableFields: { id: 256, name: "IO_InputTableFields", cacheName: "IO_InputTableFields", mode: cacheOrDb.dbMode, dependent: false },
        IO_Alignment: { id: 257, name: "IO_Alignment", cacheName: "IO_Alignment", mode: cacheOrDb.cacheMode, dependent: false },
        IO_Format: { id: 258, name: "IO_Format", cacheName: "IO_Format", mode: cacheOrDb.cacheMode, dependent: false },
        NoData_dbMode: { id: 259, name: "NoData_dbMode", cacheName: "NoData_dbMode", mode: cacheOrDb.cacheMode, dependent: false },
        IO_InputFileColumns: { id: 260, name: "IO_InputFileColumns", cacheName: "IO_InputFileColumns", mode: cacheOrDb.dbMode, dependent: false },
        IO_SliderType: { id: 261, name: "IO_SliderType", cacheName: "IO_SliderType", mode: cacheOrDb.cacheMode, dependent: false },
        IO_salaryTables: { id: 262, name: 'IO_salaryTables', cacheName: "IO_salaryTables", mode: cacheOrDb.dbMode, dependent: false },
        IO_Table_fields: { id: 263, name: 'IO_Table_fields', cacheName: "IO_Table_fields", mode: cacheOrDb.dbMode, dependent: false },
        IO_FieldType: { id: 264, name: "IO_FieldType", cacheName: "IO_FieldType", mode: cacheOrDb.cacheMode, dependent: false },
        IO_SliderFilter: { id: 265, name: "IO_SliderFilter", cacheName: "IO_SliderFilter", mode: cacheOrDb.dbMode, dependent: false },
        ActivityType: { id: 266, name: "ActivityType", cacheName: "ActivityType", mode: cacheOrDb.cacheMode, dependent: false },
        OtpType: { id: 267, name: "OtpType", cacheName: "OtpType", mode: cacheOrDb.cacheMode, dependent: false, titleResId: 564 },
        //ProcsStatus: { id: 268, name: "ProcsStatusList", cacheName: "ProcsStatusList", mode: cacheOrDb.byCountMode, dependent: false }, // 26.08.2018
        Form101_DenyNotesList: { id: 269, name: "Form101_DenyNotesList", cacheName: "Form101_DenyNotesList", mode: cacheOrDb.cacheMode, dependent: false, titleResId: 4776 },
        ApprManagersToList: { id: 270, name: "ApprManagersToList", cacheName: "ApprManagersToList", mode: cacheOrDb.cacheMode, dependent: false },
        ApprManagerType: { id: 271, name: "ApprManagerType", cacheName: "ApprManagerType", mode: cacheOrDb.cacheMode, dependent: false },
        ApprManagerFilter: { id: 272, name: "ApprManagerFilter", cacheName: "ApprManagerFilter", mode: cacheOrDb.cacheMode, dependent: false },
        ApprManagerEmployees: { id: 273, name: "ApprManagerEmployees", cacheName: "ApprManagerEmployees", mode: cacheOrDb.cacheMode, dependent: false },
        ApprManagersFromList: { id: 274, name: "ApprManagersFromList", cacheName: "ApprManagersFromList", mode: cacheOrDb.cacheMode, dependent: false },
        IO_Table_fieldsExport: { id: 275, name: 'IO_Table_fieldsExport', cacheName: "IO_Table_fieldsExport", mode: cacheOrDb.dbMode, dependent: false },
        BudgetUpdEmp: { id: 276, name: "Budget", cacheName: "BudgetUpdEmp", mode: cacheOrDb.dbMode, dependent: false, titleResId: 2822 },
        BudgetUpdGrp: { id: 277, name: "Budget", cacheName: "BudgetUpdGrp", mode: cacheOrDb.dbMode, dependent: false, titleResId: 2822 },
        Form101CountriesList: { id: 278, name: "Form101Countries", cacheName: "Form101Countries", mode: cacheOrDb.dbMode, dependent: false },
        UserNotesListCodeDescr: { id: 279, name: "UserNotesListCodeDescr", cacheName: "UserNotesListCodeDescr", mode: cacheOrDb.cacheMode, dependent: false },
        ScreenFilterList: { id: 280, name: "ScreenFilterList", cacheName: "ScreenFilterList", mode: cacheOrDb.dbMode, dependent: false },
        SignDigitService: { id: 281, name: "SignDigitService", cacheName: "SignDigitService", mode: cacheOrDb.cacheMode, dependent: false },
        EmployeeActions: { id: 282, name: "EmployeeActions", cacheName: "EmployeeActions", mode: cacheOrDb.cacheMode, dependent: false },
        ProcessesList: { id: 283, name: "ProcessesList", cacheName: "ProcessesList", mode: cacheOrDb.cacheMode, dependent: false },
        StagesList: { id: 284, name: "StagesList", cacheName: "StagesList", mode: cacheOrDb.cacheMode, dependent: false }

        //last id is 283
    };

    hostPage = {
        employeesPage: { id: 1, name: "employeesPage" },
        attendancePage: { id: 2, name: "attendancePage" },
        weeklyPage: { id: 3, name: "weeklyPage" },
        dailyPage: { id: 4, name: "dailyPage" },
        approvingManagerPage: { id: 5, name: "approvingManagerPage" }
    };

    var languagesShortNames = {
        English: "en",
        English_USA: "en",
        עברית: "he",
        Français: "fr",
        Deutsch: "de",
        Netherlandish: "nl",
        Netherlandish_Français: "de",
        Español: "es",
        Magyar: "hu",
        Polski: "pl",
        Русский: "ru",
        Türk: "tr",
        中國的: "zh-CN",
    }

    var types = {
        string: "string",
        boolean: "boolean",
        date: "date",
        number: "number",
        time: "time",
    };

    var fieldType = {
        1: types.string,
        2: types.boolean,
        3: types.date,
        4: types.number,
        5: types.time,
    };

    var componentType = {
        edit: 0,
        combo: 1,
        comboAndLookup: 2,
        checkBox: 3,
        dateTime: 4,
        date: 5,
        time: 6,
        image: 7,
        color: 8

    };

    var OrgTreeLevelIcons = {
        6: imagesManager.man,//Emp
        1: imagesManager.orange_8,//Region
        2: imagesManager.orange_6,//Factory
        3: imagesManager.orange_4,//Section
        4: imagesManager.orange_2,//Dep
        5: imagesManager.orange_1,//WC
        7: imagesManager.men,       // empGrp
        11: imagesManager.filter_active1 //flaxible group
    };
    var OrgTreeLevel = {
        Emp: { id: 6, name: "emp" },//Emp
        Region: { id: 1, name: "Region" },//Region
        Factory: { id: 2, name: "Factory" },//Factory
        Section: { id: 3, name: "Section" },//Section
        Dep: { id: 4, name: "Dep" },//Dep
        WC: { id: 5, name: "WC" },//WC
    };
    formId = {
        3: { name: "SecurityGroup", iconFieldName: "LevelOrg", icons: OrgTreeLevelIcons },
        2: { name: "OrgLevel", iconFieldName: "OrgTreeLevel", icons: OrgTreeLevelIcons },
        1: { name: "Tel", iconFieldName: "OrgTreeLevel1", icons: OrgTreeLevelIcons },
    };

    selectionFrameFormId = {
        Tel: { id: 1 },
        OrgLevel: { id: 2 },
        SecurityGroup: { id: 3 },
        Computers: { id: 7 },
        Employees: { id: 17 },
        EmployeesQualification: { id: 32 },
        SchedQualifEmployees: { id: 31 },
        PermCostCenter: { id: 34 },
        PermSubCostCenter: { id: 35 },
        AttendanceInterface: { id: 36 }

    }

    var paymentRuleType = {
        callOn: { code: 1 },
        absence: { code: 2 },
        shift: { code: 3 },
        dayCons: { code: 4 }
    };

    var cacheMode = {
        COOKIE: { name: "cookie" },
        LOCAL_STORAGE: { name: "localStorage" },
        MEMORY_CACHE: { name: "memoryCache" }
    };

    var showPopupMode = {
        ForNew: { id: 1, name: "forNew" },
        ForUpdate: { id: 2, name: "forUpdate" },
        ForCopy: { id: 3, name: "forCopy" },
    };

    cacheItems = {
        logoutShellEventHasAlreadyBeenCatched: { name: "logoutShellEventHasAlreadyBeenCatched", cacheMode: cacheMode.MEMORY_CACHE },
        IsAfterReloadByCode: { name: "IsAfterReloadByCode", cacheMode: cacheMode.MEMORY_CACHE },
        ATTENDANCE_LAST_SORT_DEFINITIONS_FOR_TASK_POPUP: { name: 'LastSortDefinitionsForTaskPopup', cacheMode: cacheMode.LOCAL_STORAGE },
        USER: { name: "User", cacheMode: cacheMode.MEMORY_CACHE },
        MNG_DASHBOARD_PERMITIONS: { name: "mngDashboardsPremissions", cacheMode: cacheMode.MEMORY_CACHE },
        ELEMENTS_TO_HIDE: { name: "elementsToHide", cacheMode: cacheMode.MEMORY_CACHE },
        EMP_DASHBOARD_PERMITIONS: { name: "empDashboardsPremissions", cacheMode: cacheMode.MEMORY_CACHE },
        FORMS_ELEMENT_SHOW_TYPE: { name: "formsElementsShowType", cacheMode: cacheMode.MEMORY_CACHE },
        LOOKUPS: { name: "Lookups", cacheMode: cacheMode.MEMORY_CACHE },
        LOOKUPS_RECORDS_COUNT: { name: "LookupsRecordsCount", cacheMode: cacheMode.MEMORY_CACHE },
        LAYOUT: { name: "Layout", cacheMode: cacheMode.LOCAL_STORAGE },//TODO Note:only grid layout needs to be saved per user in localstorage
        LANGUAGE: { name: "Language", cacheMode: cacheMode.COOKIE },
        DICT: { name: "Dict", cacheMode: cacheMode.MEMORY_CACHE },
        DICTMSG: { name: "DictMessage", cacheMode: cacheMode.MEMORY_CACHE },
        TOOLTIPS: { name: "Tooltip", cacheMode: cacheMode.MEMORY_CACHE },
        LAST_LANGUAGE: { name: "LastLang", cacheMode: cacheMode.LOCAL_STORAGE },
        LANGUAGES_LIST: { name: "LanguagesList", isSystemParam: true, cacheMode: cacheMode.MEMORY_CACHE },
        CURCOMP: { name: "CurrentCompany", isSystemParam: true, cacheMode: cacheMode.MEMORY_CACHE },
        LASTCOMP: { name: "LastCompany", cacheMode: cacheMode.LOCAL_STORAGE },
        LAST_LOGIN_SCREEN: { name: "LastLoginScreen", cacheMode: cacheMode.MEMORY_CACHE },
        LAST_ORG_LEVEL_EMP: { name: "LastOrganizationLevelEmp", cacheMode: cacheMode.LOCAL_STORAGE },
        LAST_ORG_LEVEL_WEEKLY: { name: "LastOrganizationLevelWeekly", cacheMode: cacheMode.LOCAL_STORAGE },
        LAST_ORG_LEVEL_DAILY: { name: "LastOrganizationLevelDaily", cacheMode: cacheMode.LOCAL_STORAGE },
        LAST_ORG_LEVEL_APPR_MANAGER: { name: "LastOrganizationLevelApprManager", cacheMode: cacheMode.LOCAL_STORAGE },
        LAST_ORG_CODE_APPR_MANAGER: { name: "LastOrganizationCodeApprManager", cacheMode: cacheMode.LOCAL_STORAGE },
        LAST_STATUS_FILTER_EMP: { name: "LastStatusFilterEmp", cacheMode: cacheMode.LOCAL_STORAGE },
        LAST_STATUS_FILTER_PENDING_REP: { name: "lastStatusFilterMngPendingRep", cacheMode: cacheMode.LOCAL_STORAGE },
        LAST_VIEW_FILTER_MNG_APPR_REQ: { name: "lastViewFilterApprReq", cacheMode: cacheMode.LOCAL_STORAGE },
        LAST_ORG_LEVEL_ATT: { name: "LastOrganizationLevelAtt", cacheMode: cacheMode.LOCAL_STORAGE },
        LAST_STATUS_FILTER_ATT: { name: "LastStatusFilterAtt", cacheMode: cacheMode.LOCAL_STORAGE },
        LAST_VIEW_FILTER_ATT: { name: "LastViewFilterAtt", cacheMode: cacheMode.LOCAL_STORAGE },
        LAST_ABS_ATTEND_FILTER_ATT: { name: "LastAbsAttendFilterAtt", cacheMode: cacheMode.LOCAL_STORAGE },
        LAST_WORK_SCHEDULE_DAILY_SORT: { name: "lastWorkScheduleDailySort", cacheMode: cacheMode.LOCAL_STORAGE },
        LAST_WORK_SCHEDULE_DAILY_SHOW: { name: "lastWorkScheduleDailyShow", cacheMode: cacheMode.LOCAL_STORAGE },
        LAST_WORK_SCHEDULE_WEEKLY_DATE: { name: "lastWorkScheduleWeeklyDate", cacheMode: cacheMode.MEMORY_CACHE },
        LAST_USER: { name: "LastUser", cacheMode: cacheMode.LOCAL_STORAGE },
        COMPANY_PARAMS: { name: "companyParams", cacheMode: cacheMode.MEMORY_CACHE },
        CUSTOM_CONFIG: { name: "customConfigurations", cacheMode: cacheMode.MEMORY_CACHE, isSystemParam: true },
        COMPANY_PERMISSIONS: { name: "companyPermissions", cacheMode: cacheMode.MEMORY_CACHE },
        COMPANY_PREFERENCES: { name: "companyPreferences", cacheMode: cacheMode.MEMORY_CACHE },
        COMPANY_PREFERENCES_PERMISSIONS: { name: "companyPreferencesPermissions", cacheMode: cacheMode.MEMORY_CACHE },
        NOTIFIER_PARAMS: { name: "notifierParams", cacheMode: cacheMode.MEMORY_CACHE },
        NOTIFIER_EVENTTYPES_LIST: { name: "notifierEventTypes", cacheMode: cacheMode.MEMORY_CACHE },
        SESSION_ID: { name: "sessionId", cacheMode: cacheMode.MEMORY_CACHE, isSystemParam: true },
        SessionExpiryTime: { name: "sessionExpiryTime", cacheMode: cacheMode.MEMORY_CACHE },
        DATE_FORMAT: { name: "dateFormat", cacheMode: cacheMode.MEMORY_CACHE, isSystemParam: true },
        DATE_FORMAT_YYYYMM: { name: "dateFormat_YYYYMM", cacheMode: cacheMode.MEMORY_CACHE, isSystemParam: true }, // 02.01.2018
        DATE_WITHOUT_YEAR_FORMAT: { name: "dateWithoutYearFormat", cacheMode: cacheMode.MEMORY_CACHE, isSystemParam: true },
        CURRENCY_SYMBOL: { name: "currencySymbol", cacheMode: cacheMode.MEMORY_CACHE, isSystemParam: true },
        IS_SECTION_EXIST: { name: "isSectionExist", cacheMode: cacheMode.MEMORY_CACHE },
        IS_REGION_EXIST: { name: "isRegionExist", cacheMode: cacheMode.MEMORY_CACHE },
        IS_FACTORY_EXIST: { name: "isFactoryExist", cacheMode: cacheMode.MEMORY_CACHE },
        LOGO_MAIN: { name: "logoMain", cacheMode: cacheMode.MEMORY_CACHE },
        MAINTENANCE_LAST_VALUES: { name: 'maintenanceLastValues', cacheMode: cacheMode.LOCAL_STORAGE },
        MAINTENACNE_LAST_DISPLAY_WRAPPER_MODE: { name: 'maintenanceLastDisaplyWrapperMode', cacheMode: cacheMode.MEMORY_CACHE },
        CONTACT_TYPES: { name: "contactTypes", cacheMode: cacheMode.MEMORY_CACHE },
        USR_AUTO_APPROVE: { name: "UsrAutoApprove", cacheMode: cacheMode.MEMORY_CACHE },
        GRP_UPD_AUTO_APPROVE: { name: "GrpUpdAutoApprove", cacheMode: cacheMode.MEMORY_CACHE },
        GRID_LAYOUT: { name: "GridLayout", cacheMode: cacheMode.LOCAL_STORAGE },
        SPLITTER_LAYOUT: { name: "SplitterLayout", cacheMode: cacheMode.LOCAL_STORAGE },
        MESSAGE_LAYOUT: { name: "MessageLayout", cacheMode: cacheMode.LOCAL_STORAGE },
        LAST_DAILY_REPORTING_OPER: { name: "lastDailyReportingOper", cacheMode: cacheMode.LOCAL_STORAGE },
        LAST_DAILY_REPORTING_ACTION: { name: "lastDailyReportingAction", cacheMode: cacheMode.LOCAL_STORAGE },
        LAST_DAILY_REPORTING_MACHINE: { name: "lastDailyReportingMachine", cacheMode: cacheMode.LOCAL_STORAGE },
        LAST_DAILY_REPORTING_LEVEL: { name: "lastDailyReportingLevel", cacheMode: cacheMode.LOCAL_STORAGE },
        LAST_DAILY_REPORTING_BUDGET: { name: "lastDailyReportingBudget", cacheMode: cacheMode.LOCAL_STORAGE },
        LAST_DAILY_REPORTING_SUB_BUDGET: { name: "lastDailyReportingSubBudget", cacheMode: cacheMode.LOCAL_STORAGE },
        LAST_ATTENDANCE_ON_DUTY_CODES: { name: "lastAttendanceOnDutyCodes", cacheMode: cacheMode.LOCAL_STORAGE },
        LOGIN_DETAILS_COOKIE: { name: "LoginCookie", cacheMode: cacheMode.COOKIE },
        ReportParams: { name: 'reportParams', cacheMode: cacheMode.LOCAL_STORAGE },
        ADS_USER: { name: "ADSUser", cacheMode: cacheMode.LOCAL_STORAGE },
        LAST_FORM_101_MAIN_VALUES: { name: 'lastForm101MainValues', cacheMode: cacheMode.MEMORY_CACHE },
        FORM_101_YEARS_LIST: { name: "form101YearsList", cacheMode: cacheMode.MEMORY_CACHE },
        NEED_RETRIVE_COMPANY_DATA_AGAIN: { name: "needRetriveCompanyDataAgain", cacheMode: cacheMode.MEMORY_CACHE, isSystemParam: true },
        TASK_MOUDLE_SRC_TABLE_NAME: { name: "taskMoudleSrcTableName", cacheMode: cacheMode.MEMORY_CACHE },
        SALARY_IO_EXPORT_LAST_VALUES: { name: "salaryExportLastValues", cacheMode: cacheMode.LOCAL_STORAGE },
        ATTENDANCE_IO_EXPORT_LAST_VALUES: { name: "attendanceExportLastValues", cacheMode: cacheMode.LOCAL_STORAGE },
        LAST_RUN_REPORT_DLL_NO: { name: "lastRunReportDll", cacheMode: cacheMode.MEMORY_CACHE },
        ATTENDANCE_RUN_PROCESS: { name: "attendanceRunProcess", cacheMode: cacheMode.MEMORY_CACHE },
        LAST_DOCUMENT_TYPE: { name: "LastDocumentType", cacheMode: cacheMode.LOCAL_STORAGE },
        LAST_STATUS_FILTER_EMP_DOCUMENT: { name: "LastStatusFilterEmpDocument", cacheMode: cacheMode.LOCAL_STORAGE },
        SCREEN_PARAMS: { name: "screenParams", cacheMode: cacheMode.LOCAL_STORAGE },
        CURRENT_TAX_YEAR: { name: "currentTaxYear", cacheMode: cacheMode.MEMORY_CACHE },
        WEB_SITE_VERSION: { name: "VersionCookie", cacheMode: cacheMode.COOKIE },
        LOGOUT_HAS_OCCURED: { name: "LogoutHasOccured", cacheMode: cacheMode.LOCAL_STORAGE },
        EXIST_USER_SECURE_COOKIE: { name: "ExistUserSecureCookie", isSystemParam: true, cacheMode: cacheMode.MEMORY_CACHE },
        LAST_STATUS_FILTER_EMP_IN_101: { name: "LastStatusFilterEmpIn101", cacheMode: cacheMode.LOCAL_STORAGE },
        USER_HAS_PROFILE: { name: "UserHasProfile", cacheMode: cacheMode.LOCAL_STORAGE },
        LAST_START_DATE_EMP_ATTEND_MNG: { name: "LastStartDateEmpAttendMng", cacheMode: cacheMode.LOCAL_STORAGE },
	    LAST_END_DATE_EMP_ATTEND_MNG: { name: "LastEndDateEmpAttendMng", cacheMode: cacheMode.LOCAL_STORAGE },
	    HEADER_DISPLAY_MODE: { name: "LastHeaderDisplayMode", cacheMode: cacheMode.LOCAL_STORAGE },
	    REPORT_FMT: { name: "REPORT_FMT", cacheMode: cacheMode.MEMORY_CACHE },
        LAST_CREATED_INTERFACE: { name: "LAST_CREATED_INTERFACE", cacheMode: cacheMode.MEMORY_CACHE },
        COMPANY_ORG_TREE: { name: 'CompanyOrgTree', cacheMode: cacheMode.LOCAL_STORAGE },
        COMPANY_ORG_TREE_PB: { name: 'CompanyOrgTreePB', cacheMode: cacheMode.LOCAL_STORAGE },
        M_CLIENT_ID: { name: "ClientId", cacheMode: cacheMode.COOKIE },
        M_CLIENT_AGENT: { name: "ClientAgent", cacheMode: cacheMode.COOKIE },
    };

    permissionCodes = {
        SuperVisor: { code: 'SuperVisor' },
        NO_PERMISSION: { code: 'NoPermission' },
        ALWAYS_READ_ONLY: { code: 'AlwaysReadOnly' },
        ALWAYS_NOT_VISIBLE: { code: 'AlwaysNotVisible' },
        tabDailyPermissionCode: { code: 101620 },//8
        buttonPermissionCode: { code: 10530 },//3
        textPermissionCode: { code: 10210 },//1
        gridPermissionCode: { code: 10210 },//1
        grid2PermissionCode: { code: 101620 },//8
        cbDailyChangeTime: { code: 101620 },//1
        EMPLOYEE_PERMISSION: { code: 'G10200C10200' },
        EMPLOYEE_DATA: { code: 'G10200C10210' },
        EMPLOYEETAG_DATA: { code: 'G10200C10250' }, // Lyn 
        EMPLOYEE_DETAILS_TABS: { code: 'G111C17' },
        EMP_DETAILS_TAB: { code: 'G17C10' },
        EMP_CARDS_TAB: { code: 'G17C20' },
        EMP_HISTORY_TAB: { code: 'G17C60' },
        EMP_TASKS_TAB: { code: 'G17C30' },
        EMP_SECURITY_GROUP_TAB: { code: 'G17C40' },
        EMP_PHONE_TAB: { code: 'G17C50' },
        EMP_EMPLOYEES_FOR_APPROVAL_TAB: { code: 'G17C70' },
        EMP_APPROVING_MANAGERS_TAB: { code: 'G17C80' },
        EMP_COST_CENTER_TAB: { code: 'G17C100' },
        EMP_PERM_COST_CENTER_TAB: { code: 'G17C170' },
        EMP_PERM_SUB_COST_CENTER_TAB: { code: 'G17C180' },
        EMP_DOCUMENTS_TAB: { code: 'G17C120' },
        EMP_COMPUTERS_TAB: { code: 'G17C110' },
        EMP_QUALIFICATION_TAB: { code: 'G17C130' },
        EMP_TARIF_PAYROLL_TAB: { code: 'G17C160' },
        EMP_PAYROLL_DATA_TAB: { code: 'G17C150' },
        EMP_PREFERENCES_TAB: { code: 'G17C140' },
        EMP_POPUP: { code: 'G111C18' },
        EMP_POPUP_MAIN_TAB: { code: 'G18C10' },
        EMP_POPUP_DEFAULT_TAB: { code: 'G18C20' },
        EMP_POPUP_MISCELLANEOUS_TAB: { code: 'G18C30' },
        EMP_POPUP_ACCESSLEVEL_TAB: { code: 'G18C40' },
        EMP_POPUP_PERSONALDETAILS_TAB: { code: 'G18C50' },
        EMP_POPUP_CONTACTS_TAB: { code: 'G18C60' },
        EMP_POPUP_ACCESS_CONTROL_TAB: { code: 'G18C70' },
        EMP_DOCUMENTS: { code: 'G20140C4704' },
        
        FORMS_DIGITAL_DOCUMENTS_DEF: { code: 'G20140C5552' },

        MENU_HOME: { code: 'G20000C20100' },
        MENU_MANUAL_EDIT: { code: 'G10100C10100' },
        MENU_EMPLOYEES: { code: 'G10200C10200' },
        MENU_VISITORS: { code: 'G10500C10500' },
        MENU_COST_CENTER: { code: 'G5000C10632' },
        // === sidur avida, grp=10700 MENU_WORK_SCHEDULE ===
        MENU_WORK_SCHEDULE_MAIN: { code: 'G10700C10700' },
        MENU_WORK_SCHEDULE: { code: 'G10700C10056' },
        MENU_WORK_SCHED_EMP: { code: 'G10700C10701' },
        MENU_WORK_SCHED_PLAN_OT: { code: 'G10700C10702' }, // relevant if PlanOT=1

        MENU_REPORTS: { code: 'G10300C10300' },
        MENU_MAINTENANCE: { code: 'G10600C10600' },
        MENU_MEAL_COUPON: { code: 'G-2896C-2896' },
        //MENU_DOCUMENTS: { code: 'G20000C20140' },
        MENU_DOCUMENTS: { code: 'G20141C4747' }, //29/11/2015
        ATTENDANCE_DAILY_TAB: { code: 'G10100C10150' },
        ATTENDANCE_PERIOD_TAB: { code: 'G10100C10160' },
        ATTENDANCE_MANUAL_UPDATE: { code: 'G10100C10110' },
        ATTENDANCE_GROUP_UPDATE: { code: 'G10100C10130' },
        ATTENDANCE_DATA: { code: 'G10100C10100' },
        DAILY_REPORTING_ATTEND_IN: { code: 'G10000C10010' },
        DAILY_REPORTING_ATTEND_OUT: { code: 'G10000C10020' },
        DAILY_REPORTING_PROJECTS: { code: 'G10000C10030' },
        DAILY_REPORTING_COST_CENTER: { code: 'G10000C10040' },
        HOME_PAGE: { code: 'G20000C20100' },
        HOME_PAGE_ATTEND: { code: 'G20000C20110' },
        HOME_PAGE_DASHBOARDS: { code: 'G20000C20120' },
        HOME_PAGE_DASHBOARD_1: { code: 'G20000C4524' },
        HOME_PAGE_DASHBOARD_2: { code: 'G20000C4525' },
        HOME_PAGE_DASHBOARD_3: { code: 'G20000C4541' },
        HOME_PAGE_DASHBOARD_4: { code: 'G20000C4542' },

        HOME_PAGE_ACTIONS: { code: 'G20000C20130' },
        HOME_PAGE_ACTIONS_APPROVE_OT: { code: 'G20130C20131' },
        HOME_PAGE_ACTIONS_APPROVE_OT_BY_ACTUALTIME: { code: 'G20130C20132' },
        HOME_PAGE_ACTIONS_HR_PROCESS: { code: 'G20130C20133' },

        HOME_PAGE_DOCUMENTS: { code: 'G20000C20140' },
        HOME_PAGE_DOC_FORMS: { code: 'G20141C4747' },
        HOME_PAGE_DOC_REPORTS: { code: 'G20142C319' },
        HOME_PAGE_HOURS_DISTRIBUTION: { code: 'G20000C4524' },
        HOME_PAGE_REQUESTS_DISTRIBUTION: { code: 'G20000C4525' },
        HOME_PAGE_RECORDS_PENDING: { code: 'G20130C10120' },
        HOME_PAGE_REPORT_APPROVAL: { code: 'G10100C10140' },
        MAINTENANCE_REPROCESS: { code: 'G10600C10610' },
        MAINTENANCE_CLOSING_PERIOD: { code: 'G10600C10660' },
        MAINTENANCE_INTERFACE_PAYROL: { code: 'G10600C10620' },
        MAINTENANCE_IO_INTERFACE: { code: 'G10600C10640' },
        FORM_101_PERMISSION: { code: 'G20140C4418' },
        FORM_101_PAY_SLIP_PERMISSION: { code: 'G20140C4523' },
        DOCS_PAYROLL: { code: 'G20140C4523' },
        DOCS_FORM106: { code: 'G20140C4518' }, //not ready yet,24/02/2015; WI=13134
        //#region maintenance permissions
        WORK_RULES_MENU: { code: 'G4C4' },
        WORK_RULES_WORK_RULES: { code: 'G4C4000', selfCode: 4000 },
        WORK_RULES_PAY_CODE: { code: 'G4C4010', selfCode: 4010 },
        WORK_RULES_TIME_CLASS: { code: 'G4C4020', selfCode: 4020 },
        WORK_RULES_DAY_TYPE: { code: 'G4C4030' },
        WORK_RULES_CALENDAR: { code: 'G4C4040' },
        WORK_RULES_LAW_EVENTS: { code: 'G4C4050' },
        WORK_RULES_ABSENCES: { code: 'G4C4060' },
        WORK_RULES_BALANCE_TRACKING: { code: 'G4C310' },
        COMUNICATION_MENU: { code: 'G6C6' },
        COMUNICATION_PARAMETERS: { code: 'G6C900' },
        COMUNICATION_MAINTENANCE: { code: 'G6C901' },
        COMUNICATION_BUILD_SITE: { code: 'G6C902' },
        COMUNICATION_TERMINALS: { code: 'G6C903' },
        COMUNICATION_NOTIFIER: { code: 'G6C904' },
        GLOBAL_PARAMS_MENU: { code: 'G7C1200' },
        GLOBAL_PARAMS_GENERAL: { code: 'G7C1210' },
        GLOBAL_PARAMS_MODULES: { code: 'G7C1220' },
        GLOBAL_PARAMS_SECURITY: { code: 'G7C1230' },
        GLOBAL_PARAMS_PIP_DEFINITIONS: { code: 'G7C1240' },
        SYSTEM_DEFINITIONS_MENU: { code: 'G10600C10630' },
        SYSTEM_DEFINITIONS_USER_PROFILE: { code: 'G10630C10631' },
        // SYSTEM_DEFINITIONS_COST_CENTER: { code: 'G10630C10632' },       
        SYSTEM_DEFINITIONS_AUDIT: { code: 'G10630C10633' },
        SYSTEM_DEFINITIONS_ORGANIZATION: { code: 'G10630C10634' },
        SYSTEM_DEFINITIONS_MEALS: { code: 'G10630C10635' },
        SYSTEM_DEFINITIONS_APPROVINGMANAGER: { code: 'G10630C10636' },
        MAINTENANCE_SCHEDULING: { code: 'G10600C10650' },
        MAINTENANCE_SCHEDULING_QUALIFICATION: { code: 'G10650C10651' },
        MAINTENANCE_SCHEDULING_JOB_CODE: { code: 'G10650C10652' },
        SYSTEM_DEFINITIONS_SCHEDULER: { code: 'G10630C10635' },
        SYSTEM_DEFINITIONS_QUEUES: { code: 'G10630C10635' },
        MAINTENANCE_MENU_PAYROL: { code: 'G10600C10670' },
        MAINTENANCE_PAYROL_EMPLOYER_DETAILS: { code: 'G10670C10672' },
        MAINTENANCE_PAYROL_COMPANY_DETAILS: { code: 'G10670C10671' }
        //todo:add permission for systemSchedulers
        //#endregion

    };

    companyParamNames = {
        IsTaskModule: { name: "IsTaskModule" },
        Budget: { name: "Budget" },
        Meals: { name: 'MEALS' },
        ScheduleModuleIsActive: { name: "ScheduleModuleIsActive" },
        Balance: { name: "Balance" },
        DailyChangeDate: { name: "DailyChangeDate" },
        DailyChangeTime: { name: "DailyChangeTime" },
        IsSubBudget: { name: "IsSubBudget" },
        IsWebRepAppr: { name: "IsWebRepAppr" },
        IsRepApprByManagerOnly: { name: "IsRepApprByManagerOnly" },
        WebRepPeriodType: { name: "WebRepPeriodType" },
        RetroModuleIsActive: { name: "RetroModuleIsActive" },
        IsMngApprEmpRequestByList: { name: "isMngApprEmpRequestByList" },
        isMngApprEmpReportByList: { name: "isMngApprEmpReportByList" },
        SynergySystemDir: { name: "SynergySystemDir" },
        HiddenWebRep2Appr: { name: "hiddenWebRep2Appr" },
        IsExistCallOnCallDuty: { name: "IsExistCallOnCallDuty" },
        IsElectronicForm101: { name: "isElectronicForm101" },
        IsForm106: { name: "isForm106" },
        guid: { name: "GUID" },
        frmSchedule: { name: "frmSchedule" },
        frmEmployees: { name: "frmEmployees" },
        frmTags: { name: "frmTags" }, // 15.01.2018 not exist in companyparams so use default 
        frmManualEdit: { name: "frmManualEdit" },
        frmReProcEmpFailed: { name: "frmReProcEmpFailed" },
        CommIP: { name: "CommIP" },
        CommTIMEOUT: { name: "CommTIMEOUT" },
        CommPORT: { name: "CommPORT" },
        CommRETRYS: { name: "CommRETRYS" },
        SalaryPortalSupport: { name: "SalaryPortalSupport" },
        BudgetCalc: { name: "BudgetCalc" },
        ReportsCodesForWS: { name: "ReportsCodesForWS" },
        PayrollModule: { name: "PayrollModule" } // 02.05.2018 lyn for payroll
    };


    companyPreferencesNames = {
        SortDepartmentComboInEmployeePopupMainTabByName: { name: "SortDepartmentComboInEmployeePopupMainTabByName" },
        SortWCComboInEmployeePopupMainTabByName: { name: "SortWCComboInEmployeePopupMainTabByName" },
        SortWorkruleComboInEmployeePopupMainTabByName: { name: "SortWorkruleComboInEmployeePopupMainTabByName" },
        EnablePayrollIDInEmployeePopupPersonalDetailsTab: { name: "EnablePayrollIDInEmpPopupPersonalDetailsTab" },
        EnableTravelExpensesInEmpPopupPersonalDetailsTab: { name: "EnableTravelExpensesInEmpPopupPersonalDetailsTab" },
        EnableTransportationPaymentInEmpPersonalDetailsTab: { name: "EnableTransportationPaymentInEmpPersonalDetailsTab" },
        EnableEmpHourlyInEmployeePopupDataMainTab: { name: "EnableEmpHourlyInEmployeePopupDataMainTab" },
        alwaysReadOnly: { name: "AlwaysReadOnly" },
        DisplAttendEmpNotes: { name: "DisplAttendEmpNotes" },
        DisplAttendRoundTimes: { name: "DisplAttendRoundTimes" },
        DisplAttendClnStandardTotalTime: { name: "DisplAttendClnStandardTotalTime" },
        DisplAttendUpdateStatus: { name: "DisplAttendUpdateStatus" },
        DisplAttendInOutTypes: { name: "DisplAttendInOutTypes" },
        DisplAttendClnAbsence: { name: "DisplAttendClnAbsence" },
        DisplAttendClnException: { name: "DisplAttendClnException" },
        DisplAttendClnBudget: { name: "DisplAttendClnBudget" },
        EnableEditAttenInOut: { name: "EnableEditAttenInOut" },
        EnableEditMissingAttendInOut: { name: "EnableEditMissingAttendInOut" },
        DefaultGridPageSize: { name: "DefaultGridPageSize" },
        AttendNotesFieldIsRequired: { name: "AttendNotesFieldIsRequired" },
        isEmpGrpRequired: { name: "isEmpGrpRequired" },
        isEmpPermGrpRequired: { name: "isEmpPermGrpRequired" },
        GrdMngApprDisplRegion: { name: "GrdMngApprDisplRegion" },
        LogOutExternalLink: { name: 'LogOutExternalLink' },
        ReportHideFormatPDF: { name: 'ReportHideFormatPDF' },
        ReportHideFormatExcel: { name: 'ReportHideFormatExcel' },
        ReportHideFormatHTML: { name: 'ReportHideFormatHTML' },
        StartScreen: { name: 'StartScreen' },
        AttendanceCostSenterRequires: { name: 'AttendCostCenterFieldIsRequired' },
        AttendanceSubCostSenterRequires: { name: 'AttendSubCostCenterFieldIsRequired' },      
        DateFormat: { name: 'DateFormat' },
        DisableDeleteInEmpScreen: { name: 'DisableDeleteInEmpScreen' },
        DisableDeleteInEmpScreenSystemAdmin: { name: 'DisableDeleteInEmpScreenSystemAdmin' },
        DisplAttendWorkSchedule: { name: 'DisplAttendWorkSchedule' }
    };

    accessType = {
        readonly: { code: 1 },
        autoApproval: { code: 10 },
        visible: { code: 8 },
        notVisible: { code: 3 },
        managerApproval: { code: 14 },
        managerApprovalReadOnly: { code: 15 }
    };

    selfOnlyState = {
        SelfOnlyVisible: { id: 1, name: "selfOnlyVisible" },
        SelfOnlyReadonly: { id: 2, name: "selfOnlyReadonly" }
    };

    cssPath = {
        RtlHarmonyCss: { path: "/Content/harmony-rtl.css" },
        RtlResponsiveCss: { path: "/Content/bootstrap-responsive-rtl.min.css" },
        RtlCss: { path: "/Content/bootstrap-rtl.min.css" },
        LtrHarmonyCss: { path: "/Content/harmony.css" },
        LtrResponsiveCss: { path: "/Content/bootstrap-responsive.min.css" },
        LtrCss: { path: "/Content/bootstrap.min.css" }
    };

    SystemUsers = {
        WebUser: { code: 9999 }
    };

    errorSender = {
        SERVER: { name: "Server" },
        CLIENT: { name: "Client" }
    };

    langType = {
        Main: { id: 1, name: "Main" },
        Sub: { id: 2, name: "Sub" }
    };

    configParams = {
        MAIN_CHARSET: { name: "MainCharset" },
        LANGUAGE: { name: "lang" },
        IS_PORTAL: { name: "isPortal" },
        HELP_PATH: { name: "helpPath" },
        LOGO_PATH: { name: "logoPath" },
        EXPIRE_SESSION_TIME: { name: "ExpiryTime" },
        SAVE_LAYOUT: { name: "saveLayout" },
        BILLING_SERVER: { name: "billingServer" },
        LOG_PATH: { name: "harmonySrvLogPath " },
        RESPONSE_COMP_OF_PORTAL: { name: "responseCompanyOfPortal" },
        MODE_OF_RUNNING_APP: { name: "modeOfRunningApp" },
        EHARMONY_DOCS_PATH: { name: "eHarmonyDocsPath" },
        ISL_DOWNLOAD_URL: { name: "ISLDownloadURL" },
        REPORT_URL_PATH: { name: "ReportServerLocation" },
        REPORT_CODES_WS: { name: "ReportsCodesForWS" },
        REPORT_WS_URL: { name: "ReportsWSUrl" },
        WEB_CONTAINS_101: { name: "WebContains101" }
    };

    events = {
        CURRENT_CALENDAR_TYPE_HAS_BEEN_DELETED: { name: "currentCalendarTypeHasBennDeleted" },
        NEW_CALENDAR_TYPE_HAS_BEEN_ADDED: { name: "newCalendarTypeHesBeenAdded" },
        LOGOUT_SHELL: { name: "logoutFromShell" },
        REMOVE_SESSION: { name: "removeSession" },
        EXPIRE_SESSION: { name: "expireSession" },
        FORM101_UPDATE_END: { name: 'form101UpdateEnd' },
        PROCESS: { name: "process" },
        SELECT_FOLDER_TREE_NODE: { name: "selectFolderTreeNode" },
        ERROR_IN_EMPLOYEE_SAVING: { name: "errorInEmployeeSaving" },
        SAVE_EMPLOYEE_START: { name: "saveEmployeeStart" },
        SAVE_EMPLOYEE_FINISHED: { name: "saveEmployeeFinished" },
        SAVE_EMPLOYEE_DETAILS_TABS_FINISHED: { name: "saveEmployeeFinished" },
        ERROR_IN_ATTENDANCE_SAVING: { name: "errorInConsecutiveAbsenceSaving" },
        SAVE_CONSECUTIVE_ABSENCE_START: { name: "saveConsecutiveAbsenceStart" },
        SAVE_CONSECUTIVE_ABSENCE_FINISHED: { name: "saveConsecutiveAbsenceFinished" },
        SAVE_SICK_PAY_FINISHED: { name: "saveSickPayFinished" },
        SAVE_CONSECUTIVE_ABSENCE_DETAILS_TABS_FINISHED: { name: "saveConsecutiveAbsenceFinished" },
        ERROR_IN_CONSECUTIVE_ABSENCE_SAVING: { name: "errorInAttendanceSaving" },
        SAVE_CONSECUTIVE_ABSENCE_DETAILS_TABS_FINISHED: { name: "saveATTENDANCEFinished" },
        CHANGE_REPORT_SELECTIONFRAME_VISIBILITY: { name: "changeReportSelectionFrameVisibility" },
        ERROR_IN_ATTENDANCE_SAVING: { name: "errorInAttendanceSaving" },
        SAVE_ATTENDANCE_START: { name: "saveAttendanceStart" },
        SAVE_ATTENDANCE_FINISHED: { name: "saveAttendanceFinished" },
        SAVE_ATTENDANCE_DETAILS_TABS_FINISHED: { name: "saveAttendanceFinished" },
        ERROR_IN_ATTENDANCE_SAVING: { name: "errorInAttendanceSaving" },
        SAVE_ATTENDANCE_DETAILS_TABS_FINISHED: { name: "saveATTENDANCEFinished" },
        START_WHITE_TO_COMPANY_ID: { name: "startWithToCompanyId" },
        START_WHITE_TO_USER_ID_AND_PASSWORD: { name: "startWhiteToUserIdAndPassword" },
        CHANGE_ACTION_BUTTON_PERMISSION: { name: "changeActionStackButtonPermission" },
        REPORT_HAS_BEEN_SELECTED: { name: "ReportHasBeenSelected" },
        SCHEDULER_REPORT_HAS_BEEN_SELECTED: { name: "SchedulerReportHasBeenSelected" },
        REPORT_CUSTOMIZE_HAS_BEEN_SELECTED: { name: "ReportCustomizeHasBeenSelected" },
        REPORT_CUSTOMIZE_GRID_DATASOURCE_CHANGED: { name: "ReportCustomizeGridDataSourceChanged" },
        REPORT_CUSTOMIZE_CLOSE: { name: 'ReportCustomizeClose' },
        REPORT_VIEW_BTN_CLICKED: { name: 'ReportViewBtnClicked' },
        UPDATE_SPECIFIC_WIDTH_LIMIT: { name: 'UpdateSpecifiWidthLimit' },
        SAVE_COLUMN_GRID_UPDATE: { name: 'SaveColumnAndGridUpdate' },
        REPORT_PAGE_ORIENTATION_CHANGED: { name: "ReportPageOrientationChanged" },
        REPORT_SHOW_PERIOD_TOTAL: { name: "ReportShowPeriodTotals" },
        REPORT_SHOW_COSTCENTER_TOTAL: { name: "ReportShowCostCentersTotals" },
        REPORT_BUDGET_HAS_BEEN_CHANGED: {name: "BudgetHasBeenChangedForSubBudget"},
        CALL_PROCESSING: { name: "CallProcessing" },
        MAINTENANCE_PROCESS_HAS_BEEN_SELECTED: { name: "MaintenanceProcessHasBeenSelected" },
        DISABLE_CONTROLS: { name: "disableControls" },
        EMPLOYEE_LIST_HAS_BEEN_CHANGED: { name: "employeeListHasBeenChanged" },
        CALL_PROCESSING_HAS_FINISHED: { name: "callProcessingHasFinished" },
        CALL_ATTEND_PERIOD_PROCESSING_HAS_FINISHED: { name: "callAttendPeriodProcessingHasFinished" },
        PROCESS_ENDED: { name: "ProcessEnded" },
        NEED_REFRESH_GRID: { name: 'needRefreshGrid' },
        REFRESH_DASHBOARDS: { name: 'RefreshDashboard' },
        ATTENDACE_DELETE_PROCESS_ENDED: { name: 'attendanceDeleteProcessEnded' },
        ATTENDACE_GLOBAL_UPDATE_PROCESS_ENDED: { name: 'attendanceGlobalUpdateProcessEnded' },
        ATTENDACE_PROCESS_ENDED: { name: 'attendanceProcessEnded' },
        SAVE_CANCEL_FORM101: { name: 'saveCancelForm101' },
        CANCEL_FORM101: { name: 'cancelForm101' },
        SAVE_EMPLOYEE_HISTORY_CHANGES_FINISHED: { name: "saveEmployeeHistoryChangesFinished" },
        SAVE_PAY_CODE_FINISHED: { name: "savePayCodeFinished" },
        SAVE_DAY_TYPE_FINISHED: { name: "saveDayTypeFinished" },
        SAVE_DISTRIBUTION_LIST_FINISHED: { name: "saveDistributionListFinished" },
        SAVE_CONTROLLLER_SCHEDULER: { name: "saveControllerScheduler" },
        SAVE_DEVICE: { name: "saveDevice" },
        SAVE_CONSECUTIVE_ABSENCE_FINISH: { name: "saveConsecutiveAbsenceFinished" },
        SAVE_TIME_CLASSIFICATION_FINISHED: { name: "saveTimeClassificationFinished" },
        SAVE_TEMPLATE_DEFINITION_FINISHED: { name: "saveTemplateDefinitionFinished" },
        SAVE_JOB_CODE_FINISHED: { name: "saveJobCodeFinished" },
        SAVE_GLOBALPARAMS_SECURITY_DATA: { name: "saveGlobalParamsSecurityForce" },
        ON_ROUTE: { name: "onRoute" },
        BACK_FROM_EMP_REQUEST_CHILD_TO_PARENT: { name: "backFromRmpRequestChildToParent" },
        BACK_FROM_OVERTIME_WORK_CHILD_TO_PARENT: { name: "backFromOvertimeWorkChildToParent" },
        BACK_FROM_DISTRIBUTION_LIST_DETAILS_TO_DISTRIBUTION_LIST: { name: "backFromDistributionListDetailsToDistributionList" },
        BACK_FROM_IO_interfaces_LIST_DETAILS_TO_IO_interfaces_LIST: { name: "backFromDistributionListDetailsToDistributionList" },
        EMP_REQUEST_PARENT_PERIOD_PROCESS_CALLED: { name: "empRequsetParentPeriodProcessCalled" },
        RFRESH_CARDS_GRID: { name: "refreshCardsGrid" },
        SAVE_MAINTENANCE_CONTROLLER_POPUP_SUCCEEDED: { name: "saveMaintenanceControllerPopupSucceeded" },
        SAVE_TERMINAL_CONTROLLER_POPUP_SUCCEEDED: { name: "saveTerminalControllerPopupSucceeded" },
        BACK_FROM_CALENDAR_DETAILS_TO_CALENDAR_LIST: { name: "backFromCalendarDetailsToCalendarList" },
        BACK_FROM_WORKRULES_DETAILS_TO_WORKRULES_LIST: { name: "backFromWorkRulesDetailsToWorkRulesList" },
        BACK_FROM_SECURITYGROUP_DETAILS_TO_SECURITYGROUP_LIST: { name: "backFromSecurityGroupDetailsToSecurityGroupList" },
        BACK_FROM_DISTRIBUTION_DETAILS_TO_DISTRIBUTION_LIST: { name: "backFromDistributionDetailsToDistributionList" },
        UPDATE_CONTROLLER_STATUS: { name: 'updateControllerStatus' },
        SUBSCRIBE_NOTIFIER_ALERT: { name: 'subscribeNotifierAlert' },
        WORK_RULE_POPUP_SAVE_STATUS: { name: 'workRulePopupSaveStatus' },      
        WORK_RULE_POPUP_SAVE: { name: 'workRulePopupSave' },
        SAVE_IO_FINISHED: { name: "saveIOFinished" },
        REFRESH_REPORT_SELECTION_FRAME_DATA: { name: "refreshSFData" },
        SAVE_QUEUES_PARAMETERS_FINISHED: { name: "saveQueuesParametersFinish" },
        SAVE_IMPORT_FLD_FINISHED: { name: "saveImportFldFinished" },
        SAVE_INTERFACE_TYPE: { name: "saveInterfaceType" },
        UPDATE_SEARCH_FILTERS: { name: "updateSearchFilters" },
        FORCED_SESSION_LOGOUT: { name: "forcedSessionLogout" },
        HOMEPAGE_DATE_PERIOD_CHANGE: { name: "homepageDatePeriodChange" },
        HOMEPAGE_DATE_SCHEDULAR_PERIOD_CHANGE: { name:"homepageSchedularDatePeriodChange"}
    };

    loginError = {
        None: { id: 0, name: "None" },
        Error: { id: 1, name: "Error" },
        ResetPassword: { id: 2, name: "ResetPassword" },
        ChooseProfile: { id: 3, name: "ChooseProfile" },
        BackToPortal: { id: 4, name: "BackToPortal" }
    };

    entityStateIndicator =
    {
        nothingModify: { name: "nothingModify", id: 0 },
        onlyEntityModify: { name: "onlyEntityModify", id: 1 },
        arrayAndEntityModify: { name: "arrayAndEntityModify", id: 2 },
        onlyArrayModify: { name: "onlyArrayModify", id: 3 }

    };

    exportFileType = {
        XML: { id: 0 },
        EXL: { id: 1 },
        CSV: { id: 2 },
        PDF: { id: 3 },
        CSV_REPORT: { id: 4 },
        CSV_TO_SACHAR_PAST: { id: 5 },
        CSV_TO_SACHAR_FUTURE: { id: 6 },
        CSV_TO_SACHARMAIN: { id: 999 },
        EXL_DICT: { id: 7 }
    };

    sendEmailType = {
    	SelectedEmp: { id: 0 },
    	AllEmp: { id: 1 }
    };

	statusForm101Type = {
    	ElectronicForm : { id: 0 },
		ManualForm: { id: 1 }
    };

	var httpPath = {
		GeneralUpdate: { path: 'Common/GeneralUpdate' },
		GeneralInsert: { path: 'Common/GeneralInsert' },
		GeneralInsertMultiple: { path: 'Common/GeneralInsertMultiple' },
		AbsenceListAndLookup: { path: "Attendance/GetAbsenceListAndLookup" },
		AddNewAgreement: { path: "WorkRules/AddNewAgreement" },
		AddNewWorkRuleBlock: { path: "WorkRules/AddNewWorkRuleBlock" },
		Attendance: { path: "Attendance/GetAttendance" },
		GetDefaultPeriodTime: { path: "Attendance/GetDefaultPeriodTime" },
		AttendanceCostCenter: { path: "AttendanceDetails/GetAttendanceCostCenter" },
		AttendanceDailyCostCenter: { path: "AttendanceDetails/GetAttendanceDailyCostCenter" },
		AttendanceDailyPeriodCostCenter: { path: "AttendanceDetails/GetAttendanceDailyPeriodCostCenter" },
		AttendanceDailyPayTotals: { path: "AttendanceDetails/GetAttendanceDailyPayTotals" },
		AttendanceDailyPeriodPayHandly: { path: "AttendanceDetails/GetAttendanceDailyPeriodPayHandly" },
		GetIsClosedPeriod: { path: "AttendanceDetails/GetIsClosedPeriod" },
		AttendanceGetDefaultTimesForNewTask: { path: "Attendance/GetDefaultTimesForNewTask" },
		AttendanceOTPeriodPay: { path: "AttendanceDetails/GetEmpOTPeriodPay" },
		AttendancePeriodCostCenter: { path: "AttendanceDetails/GetAttendancePeriodCostCenter" },
		CreateTempEmpTblForPeriodUpd: { path: "AttendanceDetails/CreateTempEmpTblForPeriodUpd" },
		SaveHandlyDailyPeriod: { path: "AttendanceDetails/SaveHandlyDailyPeriodFromGrid" },
		SaveHandlyDailyPeriodCostCenter: { path: "AttendanceDetails/SaveHandlyDailyPeriodCostCenterFromGrid" },// by ActionName
		UpdatePeriodBudgetProcess: { path: "AttendanceDetails/UpdatePeriodBudgetProcess" },
		DeleteHandlyDailyPeriod: { path: "AttendanceDetails/DeleteHandlyDailyPeriodFromGrid" },
		DeleteHandlyDailyPeriodCostCenter: { path: "AttendanceDetails/DeleteHandlyDailyPeriodCostCenterFromGrid" },// by ActionName

		AttendancePeriodPayTotals: { path: "AttendanceDetails/GetAttendancePeriodPayTotals" },
		GetPermListTimeClassParams: { path: "AttendanceDetails/GetPermListTimeClassParams" },
		GetPermListPayCode: { path: "AttendanceDetails/GetPermListPayCode" },
		PostAttendanceAttachment: { path: "Attendance/PostAttendanceAttachment" },
		UpdateAttendanceAttachment: { path: "Attendance/UpdateAttendanceAttachment" },
		DeleteAttachmentsByAbsence: { path: "Attendance/DeleteAttachmentsByAbsence" },
		AttendanceTaskByNumerator: { path: "Attendance/GetTaskByNumerator" },
		//------ 10/05/2018 :start ---
		GetDailySwipeForRebuild: { path: "Attendance/GetDailySwipeForRebuild" },
		SaveDailySwapForRebuild: { path: "Attendance/SaveDailySwipeForRebuild" },
		DeleteDailySwapForRebuild: { path: "Attendance/DeleteDailySwipeForRebuild" },
		//------ 10/05/2018 :end ---
		AttendanceTotalsBalance: { path: "AttendanceDetails/GetTotalsBalance" },

		GetBalanceEmpByAbsCode: { path: "Attendance/GetBalanceEmpByAbsCode" },
		GetBalanceTblEmpByAbsCode: { path: "Attendance/GetBalanceTblEmpByAbsCode" },
		AttendanceMovement: { path: "AttendanceDetails/GetAttendanceMovementList" },
		AttendanceDailyReportingWeb: { path: "DailyReporting/AttendanceDailyReportingCalcWeb" },
		AttendanceProcess: { path: "Attendance/AttendanceProcess" },
		AttendanceProcessSend2Queue: { path: "Attendance/AttendanceProcessSend2Queue" },
		AttendanceMeals: { path: "AttendanceDetails/AttendanceMeals" },
		ChangePassword: { path: "login/ChangePassword" },
		CheckCardNo: { path: "EmployeeDetails/CheckCardNo" },    
		CheckDailyReportingMovement: { path: "DailyReporting/CheckDailyReportingMovement" },
		CheckDailyReportingTableNames: { path: "DailyReporting/CheckDailyReportingTableNames" },
		CheckExistControllerCode: { path: "Communication/CheckExistControllerCode" },
		CheckAutoTagID: { path: "Communication/CheckAutoTagID" },
		CheckIfHasSubBudget: { path: "Attendance/CheckIfHasSubBudget" },
		CheckProcessEnded: { path: 'Attendance/CheckProcessEnded' },
		CheckKeyValInTable: { path: "Common/CheckKeyValInTable" },
		CheckMadanAlert: { path: "Attendance/CheckMadanAlert" },
		CheckBalanceAlert: { path: "Attendance/CheckBalanceAlert" },
		CheckAbsenceTypeAlert: { path: "Attendance/CheckAbsenceTypeAlert" },
		CheckEmployeeHistory: { path: "EmployeeDetails/CheckEmployeeHistory" },
		CheckFileOrDirExistByMapPath: { path: "Export/CheckFileOrDirExistByMapPath" },
		CheckExistMadan: { path: "GlobalParameters/CheckExistMadan" },
		ConnectToCompanyFromPortal: { path: "login/ConnectToCompanyFromPortal" },
		ConnectToCompanyCaseInHouse: { path: "login/ConnectToCompanyCaseInHouse" },
		CopyCalendarToNextYear: { path: "WorkRules/CopyCalendarToNextYear" },
		CopyAgreement: { path: "WorkRules/CopyAgreement" },
		CopyLawEvent: { path: "WorkRules/CopyLawEvent" },
		CreateCalendarsToTheNewYear: { path: "WorkRules/CreateCalendarsToTheNewYear" },
		CostCenterDailyReportingWeb: { path: "DailyReporting/CostCenterDailyReportingCalcWeb" },
		DeleteAgreement: { path: "WorkRules/DeleteAgreement" },
		DeleteAssignedSecurityGroup: { path: 'AccessControl/DeleteAssignedSecurityGroup' },
		DeleteAttendance: { path: "Attendance/DeleteAttendanceFromGrid" },
		DeleteEmployeeTelForReport: { path: "EmployeeDetails/DeleteEmployeeTelForReport" },
		DeleteEmployees: { path: "Employee/DeleteEmployees" },
		DeleteEmployeeForApprovalAndApprovingManger: { path: "EmployeeDetails/DeleteEmployeeForApprovalAndApprovingManger" },
		DeleteEmployeeCards: { path: "EmployeeDetails/DeleteEmployeeCards" },
		DeleteEmployeeComputers: { path: "EmployeeDetails/DeleteEmployeeComputers" },
		DeleteEmployeeHistories: { path: "EmployeeDetails/DeleteEmployeeHistories" },
		DeleteEmployeeSecurityGroup: { path: "EmployeeDetails/DeleteEmployeeSecurityGroup" },
		DeleteSecurityGroup: { path: "AccessControl/DeleteSecurityGroup" },
		DeleteUserProfile: { path: "SystemSettings/DeleteUserProfile" },
		DeleteTimeClassificationItem: { path: "WorkRules/DeleteTimeClassificationItem" },
		DeleteTimeClassificationQuotaCategItem: { path: "WorkRules/DeleteTimeClassificationQuotaCategItem" },
		DeleteBalanceTracking: { path: "WorkRules/DeleteBalanceTracking" },
		DeleteTerminals: { path: "Communication/DeleteTerminals" },
		DeleteDevices: { path: "Communication/DeleteDevices" },
		DeleteLawEvent: { path: "WorkRules/DeleteLawEvent" },
		DeleteWorkRuleBlock: { path: "WorkRules/DeleteWorkRuleBlock" },
		DeleteCompPreferencesParams: { path: "GlobalParameters//DeleteCompPreferencesParams" },
		SaveDistributionListDetails: { path: "AccessControl/SaveDistributionListDetails" },
		UpdateDistributionListDetails: { path: "AccessControl/UpdateDistributionListDetails" },
		DropTable: { path: 'Common/DropTable' },
		GetDeviceDataAndControlsList: { path: "Communication/GetDeviceDataAndControlsList" },
		DvcDefDescriptsByCodes: { path: "Attendance/GetDvcDefDescriptsByCodes" },
		GetActivityReportingDetails: { path: "Attendance/GetActivityReportingDetails" },
		Employees: { path: "Employee/GetEmployees" },
		EmployeeTags: { path: "EmployeeTags/GetEmployeeTags" }, // Lyn        
		EmployeeApprovingManagers: { path: "EmployeeDetails/GetEmployeeApprovingManagers" },
		EmployeeCards: { path: "EmployeeDetails/GetEmployeeCards" },
		EmployeeDetails: { path: "EmployeeDetails/GetEmployeeDetails" },
		GetEmpMealLabel: { path: "EmployeeDetails/GetEmpMealLabel" },
		UpdateEmpMealLabel: { path: "EmployeeDetails/UpdateEmpMealLabel" },
		EmployeeContactData: { path: "Employee/GetEmployeeContactData" },
		ResetPwdProcOneEmp: { path: "Employee/ResetPwdProcOneEmp" },
		EmployeeEmployeesForApproval: { path: "EmployeeDetails/GetEmployeeEmployeesForApproval" },
		EmployeeHistory: { path: "EmployeeDetails/GetEmployeeHistory" },
		EmployeeCostCenter: { path: "EmployeeDetails/GetEmployeeCostCenter" },
		EmployeePermCostCenter: { path: "EmployeeDetails/EmployeePermCostCenter" },
		SaveEmployeePermCostCenter: { path: "EmployeeDetails/SaveEmployeePermCostCenter" },
		DeletePermCostCenter: { path: "EmployeeDetails/DeletePermCostCenter" },
		EmployeePermSubCostCenter: { path: "EmployeeDetails/EmployeePermSubCostCenter" },
		SaveEmployeePermSubCostCenter: { path: "EmployeeDetails/SaveEmployeePermSubCostCenter" },
		DeletePermSubCostCenter: { path: "EmployeeDetails/DeletePermSubCostCenter" },
		CheckIfHasBudget: { path: "EmployeeDetails/CheckIfHasBudget" },
		CheckIfHasPermSubBudget: { path: "EmployeeDetails/CheckIfHasPermSubBudget" },
		checkEmployeeIfSuperUser: { path: "EmployeeDetails/checkEmployeeIfSuperUser" },
		EmployeeAttachment: { path: "EmployeeDetails/GetEmployeeAttachment" },
		EmployeeQualifications: { path: "EmployeeDetails/GetEmployeeQualifications" },
		UpdateEmployeeQualifications: { path: "EmployeeDetails/UpdateEmployeeQualifications" },
		GetEmployeeTarifPayroll: { path: "EmployeeDetails/GetEmployeeTarifPayroll" },
		GetEmployeePayrollData: { path: "EmployeeDetails/GetEmployeePayrollData" },
		UpdateEmployeeTarifPayroll: { path: "EmployeeDetails/UpdateEmployeeTarifPayroll" },
		UpdateEmployeePayrollData: { path: "EmployeeDetails/UpdateEmployeePayrollData" },
		GetEmpFutureSchedQualifications: { path: "EmployeeDetails/GetEmpFutureSchedQualifications" },
		GetMaintSchedEmpFutureSchedQualifications: { path: "Scheduling/GetMaintSchedEmpFutureSchedQualifications" },
		PostEmployeeAttachment: { path: "EmployeeDetails/PostEmployeeAttachment" },		
		DeleteEmployeeAttachment: { path: "EmployeeDetails/DeleteEmployeeAttachment" },
		UpdateEmployeeCostCenter: { path: "EmployeeDetails/UpdateEmployeeCostCenter" },
		EmployeeComputers: { path: "EmployeeDetails/GetEmployeeComputers" },
		EmployeeSecurityGroup: { path: "EmployeeDetails/GetEmployeeSecurityGroup" },
		EmployeeTelForReport: { path: "EmployeeDetails/GetEmployeeTelForReport" },
		ETableInformation: { path: "ETable/GetETableInfo" },
		ETableExecUnknownProcedure: { path: 'ETable/ETableExecUnknownProcedure' },
		ExportGridToExcel: { path: "Export/ExportGridToExcel" },
		ExportGridToPDF: { path: "Export/ExportGridToPDF" },
		ExportForm101Pdf: { path: "Form101/ExportForm101Pdf" },
		GetAttachmentsByAbsenceData: { path: "Attendance/GetAttachmentsByAbsence" },
		GetAttachmentsByMngData: { path: "EmployeeDetails/GetAttachmentsByMng" },
		CheckIfDigitalDocs: { path: "EmployeeDetails/CheckIfDigitalDocs" },
		GetBalanceRule: { path: 'WorkRules/GetBalanceRule' },
		GetPPayRule: { path: 'WorkRules/GetPPayRule' },
		GetCycle: { path: 'WorkRules/GetCycle' },
		GetForm101CompareVersions: { path: 'Form101/GetForm101CompareVersions' },
		GetNextPrimaryKeyForETable: { path: 'ETable/GetNextPrimaryKeyForETable' },//etable need other function from other places becouse its data is dynamic
		GetNextPrimaryKeyInTable: { path: 'Common/GetNextPrimaryKeyInTable' },
		GetOrgItemDetails: { path: 'AccessControl/GetOrgItemDetails' },
		GetOrgItemDetailsAndDirectDescendants: { path: 'AccessControl/GetOrgItemDetailsAndDirectDescendants' },
		GetPortalOtp: { path: 'GlobalParameters/GetPortalOtp' },
		CheckIsraelFormsEnabled: { path: 'GlobalParameters/CheckIsraelFormsEnabled' },
		GetLookupsCount: { path: 'Lookup/GetLookupsCount' },
		GetWorkRuleData: { path: 'WorkRules/GetWorkRuleData' },
		GetNewAgrNo: { path: 'WorkRules/GetNewAgrNo' },
		GetNewLawEventNo: { path: 'WorkRules/GetNewLawEventNo' },
		GetLawEvent: { path: 'WorkRules/GetLawEvent' },
		GetLawEventDistributionList: { path: 'WorkRules/GetLawEventDistributionList' },
		GetLawEventEmployeesByGroup: { path: 'WorkRules/GetLawEventEmployeesByGroup' },
		GetLawEventEmployeesByDistribution: { path: 'WorkRules/GetLawEventEmployeesByDistribution' },
		GetPermGroupItems: { path: 'SystemSettings/GetPermGroupItems' },
		GetNewPermGroupNo: { path: 'SystemSettings/GetNewPermGroupNo' },
		GetSecurityGroupsForOrgItem: { path: 'AccessControl/GetSecurityGroupsForOrgItem' },
		IsNewEmp: { path: "Login/IsNewEmp" },
		SaveForm101Pdf: { path: "Form101/SaveForm101Pdf" },
		SaveCalendarAs: { path: "WorkRules/SaveCalendarAs" },
		SaveLawEvent: { path: "WorkRules/SaveLawEvent" },
		SaveWorkRule: { path: "WorkRules/SaveWorkRule" },
		GetWorkRuleSpeceificParamVal: { path: "WorkRules/GetWorkRuleSpeceificParamVal" },
		SaveAssignedSecurityGroup: { path: 'AccessControl/SaveAssignedSecurityGroup' },
		Form101Saving: { path: "Form101/SaveForm101" },
		Form101Data: { path: "Form101/GetForm101Data" },
		Form101MainEmpData: { path: "Form101/GetForm101MainEmpData" },
		Form101Pdf: { path: "Form101/GetForm101Pdf" },
		GetForm101PDFWithCompareVersion: { path: "Form101/GetForm101PDFWithCompareVersion" },
		Form101Attachments: { path: "Form101/GetForm101Attachments" },
		Form101RemoveAttachmentFile: { path: "Form101/RemoveForm101AttachmentFile" },
		Form101Comments: { path: "Form101/GetForm101EmpComments" },
		Form101UpdateComment: { path: "Form101/Form101UpdateComment" },
		Form101ChangeStatus: { path: "Form101/ChangeStatus" },
		Form101CheckPassword: { path: "Form101/CheckForm101Password" },
		Form101EmployerDetails: { path: "Form101/GetEmployerDetailsByDeductionsPortfolio" },
		Form101SignPdf: { path: "Form101/Form101SignPdf" },
		Form101CheckSignLicense: { path: "Form101/Form101CheckSignLicense" },
		Form101IsLockByManager: { path: "Form101/CheckIfForm101LockByManager" },
		Form101SignPdfList: { path: "Form101/Form101SignPdfList" },
		PostForm101Attachment: { path: "Form101/PostForm101Attachment" },
		PostFile: { path: "Attachment/PostFile" },
		PostFileT2: { path: "Attachment/PostFileT2"},
		GetFile: { path: "Attachment/GetFile" },
		DeleteAttachmentFileById: { path: "Attachment/DeleteAttachmentFileById" },
		GetIdNumForNewCalendar: { path: 'WorkRules/GetIdNumForNewCalendar' },
		SaveFile: { path: "Attachment/SaveFile" },
		GeneralDelete: { path: "common/GeneralDelete" },
		GeneralListDelete: { path: "common/GeneralListDelete" },
		ETableInsertUpdateDelete_SpecificMode: { path: 'ETable/ETableInsertUpdateDelete_SpecificMode' },
		GeneralDeleteNew: { path: "common/GeneralDeleteNew" },
		GeneralDeleteUnknownObject: { path: "common/GeneralDeleteUnknownObject" },
		ConvertPicture: { path: "common/ConvertPicture" },
		GeneralDeleteByMultipleKey: { path: "common/GeneralDeleteByMultipleKey" },
		GeneralDeleteByMultipleKeyNew: { path: "common/GeneralDeleteByMultipleKeyNew" },
		GetAllCookiesFromServer: { path: 'Common/GetAllCookiesFromServer' },
		GetCalendarData: { path: 'WorkRules/GetCalendar' },
		GetAbsencesTimeByCodePortal: { path: "Attendance/GetAbsencesTimeByCodePortal" },
		GetCardTypeData: { path: "Communication/GetCardTypeData" },
		GetFunctionKeyData: { path: 'Communication/GetFunctionKeyData' },
		GetLastEmpReporting: { path: 'DailyReporting/GetLastEmpReporting' },
		GetOnCallOnDutyList: { path: "Attendance/GetOnCallOnDutyList" },
		GetEmployeesRulerList: { path: "Attendance/GetEmployeesRulerList" },
		GetOneContollerDataAndFields: { path: "Communication/GetOneContollerDataAndFields" },
		GetDeviceControlsList: { path: "Communication/GetDeviceControlsList" },
		GetControllerSys: { path: "Communication/GetControllerSys" },
		GetTimeZones: { path: "Communication/GetTimeZones" },
		GetControlSecurityGroup: { path: "Communication/GetControlSecurityGroup" },
		GetControllerSGTreeLevel: { path: "Communication/GetControllerSGTreeLevel" },
		GetContactTypes: { path: "Employee/GetContactTypes" },
		GetContactTypeMenuItems: { path: "Employee/GetContactTypeMenuItems" },
		GetDailyReportingMovement: { path: "DailyReporting/GetDailyReportingMovement" },
		GetETableComboData: { path: 'ETable/GetETableComboData' },
		GetHomePageMenus: { path: "HomePage/GetHomePageMenus" },
		GetLanguagesList: { path: "Login/GetLanguagesList" },
		GetLawEventsList: { path: "WorkRules/GetLawEventsList" },
		GetEmployeeHeaderData: { path: "Common/GetEmployeeHeaderData" },
		GetMealCouponData: { path: "Communication/GetMealCouponData" },
		GetResources: { path: "login/GetResources" },
		GetPagingLookup: { path: "Lookup/GetPagingLookup" },
		GetPaymentByCallOn: { path: "WorkRules/GetPaymentByCallOn" },
		GetTimeZoneData: { path: "WorkRules/GetTimeZoneData" },
		GetTimeZoneByDateData: { path: "AccessControl/GetTimeZoneByDateData" },
		TimeZoneClientServer: { path: "Common/TimeZoneClientServerHandling" },
		GetAgrEntryParams: { path: "WorkRules/GetAgrEntryParams" },
		GetWorkRuleParametersForPopup: { path: "WorkRules/GetWorkRuleParametersForPopup" },
		GetTagNo: { path: "DailyReporting/GetTagNo" },
		GetCompanyLogoName: { path: "login/GetCompanyLogoName" },
		GetOneSecurityGroupDetails: { path: "AccessControl/GetOneSecurityGroupDetails" },
		GlobalSearchEmpUniverse: { path: "Common/GlobalSearchEmpUniverse" },
		GlobalUpdateProcess: { path: "Attendance/GlobalUpdateProcess" },
		HomePageEmpAttendForEmpScheduler: { path: "HomePage/GetHomePageEmpAttendForEmpScheduler" },
		HomePageEmpAttendForMng: { path: "HomePage/GetHomePageEmpAttendForMng" },
		HomePageEmpAttendForMngData: { path: "HomePage/GetHomePageEmpAttendForMngData" },
		HomePageTLRepDashboards: { path: "HomePage/GetHomePageTLRepDashboards" },
		HomePageDashboardsData: { path: "HomePage/GetHomePageDashboardsData" },
		HomePageDashboardsDataList: { path: "HomePage/GetHomePageDashboardsDataList" },
		HomePageDashboardsDataFields: { path: "HomePage/GetHomePageDashboardsDataFields" },
		HomePageRecordsPending: { path: "HomePage/GetRecordsPending" },
		HomePageRecordsPendingChild: { path: "HomePage/GetRecordsPendingChild" },
		HomePageAlertData: { path: "HomePage/GetHomePageAlertData" },
		HomePageEmpActualOverTimeForMng: { path: "HomePage/GetEmpActualOverTimeForMngAppr" },
		HomePageGetProcessesAppr: { path: "HomePage/GetProcsStatus" }, // 26.08.2018 Lyn
		HomePageSaveProcessesAppr: { path: "HomePage/SaveProcsStatus" }, // 26.08.2018 Lyn
		HomePageRefreshProcessesAppr: { path: "HomePage/RefreshProcsStatus" }, // 11.12.2018 Lyn
		HomePageGetProcsAttachments: { path: "HomePage/GetProcsAttachments" }, // 06.01.2019
		HomePageDeleteProcessAttachment: { path: "HomePage/DeleteProcessAttachment" }, // 16.01.2019 
		HomePageSaveProcessAttachment: { path: "HomePage/SaveProcessAttachment" }, // 16.01.2019 
		HRProcessCheckAttachmentViewHist: { path: "HomePage/CheckAttachmentViewHist" },
		HRProcessCheckAttachmentRequired: { path: "HomePage/CheckAttachmentRequired" },
		HomePageGetProcsStagesList: { path: "HomePage/GetProcsStagesList" },
		HomePageSaveEmployeeProcess: { path: "HomePage/SaveEmployeeProcess" },
		SaveEmpActualOverTimeForMngAppr: { path: "HomePage/SaveEmpActualOverTimeForMngAppr" },
		GetInitStartPeriod: { path: "HomePage/GetInitStartPeriod" },
		CheckDoAlertOverTime: { path: "HomePage/CheckDoAlertOverTime" },
		CheckOverTimeByEmpLimitFromGrid: { path: "HomePage/CheckOverTimeByEmpLimitFromGrid" },
        
		SaveApprEmpReqPopup: { path: "HomePage/SaveApprEmpReqPopup" },
		GetReportApproval: { path: "HomePage/GetReportApproval" },
		GetLogProcess: { path: "HomePage/GetLogProcess" },
		GetApproveOT: { path: "HomePage/GetApproveOT" },
		GetScheduleOverTimePlanning: { path: "HomePage/GetScheduleOverTimePlanning" },
		SaveGridMngOvertimeWork: { path: "HomePage/SaveGridMngOvertimeWork" },
		getIsUpdSchedulePlanOT: { path: "HomePage/getIsUpdSchedulePlanOT" },
		InitializeSystem: { path: "Common/InitializeSystem" },
		LoadConfig: { path: "Common/LoadConfig" },
		Login: { path: "login/Login" },
		LoginByProfile: { path: "login/LoginByProfile" },
		Lookup: { path: "lookup/GetLookup" },
		PasteWorkRuleDayType: { path: 'WorkRules/PasteWorkRuleDayType' },
		PasteWorkRuleShift: { path: 'WorkRules/PasteWorkRuleShift' },
		PasteWorkRuleBlock: { path: 'WorkRules/PasteWorkRuleBlock' },
		GetNextControllerCode: { path: 'Communication/GetNextControllerCode' },
		GetTerminalsData: { path: 'Communication/GetTerminalsData' },
		GetFingerprintTerminalData: { path: 'Communication/GetFingerprintTerminalData' },
		GetAuditTrailData: { path: 'Communication/GetAuditTrailData' },
		GetFingerPrintEmpList: { path: 'Communication/GetFingerPrintEmpList' },
		GetTerminalsIpAndPortList: { path: "Communication/GetTerminalsIpAndPortList" },
		GetCommunicationMaintenanceData: { path: 'Communication/GetCommunicationMaintenanceData' },
		GetModulesForm101TaxYearParams: { path: "GlobalParameters/GetModulesForm101TaxYearParams" },
		GetForm101CompaniesList: { path: "GlobalParameters/GetForm101CompaniesList" },
		DeleteCompanies: { path: "GlobalParameters/DeleteCompanies" },
		UpdateCompanies: { path: "GlobalParameters/UpdateCompanies" },
		SaveModulesForm101TaxYearParams: { path: "GlobalParameters/SaveModulesForm101TaxYearParams" },
		GetDevicesData: { path: 'Communication/GetDevicesData' },
		GetFilesTree: { path: 'Common/GetFilesTree' },
		GetDirectoriesTree: { path: 'Common/GetDirectoriesTree' },
		OrganizationLevelsExist: { path: "organizationLevel/GetOrganizationLevelsExist" },
		OrgItemDelete: { path: 'AccessControl/DeleteOrgItem' },
		PeriodProcessingWithoutIndicator: { path: "Attendance/PeriodProcessingWithoutIndicator" },
		RemoveSessionBySessionId: { path: "login/RemoveSessionBySessionId" },
		RemindPassword: { path: "login/RemindPassword" },
		RemindPasswordRegularModule: { path: "login/RemindPasswordRegularModule" },
		AbsenceOrAttendanceGlobalUpdate: { path: "Attendance/AbsenceOrAttendanceGlobalUpdate" },
		SaveAttendance: { path: "Attendance/SaveAttendanceFromGrid" },
		CheckBalanceByAbsenceFromGrid: { path: "Attendance/CheckBalanceByAbsenceFromGrid" },
		CheckBalanceByAbsenceFromGlobalUpd: { path: "Attendance/CheckBalanceByAbsenceFromGlobalUpd" },
		CheckAbsAttBeforeDelete: { path: "Attendance/CheckAbsAttBeforeDelete" },
		SaveAttendanceMealsPopupData: { path: "AttendanceDetails/SaveAttendanceMealsPopupData" },
		CalculationParameterGlobalUpdate: { path: "Attendance/CalculationParameterGlobalUpdate" },
		SaveCalendarHolidays: { path: 'WorkRules/SaveCalendarHolidays' },
		SaveEmployeeCards: { path: "EmployeeDetails/SaveEmployeeCards" },
		SaveEmployeeComputers: { path: "EmployeeDetails/SaveEmployeeComputers" },
		SaveEmployeeHistories: { path: "EmployeeDetails/SaveEmployeeHistories" },
		SaveEmployeeManagmentContacts: { path: "EmployeeDetails/SaveEmployeesManagmentContacts" },
		SaveEmployees: { path: "Employee/SaveEmployees" },
		SaveAsEmployee: { path: "Employee/SaveAsEmployee" },
		ChangeEmployeeNumber: { path: "Employee/ChangeEmployeeNumber" },
		ChangeEmployeeNumberAllData: { path: "Employee/ChangeEmployeeNumberAllData" },
		SaveEmployeeHistory: { path: "Employee//SaveEmployeeHistory" },
		SaveEmployeeSecurityGroup: { path: "EmployeeDetails/SaveEmployeeSecurityGroups" },
		SaveEmployeeContacts: { path: "Employee/SaveEmployeeContacts" },
		SaveEmployeeTelForReport: { path: "EmployeeDetails/SaveEmployeeTelForReport" },
		SaveRecordsPendingChild: { path: "HomePage/SaveRecordsPendingChild" },
		SaveRecordsPending: { path: "HomePage/SaveRecordsPending" },
		SaveEmployeePicture: { path: "Employee/SaveEmployeePicture" },
		SavePaymentRule: { path: 'WorkRules/SavePaymentRule' },
		SynergyTableFlag: { path: 'Communication/SynergyTableFlag' },
		SYserverSynchronize: { path: 'Communication/SYserverSynchronize' },
		SYserverSendFile: { path: 'Communication/SYserverSendFile' },
		SYserverDLL: { path: 'Communication/SYserverDLL' },
		SYserverListen: { path: 'Communication/SYserverListen' },
		SYserverStatus: { path: 'Communication/SYserverStatus' },
		GetSynergyDataResult: { path: 'Communication/GetSynergyDataResult' },
		SaveSynergyDataResult: { path: 'Communication/SaveSynergyDataResult' },
		SaveCommunicationParams: { path: 'Communication/SaveCommunicationParams' },
		SendStatusMail: { path: 'Form101/SendStatusMail' },
		MealsGlobalUpdate: { path: "Attendance/MealsGlobalUpdate" },
		GetControlsPerLawEvent: { path: "WorkRules/GetControlsPerLawEvent" },
		GetInfraSourceDestForms: { path: "SelectionFrame/GetInfraSourceDestForms" },
		GetSelectionFrame: { path: "SelectionFrame/GetSelectionFrame" },
		GetCustomizeFields: { path: "Report/GetCustomizeFields" },
		GetGeneralParameters: { path: "Report/GetGeneralParameters" },
		SaveReportCustomization: { path: "Report/SaveReportCustomization" },
		CreateAndSaveReportCustomization: { path: "Report/CreateAndSaveReportCustomization" },
		GetLanguagesList: { path: "Login/GetLanguagesList" },
		GetEmployeeHeaderData: { path: "Common/GetEmployeeHeaderData" },
		GetETableGridData: { path: "ETable/GetETableGridData" },
		CheckUserLogin: { path: "Common/CheckUserLogin" },
		ProjectsDailyReportingWeb: { path: "DailyReporting/ProjectsDailyReportingCalcWeb" },
		PeridoicTotalEmp: { path: 'HomePage/PeridoicTotalEmp' },
		PeridoicTotalMng: { path: "HomePage/PeridoicTotalMng" },
		TreatClientError: { path: "Common/TreatClientError" },
		ThisPeriodTime: { path: "Common/GetThisPeriodTime" },
		LastPeriodTime: { path: "Common/GetLastPeriodTime" },
		StartEndPeriodTimeByDate: { path: "Common//GetStartEndPeriodTimeByDate" },
		RenameAgreement: { path: "WorkRules/RenameAgreement" },
		RenameLawEvent: { path: "WorkRules/RenameLawEvent" },
		ReportList: { path: "Report/GetReportList" },
		ReportRunTimeParameters: { path: "Report/GetReportRunTimeParameters" },
		ReportTableName: { path: "Report/GetReportTableName" },
		BudgetDailyReportTableName: { path: "Report/GetBudgetDailyReportTableName" },
		UpdateController: { path: "Communication/UpdateController" },
		UpdateReportHistByEmp: { path: "Report/UpdateReportHistByEmp" },
		isExistEHarmonyRep: { path: "Report/isExistEHarmonyRep" },
		GetMainReportURL: { path: "Report/GetMainReportURL" },
		GetMainReportSchedulURL: { path: "Report/GetMainReportSchedulURL" },
		GetIsReportManagerMode: { path: "Report/GetIsReportManagerMode" },
		IsReportTableResultWithData: { path: "Report/IsReportTableResultWithData" },
		GetReportParamFields: { path: "Report/GetReportParamFields" },
		DeleteReportVersion: { path: "Report/DeleteReportVersion" },
		GetAutomationJobsByTypeAndCode: { path: "JobAutomation/GetAutomationJobsByTypeAndCode" },
		GetAutomationJobsExecutionLog: { path: "JobAutomation/GetAutomationJobsExecutionLog" },
		GetAutomationJobsExecutionLogSteps: { path: "JobAutomation/GetAutomationJobsExecutionLogSteps" },
		SaveAsAutomationReport: { path: "JobAutomation/SaveAsAutomationReport" },
		DeleteAutomationJobsByKey: { path: "JobAutomation/DeleteAutomationJobsByKey" },
		UpdateWorkScheduleDayPattern: { path: "WorkSchedule/UpdateWorkScheduleDayPattern" },
		GetProcessingFailedList: { path: "Maintenance/GetProcessingFailedList" },
		GetProcessNo: { path: "Maintenance/GetProcessNo" },
		GetQtyEmpByParam: { path: "Maintenance/GetQtyEmpByParam" },
		insertLogProcessInfo: { path: "Maintenance/insertLogProcessInfo" },
		updateLogProcessInfo: { path: "Maintenance/updateLogProcessInfo" },
		InsertEmployeeTag: { path: "EmployeeDetails/InsertEmployeeTag" },
		GetLogProcessInfoByProcessNo: { path: "Maintenance/GetLogProcessInfoByProcessNo" },
		GetBakaraFailedEmpList: { path: "Maintenance/GetBakaraFailedEmpList" },
		getLogInterfacesInfoByRunNo: { path: "IO_interfaces/getLogInterfacesInfoByRunNo" },
		getInfoByRunNo: { path: "IO_interfaces/getInfoByRunNo" },
		ExecuteReProcess: { path: "Maintenance/ExecuteReProcess" },
		GetProcessingStatistics: { path: "Maintenance/GetProcessingStatistics" },
		GetControllerSchedulareData: { path: "Communication/GetControllerSchedulareData" },
		GetControllerSchedulareDetail: { path: "Communication/GetControllerSchedulareDetail" },
		GetReportApprovalData: { path: "HomePage/GetReportApprovalData" },
		GetReportApprovalRepVersion: { path: "HomePage/GetReportApprovalRepVersion" },
		ApproveReportByPeriodEmpList: { path: "HomePage/ApproveReportByPeriodEmpList" },
		ApproveReportByPeriod: { path: "HomePage/ApproveReportByPeriod" },
		RepeatedRetrivalCompanyData: { path: 'Login/RepeatedRetrivalCompanyData' },
		LoginGenerateOTP: { path: "Login/LoginGenerateOTP" },
		SaveGridsLayouts: { path: "Common/SaveGridsLayouts" },
		GetReplacementManagerSwitchEnabled: { path: "Common/GetReplacementManagerSwitchEnabled" },
		SaveReplacementMng: { path: "Common/SaveReplacementMng" },
		SaveNewCalendarByNewCycl: { path: 'WorkRules/SaveNewCalendarByNewCycl' },
		SaveAssignQuotaTabForEmp: { path: "WorkRules/SaveBalanceTrackingAssignQuotaTabForEmp" },
		SaveDistributionListAs: { path: "AccessControl/SaveDistributionListAs" },
		UpdateControllerFunctionKey: { path: "Communication/UpdateFunctionKeyData" },
		WriteInfoToLog: { path: "Common/WriteInfoToLog" },
		WorkScheduleWeekly: { path: "WorkSchedule/GetWorkScheduleWeekly" },
		WorkSchedulePattern: { path: "WorkSchedule/GetPattern" },
		WorkScheduleAssignedList: { path: "WorkSchedule/GetAssignedList" },
		WorkScheduleUnAssignedList: { path: "WorkSchedule/GetUnAssignedList" },
		WorkScheduleMorningShiftList: { path: "WorkSchedule/GetMorningShiftList" },
		WorkScheduleAfternoonShiftList: { path: "WorkSchedule/GetAfternoonShiftList" },
		WorkScheduleEveningShiftList: { path: "WorkSchedule/GetEvrningShiftList" },
		WorkScheduleSaveWeekly: { path: "WorkSchedule/saveWorkScheduleWeekly" },
		WorkScheduleCopyTemplate: { path: "WorkSchedule/CopyWorkSchedulerTemplate" },
		WorkSchedulePatternDetails: { path: "WorkSchedule/GetWorkSchedulePatternDetails" },
		WorkScheduleDaily: { path: "WorkSchedule/GetWorkScheduleDaily" },
		WorkScheduleSaveDaily: { path: "WorkSchedule/SaveWorkScheduleDaily" },
		WorkScheduleDailyFromAttendGrid: { path: "Attendance/SaveWorkScheduleDailyFromAttendGrid" },
		WorkScheduleCopyDaily: { path: "WorkSchedule/CopyScheduleDaily" },
		CheckLaborLawOneEmpSchedule: { path: "WorkSchedule/CheckLaborLawOneEmpSchedule" },
		CheckLaborLawShiftEmpSchedule: { path: "WorkSchedule/CheckLaborLawShiftEmpSchedule" },
		CheckLaborLawListSchedule: { path: "WorkSchedule/CheckLaborLawListSchedule" },
		GetScheduleWeeklyBlock: { path: "WorkSchedule/GetScheduleWeeklyBlock" },
		WorkRuleGetDayType: { path: "WorkRules/GetWorkRuleDayTypeData" },
		WorkRulesGetConsecutiveAbsence: { path: "WorkRules/GetWorkRulesConsecutiveAbsenceData" },
		WorkRuleDeleteConsecutiveAbsences: { path: "WorkRules/DeleteConsecutiveAbsences" },
		WorkRulesSaveAssignmens: { path: "WorkRules/WorkRulesSaveAssignmens" },
		WorkRulesSavePayCodes: { path: "WorkRules/WorkRulesSavePayCodes" },
		WorkRulesGetCASickPays: { path: "WorkRules/WorkRulesGetCASickPayData" },
		WorkRulesGetCASickPay: { path: "WorkRules/WorkRulesGetCASickPay" },
		WorkRulesGetCAPayCodes: { path: "WorkRules/WorkRulesGetCAPayCodesData" },
		WorkRulesGetCAAssignment: { path: "WorkRules/WorkRulesGetCAAssignmentData" },
		WorkRuleDeleteYearFromCalendarType: { path: "WorkRules/DeleteYearFromCalendarType" },
		WorkRulesBalanceTrackingSeniorityData: { path: "WorkRules/GetBalanceTrackingSeniorityData" },
		WorkRuleCheckBalanceTrackingTimeClassHourCat: { path: "WorkRules/CheckBalanceTrackingTimeClassHourCat" },
		Get101FormsList: { path: "Form101/Get101FormsList" },
		GetTaxYearsRange: { path: "Form101/GetTaxYearsRange" },
		GetScalarValue: { path: "Common/GetScalarValue" },
		GetRecordSet: { path: "Common/GetRecordSet" },
		UpdatePatternTemplate: { path: "WorkSchedule/UpdatePatternTemplate" },
		UpdateWorkRulesCASickPay: { path: "WorkRules/UpdateWorkRulesCASickPay" },
		UpdateTerminals: { path: "Communication/UpdateTerminals" },
		SaveTerminalAs: { path: "Communication/SaveTerminalAs" },
		SaveDeviceAs: { path: "Communication/SaveDeviceAs" },
		UpdateCompanyParamsData: { path: "GlobalParameters/UpdateCompanyParamsData" },
		ManagementOTPRegister: { path: "GlobalParameters/ManagementOTPRegister" },
		ManagementOTPUpdate: { path: "GlobalParameters/ManagementOTPUpdate" },
		UpdateDevices: { path: "Communication/UpdateDevices" },
		UpdateControllerSysParams: { path: "Communication/UpdateControllerSysParams" },
		DeleteControllerSchedulare: { path: "Communication/DeleteControllerSchedulare" },
		UpdateControllerSchedulare: { path: "Communication/UpdateControllerSchedulare" },
		WorkRulePayCode: { path: "WorkRules/GetPayCodeData" },
		WorkRuleBalanceTracking: { path: "WorkRules/GetBalanceTrackingData" },
		WorkRuleBTSaveSeniorityFromGrid: { path: "WorkRules/SaveBalanceTrackingSeniorityFromGrid" },
		WorkRuleSaveBalanceTimeClassFromGrid: { path: "WorkRules/SaveBalanceTrackingTimeClassFromGrid" },
		WorkRuleGetBalanceTimeClass: { path: "WorkRules/GetBalanceTrackingTimeClassData" },
		WorkRuleGetBalanceQuotaGroup: { path: "WorkRules/GetBalanceTrackingQuotaGroupData" },
		WorkRuleSaveQuotaGroup: { path: "WorkRules/SaveBalanceTrackingAssignQuotaGroup" },
		TerminalsGetControlsListForController: { path: 'Communication/GetControlsListForContorollerPopup' },
		TimeClassificationUpdate: { path: 'WorkRules/TimeClassificationUpdate' },
		TimeClassificationInsert: { path: 'WorkRules/TimeClassificationInsert' },
		TimeClassificationSave: { path: 'WorkRules/TimeClassificationSave' },
		TimeClassificationGetCodeForNew: { path: "WorkRules/TimeClassificationGetCodeForNew" },
		CompParamsByChoice: { path: 'GlobalParameters/GetDataByChoiceList' },
		GetAccessControlSecurityGroupData: { path: 'AccessControl/GetAccessControlSecurityGroupData' },
		GetDistributionList: { path: 'AccessControl/GetDistributionList' },
		GetDistributionListDetails: { path: 'AccessControl/GetDistributionListDetails' },
		GetQualificationsList: { path: 'Scheduling/GetQualificationsList' },
		GetQualificationsDetails: { path: 'Scheduling/GetQualificationsDetails' },
		SaveQualificationsDetails: { path: 'Scheduling/SaveQualificationsDetails' },
		SaveQualificationsEmpDetails: { path: 'Scheduling/SaveQualificationsEmpDetails' },
		SaveQualificationsEmpDetailsAll: { path: 'Scheduling/SaveQualificationsEmpDetailsAll' },
		SaveAsQualificationDetails: { path: 'Scheduling/SaveAsQualificationDetails' },
		DeleteQualificationFromList: { path: 'Scheduling/DeleteQualificationFromList' },
		GetMaintenanceJobCodeData: { path: 'Scheduling/GetMaintenanceJobCodeData' },
		SaveMaintenanceJobCodeData: { path: 'Scheduling/SaveMaintenanceJobCodeData' },
		GetIO_interfacesList: { path: 'Maintenance/GetIO_interfacesList' },
		GetIO_interfacesListDetails: { path: 'Maintenance/GetIO_interfacesListDetails' },
		UpdateIO_inputData: { path: 'Maintenance/UpdateIO_inputData' },
		GetIO_inputData: { path: 'IO_interfaces/GetIO_inputData' },
		GetIO_outputData: { path: 'IO_interfaces/GetIO_outputData' },
		GetIO_outputExportData: { path: 'IO_interfaces/GetIO_outputExportData' },
		GetIO_outputSalaryData: { path: 'IO_interfaces/GetIO_outputSalaryData' },
		IO_interfaces: { path: 'IO_interfaces/UpdateIO_inputData' },
		IO_interfacesOutput: { path: 'IO_interfaces/UpdateIO_outputData' },
		IO_interfacesOutputSalary: { path: 'IO_interfaces/UpdateIO_outputSalaryData' },
		IO_interfacesOutputAttendance: { path: 'IO_interfaces/UpdateIO_outputAttendanceData' },
		IO_interfacesOutputExport: { path: 'IO_interfaces/UpdateIO_outputExportData' },
		IO_TransactionsFields: { path: "IO_interfaces/GetIO_outputTransactionFields" },
		IO_ByChoice: { path: 'IO_interfaces/getDataByChoiceList' },
		IO_GetProcessID: { path: 'IO_interfaces/GetProcessID' },
		IO_GetInputFileName: { path: 'IO_interfaces/GetInputFileName'},
		IO_RunInput: { path: 'IO_interfaces/RunInput' },
		IO_RunSalary: { path: 'IO_interfaces/RunSalary' },
		IO_RunActivity: { path: 'IO_interfaces/RunActivity' },
		IO_RunOutput: { path: 'IO_interfaces/RunOutput' },
		IO_UpdateIcons: { path: 'IO_interfaces/UpdateIcons' },
        IO_interfacesUpdateFieldsLocation: { path: 'IO_interfaces/UpdateIO_outputFieldsLocation' },
        IO_CreateAndSaveInterface: { path: 'IO_interfaces/CreateAndSaveInterface' },
        IO_BackupInterface: { path: 'IO_interfaces/BackupInterface' },
        IO_RestoreInterface: { path: 'IO_interfaces/RestoreInterface' },
        IO_CheckExistenceBeforeRestore: { path: 'IO_interfaces/CheckExistenceBeforeRestore' },
		GetPayrollIconsGridData: { path: 'IO_interfaces/GetPayrollIconsGridData' },
		GetIO_Log_GridData: { path: 'IO_interfaces/GetIO_Log_GridData' },
		GetAccessControlSecurityGroupContentData: { path: 'AccessControl/GetAccessControlSecurityGroupContentData' },
		GetNewSecurityGroupNo: { path: 'AccessControl/GetNewSecurityGroupNo' },
		SaveOneSecurityGroup: { path: 'AccessControl/SaveOneSecurityGroup' },
		SaveSecurityGroup: { path: 'AccessControl/SaveSecurityGroup' },
		SaveTimeZoneByDateData: { path: 'AccessControl/SaveTimeZoneByDateData' },
		DeleteTimeZoneAccessControl: { path: 'AccessControl/DeleteTimeZoneAccessControl' },
		GetAccessControlSecurityGroupData: { path: 'AccessControl/GetAccessControlSecurityGroupData' },
		GetAgreementListFromDll: { path: "WorkRules/GetAgreementListFromDll" },
		GetAgreementParametersFromDll: { path: "WorkRules/GetAgreementParametersFromDll" },
		SaveProfileParams: { path: "SystemSettings/SaveProfileParams" },
		SaveUserProfileAs: { path: "SystemSettings/SaveUserProfileAs" },
		UpdateSecurityGroupData: { path: "AccessControl/UpdateSecurityGroupData" },
		UpdateSecurityGroupContent: { path: "AccessControl/UpdateSecurityGroupContent" },
		GetAuditTrailList: { path: 'GlobalParameters/GetAuditTrailList' },
		GetAuditTrailGridData: { path: 'GlobalParameters/GetAuditTrailGridData' },
		SaveAuditTrailList: { path: 'GlobalParameters/SaveAuditTrailList' },
		GetLoginsHistoryGridData: { path: 'GlobalParameters/GetLoginsHistoryGridData' },
		UpdateLoginsHistory: { path: 'login/UpdateLoginsHistory' },
		PrismSSO: { path: 'login/PrismSSO' },
		TokenValid: { path: 'Form101/TokenValid' },
		GetToken: { path: 'Form101/GetToken' },
		ReconnectAnotherClient: { path: 'login/ReconnectAnotherClient' },
		GetMaintenanceCostCenter: { path: 'Maintenance/GetMaintenanceCostCenterData' },
		GetMaintenanceSubCostCenter: { path: 'Maintenance/GetMaintenanceSubCostCenterData' },
		GetMaintenanceCostCenterDef: { path: 'Maintenance/GetMaintenanceCostCenterDefData' },
		MaintenanceCostCenterDefUpdate: { path: 'Maintenance/MaintenanceCostCenterDefUpdate' },
		MaintenanceSubCostCenterUpdate: { path: 'Maintenance/MaintenanceSubCostCenterUpdate' },
		MaintenanceCostCenterUpdate: { path: 'Maintenance/MaintenanceCostCenterUpdate' },
		MaintenanceCostCenterDelete: { path: 'Maintenance/MaintenanceCostCenterDelete' },
		MaintenanceSaveCostCenterFromGrid: { path: 'Maintenance/SaveCostCenterFromGrid' },
		MaintenanceSaveCostCenterDefFromGrid: { path: 'Maintenance/SaveCostCenterDefFromGrid' },
		MaintenanceSaveSubCostCenterFromGrid: { path: 'Maintenance/SaveSubCostCenterFromGrid' },
		SaveMaintenanceMeals: { path: 'Maintenance/SaveMaintenanceMeals' },
		SaveMaintenanceMealsDetails: { path: 'Maintenance/SaveMaintenanceMealsDetails' },
		DeleteMaintenanceMealsDetails: { path: 'Maintenance/DeleteMaintenanceMealsDetails' },
		SaveMaintenanceRestaurantDetails: { path: 'Maintenance/SaveMaintenanceRestaurantDetails' },
		DeleteMaintenanceMeals: { path: 'Maintenance/DeleteMaintenanceMeals' },
		DeleteMaintenanceRestaurantDetails: { path: 'Maintenance/DeleteMaintenanceRestaurantDetails' },
		GetMaintenanceTemplate: { path: 'Maintenance/GetMaintenanceTemplateDefinitionData' },
		UpdateMaintenanceTemplate: { path: 'Maintenance/UpdateMaintenanceTemplateDefinition' },
		GetMaintenanceMeals: { path: 'Maintenance/GetMaintenanceMealsData' },
		GetMaintenanceMealsDetails: { path: 'Maintenance/GetMaintenanceMealsDetailsData' },
		GetMaintenanceRestaurants: { path: 'Maintenance/GetMaintenanceRestaurantsData' },        
		GetClosingPeriodEmpData: { path: 'Maintenance/GetClosingPeriodEmpData' },
		GetClosingPeriodSiteData: { path: 'Maintenance/GetClosingPeriodSiteData' },
		GetReprocessClosingPeriodEmpData: { path: 'Maintenance/GetReprocessClosingPeriodEmpData'},
		MaintenanceCloseEmpPeriod: { path: 'Maintenance/MaintenanceCloseEmpPeriod' },
		MaintenanceCloseSitePeriod: { path: 'Maintenance/MaintenanceCloseSitePeriod' },
		GetTerminalsRestDetails: { path: 'Maintenance/GetTerminalsRestDetailsData' },
		GetApprManagersData: { path: 'Maintenance/GetApprManagersData' },
		UpdateApprManagersData: { path: 'Maintenance/UpdateApprManagersData' },
		GetApprManagersEmployeesData: { path: 'Maintenance/GetApprManagersEmployeesData' },
		UpdateApprManagersPopup: { path: 'Maintenance/UpdateApprManagersPopup' },
		ApprMangExportGridToExcel: { path: 'Maintenance/ApprMangExportGridToExcel' },
		ApprMangExportEmpGridToExcel: { path: 'Maintenance/ApprMangExportEmpGridToExcel' },
		GetMaxStatusTimeOutSysController: { path: 'Communication/GetMaxStatusTimeOutSysController' },
		GetMaxStatusTimeOutSysControllerByControllerCodes: { path: 'Communication/GetMaxStatusTimeOutSysControllerByControllerCodes' },
		GetEmployeePassportNo: { path: 'Employee/GetEmployeePassportNo' },
		GetIsUseFPU: { path: 'Employee/GetIsUseFPU' },
		GetPermGroupDescr: { path: 'Employee/GetPermGroupDescr' },
		GetLastDayType: { path: 'WorkRules/GetLastDayType' },
		GetDayTypeByDayType: { path: 'WorkRules/GetDayTypeByDayType' },
		GetLastPayCode: { path: 'WorkRules/GetLastPayCode' },
		GetPayCodeByPayCode: { path: 'WorkRules/GetPayCodeByPayCode' },
		GetLastQuotaBalance: { path: 'WorkRules/GetLastQuotaBalance' },
		GetTimeClassByHourCat: { path: 'WorkRules/GetTimeClassByHourCat' },
		GetQuotaBalanceCodeByCode: { path: 'WorkRules/GetQuotaBalanceCodeByCode' },
		GetNextPatternNo: { path: 'WorkSchedule/GetNextPatternNo' },
		GetPatternNoByPatternNo: { path: 'WorkSchedule/GetPatternNoByPatternNo' },
		GetAbsenceEnum: { path: 'Attendance/GetAbsenceEnum' },
		GetSrcTableName: { path: 'Attendance/GetSrcTableName' },
		GetAbsParamByCode: { path: 'Attendance/GetAbsParamByCode' },
		GetQuotaCategoryByAbsCode: { path: 'Attendance/GetQuotaCategoryByAbsCode' },
		GetLastDistributionList: { path: 'AccessControl/GetLastDistributionList' },
		GetLastBudgetCode: { path: 'SystemSettings/GetLastBudgetCode' },
		GetLastSubBudgetCode: { path: 'SystemSettings/GetLastSubBudgetCode' },
		GetEmployeeSmartPhone: { path: 'Form101/GetEmployeeSmartPhone' },
		GetPermGroupType: { path: 'Common/GetPermGroupType' },
		GetEmpLookupRecordsCount: { path: 'Common/GetEmpLookupRecordsCount' },
		UpdateConfigParams: { path: "GlobalParameters/UpdateConfigParams" },
		GetDictList: { path: "SystemSettings/GetDictLists" }, // 12.07.2016
		ViewFile: { path: "Export/ViewFile" },
		CreateFile: { path: "Attachment/CreateFile" },
        ExportFile: { path: "ExportFile/Download" },
        ExportFileMobile: { path: "ExportFile/DownloadMobile" },
        ClearFile: { path: "ExportFile/ClearFile" },
		ExportMessageFile: { path: "ExportFile/DownloadMessage" },
		CopyFileToDestFolder: { path: "Export/CopyFileToDestFolder" },
		SaveDictList: { path: "SystemSettings/SaveDictLists" }, // 18.08.2016
		UpdateDictList: { path: "SystemSettings/UpdateDictLists" }, // 08.09.2016
		ResetDictList: { path: "SystemSettings/ResetDictLists" }, // 11.09.2016
		FileDownload: { path: "Export/FileDownload" },
		GetBreaksForWeeklyDirtyCells: { path: "WorkSchedule/GetBreaksForWeeklyDirtyCells" },
		CheckLoginIP: { path: "Login/CheckLoginIP" },
		GetSchedulingDataAndList: { path: "Scheduling/SchedulingDataAndList" },
		SaveSchedulingPlanListStatus: { path: "Scheduling/SaveSchedulingPlanListStatus" },
		SavePlanningSchedulingEmpList: { path: "Scheduling/SavePlanList" },
		PlanningSchedulingEmpList: { path: "Scheduling/PlanningSchedulingEmpList" },
		RemoveSecurityCookie: { path: "login/RemoveSecurityCookie" },
		Print101PdfFiles: { path: "Form101/Print101PdfFiles" },
		ExportForm101DataToFile: { path: 'Form101/ExportForm101DataToFile' },
		UpdateForm101StatusAllToApprByEmp: { path: 'Form101/UpdateForm101StatusAllToApprByEmp' },
		DeleteForm101Pdf: { path: 'Form101/DeleteForm101Pdf' },
		DateFormatLookup: { path: 'Common/DateFormatLookup' },
		GetTimeZoneLookup: { path: 'lookup/GetTimeZoneLookup' },
		GetQueueMessages: { path: 'AutomationQueues/GetQueueMessages' },
		GetQueuesList: { path: 'AutomationQueues/GetQueuesList' },
		DeleteQueueMessages: { path: 'AutomationQueues/DeleteQueueMessages' },
		OneAutomationJobData: { path: 'JobAutomation/OneAutomationJobData' },
		SaveAutomationOneJobData: { path: 'JobAutomation/SaveAutomationOneJobData' },
		AutoJobRunNow: { path: 'JobAutomation/AutoJobRunNow' },
		CreateAutomationJobFile: { path: 'JobAutomation/CreateAutomationJobFile' },
		QueueMessagePriorityChange: { path: 'AutomationQueues/QueueMessagePriorityChange' },
		GetQueuesParamGridByCode: { path: 'AutomationQueues/GetQueuesParamGridByCode' },
		SaveQueuesParamGrid: { path: 'AutomationQueues/SaveQueuesParamGrid' },
		DeleteQueuesParamFromList: { path: 'AutomationQueues/DeleteQueuesParamFromList' },
		getDataForGraph: { path: 'AutomationQueues/getDataForGraph' },
		GetPRPayrollParams: { path: 'PRPayrollParams/GetPRPayrollParams' }, // 14.12.2017
		SavePRPayrollParams: { path: 'PRPayrollParams/SavePRPayrollParams' }, // 14.12.2017
		DeletePRPayrollParams: { path: 'PRPayrollParams/DeletePRPayrollParams' }, // 29.04.2018
		CheckFirmwareVersion: { path: 'Communication/CheckFirmwareVersion' },
		CheckIfTerminalsNotToUpdate: { path: 'Communication/CheckIfTerminalsNotToUpdate' },
		Send2Queue: { path: 'AutomationQueues/Send2Queue' },
		GetIOInputFieldsGridData: { path: 'IO_interfaces/GetIOInputFieldsGridData' },
		GetIOInputFileFields: { path: "IO_interfaces/GetIOInputFileFields" },
		GetIOInputFieldLength: { path: "IO_interfaces/GetIOInputFieldLength" },
		DeleteInputFields: { path: "IO_interfaces/DeleteInputFields" },
		GetIOOutputFieldsGridData: { path: 'IO_interfaces/GetIOOutputFieldsGridData' },
		DeleteSalaryFields: { path: "IO_interfaces/DeleteSalaryFields" },
		GetIONumberForKey: { path: "IO_interfaces/GetIONumberForKey" },
		GetIO_ExportFldCount: { path: 'IO_interfaces/GetIO_ExportFldCount' },
		IO_arrangeIndex: { path: 'IO_interfaces/IO_arrangeIndex' },
		GenerateOTP: { path: 'Form101/GenerateOTP' },
		GetChildrenCountAnder19: { path: 'Form101/GetChildrenCountAnder19' },
		CheckIfExistEmployeeManualForm101: { path: 'Form101/CheckIfExistEmployeeManualForm101' },
		ChangeForm101Status: { path: 'Form101/ChangeForm101Status' },
		RunSetupHRProcsData: { path: 'HRProcesses/RunSetupHRProcsData' }, // 02.12.2018 Lyn
		GetHomePage_HRProc_AlertData:{ path: 'HRProcesses/GetHomePage_HRProc_AlertData' }, //23/09/2019
		OneAutomationInterfaceData: { path: 'IO_interfaces/OneAutomationInterfaceData' },
		SaveOneAutomationInterfaceData: { path: 'IO_interfaces/SaveOneAutomationInterfaceData' },
		GetSchedulerSettings: { path: 'IO_interfaces/GetSchedulerSettings' },
		GetAutomationInterfaceGridData: { path: 'IO_interfaces/GetAutomationInterfaceGridData' },
		GetInterfaceHistoryGridData: { path: 'IO_interfaces/GetInterfaceHistoryGridData' },

	    PostTemplateFormFile: { path: "Attachment/PostTemplateFormFile" },
	    GetTemplateFormsData: { path: "TemplateForms/GetTemplateFormsData" },
	    GetTemplateFormById: { path: "TemplateForms/GetTemplateFormById" },
	    SaveDigitalFormEmp: { path: "Attachment/SaveDigitalFormEmp" },
	    GetIOScheduler: { path: 'IO_interfaces/GetIOScheduler' },
	    SavePayRollDocViewHist: { path: "PRPayrollParams/SavePayRollDocViewHist" },

	    GetAttachFile: { path: "Attachment/GetAttachFile" }
    };

    var tableCode = {
        functionKeyMealNote: 1,
        controllers: 2,
        ControllerSys: 3,
        cardType: 4,
        controllerFunctionKey: 5,
        TLA_ControllerTime: 6,
        TLA_Devices: 7,
        controllersDst: 8,
        distributionList_M: 9,
        distributionList: 10,
        emp: 11,
        work_center: 12,
        department: 13,
        section: 14,
        factory: 15,
        region: 16,
        orgTree: 17,
        permGroup: 18,
        subCostCenter: 19,
        passPerm: 20,
        quotaforGroup: 21,
        securityGroupToOrg: 22,
        IO_import: 25,
        IO_export: 26,
        MealsAgree: 27,
        MealsRest: 28,
        TLS_Qualifications: 29,
        JobCode: 30,
        TLJ_AutomationJobs: 31,
        TLJ_QueuesParams_M: 32,
        IO_importFld: 33,
        IO_exportFld: 34,
        empGroup: 35
    };



    var employeeDetailsTabs = {
        DETAILS: { id: "details" },
        CARDS: { id: "cards" },
        TASKS: { id: "tasks" },
        SECURITY_GROUP: { id: "securityGroup" },
        TEL_FOR_REPORT: { id: "telForReport" },
        HISTORY: { id: "history" },
        EMPLOYEES_FOR_APPROVAL: { id: "employeesForApproval" },
        APPR_MANAGERS: { id: "apprManagers" },
        COST_CENTER: { id: "costCenter" },
        PERM_COST_CENTER: { id: "permCostCenter" },
        PERM_SUB_COST_CENTER: { id: "permSubCostCenter" },
        COMPUTERS: { id: "computers" },
        EMPLOYEE_DOCUMENTS: { id: "empDocuments" },
        EMPLOYEE_QUALIFICATIONS: { id: "empQualifications" },
        EMPLOYEE_PREFERENCES: { id: "empPreferences" },
        EMPLOYEE_TARIF_PAYROLL: { id: "empTarifPayroll" },
        EMPLOYEE_PAYROLL_DATA: { id: "empPayrollData" }
    };

    var attendanceDetailsTabs = {
        MOVEMENT: { id: "movement" },
        TOTAL_SBALANCE: { id: "totalsBalance" },
        PAY_TOTAL: { id: "payTotal" },
        COST_CENTER: { id: "costCenter" },
        MEALS: { id: "meals" }
    };

    var consecutiveAbsenceDetailsTabs = {
        PAYMENT_CODE: { id: "paymentCodes" },
        SICK_PAY: { id: "sickPay" },
        ASSIGNMENT: { id: "assignment" }
    };

    var balanceTrackingDetailsTabs = {
        ASSIGNMENT_TIME_CLASSIFICATIONS: { id: "assignmentTimeClassifications" },
        SENIORITY: { id: "seniority" },
        ASSIGN_QUOTA: { id: "assignQuota" }
    };

    var systemParams = {
        isTaskModule: "isTaskModule"
    };

    var cardType = {
        EMPLOYEE: { id: 0 },
        VISITORS: { id: 1 },
        CARS: { id: 2 }
    };

    var cardStatus = {
        ACTIVE: { id: 0 },
        SUSPENDED: { id: 1 },
        BLOCKED: { id: 2 },
        STOLEN: { id: 3 }
    };

    var entityState = {
        isModified: { id: 0 },
        isAdded: { id: 1 },
        isDeleted: { id: 2 },
    };

    var contactDataFieldType = {
        text: { id: 0 },
        date: { id: 1 },
        time: { id: 2 },
        combo: { id: 3 }
    };

    var employeeTabMode = {
        FromEmployees: { id: 1, name: "FromEmployees" },
        FromHistory: { id: 2, name: "FromHistory" },
    };

    var filterEmpList = {
        EMPNO: { id: 1 }
    };

    var manualEditMode = {
        userUpdate: 'userUpdate',
        groupUpdate: 'groupUpdate'
    };

    var manualEditType = {
        userUpdate: 0,
        groupUpdate: 1
    };

    var periodType = {
        daily: 0,
        period: 1,
        otPeriod: 2
    };

    var attendanceGridPopupType = {
        task: 0,
        insertTransaction: 1
    };

    var sortMode = {
        code: { name: 'code', value: false },
        descript: { name: 'descript', value: true }
    };

    var sortDirection = {
        down: { name: 'down', value: true },
        up: { name: 'up', value: false }
    };

    var messageType = {
        info: 0,
        error: 1,
        warning: 2,
        question: 3
    };

    var dialogCloseResult = {
        none: null,
        saveSucceed: 'saveSucceed',
        saveFailed: 'saveFaild',
        ok: 'ok'
    };

    var btnsMode = {
        //ok: 0,
        yesNo: 1,
        yesNoCancel: 2,
        logOutOk: 3,
        ok: 4,
        okCancel: 5,
    	continueBack: 6
    };

    var customMsgWindowResult = {
        ok: 'ok',
        yes: 'yes',
        no: 'no',
        cancel: 'cancel',
        continue: 'continue'
    };

    var dailyReportingMode = {
        attendance: "attendance",
        projects: "projects",
        costCenter: "costCenter"
    };

    var directions = {
        LTR: 'ltr',
        RTL: 'rtl'
    };

    var explorerType = {
        IE: "IE",
        NOTIE: "notIE"
    };

    var dashboardType = {
        1: "pie",
    };

    var gridRequestType = {
        update: 'update',
        read: 'read',
        create: 'create'
    };

    var subFormCategory = {
        yearlyQuota: 218,
        payCode: 222,
        timeClass: 223,
        breakType: 227
    }
    var processType = {
        MNG_APPR_CHILD: 'mngApprChild',
        MAINTENANCE: 'maintenance',
        GLOBAL_UPDATE: 'globalUpdate',
        ATTENDANCE: 'attendance',
        ATTENDANCE_DELETE: 'attendanceDelete',
        ATTENDANCE_SEND2QUEUE: 'attendanceSend2Queue',
        PERIOD_PROCESS: 'periodProcess',
        PERIOD_BUDGET_UPDATE_PROCESS: 'periodUpdateBudgetProcess',
        IO_SALARY_EXPORT: 'ssis_IOSalaryExport',
        IO_SALARY_EXPORT_FINISH: 'ssis_IOSalaryExportFinish',
        IO_INTERFACES_FINISH: 'IO_interfacesFinish',
        IO_INPUT_START: 'IO_inputStart',
        IO_OUTPUT_START: 'IO_outputStart',
        IO_INPUT_FINISH: 'IO_inputFinish',
        NOTIFIER_RUNNOW_FINISH: 'notifier_RunNowFinish',
        PWD_SENTINIT_FINISH: 'pwdmodule_sentInitPwdByMail_Finish',
        JOB_AUTOMATION_RUNNOW_FINISH: 'jobAutomation_RunNowFinish',
        HRPROC_SENTACTIVITYMSG_FINISH: 'HR_Proc_sentActivityByMailSms_Finish',
        IO_BACKUP_INTERFACE_FINISH: 'IO_backup_Start',
        IO_BACKUP_INTERFACE_START: 'IO_backup_Finish'
    };

    var costCenterDetailsTabs = {
        DEFAULT: { id: "costCenterDefault" },
        SUB_COST_CENTER: { id: "subCostCenter" }
    };

    var maintenanceViews = {
        workRules: { id: "0", path: "views/maintenance/workRules/workRules/workRulesList", name: "workRules", permission: permissionCodes.WORK_RULES_WORK_RULES },
        workRulePayCode: { id: "1", path: "views/maintenance/workRules/workRulesPayCode/workRulesPayCode", name: "workRulePayCode", permission: permissionCodes.WORK_RULES_PAY_CODE },
        workRuleDayType: { id: "2", path: "views/maintenance/workRules/workRulesDayType/workRulesDayType", name: "workRuleDayType", permission: permissionCodes.WORK_RULES_DAY_TYPE },
        workRuleBalanceTracking: { id: "3", path: "views/maintenance/workRules/workRulesBalanceTracking/workRulesBalanceTracking", name: "workRuleBalanceTracking", permission: permissionCodes.WORK_RULES_BALANCE_TRACKING },
        workRuleTimeClassification: { id: "4", path: "views/maintenance/workRules/workRulesTimeClassification/workRulesTimeClassification", name: "workRuleTimeClassification", permission: permissionCodes.WORK_RULES_TIME_CLASS },
        processingReProcess: { id: "5", path: "views/maintenance/processing/reProcess/reProcessWrapper/reProcessWrapper", name: "processingReProcess" },
        workRuleConsecutiveAbsence: { id: "6", path: "views/maintenance/workRules/workRulesConsecutiveAbsence/workRulesConsecutiveAbsence", name: "workRuleConsecutiveAbsence", permission: permissionCodes.WORK_RULES_ABSENCES },
        workRulesCalendarType: { id: "7", path: "views/maintenance/workRules/workRulesCalendarType/workRulesCalendarTypeList", name: "workRulesCalendarType", permission: permissionCodes.WORK_RULES_CALENDAR },
        communicationTerminal: { id: "8", path: "views/maintenance/communication/terminals/terminals", name: "communicationTerminal", permission: permissionCodes.COMUNICATION_TERMINALS },
        compParamsDefault: { id: "9", path: "views/maintenance/companyParams/defaultParams/companyParamsDefault", name: "compParamsDefault" },
        compParamsTagDef: { id: "10", path: "views/maintenance/companyParams/TagDefinition/companyParamsTagDef", name: "compParamsTagDef" },
        compParamsWEB: { id: "11", path: "views/maintenance/companyParams/WebParams/companyParamsWEB", name: "compParamsWEB" },
        accessControlSecurityGroups: { id: "12", path: "views/maintenance/accessControl/securityGroups/securityGroupsList", name: "accessControlSecurityGroups" },
        communicationMaintenance: { id: "13", path: "views/maintenance/communication/maintenance/maintenance", name: "communicationMaintenance", permission: permissionCodes.COMUNICATION_MAINTENANCE },
        compParamsReports: { id: "14", path: "views/maintenance/companyParams/ReportParams/companyParamsReports", name: "compParamsReports" },
        compParamsModules: { id: "15", path: "views/maintenance/companyParams/ModulesParams/companyParamsModules", name: "compParamsModules" },
        interfaceSalary_IO_Export: { id: "16", path: "views/maintenance/interfaces/salaryIOExport/salaryIOExport", name: "interfaceSalary_IO_Export", permission: permissionCodes.MAINTENANCE_INTERFACE_PAYROL },
        updateDateTimeTerminalPopup: { id: "17", path: "views/maintenance/communication/maintenance/controllerPopup/updateDateTimeTerminalPopup", name: "updateDateTimeTerminalPopup" },
        fingerprintPopup: { id: "18", path: "views/maintenance/communication/maintenance/controllerPopup/fingerprintPopup", name: "fingerprintPopup" },
        definingEventsPopup: { id: "19", path: "views/maintenance/communication/maintenance/controllerPopup/definingEventsPopup", name: "definingEventsPopup" },
        deleteFingerprintTemplatePopup: { id: "21", path: "views/maintenance/communication/maintenance/controllerPopup/deleteFingerprintTemplatePopup", name: "deleteFingerprintTemplatePopup" },
        terminalNetworkPropertiesPopup: { id: "21", path: "views/maintenance/communication/maintenance/controllerPopup/terminalNetworkPropertiesPopup", name: "terminalNetworkPropertiesPopup" },
        compParamsSecurity: { id: "22", path: "views/maintenance/companyParams/SecurityParams/companyParamsSecurity", name: "compParamsSecurity" },
        organization: { id: "23", path: "views/maintenance/accessControl/organization/organization", name: "organization", permission: permissionCodes.SYSTEM_DEFINITIONS_ORGANIZATION },
        distributionList: { id: "24", path: "views/maintenance/accessControl/distributionList/distributionList", name: "distributionList" },
        compParamsCommunication: { id: "25", path: "views/maintenance/communication/communicationParams/communicationParam", name: "compParamsCommunication", permission: permissionCodes.COMUNICATION_PARAMETERS },
        eventsDefinition: { id: "26", path: "views/maintenance/accessControl/eventsDefinition/eventsDefinitionList", name: "eventsDefinition" },
        workRuleLawEvents: { id: "27", path: "views/maintenance/workRules/workRulesLawEvents/lawEventsList", name: "workRuleLawEvents", permission: permissionCodes.WORK_RULES_LAW_EVENTS },
        globalParametersGeneral: { id: "28", path: "views/maintenance/globalParameters/general/general", name: "globalParametersGeneral", permission: permissionCodes.GLOBAL_PARAMS_GENERAL },
        globalParametersModules: { id: "29", path: "views/maintenance/globalParameters/modules/modules", name: "globalParametersModules", permission: permissionCodes.GLOBAL_PARAMS_MODULES },
        globalParametersPipDefinitions: { id: "30", path: "views/maintenance/globalParameters/pipDefinitions/pipDefinitions", name: "globalParametersPipDefinitions", permission: permissionCodes.GLOBAL_PARAMS_PIP_DEFINITIONS },
        globalParametersSecurity: { id: "31", path: "views/maintenance/globalParameters/security/security", name: "security", permission: permissionCodes.GLOBAL_PARAMS_SECURITY },
        auditTrail: { id: "32", path: "views/maintenance/auditTrail/auditTrail", name: "auditTrail", permission: permissionCodes.SYSTEM_DEFINITIONS_AUDIT },
        userProfile: { id: "33", path: "views/maintenance/systemSettings/userProfile/userProfile", name: "userProfile", permission: permissionCodes.SYSTEM_DEFINITIONS_USER_PROFILE },
        costCenter: { id: "34", path: "views/maintenance/systemSettings/costCenter/costCenterMain", name: "costCenter", permission: permissionCodes.MENU_COST_CENTER },
        meals: { id: "35", path: "views/maintenance/systemSettings/meals/mealsMain", name: "meals", permission: permissionCodes.SYSTEM_DEFINITIONS_MEALS },
        IO_interfaces: { id: "36", path: "views/maintenance/interfaces/IO_interfacesA/IO_interfacesMain", name: "IO_interfaces", permission: permissionCodes.MAINTENANCE_IO_INTERFACE },
        templateDefinition: { id: "37", path: "views/maintenance/systemSettings/templateDefinition/templateDefinition", name: "templateDefinition" },
        dictTranslation: { id: "38", path: "views/maintenance/systemSettings/dictTranslation/dictTranslation", name: "dictTranslation" }, // lyn 05.07.2016
        Notifier: { id: "39", path: "views/maintenance/communication/Notifier/NotifierMain", name: "Notifier", permission: permissionCodes.COMUNICATION_NOTIFIER },
        qualificationsParams: { id: "40", path: "views/maintenance/scheduling/qualifications/qualificationsParams/qualificationsParams", name: "qualificationsParams", permission: permissionCodes.MAINTENANCE_SCHEDULING_QUALIFICATION }, 
        jobCode: { id: "41", path: "views/maintenance/scheduling/jobCode/jobCode", name: "jobCode", permission: permissionCodes.MAINTENANCE_SCHEDULING_JOB_CODE },
        closingCurrentPeriod: { id: "42", path: "views/maintenance/processing/period/closingCurrentPeriod", name: "closingCurrentPeriod", permission: permissionCodes.MAINTENANCE_CLOSING_PERIOD },
        Scheduler: { id: "43", path: "views/maintenance/systemSettings/Scheduler/SchedulerMain", name: "Scheduler", permission: permissionCodes.SYSTEM_DEFINITIONS_SCHEDULER },
        Queues: { id: "44", path: "views/maintenance/systemSettings/Queues/queuesParametersMain", name: "Queues", permission: permissionCodes.SYSTEM_DEFINITIONS_QUEUES },
        jobsAutomation: { id: "45", path: "views/maintenance/systemSettings/jobsAutomation/jobsAutomation", name: "jobsAutomation", permission: permissionCodes.SYSTEM_DEFINITIONS_MENU },
        payrollParams: { id: "46", path: "views/maintenance/payroll/companyDetails/prPayrollParams", name: "prPayrollParams", permission: permissionCodes.MAINTENANCE_PAYROL_COMPANY_DETAILS },
        approvingManager: { id: "47", path: "views/maintenance/systemSettings/approvingManager/approvingManagerDef", name: "approvingManager", permission: permissionCodes.SYSTEM_DEFINITIONS_APPROVINGMANAGER },
        employerDetails: { id: "48", path: "views/maintenance/payroll/employerDetails/employerDetails", name: "employerDetails", permission: permissionCodes.MAINTENANCE_PAYROL_EMPLOYER_DETAILS } 
    };

    //=================================== enums for report page view ============================

    var reportModule = {
        1: {
            parametersDateParam: 1,
            parametersFormatParam: 1
        },
        2: 2
    };

    var reportDateArea = {
        parametersDateRange: {
            loadModule: function createParametersDateRange(observableField) {
                var module;
                require(['views/report/dateArea/parametersDateRange'], function createDateRangeInstance(moduleVM) {
                    observableField(new moduleVM());
                });
            }
        },
        parametersDateAdvanced: {
            loadModule: function createParametersDateAdvanced(observableField) {
                var module;
                require(['views/report/dateArea/parametersDateAdvanced'], function createDateAdvancedInstance(moduleVM) {
                    observableField(new moduleVM());
                });
            }
        },
        parametersDateTimeRange: {
            loadModule: function createParametersDateTimeRange(observableField) {
                var module;
                require(['views/report/dateArea/parametersDateTimeRange'], function createDateTimeRangeInstance(moduleVM) {
                    observableField(new moduleVM());
                });
            }
        },
        parametersDateYear: {
            loadModule: function createParametersDateYear(observableField) {
                var module;
                require(['views/report/dateArea/parametersDateYear'], function createDateYearInstance(moduleVM) {
                    observableField(new moduleVM());
                });
            }
        }
    };

    var reportFormatArea = {
        parametersReportFormat: {
            loadModule: function createParametersReportFormat(observableField) {
                var module;
                require(['views/report/formatArea/parametersReportFormat'], function createFormatInstance(moduleVM) {
                    observableField(new moduleVM());
                });
            }
        }
    };

    var conditionsTypes = {
        full: 'full',
        empty: 'empty',
        trueVal: 'trueVal',
        falseVal: 'falseVal',
        fullAndNotZeroTime: 'fullAndNotZeroTime',
        equalToVal: 'equalToVal',
        notEqualToVal: 'notEqualToVal',
        companyPreference: 'companyPreference',
        companyParam: 'companyParam'
    };

    var validateType = conditionsTypes;

    //=================================== end enums for report page view============================

    var colors = {
        0: "transparent",
        3: "#FF5555",//red
        1: "#7FD88B",//green
        2: "#F1EF54",//yellow
        4: "#90EE90",//light green
        5: "#d3d3d3",//gray
    };

    var comboTemplates = {
        codeDescript: 'codeDescript',
        descriptOnly: 'descriptOnly',
        codeOnly: 'codeOnly'
    };

    var IconcomboTemplates = {
        IconcodeDescript: 'IconcodeDescript',
        codeDescript: 'codeDescript',
        descriptOnly: 'descriptOnly',
        codeOnly: 'codeOnly'
    };

    var mngAttendFrames = {
        mngGrid: { id: 1, name: 'mngGrid', mode: 'manager' },
        scheduler: { id: 2, name: 'scheduler', mode: 'employee' }
    };

    var gridTypes = {
        manuallyUpdate: { id: 0 },
        groupUpdate: { id: 1 },
        managerApprovalEmpRequest: { id: 2 },
        managerApprovalReport: { id: 3 },
        ProcessesAppr: { id: 4 } // 26.08.2018
    };

    var AttachmentCategoty =
    {
        General: { id: 1, name: "General" },
        Form101: { id: 2, name: "Form101" },
        Visitors: { id: 3, name: "Visitors" },
        Processes: { id: 6, name: "Processes" }, // 08.01.2019 Lyn
    };
    var AttachmentCategotyLvl =
    {
        Form101: { id: 1, name: "Form101" },
        UnitB: { id: 2, name: "UnitB" },
        UnitC: { id: 3, name: "UnitC" },
        UnitD: { id: 4, name: "UnitD" },
        UnitE: { id: 5, name: "UnitE" },
        UnitF: { id: 6, name: "UnitF" },
        UnitG: { id: 7, name: "UnitG" },
        UnitH: { id: 8, name: "UnitH" },
        UnitI: { id: 9, name: "UnitI" },
        UnitJ: { id: 10, name: "UnitJ" },
    };

    var AttachmentFormat =
    {
        Other: { id: 1, name: "Other" },
        "application/pdf": { id: 2, name: "PDF" },
        "application/vnd.ms-word": { id: 3, name: "DOC" },
        "image/gif": { id: 4, name: "IMAGE-GIF" },
        "image/png": { id: 5, name: "IMAGE-PNG" },
        "image/jpeg": { id: 6, name: "IMAGE-JPEG" },
        "application/rtf": { id: 7, name: "RTF" }
    };

    var AttachmentFileExtension = {
        pdf: { id: 1, name: "PDF", format: "application/pdf" },
        png: { id: 2, name: "IMAGE-PNG", format: "image/png" },
        jpg: { id: 3, name: "IMAGE-JPEG", format: "image/jpeg" },
        jpeg: { id: 4, name: "IMAGE-JPEG", format: "image/jpeg" },
        gif: { id: 5, name: "gif", format: "image/gif" },
        docx: { id: 5, name: "DOC", format: "application/vnd.ms-word" } // 16.01.2019

    };

    var AttachmentType =
    {
        Other: { id: 1, name: "Other" },
        IdentityCard: { id: 2, name: "IdentityCard" },
        MarriageCertificate: { id: 3, name: "MarriageCertificate" },
        DivorceCertificate: { id: 4, name: "DivorceCertificate" },
        BirthCertificate: { id: 5, name: "BirthCertificate" },
        DeathCertificate: { id: 6, name: "DeathCertificate" },
        OtherProceedsCertificate: { id: 9, name: "OtherProceedsCertificate" },

        NewEmployeeTemplate: { id: 1017, name: "NewEmployeeTemplate" },//kivunim
        PayRollCheck: { id: 1018, name: "PayRollCheck" },
        Form101SignatureImg: { id: 1019, name: "Form101SignatureImg" },//used for Comda Sign
    };

    var form101status =
    {
        New: 0,
        Edit: 1,
        WatingToAccountManager: 2,
        RejectedByAccountManager: 3,
        ConfirmByAccountManager: 5,
        SignedByelectronicSignature: 6,
        FinalConfirmByUser: 7,
        NotAllreadyFill: 10
    };

    var signingForm101Status =
    {
        Success: 0,
        NotRegisteredOTP: 1,
        NoLicenseSAPI: 2,
        FailedSigningBySAPI: 3,
    };

    //ARX Cosign -1st version of 101 sign; ComSignTrust from Comdo WS, from July 2019
    var signatureDigitSW = {
        ARXCosign: { id: 1, name: "ARX Cosign", supplier: "Cosign" },
        ComdaSignTrust: { id: 2, name: "ComSignTrust", supplier: "Comda" }
    };

    var workRuleCalendarTypeScreenMode = {
        forUpdate: 'forUpdate',
        forNew: 'forNew',
        forHoliday: 'forHoliday',
        forMain: 'forMain'
    };

    var documentType = {
        report: 1,
        form101: 2,
        form106: 3,
        paycheck: 4,
        employee: 5,
        template: 6
    }

    var actionType = {        
        requestForApproval: 1,
        requestForApprovalEmp: 2,
        pendingChanges: 3,
        absence: 4,
        empContactData: 10,
        requestActualOTForApproval: 11,
        processForApproval: 12 // 22.08.2018 Lyn
    };

    orderType = {
        desc: 0,
        asc: 1,
    };

    var fileType = {
        image: "IMAGE",
        audio: "MP3",
        icon: "ICON",
        asci: "Asci",
    }
    var absenceListType = {
        manualEdit: 39,
        groupEdit: 40
    };

    var blockType = {
        shift: "shift",
        absenceShift: "absenceShift",
        shiftPart: "shiftPart",
        dayType: "dayType"
    }

    var controlType = {
        autoComplete: 'autoComplete',
        combo: 'ComboBox',
        Tcombo: "TComboBox",
        datePicker: 'DatePicker',
        PRdatePicker: 'PRdatePicker',
        timeInput: 'TimePicker',
        numricTextBox: 'numricTextBox',
        colorPickerSlider: 'colorPickerSlider',
        panel: "Panel",
        edit: "Edit",
        Labels: "2Labels",
        roundInterval: "RoundInterval",
        roundInterval2: "RoundInterval2",
        selectFile: "roundInterval2",
        block: "ParamBlock",
        checkBox: "CheckBox",
        multiSelect: "multiSelect",
        selectionFrame: "selectionFrame",
        lblEdit: "LblEditNonVisible",
        radioBtn: "RadioBtn_Edit"
    };

    var formats = {
        hoursMinutes: { format: "HH:mm", defaultValue: "00:00", isMaxTime24: true, maskFormat: "HM:SD", placeHolder: "__:__" },
        hoursMinutesSeconds: { format: "HH:mm:ss", defaultValue: "00:00:00", isMaxTime24: true, maskFormat: "HM:SD:SD", placeHolder: "__:__:__" },
        millisecondsInTime: { format: "fff:mm", defaultValue: "000:00", isMaxTime24: false, maskFormat: "MMM:SD", placeHolder: "___:__" },
        //format for total hours max value 99:99
        totalHours: { format: "ff:ff", defaultValue: "00:00", isMaxTime24: false, maskFormat: "MM:MM", placeHolder: "__:__" },
        //format time when max value 99:59
        totalHoursMinutes: { format: "ff:mm", defaultValue: "00:00", isMaxTime24: false, maskFormat: "MM:SD", placeHolder: "__:__" }
    };

    var numberForamt = {
        optionalDeciaml: "0.##",
        int: "0",
        deciaml: "0",
    }

    var controlPath = {
        combo: { path: controlType.combo, path: "views/controls/combo/combo.html" },
        TimePicker: { path: controlType.combo, path: "views/controls/timeInput/timeInput.html" },
        numricTextBox: { path: controlType.numricTextBox, path: "views/controls/numericTextBox/numericTextBox.html" }
    };

    var pathName = {
        vsOkPicPathName: "/img/accepted.png",
        vsOkSoundPath: "/mp3/SuccessBuzzer.wav",
        vsOkImagePath: "/Arm/Synergy/jpg",
        vsFailedPicPathName: "/img/rejected.png",
        vsFailedSoundPath: "/mp3/FailedBuzzer.wav",
        vsFailedImagePath: "/Arm/Synergy/jpg",
        stepImagePath: "/img/GreenLed.png",
    };

    var workRuleActions = {
        showAgrList: { Code: 1, Descript: 2671 },
        showAgrParameters: { Code: 2, Descript: 2670 }
    };

    var exceptionTypes = {
        ConnectSQL: 1,
        SQL: 2,
        Regular: 3
    };

    var getDataMode = {
        lookupMode: 1,
        queryMode: 2
    };

    var workRulePopupType = {
        payment: 1,
        timeZone: 2,
        callOnParameters: 3
    };

    var OrgTreeSearchField = {
        Region: 1,
        Factory: 2,
        Section: 3,
        Department: 4,
        WC: 5,
        EMP_NO: 6,
        EMP_NO_ONLY: 7
    }
    var globalSearchType = {
        employees: 1,
        orgTree: 2

    };

    var checkSaveNeededResult = {
        notModified: 1,
        saveDone: 2,
        saveFaild: 3,
        noSave: 4,
        cancel: 5
    }

    var responseCompanyOfPortal = {
        DT: { id: "0", name: "DT" },
        Synel: { id: "1", name: "Synel" }
    }

    var excelFormat = {
        time: 'hh:mm',
        date: "dd/MM/yyyy"
    };

    var showType = {
        hide: 0,
        disable: 1
    };

    var fileValidMessage = {
        valid: 0,
        invalidType: 1,
        invalidSize: 2,
        missing: 3
    };

    var copyFileToDestinationType = {
        compParam: 0,
        form101ExportedDataFiles: 1,
        general: 2
    }

    //helper link for coloring images
    //https://www.base64-image.de/
    var filterStatusImages = {
        1: { imagePath: null, imagesBase64Val: null },
        2: { imagePath: imagesManager.red, imagesBase64Val: "iVBORw0KGgoAAAANSUhEUgAAABIAAAATCAYAAACdkl3yAAAAAXNSR0ICQMB9xQAAAAlwSFlzAAAXEgAAFxIBZ5/SUgAAABl0RVh0U29mdHdhcmUATWljcm9zb2Z0IE9mZmljZX/tNXEAAADkSURBVDjLrZQvEoJQEMa/SPQIRCPHIBo5gseQZDQaOYKRaOQIRqORSFL8llmZnTdPBljCN8vw2B/79h/KskSoHthRxRu4fIC7iM9XvjtSacwnBino2NL2/0TomTaJguSAH1RTACv+rLHRjSAe3OZCDOz5i2y8zlKIveYAksSS/FoLom9Hm7miMTpBSuwFMapaklxvAGqhmfderYf2gzeiDtr6XlADnR8XSAomoHSDHOVDZ3taQDaDHZFkTfW0q9Nw+rMlMIXk0X0kczdnlRDyoN1PLjYFHmSt2AileyUfWuUk9PkCyBB05ZpBhcIAAAAASUVORK5CYII=" },
        3: { imagePath: imagesManager.yellow, imagesBase64Val: "iVBORw0KGgoAAAANSUhEUgAAABIAAAATCAYAAACdkl3yAAAAAXNSR0ICQMB9xQAAAAlwSFlzAAAXEgAAFxIBZ5/SUgAAABl0RVh0U29mdHdhcmUATWljcm9zb2Z0IE9mZmljZX/tNXEAAADlSURBVDjLrZQtEoNADIUjV/YIKys5BrKSI/QYRVVWVnKESmQlR6isrESiYPvCpExmZ8sAQbwJw5KPbP6oLEuKFQIdoKLv6TYM9GTh+Y53Z8infFKQAo4tbPgnQK+wLgniA3xQzQG08LNGRzeBcPBYClGw9y+y6TprIfqaI4gTC/JnKwi+HWxmikbpQlxiKwhR1ZzkegdQS5J569UCST9YI+pIWt8KakjmxwTigjHI75CjfOxsSwvwZtAj4rZUT7rax9OfrYEJJE/uI567JasEkBfscXaxCfDEa0VHyN3L+ZAqu9jnC9stmKL/qcgNAAAAAElFTkSuQmCC" },
        4: { imagePath: imagesManager.green, imagesBase64Val: "iVBORw0KGgoAAAANSUhEUgAAABIAAAATCAYAAACdkl3yAAAAAXNSR0ICQMB9xQAAAAlwSFlzAAAXEgAAFxIBZ5/SUgAAABl0RVh0U29mdHdhcmUATWljcm9zb2Z0IE9mZmljZX/tNXEAAAEJSURBVDjLrVQxEoIwELzS0idYWgKHwwcsKC19AATHV0hlaWnpEywtKX2CpaWlJRWJuSAQEJlgLBZmwrDZu9s9SNMUumACp5FYrFnhH2LuZoSkwGMkcLMVOOv75+NAEXB8SjLxDVHh7plYTnqJ6IO89TREoCPheNXV1UQx986mJBVijvdKWVPOSBK9TEWkGsu9h3FJ3TPu5UwEjpWaBv4OaMSDN5qUx/0L0MNakbQLlJ23LQ0FkB/sFXk5kPVtiUgMUH6sFcmBAdn8Dz0Ky5x1LDAuJm5WR4Ty8tP0ZJOr4GrpD5xRZCoaGPbuI8qdySqRm+Im3/PBxfYmXNFaaSmU7qV+lFNuLzXCC40bJF52TOGCAAAAAElFTkSuQmCC" },
        5: { imagePath: imagesManager.blue, imagesBase64Val: "iVBORw0KGgoAAAANSUhEUgAAABAAAAAPCAYAAADtc08vAAAAAXNSR0ICQMB9xQAAAAlwSFlzAAAXEgAAFxIBZ5/SUgAAABl0RVh0U29mdHdhcmUATWljcm9zb2Z0IE9mZmljZX/tNXEAAADKSURBVDjLY2hsbGRAxgyr3gkwbPyYAcT9DBs+7AfjjR+nM6x7V8Cw+bsEhnoUzrp3CUANz4H4Pw78HWhYBcPu/xwYBgAlluPRiI7PwwyB2VxAgmYo/jgfrBeoWQHsNGTJjR+JM2TduwAGhvXvG8jSDMHrGcAEyc6H4/sMYIJ8A/4zgEOUfAO+M0ATDLlhsB9kgAeGBDZDsImBop+MRISSmBDpn7TAfM+w+bMGalIGZhQio/Q4TDNGZoJ6xwNq0HMUGzd83A7KbOjqAbIPOv7TNW2MAAAAAElFTkSuQmCC" }
    }

    var notifSentStatusImages = {
        0: imagesManager.yellow,
        1: imagesManager.green,
        2: imagesManager.red,
        3: imagesManager.blue,
        100: null
    }

    var autoJobSentStatusImages = {
    	0: imagesManager.green,
    	1: imagesManager.red,
    	2: imagesManager.blue,
    	3: imagesManager.yellow,
    	4: imagesManager.sm_gray
    }

    var autoJobHistorySentStatusImages = {
    	0: imagesManager.green,
    	1: imagesManager.red,    
    	2: imagesManager.yellow,
    	3: imagesManager.sm_gray
    }

    var dailyPagerTypes = {
        daysInWeek: 0,
        periodInYear: 1
    }

    var payrollJobType = {
        Employee: 1,
        Pensioner: 2
    }

    var requestStatus = {
        None: 0,
        Accept: 1,
        Reject: 2
    }        

    return {
        showType: showType,
        absenceListType: absenceListType,
        workRuleCalendarTypeScreenMode: workRuleCalendarTypeScreenMode,
        permissionCodes: permissionCodes,
        companyParamNames: companyParamNames,
        companyPreferencesNames: companyPreferencesNames,
        lookupName: lookupName,
        cacheOrDb: cacheOrDb,
        hostPage: hostPage,
        cacheItems: cacheItems,
        errorSender: errorSender,
        fieldType: fieldType,
        componentType: componentType,
        OrgTreeLevel: OrgTreeLevel,
        langType: langType,
        accessType: accessType,
        errorSender: errorSender,
        selfOnlyState: selfOnlyState,
        entityState: entityState,
        SystemUsers: SystemUsers,
        configParams: configParams,
        loginError: loginError,
        events: events,
        cssPath: cssPath,
        httpPath: httpPath,
        employeeDetailsTabs: employeeDetailsTabs,
        attendanceDetailsTabs: attendanceDetailsTabs,
        costCenterDetailsTabs: costCenterDetailsTabs,
        consecutiveAbsenceDetailsTabs: consecutiveAbsenceDetailsTabs,
        balanceTrackingDetailsTabs: balanceTrackingDetailsTabs,
        cardType: cardType,
        cardStatus: cardStatus,
        showPopupMode: showPopupMode,
        employeeTabMode: employeeTabMode,
        contactDataFieldType: contactDataFieldType,
        entityStateIndicator: entityStateIndicator,
        filterEmpList: filterEmpList,
        types: types,
        manualEditMode: manualEditMode,
        manualEditType: manualEditType,
        periodType: periodType,
        attendanceGridPopupType: attendanceGridPopupType,
        sortMode: sortMode,
        sortDirection: sortDirection,
        systemParams: systemParams,
        messageType: messageType,
        btnsMode: btnsMode,
        customMsgWindowResult: customMsgWindowResult,
        dialogCloseResult: dialogCloseResult,
        cacheMode: cacheMode,
        formId: formId,
        selectionFrameFormId: selectionFrameFormId,
        paymentRuleType: paymentRuleType,
        lookupExtraField: lookupExtraField,
        dailyReportingMode: dailyReportingMode,
        directions: directions,
        explorerType: explorerType,
        dashboardType: dashboardType,
        gridRequestType: gridRequestType,
        exportFileType: exportFileType,
        sendEmailType: sendEmailType,
    	statusForm101Type: statusForm101Type,
        conditionsTypes: conditionsTypes,
        processType: processType,
        colors: colors,
        comboTemplates: comboTemplates,
        IconcomboTemplates: IconcomboTemplates,
        subFormCategory: subFormCategory,
        mngAttendFrames: mngAttendFrames,
        validateType: validateType,
        gridTypes: gridTypes,
        AttachmentCategoty: AttachmentCategoty,
        AttachmentCategotyLvl: AttachmentCategotyLvl,
        AttachmentType: AttachmentType,
        AttachmentFormat: AttachmentFormat,
        AttachmentFileExtension: AttachmentFileExtension,
        form101status: form101status,
        signingForm101Status: signingForm101Status,
        signatureDigitSW:signatureDigitSW,
        maintenanceViews: maintenanceViews,
        documentType: documentType,
        actionType: actionType,
        orderType: orderType,
        fileType: fileType,
        blockType: blockType,
        tableCode: tableCode,
        controlType: controlType,
        formats: formats,
        numberForamt: numberForamt,
        pathName: pathName,
        workRuleActions: workRuleActions,
        languagesShortNames: languagesShortNames,
        exceptionTypes: exceptionTypes,
        getDataMode: getDataMode,
        OrgTreeSearchField: OrgTreeSearchField,
        globalSearchType: globalSearchType,
        workRulePopupType: workRulePopupType,
        checkSaveNeededResult: checkSaveNeededResult,
        responseCompanyOfPortal: responseCompanyOfPortal,
        excelFormat: excelFormat,
        fileValidMessage: fileValidMessage,
        copyFileToDestinationType: copyFileToDestinationType,
        filterStatusImages: filterStatusImages,
        notifSentStatusImages: notifSentStatusImages,
        autoJobSentStatusImages: autoJobSentStatusImages,
        autoJobHistorySentStatusImages: autoJobHistorySentStatusImages,
        dailyPagerTypes: dailyPagerTypes,
        payrollJobType: payrollJobType,
        requestStatus: requestStatus
    };

});