﻿define(function yearsCombo(require) {

    var global = require('common/global');

    function ViewModel() {
        var yearsArr = [];
        var currentYear = new Date().getFullYear();
        var containerListElement = null;
        var comboWidthElement = null;

        function initialize(options) {
            if (!global.isNull(options)) {
                module.yearsComboId(options.id);

                if (!global.isNull(options.title)) {
                    module.title(options.title);
                }
                if (!global.isNull(options.isReadOnly)) {
                    module.isReadOnly(options.isReadOnly);
                }
                // module.lblYearClass('col-md-6 paddingRight0 organizationLevelTitle');
                if (!global.isNull(options.lblYearClass))
                    module.lblYearClass(options.lblYearClass); //'col-md-6 paddingRight0' or 'col-md-6 ColorBlack'
                if (!global.isNull(options.comboCol)) {
                    module.comboCol(options.comboCol);
                }
                if (global.isNull(options.width)) {
                    module.comboWidth('200px');
                }
                else {
                    module.comboWidth(options.width);
                }
                var minYear = global.isNull(options.minYear) ? currentYear - 5 : options.minYear;
                var maxYear = global.isNull(options.maxYear) ? currentYear + 0 : options.maxYear;
                var years = [];

                var ordType = global.isNull(options.order) ? global.enums.orderType.asc : options.order;
                if (ordType == global.enums.orderType.asc) { // asc
                    for (var year = minYear; year <= maxYear; year++) {
                        years.push({ year: year });
                    }
                }
                else {
                    for (var year = maxYear; year >= minYear; year--) {
                        years.push({ year: year });
                    }
                }
                module.dataSource = new kendo.data.DataSource({ data: years });

            }
        }

        function onChange(itemSender) {
            try {
                module.customSelectionChanged(global.isNull(this.dataItem()) ? null : this.dataItem().year);
            }
            catch (err) {
                global.treatError(err);
            }
        }

        function setDataSource(data, selectedValue) {
            var years = [];
            if (!global.isNull(data) && data.length > 0) {
                for (var y in data) {
                    years.push({ year: data[y] });
                }
            }
            module.selectedItem(global.isNull(selectedValue) ? currentYear : selectedValue);
            module.dataSource.data(years);
        }


        function compositionComplete() {
            containerListElement = $("#" + module.yearsComboId() + listBoxIdSuffix).closest(".k-list-container");
            comboWidthElement = $("#" + module.yearsComboId()).prev();

        }

        function openList() {
            try{
                if (containerListElement) {
                    containerListElement.css('minWidth', comboWidthElement.innerWidth());
                }
                else {
                    containerListElement = $("#" + module.yearsComboId() + listBoxIdSuffix).closest(".k-list-container");
                    comboWidthElement = $("#" + module.yearsComboId()).prev();
                    containerListElement.css('minWidth', comboWidthElement.innerWidth());

                }
            }
            catch (err) {
                global.treatError(err);
            }

        }
        var listBoxIdSuffix = "_listbox";

        var module = {
            yearsComboId: ko.observable("yearsComboId"),
            title: ko.observable(global.res[30]),
            comboWidth: ko.observable('200px'),
            isReadOnly: ko.observable(false),
            lblYearClass: ko.observable("col-md-4 organizationLevelTitle"),
            comboCol: ko.observable('col-md-8'),
            dataSource: new kendo.data.DataSource({ data: yearsArr }),
            valueField: 'year',
            textField: 'year',
            selectedItem: ko.observable(new Date().getFullYear()),
            initialize: initialize,
            onChange: onChange,
            customSelectionChanged: function customSelectionChanged() { },
            setDataSource: setDataSource,
            compositionComplete: compositionComplete,
            openList:openList
        };
        return module;
    }
    return ViewModel;
});
